{
   "items" : [
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.unmc.edu",
            "location" : {
               "latitude" : 40.85,
               "longitude" : -99.0417
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Nebraska Medical Center"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6127",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-18 12:38:57",
            "date_created" : "2019-09-28 01:33:51",
            "id" : 6127
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "DigitalCommons@UNMC"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Nebraska Medical Center. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://digitalcommons.unmc.edu/do/oai",
            "url" : "https://digitalcommons.unmc.edu",
            "content_subjects" : [
               "10"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 6118,
            "date_modified" : "2019-11-28 10:39:38",
            "date_created" : "2019-09-28 01:32:10",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6118"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Sheffield"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "https://www.sheffield.ac.uk/",
            "location" : {
               "longitude" : -1.4874,
               "latitude" : 53.3803
            },
            "unit" : [
               {
                  "name" : "University of Sheffield Library",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "gb"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://cdm15847.contentdm.oclc.org/oai/oai.php",
            "url" : "http://cdm15847.contentdm.oclc.org",
            "content_subjects" : [
               "20"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "value" : "contentdm",
                     "language" : "en",
                     "phrase" : "CONTENTdm"
                  }
               ]
            },
            "description" : "This site allows access to the special collections image catalog at the University of Sheffield Library.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "University of Sheffield Library Digital Collections",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "jp",
            "url" : "https://www.shimane-u.ac.jp/en",
            "location" : {
               "latitude" : 34.884,
               "longitude" : 132.078
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Shimane",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "国立大学法人 島根大学"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-06 10:39:51",
            "date_created" : "2019-09-28 01:32:02",
            "id" : 6117,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6117",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "USAGI",
                  "name" : "University of Shimane Academic and Global Institution repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "島根県立大学学術機関リポジトリ",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "description" : "This site provides access to the research outputs of University of Shimane.  The interface is available in Japanese and English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "url" : "https://ushimane.repo.nii.ac.jp",
            "oai_url" : "https://ushimane.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digitalcommons.usm.maine.edu",
            "oai_url" : "https://digitalcommons.usm.maine.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site allows access to the research output of the University of Southern Maine. Users may set up RSS feeds to be alerted to new content, both interface and content are in English only",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "University of Southern Maine: Digital Commons@USM",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 6115,
            "date_created" : "2019-09-28 01:31:56",
            "date_modified" : "2019-11-26 09:51:27",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6115",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://usm.maine.edu/",
            "location" : {
               "longitude" : -70.2756,
               "latitude" : 43.6617
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "USM",
                  "name" : "University of Southern Maine"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ],
            "name" : [
               {
                  "acronym" : "SCA Archive",
                  "name" : "Sydney College of the Arts Archive",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               }
            ],
            "description" : "This site provides access to the research outputs of the The University of Sydney, Sydney College of the Arts. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "http://va.library.usyd.edu.au",
            "content_subjects" : [
               "17"
            ],
            "oai_url" : "http://va.library.usyd.edu.au/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Sydney",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "au",
            "country_phrases" : [
               {
                  "phrase" : "Australia",
                  "language" : "en",
                  "value" : "au"
               }
            ],
            "url" : "https://sydney.edu.au",
            "unit" : [
               {
                  "name" : "University of Sydney Library",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 151.187,
               "latitude" : -33.8885
            }
         },
         "system_metadata" : {
            "id" : 6111,
            "date_modified" : "2019-11-25 10:35:45",
            "date_created" : "2019-09-28 01:31:49",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6111",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6108",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 6108,
            "date_created" : "2019-09-28 01:31:29",
            "date_modified" : "2019-11-01 15:48:44",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UTRGV",
                  "name" : "The University of Texas Rio Grande Valley",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.utrgv.edu",
            "location" : {
               "latitude" : 26.3046,
               "longitude" : -98.1742
            },
            "country" : "us"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "The University of Texas Rio Grande Valley ScholarWorks",
                  "acronym" : "UTRGV ScholarWorks",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the research outputs of The University of Texas Rio Grande Valley. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.4 SNAPSHOT",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "https://utrgv-ir.tdl.org",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://utrgv-ir.tdl.org/oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6101",
            "publicly_visible" : "yes",
            "id" : 6101,
            "date_modified" : "2019-12-04 12:27:39",
            "date_created" : "2019-09-28 01:30:48"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "https://www.washington.edu",
            "location" : {
               "latitude" : 47.6543,
               "longitude" : -122.304
            },
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "University of Washington",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "UW Tacoma Digital Commons",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://digitalcommons.tacoma.uw.edu/do/oai/",
            "url" : "https://digitalcommons.tacoma.uw.edu",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Washington.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English."
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "UWM Libraries Digital Collections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://collections.lib.uwm.edu/oai/oai.php",
            "content_subjects" : [
               "17",
               "23"
            ],
            "url" : "https://collections.lib.uwm.edu",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the digital collections at the UWM Libraries. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               }
            ]
         },
         "organisation" : {
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "UWM Libraries",
                  "name" : "University of Wisconsin Milwaukee Libraries"
               }
            ],
            "location" : {
               "latitude" : 43.075,
               "longitude" : -87.8829
            },
            "url" : "https://uwm.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Wisconsin Milwaukee",
                  "acronym" : "UWM"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:30:42",
            "date_modified" : "2019-12-04 12:27:39",
            "id" : 6099,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6099"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "University of the Sacred Heart Academic Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "聖心女子大学学術リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of the University of the Sacred Heart. The interface is available in Japanese or English but all content is Japanese only.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://u-sacred-heart.repo.nii.ac.jp/oai",
            "url" : "https://u-sacred-heart.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 139.72,
               "latitude" : 35.6513
            },
            "url" : "http://www.u-sacred-heart.ac.jp/",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of the Sacred Heart"
               },
               {
                  "name" : "聖心女子大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 01:30:38",
            "date_modified" : "2019-11-29 09:43:22",
            "id" : 6098,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6098",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6089",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-11-14 13:28:24",
            "date_created" : "2019-09-28 01:29:50",
            "id" : 6089,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "it",
            "location" : {
               "latitude" : 44.8008,
               "longitude" : 10.3259
            },
            "url" : "https://www.unipr.it/",
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "value" : "it",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "University of Parma",
                  "acronym" : "UNIPR",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "acronym" : "UNIPR",
                  "name" : "Università degli Studi di Parma",
                  "language_phrases" : [
                     {
                        "value" : "it",
                        "language" : "en",
                        "phrase" : "Italian"
                     }
                  ],
                  "language" : "it"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Parma: DSpaceUnipr"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Italian",
                        "language" : "en",
                        "value" : "it"
                     }
                  ],
                  "language" : "it",
                  "name" : "Università degli Studi di Parma: DSpaceUnipr"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Italian",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the University of Parma. The interface is available in a mixture of English and Italian but full texts are in Italian only.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "url" : "http://dspace-unipr.cineca.it",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dspace-unipr.cineca.it/dspace-oai/request",
            "content_languages" : [
               "it"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6084",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 6084,
            "date_modified" : "2019-12-04 12:27:39",
            "date_created" : "2019-09-28 01:29:42",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "de",
            "url" : "https://www.uni-mannheim.de",
            "location" : {
               "latitude" : 49.4832,
               "longitude" : 8.4647
            },
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "University of Mannheimnheim",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de",
                  "name" : "Universität Man"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universität Mannheim. Users may set up RSS feeds to be alerted to new content. The interface is available in English and German.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "version" : "3.3.16",
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://madata.bib.uni-mannheim.de",
            "oai_url" : "https://madata.bib.uni-mannheim.de/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "datasets",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Mannheim Research Data Repository",
                  "acronym" : "MADATA",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Dbis Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.15"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Rostock. Users may set up RSS feeds to be alerted to new content. The interface is available in English.\r\n\r\nLehrstuhl Datenbank- und Informationssysteme:",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://eprints.dbis.informatik.uni-rostock.de/cgi/oai2",
            "url" : "http://eprints.dbis.informatik.uni-rostock.de",
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "country" : "de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "url" : "https://www.uni-rostock.de",
            "location" : {
               "longitude" : 12.1035,
               "latitude" : 54.0755
            },
            "name" : [
               {
                  "name" : "University of Rostock",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de",
                  "name" : "Universität Rostock"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 6081,
            "date_modified" : "2019-11-25 10:22:46",
            "date_created" : "2019-09-28 01:29:38",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6081"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:39",
            "date_created" : "2019-09-28 01:29:32",
            "id" : 6077,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6077"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Kassel",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Universität Kassel",
                  "language" : "gl",
                  "language_phrases" : [
                     {
                        "phrase" : "Galician",
                        "language" : "en",
                        "value" : "gl"
                     }
                  ]
               }
            ],
            "country" : "de",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "url" : "https://www.uni-kassel.de/uni/",
            "location" : {
               "longitude" : 9.5073,
               "latitude" : 51.3227
            }
         },
         "repository_metadata" : {
            "description" : "This site gives access to the University of Kassel’s online platform for manuscripts, bequests, photographs, sheet music, periodicals, monographs and maps.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Goobi Viewer",
               "version" : "3.6.0",
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "url" : "https://orka.bibliothek.uni-kassel.de",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://orka.bibliothek.uni-kassel.de/viewer/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Open Repository Kassel",
                  "acronym" : "ORKA"
               },
               {
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universitätsbibliothek Kassel",
                  "acronym" : "ORKA"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Bordeaux",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Université de Bordeaux",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "url" : "https://www.u-bordeaux.fr/",
            "location" : {
               "latitude" : 44.8258,
               "longitude" : -0.6058
            },
            "country" : "fr"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 01:29:14",
            "date_modified" : "2019-11-14 12:15:18",
            "id" : 6074,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6074",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site gives access to selected texts and photograph collections from the University of Bordeaux. These are primary source, historical texts, rather than current research. \r\nBoth text and interface are in French only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "fr"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.babordnum.fr",
            "oai_url" : "http://www.babordnum.fr/oai-pmh-repository/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Bordeaux: BaBordNum"
               },
               {
                  "name" : "Université de Bordeaux: BaBordNum",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "value" : "fr",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "language" : "en",
                     "value" : "contentdm"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site allows access to the digital collection of the University of Montreal. The interface is available in English or French, content is a mixture of the two.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "fr"
            ],
            "oai_url" : "https://calypso.bib.umontreal.ca/oai/oai.php",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://calypso.bib.umontreal.ca",
            "name" : [
               {
                  "name" : "University of Montreal digital collections",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Université de Montréal (UdeM): Calypso - Collections d'objets numériques",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ]
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6070",
            "publicly_visible" : "yes",
            "id" : 6070,
            "date_created" : "2019-09-28 01:29:10",
            "date_modified" : "2019-12-04 12:27:39"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Montreal",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Université de Montréal",
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr"
               }
            ],
            "url" : "https://www.umontreal.ca/",
            "location" : {
               "latitude" : 45.5053,
               "longitude" : -73.6138
            },
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "country" : "ca"
         }
      },
      {
         "system_metadata" : {
            "id" : 6062,
            "date_created" : "2019-09-28 01:28:32",
            "date_modified" : "2019-11-08 14:53:34",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6062",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -91.7998,
               "latitude" : 42.8409
            },
            "url" : "https://uiu.edu/",
            "country" : "us",
            "name" : [
               {
                  "name" : "Upper Iowa University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Upper Iowa University Archives",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "17",
               "3"
            ],
            "oai_url" : "https://cdm17238.contentdm.oclc.org/oai/oai.php",
            "url" : "https://cdm17238.contentdm.oclc.org",
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "language" : "en",
                     "value" : "contentdm"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site gives access to the digital collections of images and media at Upper Iowa University. The interface is available in English, Korean, German, Spanish, simplified Chinese, Traditional Chinese, Norwegian, French, Catalan, Japanese, Thai, Turkish and Vietnamese. The text are only available in English."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 6059,
            "date_modified" : "2019-11-14 11:50:09",
            "date_created" : "2019-09-28 01:28:14",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6059"
         },
         "organisation" : {
            "location" : {
               "latitude" : 35.8903,
               "longitude" : 139.712
            },
            "url" : "http://www.urawa.ac.jp/",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "name" : "Urawa University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "浦和大学",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://urawa.repo.nii.ac.jp/oai",
            "url" : "https://urawa.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Urawa University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "浦和大学リポジトリ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6054",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-11 10:39:30",
            "date_created" : "2019-09-28 01:27:45",
            "id" : 6054
         },
         "organisation" : {
            "country" : "jp",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Hayo Junior College"
               },
               {
                  "name" : "羽陽短期大学",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "url" : "http://www.uyo.ac.jp",
            "location" : {
               "longitude" : 140.354,
               "latitude" : 38.3302
            },
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Uyo Gakuen College"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Uyo Gakuen College. The interface is available in English and Japanese.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://uyo.repo.nii.ac.jp",
            "oai_url" : "https://uyo.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "10"
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "name" : [
               {
                  "name" : "Uyo Gakuen College Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "羽陽学園短期大学リポジトリ"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-28 01:27:33",
            "date_modified" : "2019-12-04 12:27:38",
            "id" : 6048,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6048",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 48.4344,
               "longitude" : -123.473
            },
            "name" : [
               {
                  "name" : "Royal Roads University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Vancouver Island University"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of Royal Roads University and Vancouver Island University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://viurrspace.ca/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://viurrspace.ca",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "VIURRSpace",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "hk",
            "url" : "http://library.vtc.edu.hk/web",
            "country_phrases" : [
               {
                  "phrase" : "Hong Kong",
                  "value" : "hk",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "acronym" : "VTC",
                  "name" : "Vocational Training Council (VTC) libraries",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6046",
            "publicly_visible" : "yes",
            "id" : 6046,
            "date_created" : "2019-09-28 01:27:26",
            "date_modified" : "2019-12-04 12:27:38"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://repository.vtc.edu.hk",
            "oai_url" : "https://repository.vtc.edu.hk/do/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the Vocational Training Council. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "VTC Institutional Repository (Vocational Training Council)"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of the Vanderbilt University Law School. Users may set up RSS feeds to be alerted to new content, both interface and content are in English only.",
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://scholarship.law.vanderbilt.edu",
            "oai_url" : "https://scholarship.law.vanderbilt.edu/do/oai/",
            "content_subjects" : [
               "26"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Vanderbilt University Law School: Scholarship@Vanderbilt Law"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6040",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 6040,
            "date_modified" : "2019-11-26 09:26:55",
            "date_created" : "2019-09-28 01:27:17",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.vanderbilt.edu/",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Vanderbilt university law school"
               }
            ],
            "location" : {
               "latitude" : 36.148,
               "longitude" : -86.8003
            },
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Vanderbilt university"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6027",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:26:41",
            "date_modified" : "2019-12-06 09:42:42",
            "id" : 6027
         },
         "organisation" : {
            "country" : "us",
            "unit" : [
               {
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "url" : "https://www1.villanova.edu/university/law.html",
            "location" : {
               "longitude" : -75.3422,
               "latitude" : 40.0369
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Villanova University Charles Widger School of Law",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://digitalcommons.law.villanova.edu/do/oai",
            "url" : "https://digitalcommons.law.villanova.edu",
            "content_subjects" : [
               "26"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Villanova University School of Law.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Digital Repository Villanova University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Villanova University. Falvey Memorial Library: Villanova Digital Library",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "VUfind",
               "version" : "2.4.1",
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site allows access to the special collections of the Villanova University, Falvey Memorial Library. Both interface and text are in English only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://digital.library.villanova.edu",
            "oai_url" : "https://digital.library.villanova.edu/OAI/Server",
            "content_subjects" : [
               "1"
            ]
         },
         "organisation" : {
            "unit" : [
               {
                  "name" : "Falvey Memorial Library"
               }
            ],
            "url" : "https://www1.villanova.edu/university.html",
            "location" : {
               "longitude" : -75.3421,
               "latitude" : 40.0373
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Villanova university"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6026",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-28 01:26:39",
            "id" : 6026,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "VRA Online",
                  "acronym" : "VRA"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://online.vraweb.org/do/oai",
            "url" : "https://online.vraweb.org",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site is a repository for the research and intellectual output and bulletins of the Visual Resources Association (VRA) in the USA. The content has been submitted  VRA members or other information professionals and selected by the Editors of the VRA Bulletin. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "year_established" : 1982,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://vraweb.org",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "VRA",
                  "name" : "Visual Resources Association",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6015",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 6015,
            "date_created" : "2019-09-28 01:16:53",
            "date_modified" : "2019-12-04 12:27:38",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "sv"
            ],
            "oai_url" : "http://www.globalarkivet.se/cgi/oai2",
            "url" : "http://www.globalarkivet.se",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the global collection of articles gathered by the World Library, Stockholm. The interface and most of the text are in Swedish only.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Drupal",
                     "value" : "drupal",
                     "language" : "en"
                  }
               ],
               "name" : "drupal",
               "version" : "7"
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Swedish",
                  "value" : "sv",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "aggregating",
            "name" : [
               {
                  "name" : "The World Library Solidarity House",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Swedish",
                        "value" : "sv",
                        "language" : "en"
                     }
                  ],
                  "language" : "sv",
                  "name" : "Världsbiblioteket Solidaritetshuset"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6010",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 6010,
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-28 01:16:40",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "The World Library Solidarity House",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Världsbiblioteket Solidaritetshuset",
                  "language_phrases" : [
                     {
                        "value" : "sv",
                        "language" : "en",
                        "phrase" : "Swedish"
                     }
                  ],
                  "language" : "sv"
               }
            ],
            "location" : {
               "longitude" : 18.05,
               "latitude" : 59.2833
            },
            "url" : "https://www.solidaritetshuset.se/",
            "country_phrases" : [
               {
                  "value" : "se",
                  "language" : "en",
                  "phrase" : "Sweden"
               }
            ],
            "country" : "se"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ie",
                  "phrase" : "Ireland"
               }
            ],
            "location" : {
               "latitude" : 52.2531,
               "longitude" : -9.3805
            },
            "url" : "https://www.wit.ie",
            "country" : "ie",
            "name" : [
               {
                  "preferred" : "acronym",
                  "acronym" : "WIT Repository",
                  "name" : "Waterford Institute of Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 01:16:09",
            "date_modified" : "2019-11-04 16:34:21",
            "id" : 6005,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6005",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://repository.wit.ie/cgi/oai2",
            "url" : "https://repository.wit.ie",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "3.4",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Waterford Institute of Technology. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Waterford Institute of Technology - Open Access Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repository of Wakkanai Hokusei Gakuen University Library",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "稚内北星学園大学図書館リポジトリ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://wakhok.repo.nii.ac.jp/oai",
            "url" : "https://wakhok.repo.nii.ac.jp",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to discussion papers, reports and bulletins of the Wakkanai Hokusei Gakuen University in Japan  The interface is available in Japanese.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 45.382,
               "longitude" : 141.718
            },
            "url" : "http://www.wakhok.ac.jp",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "WAKHOK",
                  "name" : "Wakkanai Hokusei Gakuen University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "ja",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "WAKHOK",
                  "name" : "稚内北星学園大学"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6000",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 6000,
            "date_modified" : "2019-10-28 14:59:18",
            "date_created" : "2019-09-28 01:15:48",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "https://openscholarship.wustl.edu",
            "oai_url" : "https://openscholarship.wustl.edu/do/oai/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site allows access to the research output of the Washington University school of law. Users may set up RSS feeds to be alerted to new content. Both the interface and the content are in English only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "name" : [
               {
                  "name" : "Washington University St. Louis: Open Scholarship",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 38.6496,
               "longitude" : -90.312
            },
            "unit" : [
               {
                  "name" : "Washington University School of Law"
               }
            ],
            "url" : "https://wustl.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "name" : "Washington University in St. Louis"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5995",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-26 08:42:29",
            "date_created" : "2019-09-28 01:15:33",
            "id" : 5995
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Wayo Women's University Repository"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "name" : "和洋女子大学学術リポジトリ"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://wayo.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://wayo.repo.nii.ac.jp/oai",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of Wayo Women's University. The interface is available in Japanese or English, all content is Japanese only."
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Wayo Women's University"
               }
            ],
            "url" : "https://www.wayo.ac.jp/",
            "location" : {
               "latitude" : 35.743,
               "longitude" : 139.904
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 01:15:24",
            "date_modified" : "2019-11-29 09:28:26",
            "id" : 5993,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5993",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5990",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:15:07",
            "date_modified" : "2019-12-17 12:08:18",
            "id" : 5990
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.wtamu.edu",
            "location" : {
               "latitude" : 34.9844,
               "longitude" : -101.913
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "WTAMU",
                  "name" : "West Texas A&M University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "WTAMU DSpace Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.4"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the West Texas A&M University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://wtamu-ir.tdl.org",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://wtamu-ir.tdl.org/oai/openaire",
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 41.4,
               "longitude" : -73.4435
            },
            "url" : "https://www.wcsu.edu/",
            "name" : [
               {
                  "acronym" : "WCSU",
                  "name" : "Western Connecticut State University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-06 09:23:52",
            "date_created" : "2019-09-28 01:15:01",
            "id" : 5989,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5989"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Western Connecticut State University: WestCollections - digitalcommons@wcsu",
                  "acronym" : "WCSU"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research and outputs of Western Connecticut State University. Users may set up RSS feeds to be alerted to new content. The interface is in English only.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repository.wcsu.edu",
            "oai_url" : "https://repository.wcsu.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Digital Commons @ Western Oregon University",
                  "acronym" : "Digital Commons@WOU",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ],
               "name" : "bepress"
            },
            "description" : "This site provides access to the research outputs of Western Oregon University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://digitalcommons.wou.edu/do/oai",
            "url" : "https://digitalcommons.wou.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5988",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-11-01 15:28:16",
            "date_created" : "2019-09-28 01:14:56",
            "id" : 5988,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "WOU",
                  "name" : "Western Oregon University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "name" : "Hamersly Library",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 44.8528,
               "longitude" : -123.239
            },
            "url" : "http://www.wou.edu",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -90.1075,
               "latitude" : 29.9647
            },
            "url" : "https://www.xula.edu/",
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Xavier university of Louisiana"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5968",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 5968,
            "date_created" : "2019-09-28 01:13:39",
            "date_modified" : "2019-11-20 10:25:00",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "name" : [
               {
                  "name" : "Xavier University of Louisiana: XULA Digital Commons",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "https://digitalcommons.xula.edu",
            "oai_url" : "https://digitalcommons.xula.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site allows access to the research output of the Xavier University of Louisiana. Users may set up RSS feeds to be alerted as to new content. The interface and text are available in English only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Yamagata Public University Academic Institutional Repository"
               },
               {
                  "preferred" : "name",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "山形県公立大学法人学術機関リポジトリ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "oai_url" : "https://yone.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://yone.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of Yamagata Prefectural Public University.  The interface is available in Japanese.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Yamagata Public University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Yamagata Public University Library"
               }
            ],
            "url" : "https://www.yachts.ac.jp",
            "location" : {
               "latitude" : 38.2463,
               "longitude" : 140.35
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5967",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:13:11",
            "date_modified" : "2019-12-05 15:50:10",
            "id" : 5967
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Yamagata Prefectural University of Health Sciences Repositry"
               },
               {
                  "name" : "山形県立保健医療大学リポジトリ"
               }
            ],
            "url" : "https://yachts.repo.nii.ac.jp",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "https://yachts.repo.nii.ac.jp/oai",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the academic output of the Yamagata Prefectural University, School of health science. The interface is available in English or Japanese, but all content is Japanese only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5966",
            "publicly_visible" : "yes",
            "id" : 5966,
            "date_created" : "2019-09-28 01:13:08",
            "date_modified" : "2019-12-03 13:12:45"
         },
         "organisation" : {
            "country" : "jp",
            "url" : "https://www.yamagata-u.ac.jp/en",
            "location" : {
               "latitude" : 38.2965,
               "longitude" : 140.346
            },
            "unit" : [
               {
                  "name" : "Yamagata Prefectural University of Health Sciences"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "name" : [
               {
                  "name" : "Yamagata University"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "https://nlu.edu.ua/",
            "location" : {
               "longitude" : 36.2472,
               "latitude" : 50.005
            },
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "value" : "ua",
                  "language" : "en"
               }
            ],
            "country" : "ua",
            "name" : [
               {
                  "name" : "Yaroslav Mudryi National Law University"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5963",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 01:13:00",
            "date_modified" : "2019-11-29 09:12:08",
            "id" : 5963,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "url" : "http://dspace.nulau.edu.ua",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dspace.nulau.edu.ua/oai/openaire",
            "content_languages" : [
               "ru",
               "uk"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of Yaroslav Mudryi National Law University. The interface is available in English, Russian or Ukrainian, content is a mixture of Russian and Ukrainian.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               },
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Yaroslav the Wise National Law University Kharkiv: eNULAUIR"
               },
               {
                  "language" : "uk",
                  "language_phrases" : [
                     {
                        "phrase" : "Ukrainian",
                        "language" : "en",
                        "value" : "uk"
                     }
                  ],
                  "name" : "Національний юридичний університет імені Ярослава Мудрого"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Yasuda Women's University / College. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "oai_url" : "https://yasuda-u.repo.nii.ac.jp/oai",
            "url" : "https://yasuda-u.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Yasuda Women's University / College Academic Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja",
                  "name" : "安田女子大学リポジトリ"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "url" : "https://www.yasuda-u.ac.jp",
            "location" : {
               "latitude" : 34.4799,
               "longitude" : 132.452
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Yasuda Women's University / College"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5961",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-25 10:13:53",
            "date_created" : "2019-09-28 01:12:55",
            "id" : 5961
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Yokohama City University Repository / 横浜市立大学学術機関リポジトリ",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "gl",
                  "language" : "en",
                  "phrase" : "Galician"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Yokohama City University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Japanese.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "gl"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://ycu.repo.nii.ac.jp",
            "oai_url" : "https://ycu.repo.nii.ac.jp/oai"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "acronym",
                  "acronym" : "YCU",
                  "name" : "Yokohama City University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "url" : "https://www.yokohama-cu.ac.jp",
            "location" : {
               "latitude" : 35.334,
               "longitude" : 139.618
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5960",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:12:51",
            "date_modified" : "2019-11-04 15:38:40",
            "id" : 5960
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5959",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 5959,
            "date_created" : "2019-09-28 01:12:49",
            "date_modified" : "2019-11-07 10:40:01",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Yokohama College of Commerce",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 139.66,
               "latitude" : 35.2955
            },
            "url" : "https://www.shodai.ac.jp/"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Yokohama College of Commerce Academic Repository"
               },
               {
                  "name" : "横浜商科大学機関リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://ycc.repo.nii.ac.jp/oai",
            "url" : "https://ycc.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "version" : "3",
               "name" : "weko"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research output of the Yokohama College of Commerce. The interface is only available in Japanese."
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Information Centre for Life Sciences",
                  "acronym" : "ZBMED",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de",
                  "preferred" : "acronym",
                  "acronym" : "ZBMED",
                  "name" : "Informationszentrum Lebenswissenschaften",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "de",
            "location" : {
               "latitude" : 54.395,
               "longitude" : 2.492
            },
            "url" : "https://www.zbmed.de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-28 01:12:36",
            "id" : 5955,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5955"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "ZBMED",
                  "name" : "ZB MED - Information Centre for Life Sciences Digital Collections",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de",
                  "acronym" : "ZBMED",
                  "name" : "ZB MED - Informationszentrum Lebenswissenschaften Digitale Sammlungen"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "description" : "The site  is an open access repository to research output and media from  ZB MED - Information Centre for Life Sciences in cologne and Bonn, Germany. It is also possible to download them. Items free from copyright up to 1920 are digitized. Users may set up RSS feeds to be alerted to new content. The interface is available in German and English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "url" : "http://digital.zbmed.de",
            "oai_url" : "http://digital.zbmed.de/oai",
            "content_subjects" : [
               "2"
            ]
         }
      },
      {
         "organisation" : {
            "url" : "https://www.fredhutch.org/en.html",
            "location" : {
               "latitude" : 47.6272,
               "longitude" : -122.331
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "Fred Hutch"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-08 13:54:57",
            "date_created" : "2019-09-28 01:11:35",
            "id" : 5942,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5942"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "datasets",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "authors@Fred Hutch",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://authors.fhcrc.org",
            "oai_url" : "http://authors.fhcrc.org/cgi/oai2",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to selected works in the school of cancer research as chosen by Fred Hutchinson Cancer research. The interface is only available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.14"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "UB",
                  "name" : "University of Brawijaya"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universitas Brawijaya",
                  "acronym" : "UB",
                  "language" : "id",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "language" : "en",
                        "value" : "id"
                     }
                  ]
               }
            ],
            "country" : "id",
            "location" : {
               "latitude" : -7.956,
               "longitude" : 112.615
            },
            "url" : "https://ub.ac.id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:11:32",
            "date_modified" : "2019-12-04 12:27:38",
            "id" : 5940,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5940"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "BKG",
                  "name" : "Brawijaya Knowledge Garden"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.ub.ac.id",
            "oai_url" : "http://repository.ub.ac.id/cgi/oai2",
            "content_languages" : [
               "en",
               "id"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Brawijaya in Indonesia  Users may set up RSS feeds to be alerted to new content. The interface is available in Indonesian and English. The majority of the content requires a user account login for access but there is some open access material.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.15"
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "fr",
               "de"
            ],
            "oai_url" : "https://www.dilibri.de/oai",
            "url" : "https://www.dilibri.de",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "Dilibri is the digitized collection of regional studies literature related to Rhineland-Palatinate and of imprints preserved at Rhineland-Palatine libraries. \r\nThe interface is available in English, German or French with the manuscripts being a mixture of French and German.",
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Dilibri",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "dilibri (Landesbibliothekszentrum Rheinland-Pfalz)",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 01:11:14",
            "date_modified" : "2019-12-03 12:02:05",
            "id" : 5936,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5936",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "National Library Center Rhineland-Palatinate",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Landesbibliothekszentrum Rheinland-Pfalz",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "country" : "de",
            "url" : "https://lbz.rlp.de/de/startseite/",
            "location" : {
               "longitude" : 8.6831,
               "latitude" : 50.1311
            },
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "e-rara.ch (ETH Zürich)"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://www.e-rara.ch/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://www.e-rara.ch",
            "content_languages" : [
               "de"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Open Repository",
                     "value" : "open_repository",
                     "language" : "en"
                  }
               ],
               "name_other" : "ETH-Library",
               "name" : "open_repository"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site is a Swiss digital library dedicated to providing free online access to rare antique Swiss books and prints.The interface is available in German, English, French or Italian but most of the antique books are in German only. Users can set up RSS feeds to be alerted to new uploads.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "ETH Zurich"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "ch",
                  "language" : "en",
                  "phrase" : "Switzerland"
               }
            ],
            "location" : {
               "latitude" : 47.3763,
               "longitude" : 8.548
            },
            "url" : "https://ethz.ch/en.html",
            "country" : "ch"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:09:14",
            "date_modified" : "2019-11-29 08:37:58",
            "id" : 5903,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5903"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "eCommons University of Dayton School of Law"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Dayton School of Law. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "oai_url" : "https://ecommons.udayton.edu/do/oai",
            "content_subjects" : [
               "26"
            ],
            "url" : "https://ecommons.udayton.edu",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "url" : "https://udayton.edu",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University Libraries"
               }
            ],
            "location" : {
               "longitude" : -84.1792,
               "latitude" : 39.7404
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Dayton"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5901",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-25 09:54:50",
            "date_created" : "2019-09-28 01:09:00",
            "id" : 5901
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://repository-tnmgrmu.ac.in",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://repository-tnmgrmu.ac.in/cgi/oai2",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.15",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Tamil Nadu Dr. M.G.R. Medical University. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Electronic Theses and Dissertations of The Tamil Nadu Dr. M.G.R. Medical University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country" : "in",
            "url" : "https://tnmgrmu.ac.in",
            "location" : {
               "longitude" : 80.2182,
               "latitude" : 13.0099
            },
            "country_phrases" : [
               {
                  "phrase" : "India",
                  "language" : "en",
                  "value" : "in"
               }
            ],
            "name" : [
               {
                  "name" : "Tamil Nadu Dr. M.G.R. Medical University"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5886",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 01:08:06",
            "date_modified" : "2019-11-25 09:41:30",
            "id" : 5886,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://scholar.unand.ac.id",
            "oai_url" : "http://scholar.unand.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "id"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of Andalas University. The interface is available in English but most of the articles are not.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.15",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Indonesian",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "eSkripsi Universitas Andalas",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5884",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-05 14:37:53",
            "date_created" : "2019-09-28 01:08:01",
            "id" : 5884
         },
         "organisation" : {
            "country" : "id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -0.9149,
               "longitude" : 100.46
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Andalas University"
               },
               {
                  "name" : "Universitas Andalas",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "language" : "en",
                        "value" : "id"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://edshare.gcu.ac.uk/cgi/oai2",
            "url" : "https://edshare.gcu.ac.uk",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site  is a repository of  research outputs and educational resources created by Glasgow Caledonian University. It accepts permanent resources created by GCU staff and provides a point of contact for copyright, intellectual property and licensing enquiries. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.14"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "edShare@GCU",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5880",
            "publicly_visible" : "yes",
            "id" : 5880,
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-28 01:07:34"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "name" : "Glasgow Caledonian University",
                  "acronym" : "GCU",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "location" : {
               "longitude" : -4.25016,
               "latitude" : 55.8672
            },
            "url" : "https://www.gcu.ac.uk",
            "country" : "gb"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Raden Fatah State Islamic University repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "name" : "eprint UIN Raden Fatah Palembang"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://eprints.radenfatah.ac.id/cgi/oai2",
            "url" : "http://eprints.radenfatah.ac.id",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "id"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site allows access to the research output of Raden Fatah State Islamic University. The interface is available in English but all content is in Indonesian",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5875",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-28 01:07:07",
            "date_modified" : "2019-11-25 15:57:20",
            "id" : 5875,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "https://radenfatah.ac.id/",
            "location" : {
               "latitude" : -2.9633,
               "longitude" : 104.749
            },
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "country" : "id",
            "name" : [
               {
                  "name" : "Raden Fatah State Islamic University"
               },
               {
                  "name" : "Universitas Islam Negeri Raden Fatah",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "language" : "id"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Ukrainian",
                  "value" : "uk",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "acronym" : "erKNUTD",
                  "name" : "Electronic Repository Kyiv National University of Technologies and Design",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Електронного архіву Київського національного університету технологій та дизайну",
                  "acronym" : "erKNUTD",
                  "language" : "uk",
                  "language_phrases" : [
                     {
                        "value" : "uk",
                        "language" : "en",
                        "phrase" : "Ukrainian"
                     }
                  ]
               }
            ],
            "url" : "https://er.knutd.edu.ua",
            "oai_url" : "https://er.knutd.edu.ua/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "uk"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Kyiv National University of Technologies and Design. Users may set up RSS feeds to be alerted to new content. The interface is available in English, Ukrainian and Russian.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.8",
               "name" : "dspace"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Kyiv National University of Technologies and Design",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Київського національного університету технологій та дизайну",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "uk",
                        "phrase" : "Ukrainian"
                     }
                  ],
                  "language" : "uk"
               }
            ],
            "url" : "https://knutd.edu.ua",
            "location" : {
               "longitude" : 30.537,
               "latitude" : 50.4316
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5872",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 5872,
            "date_modified" : "2019-11-18 11:19:29",
            "date_created" : "2019-09-28 01:07:01",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "version" : "4.14",
               "name_phrases" : [],
               "name_other" : "Dataverse Project"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Heidelberg University. The interface is available in German and English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://heidata.uni-heidelberg.de",
            "oai_url" : "https://heidata.uni-heidelberg.de/oai",
            "name" : [
               {
                  "acronym" : "heiDATA",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "datasets"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-04 15:27:33",
            "date_created" : "2019-09-28 01:06:59",
            "id" : 5870,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5870"
         },
         "organisation" : {
            "location" : {
               "longitude" : 8.7063,
               "latitude" : 49.4102
            },
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Competence Center Research Data"
               },
               {
                  "name" : "Kompetenzzentrum Forschungsdaten",
                  "acronym" : "KFD",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "https://www.uni-heidelberg.de/de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "country" : "de",
            "name" : [
               {
                  "name" : "Universitat Heidelberg",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Heidelberg University"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "heiDOK",
                  "name" : "Heidelberg University"
               }
            ],
            "country" : "de",
            "url" : "https://www.uni-heidelberg.de/en",
            "location" : {
               "latitude" : 49.4186,
               "longitude" : 8.6728
            },
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 01:06:58",
            "date_modified" : "2019-11-05 14:00:01",
            "id" : 5869,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5869"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output and some learning material for Heidelberg University. The interface is available in English or German.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.16",
               "name" : "eprints"
            },
            "url" : "http://archiv.ub.uni-heidelberg.de",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://archiv.ub.uni-heidelberg.de/volltextserver/cgi/oai2",
            "content_languages" : [
               "en",
               "de"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "name" : [
               {
                  "acronym" : "heiDOK",
                  "name" : "The Heidelberg Document Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "https://istardb.org",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "International Studies of Astronomy Education Research Database",
                  "acronym" : "ISTAR",
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5865",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 01:06:44",
            "date_modified" : "2019-10-28 12:26:45",
            "id" : 5865,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "iStarDB (The Astronomy Education Research Repository)",
                  "acronym" : "ISTAR"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "disciplinary",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3.3.15",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "9",
                  "language" : "en",
                  "phrase" : "Physics and Astronomy"
               }
            ],
            "description" : "This site is a collaborative repository maintained by astronomy education researchers globally. Its aim is to make astronomy education research available free of charge globally. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://istardb.org/cgi/oai2",
            "url" : "https://istardb.org",
            "content_subjects" : [
               "9"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "koara-a",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "XOOPS",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the special collections of Keio University. Both interface and content are Japanese only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://koara-a.lib.keio.ac.jp/xoonips/modules/xoonips/oai.php",
            "url" : "http://koara-a.lib.keio.ac.jp",
            "content_languages" : [
               "ja"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5858",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-28 14:30:09",
            "date_created" : "2019-09-28 01:06:19",
            "id" : 5858
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Keio University"
               },
               {
                  "name" : "慶應義塾大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "url" : "https://www.keio.ac.jp/en/",
            "location" : {
               "longitude" : 139.743,
               "latitude" : 35.6488
            },
            "country" : "jp"
         }
      },
      {
         "organisation" : {
            "country" : "id",
            "location" : {
               "latitude" : -7.7963,
               "longitude" : 109.05
            },
            "url" : "https://ugm.ac.id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "name" : [
               {
                  "name" : "Universitas Gadjah Mada",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-18 10:17:32",
            "date_created" : "2019-09-28 01:02:26",
            "id" : 5782,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5782",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Indonesian",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "name" : "Repository Universitas Gadjah Mada",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "id"
            ],
            "url" : "http://repository.ugm.ac.id",
            "oai_url" : "http://repository.ugm.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.15",
               "name" : "eprints"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universitas Gadjah Mada. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Indonesian.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "oai_url" : "http://repository.poltekkes-smg.ac.id/oai2.php",
            "url" : "http://repository.poltekkes-smg.ac.id",
            "content_subjects" : [
               "10"
            ],
            "content_languages" : [
               "id"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to medical journals from the Ministry of Health Polytechnic Semarang. The interface is available in Indonesian only",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "7 (cendana)",
               "name" : "other",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "SLiMS"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "repository.poltekkes-smg.ac.id"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-05 12:04:50",
            "date_created" : "2019-09-28 01:02:16",
            "id" : 5779,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5779"
         },
         "organisation" : {
            "country" : "id",
            "country_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesia"
               }
            ],
            "location" : {
               "longitude" : 110.438,
               "latitude" : -7.049
            },
            "url" : "http://www.poltekkes-smg.ac.id/",
            "name" : [
               {
                  "name" : "Ministry of Health Polytechnic Semarang",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "language" : "en",
                        "value" : "id"
                     }
                  ],
                  "language" : "id"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the  l’École nationale des chartes. The interface is available in French and English.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "fr"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bibnum.enc.sorbonne.fr",
            "oai_url" : "http://bibnum.enc.sorbonne.fr/oai-pmh-repository/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "language" : "en",
                        "value" : "fr"
                     }
                  ],
                  "language" : "fr",
                  "name" : "La bibliothèque numérique de l’École nationale des chartes"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "fr",
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "url" : "http://www.chartes.psl.eu",
            "location" : {
               "latitude" : 48.8488,
               "longitude" : 2.3427
            },
            "name" : [
               {
                  "name" : "École nationale des chartes",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-28 01:01:39",
            "id" : 5767,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5767",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "University of the Aegean",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language" : "el",
                  "language_phrases" : [
                     {
                        "phrase" : "Greek (modern)",
                        "value" : "el",
                        "language" : "en"
                     }
                  ],
                  "name" : "Πανεπιστήμιο Αιγαίου"
               }
            ],
            "country" : "gr",
            "location" : {
               "latitude" : 39.1,
               "longitude" : 26.55
            },
            "url" : "http://www1.aegean.gr/aegean2",
            "country_phrases" : [
               {
                  "phrase" : "Greece",
                  "language" : "en",
                  "value" : "gr"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5761",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 5761,
            "date_created" : "2019-09-28 01:01:29",
            "date_modified" : "2019-12-18 10:11:45",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "el"
            ],
            "oai_url" : "http://hellanicus.lib.aegean.gr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://hellanicus.lib.aegean.gr",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "4.2"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of the Aegean. The interface is available in English and Greek.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "el",
                  "phrase" : "Greek (modern)"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Institutional Repository Hellanicus"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "el",
                        "language" : "en",
                        "phrase" : "Greek (modern)"
                     }
                  ],
                  "language" : "el",
                  "name" : "Ιδρυματικό Αποθετήριο Hellanicus"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-28 01:00:46",
            "date_modified" : "2019-11-05 11:11:06",
            "id" : 5749,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5749",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Russian",
                        "value" : "ru",
                        "language" : "en"
                     }
                  ],
                  "language" : "ru",
                  "name" : "MOSCOW UNIVERSITY FOR THE HUMANITIES"
               }
            ],
            "country" : "ru",
            "country_phrases" : [
               {
                  "phrase" : "Russian Federation",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "url" : "http://journals.mosgu.ru",
            "location" : {
               "latitude" : 55.7299,
               "longitude" : 37.814
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Научные труды Московского гуманитарного университета",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "description" : "This site provides access to the research outputs of the MOSCOW UNIVERSITY FOR THE HUMANITIES. The interface is only available in Russian and English",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "other",
               "version" : "2.4.7.0",
               "name_other" : "Open journal systems",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ru"
            ],
            "oai_url" : "http://journals.mosgu.ru/trudy/oai",
            "url" : "http://journals.mosgu.ru",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Toyo University Repository for Academic Resources",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "東洋大学学術情報リポジトリ"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Toyo University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Japanese.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://toyo.repo.nii.ac.jp/oai",
            "url" : "https://toyo.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "id" : 5735,
            "date_created" : "2019-09-28 00:59:33",
            "date_modified" : "2019-11-04 14:20:31",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5735",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "https://www.toyo.ac.jp",
            "location" : {
               "latitude" : 35.7232,
               "longitude" : 139.75
            },
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Toyo University"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ko",
                  "language" : "en",
                  "phrase" : "Korean"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "governmental",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Korean Research Memory",
                  "acronym" : "KRM",
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "기초학문자료센터",
                  "language" : "ko",
                  "language_phrases" : [
                     {
                        "phrase" : "Korean",
                        "language" : "en",
                        "value" : "ko"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "ko"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://www.krm.or.kr/oai/oai/dp_common/OAI.jsp",
            "url" : "http://www.krm.or.kr",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the xxxxxx. Users may set up RSS feeds to be alerted to new content. The interface is available in Korean and English.",
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5731",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-28 00:59:06",
            "date_modified" : "2019-12-17 14:35:09",
            "id" : 5731,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "acronym" : "NRF",
                  "name" : "National Research Foundation of Korea",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "country" : "kr",
            "url" : "https://www.nrf.re.kr",
            "country_phrases" : [
               {
                  "phrase" : "Korea, Republic of",
                  "language" : "en",
                  "value" : "kr"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5720",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-27 18:17:25",
            "id" : 5720,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "url" : "http://www.exteriores.gob.es/Portal/en/Paginas/inicio.aspx",
            "country" : "es",
            "name" : [
               {
                  "name" : "Ministry of Foreign Affairs, European Union and Cooperation",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Ministerio de Asuntos Exteriores, Unión Europea y Cooperación",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 10043,
            "type" : "governmental",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "AECID Digital Library"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Biblioteca Digital AECID"
               }
            ],
            "oai_url" : "http://bibliotecadigital.aecid.es/bibliodig/i18n/oai/oai_bibliotecadigital.aecid.es.cmd",
            "url" : "http://bibliotecadigital.aecid.es/bibliodig/es/estaticos/contenido.cmd?pagina=estaticos/presentacion",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 1432,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site preserves and disseminates the bibliographic heritage that the library preserves on paper, along with the collections of the Hispanic Library and Islamic Library. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "software" : {
               "name_phrases" : []
            }
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_other" : "VUfind",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other",
               "version" : "6.0.1"
            },
            "description" : "This site allows access to the research output and digital collections of Philipps University of Marburg.  The interface and articles are a mixture of German and English.",
            "full_text_record_count" : 1011,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://archiv.ub.uni-marburg.de/ubfind/OAI/Server",
            "url" : "http://archiv.ub.uni-marburg.de",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Philipps University of Marburg",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de",
                  "name" : "Philipps-Universität Marburg"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 15832,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "The Philipps University of Marburg",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Philipps-Universität Marburg",
                  "language_phrases" : [
                     {
                        "phrase" : "Galician",
                        "value" : "gl",
                        "language" : "en"
                     }
                  ],
                  "language" : "gl"
               }
            ],
            "url" : "https://www.uni-marburg.de/de",
            "location" : {
               "longitude" : 8.76667,
               "latitude" : 50.8167
            },
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "country" : "de"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5714",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-27 18:08:28",
            "date_modified" : "2019-11-14 10:40:17",
            "id" : 5714,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 4120,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "St. Norbert College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "http://digitalcommons.snc.edu",
            "oai_url" : "http://digitalcommons.snc.edu/do/oai/",
            "content_subjects" : [
               "17",
               "21",
               "23"
            ],
            "full_text_record_count" : 74,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the research output of St. Norbert College. Users may set up RSS feeds to be alerted to new submissions. Both interface and content are in English only.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "url" : "https://www.snc.edu/",
            "location" : {
               "longitude" : -88.0604,
               "latitude" : 44.4489
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "St. Norbert college",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5708,
            "date_modified" : "2019-11-28 13:43:48",
            "date_created" : "2019-09-27 17:46:51",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5708"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "unit" : [
               {
                  "language" : "zh",
                  "language_phrases" : [
                     {
                        "phrase" : "Chinese",
                        "value" : "zh",
                        "language" : "en"
                     }
                  ],
                  "name" : "B.L. Fisher Library"
               }
            ],
            "url" : "https://place.asburyseminary.edu",
            "location" : {
               "longitude" : -84.6609,
               "latitude" : 37.8623
            },
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Asbury Theological Seminary"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-27 12:50:30",
            "date_modified" : "2019-12-18 10:19:59",
            "id" : 5686,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5686"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "ePlace"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 37245,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the Asbury Theological Seminary. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "full_text_record_count" : 23,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://place.asburyseminary.edu",
            "oai_url" : "http://place.asburyseminary.edu/do/oai",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 19382,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Berkeley Law Scholarship Repository"
               }
            ],
            "url" : "http://scholarship.law.berkeley.edu",
            "oai_url" : "http://scholarship.law.berkeley.edu/do/oai",
            "content_subjects" : [
               "26"
            ],
            "full_text_record_count" : 2,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Berkeley Law University of California. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://www.universityofcalifornia.edu",
            "unit" : [
               {
                  "name" : "Berkeley Law"
               }
            ],
            "location" : {
               "longitude" : -122.254,
               "latitude" : 37.8699
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "name" : "University of California",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5676,
            "date_created" : "2019-09-27 12:46:58",
            "date_modified" : "2019-11-22 16:04:05",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5676"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "ar",
                  "language" : "en",
                  "phrase" : "Argentina"
               }
            ],
            "url" : "http://www.uba.ar",
            "location" : {
               "longitude" : -58.37,
               "latitude" : -34.6
            },
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Faculty of Exact and Natural Sciences"
               },
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Facultad de Ciencias Exactas y Naturales"
               }
            ],
            "country" : "ar",
            "name" : [
               {
                  "name" : "University of Buenos Aires",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Universidad de Buenos Aires",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5675",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-27 12:46:30",
            "id" : 5675,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "name" : "The Digital Library of the FCEN",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "La Biblioteca Digital de la FCEN"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 10174,
            "description" : "This site provides access to the research outputs of the Faculty of Exact and Natural Sciences of the University of Buenos Aires. The interface is available in English and Spanish.",
            "software" : {
               "name_phrases" : []
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digital.bl.fcen.uba.ar",
            "oai_url" : "http://digital.bl.fcen.uba.ar/gsdl-282/cgi-bin/oaiserver.cgi",
            "full_text_record_count" : 3125,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Collections Numerisees - Université Rennes 2",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 301,
            "description" : "This site provides access to the collections of the Libraries of the Rennes University 2.  The interface is available in English and French.",
            "software" : {
               "name_phrases" : []
            },
            "oai_url" : "http://bibnum.univ-rennes2.fr/oai",
            "url" : "http://bibnum.univ-rennes2.fr",
            "content_subjects" : [
               "17",
               "21"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "21",
                  "language" : "en",
                  "phrase" : "Language and Literature"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "fr"
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-27 12:45:29",
            "date_modified" : "2019-12-05 15:00:58",
            "id" : 5667,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5667",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ],
                  "name" : "Universite Rennes 2"
               }
            ],
            "country" : "fr",
            "unit" : [
               {
                  "name" : "Libraries of the Rennes University 2",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "https://www.univ-rennes2.fr",
            "location" : {
               "latitude" : 48.1209,
               "longitude" : -1.70164
            },
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "oai_url" : "http://digitalcommons.bowdoin.edu/do/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcommons.bowdoin.edu",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Bowdoin College. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 1536,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Bowdoin Digital Commons"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-18 09:43:44",
            "date_created" : "2019-09-27 12:44:28",
            "id" : 5662,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5662",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Bowdoin College",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "us",
            "url" : "https://www.bowdoin.edu",
            "location" : {
               "longitude" : -69.967,
               "latitude" : 43.914
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "https://www.brandman.edu",
            "location" : {
               "longitude" : -117.767,
               "latitude" : 33.6555
            },
            "name" : [
               {
                  "name" : "Brandman University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5661",
            "publicly_visible" : "yes",
            "id" : 5661,
            "date_modified" : "2019-11-22 15:56:05",
            "date_created" : "2019-09-27 12:44:25"
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "oai_url" : "https://digitalcommons.brandman.edu/do/oai",
            "url" : "http://digitalcommons.brandman.edu",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Brandman University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 548,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Brandman Digital Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5660",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-18 15:08:46",
            "date_created" : "2019-09-27 12:44:24",
            "id" : 5660,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "House of Representatives - Palace of the National Congress",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "name" : "Camara dos Deputados - Palácio do Congresso Nacional"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "value" : "br",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -47.8682,
               "latitude" : -15.8022
            },
            "country" : "br"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://bd.camara.gov.br/oai/request",
            "content_subjects" : [
               "26"
            ],
            "url" : "http://bd.camara.gov.br",
            "software" : {
               "name" : "dspace",
               "version" : "1.8.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the House Editions, works by House technical bodies, rare and valuable works, and academic production of House of Representatives servants. Users may set up RSS feeds to be alerted to new content. The interface is available in Brazilian Portuguese and English.",
            "metadata_record_count" : 5417,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Portal of the Chamber of Deputies"
               },
               {
                  "name" : "Portal da Camara dos Deputados",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "governmental",
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5658",
            "publicly_visible" : "yes",
            "id" : 5658,
            "date_created" : "2019-09-27 12:44:20",
            "date_modified" : "2019-11-01 15:20:08"
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://law.byu.edu",
            "location" : {
               "latitude" : 40.2494,
               "longitude" : -111.645
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Brigham Young University Law School",
                  "acronym" : "BYU Law School",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the research outputs of Brigham Young University Law School. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects" : [
               "26"
            ],
            "oai_url" : "http://digitalcommons.law.byu.edu/do/oai",
            "url" : "http://digitalcommons.law.byu.edu",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "BYU Law Digital Library",
                  "name" : "Brigham Young University Law School Digital Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "metadata_record_count" : 37690
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5657,
            "date_modified" : "2019-11-08 12:11:16",
            "date_created" : "2019-09-27 12:44:11",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5657"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -76.8844,
               "latitude" : 40.9645
            },
            "url" : "https://www.bucknell.edu/",
            "name" : [
               {
                  "name" : "Bucknell University"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "metadata_record_count" : 3957,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Bucknell University"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcommons.bucknell.edu",
            "oai_url" : "http://digitalcommons.bucknell.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the research outputs of Bucknell University. Users may set up RSS feeds to be alerted to new content. The interface is available in English only.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 1174,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Commons @ CIIS",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "https://digitalcommons.ciis.edu",
            "oai_url" : "http://digitalcommons.ciis.edu/do/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the California Institute of Integral Studies. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://www.ciis.edu",
            "location" : {
               "longitude" : -122.416,
               "latitude" : 37.7745
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "California Institute of Integral Studies"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-27 12:41:46",
            "date_modified" : "2019-12-04 12:27:38",
            "id" : 5647,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5647",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5639",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 5639,
            "date_modified" : "2019-11-14 10:18:20",
            "date_created" : "2019-09-27 12:41:03",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 41.5104,
               "longitude" : -81.6087
            },
            "unit" : [
               {
                  "name" : "Case Western Reserve University School of Law"
               }
            ],
            "url" : "https://case.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Case Western Reserve University",
                  "acronym" : "CWRU",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://scholarlycommons.law.case.edu/do/oai/",
            "content_subjects" : [
               "26"
            ],
            "url" : "http://scholarlycommons.law.case.edu",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site allows access to the research output of Case Western Reserve University. Users may set up RSS feeds to be alerted to new content. Interface and text are in English only.",
            "metadata_record_count" : 10387,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Case Western Reserve University School of Law",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "CentraCare Health"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1182,
            "description" : "This site allows access to the research work of the staff of CentraCare Health. Users may set up RSS feeds to be notified for new content. Both interface and text are in English only.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://digitalcommons.centracare.com/do/oai/",
            "url" : "http://digitalcommons.centracare.com",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5638,
            "date_created" : "2019-09-27 12:40:58",
            "date_modified" : "2019-11-20 09:20:20",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5638"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Centracare",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "us",
            "url" : "https://www.centracare.com/",
            "location" : {
               "longitude" : -94.1692,
               "latitude" : 45.5743
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "value" : "ar",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -57.9798,
               "latitude" : -34.8989
            },
            "url" : "https://www.gba.gob.ar/cic",
            "country" : "ar",
            "name" : [
               {
                  "name" : "Comision de Investigaciones Cientificas",
                  "acronym" : "CIC",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-27 12:40:43",
            "date_modified" : "2019-11-08 15:25:05",
            "id" : 5634,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5634",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institutional Comisión de Investigaciones Científicas",
                  "acronym" : "CIC Digital",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 7862,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "description" : "This site provides access to the research outputs of the CIC. The interface is available in English, Spanish and Portuguese.",
            "full_text_record_count" : 3266,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://digital.cic.gba.gob.ar/oai/request",
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "https://digital.cic.gba.gob.ar"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Chicago-Kent College of Law - Illinois Institute of Technology"
               }
            ],
            "country" : "us",
            "url" : "https://www.kentlaw.iit.edu",
            "location" : {
               "latitude" : 41.8791,
               "longitude" : -87.6423
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5632",
            "publicly_visible" : "yes",
            "id" : 5632,
            "date_created" : "2019-09-27 12:40:25",
            "date_modified" : "2019-11-15 16:28:15"
         },
         "repository_metadata" : {
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the IIT Chicago-Kent College of Law. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://scholarship.kentlaw.iit.edu/do/oai",
            "url" : "http://scholarship.kentlaw.iit.edu",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Scholarly Commons @ IIT Chicago-Kent College of Law"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 7825,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5627,
            "date_modified" : "2019-11-08 11:59:07",
            "date_created" : "2019-09-27 12:40:03",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5627"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "longitude" : -71.8023,
               "latitude" : 42.2626
            },
            "url" : "https://www.clarku.edu/",
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Clark University"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Clark University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 3541,
            "description" : "This site allows access to the research output of Clark University. Users may set up RSS feeds to alert them to new content. The interface is available in English only.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "oai_url" : "http://commons.clarku.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://commons.clarku.edu",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 4
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Colorado Law Scholarly Commons"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 3068,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "description" : "This site is a repository of the William A. Wise Law Library of the University of Colorado in Boulder providing open access to scholarly resources created by that institution and its research centres. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "26"
            ],
            "oai_url" : "https://scholar.law.colorado.edu/do/oai/",
            "url" : "https://scholar.law.colorado.edu"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Colorado Boulder",
                  "acronym" : "CU",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "William A Wise Law LIbrary"
               }
            ],
            "url" : "https://www.colorado.edu",
            "location" : {
               "latitude" : 39.745,
               "longitude" : -104.983
            }
         },
         "system_metadata" : {
            "id" : 5625,
            "date_created" : "2019-09-27 12:39:04",
            "date_modified" : "2019-12-04 12:27:38",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5625",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Namur",
                  "acronym" : "UNAMUR",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "acronym" : "UNAMUR",
                  "name" : "Université de Namur",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "fr"
               }
            ],
            "location" : {
               "longitude" : 4.86,
               "latitude" : 50.466
            },
            "url" : "https://www.unamur.be",
            "country_phrases" : [
               {
                  "value" : "be",
                  "language" : "en",
                  "phrase" : "Belgium"
               }
            ],
            "country" : "be"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5610",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-27 12:37:36",
            "id" : 5610,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "metadata_record_count" : 25655,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "DIAL @ UNamur",
                  "acronym" : "UNAMUR",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 10,
            "url" : "https://dial.unamur.be/pr/UNamur",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dial.unamur.be/oai",
            "software" : {
               "name_phrases" : []
            },
            "description" : "This site provides access to the research outputs of the University of Namur in Belgium. Users may set up RSS feeds to be alerted to new content. The interface is available in English and French.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en",
               "fr"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5600",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 5600,
            "date_created" : "2019-09-27 12:36:07",
            "date_modified" : "2019-12-18 14:24:51",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "unit" : [
               {
                  "name" : "DePauw University Libraries",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "https://www.depauw.edu",
            "location" : {
               "latitude" : 39.6413,
               "longitude" : -86.8602
            },
            "country" : "us",
            "name" : [
               {
                  "name" : "DePauw University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Scholarly and Creative Work from DePauw University"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 294,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the DePauw University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://scholarship.depauw.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://scholarship.depauw.edu/do/oai",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Denison University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "https://digitalcommons.denison.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Denison University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "metadata_record_count" : 2655,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://denison.edu",
            "location" : {
               "longitude" : -82.5227,
               "latitude" : 40.074
            },
            "country" : "us",
            "name" : [
               {
                  "name" : "Denison University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-27 12:35:59",
            "date_modified" : "2019-11-01 16:14:09",
            "id" : 5598,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5598",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "url" : "https://www.uqat.ca",
            "location" : {
               "longitude" : -79.006,
               "latitude" : 48.232
            },
            "country" : "ca",
            "name" : [
               {
                  "acronym" : "UQAT",
                  "name" : "University of Quebec in Abitibi-Témiscamingue and Cégep de l'Abitibi-Témiscamingue",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "language" : "en",
                        "value" : "fr"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "fr",
                  "acronym" : "UQAT",
                  "name" : "l'Université du Québec en Abitibi-Témiscamingue et du Cégep de l'Abitibi-Témiscamingue",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5595",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-27 12:35:52",
            "date_modified" : "2019-10-28 08:51:41",
            "id" : 5595
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en",
               "fr"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "metadata_record_count" : 757,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Depositum - The Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Depositum -  Le dépôt institutionnel",
                  "language" : "fr",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 752,
            "url" : "http://depositum.uqat.ca",
            "oai_url" : "http://depositum.uqat.ca/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.15"
            },
            "description" : "This site is an institutional repository of digital archives containing scientific articles, theses, dissertations, reports, library collections etc.  produced by the University of Quebec in Abitibi-Témiscamingue and Cégep de l'Abitibi-Témiscamingue, but it also contains documents from other sources.Users may set up RSS feeds to be alerted to new content. The interface is available in French."
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ru"
            ],
            "name" : [
               {
                  "name" : "Dnipropetrovsk electronic archive National University of Railway Transport",
                  "acronym" : "eaDNURT",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 4809,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "description" : "This site provides access to the research outputs of Dnipropetrovsk National University.  Users may set up RSS feeds to be alerted to new content.  The interface is available in Russian, Ukranian & English.",
            "full_text_record_count" : 8,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://eadnurt.diit.edu.ua/oai",
            "url" : "http://eadnurt.diit.edu.ua"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5576",
            "publicly_visible" : "yes",
            "id" : 5576,
            "date_modified" : "2019-12-03 11:23:10",
            "date_created" : "2019-09-27 12:33:19"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "eaDNURT",
                  "name" : "Dnipropetrovsk National University of Railway Transport",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "ua",
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "language" : "en",
                  "value" : "ua"
               }
            ],
            "url" : "http://diit.edu.ua",
            "location" : {
               "longitude" : 35.047,
               "latitude" : 48.434
            }
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5558,
            "date_modified" : "2019-11-28 12:32:33",
            "date_created" : "2019-09-27 12:30:36",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5558"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.etsu.edu/ehome",
            "location" : {
               "longitude" : -82.3699,
               "latitude" : 36.3025
            },
            "name" : [
               {
                  "name" : "East Tennessee State University"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site allows access to the research output of  East Tennessee State University. Users can set up RSS feeds to be notified as to new submissions. Both interface and content are English only.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "oai_url" : "http://dc.etsu.edu/do/oai/",
            "url" : "http://dc.etsu.edu",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 4,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "East Tennessee State University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 9776,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "FAMU College of Law",
                  "name" : "Florida Agricultural and Mechanical University College of Law",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://law.famu.edu",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "FAMU Law Library"
               }
            ],
            "location" : {
               "longitude" : -81.3833,
               "latitude" : 28.5448
            },
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5536",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-27 12:26:57",
            "date_modified" : "2019-12-18 10:37:30",
            "id" : 5536
         },
         "repository_metadata" : {
            "metadata_record_count" : 633,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Scholarly Commons @ FAMU Law",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1,
            "content_subjects" : [
               "1"
            ],
            "url" : "https://commons.law.famu.edu",
            "oai_url" : "http://commons.law.famu.edu/do/oai",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the Florida Agricultural and Mechanical University College of Law. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_subjects" : [
               "26"
            ],
            "oai_url" : "http://ecollections.law.fiu.edu/do/oai",
            "url" : "http://ecollections.law.fiu.edu",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 12,
            "description" : "This site is a permanent, open access archive of scholarly legal materials produced by the  Law Faculty and students of Florida International University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 1923,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Florida International University College of Law",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.fiu.edu",
            "location" : {
               "longitude" : -80.374,
               "latitude" : 25.757
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "FIU",
                  "name" : "Florida International University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5535",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-25 15:30:18",
            "date_created" : "2019-09-27 12:26:57",
            "id" : 5535
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site allows access to the research output of Florida State University. Users may set up RSS feeds to be alerted to new content. Interface and text are in English only.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_subjects" : [
               "26"
            ],
            "url" : "http://ir.law.fsu.edu",
            "oai_url" : "http://ir.law.fsu.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Florida State University College of Law"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2410,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5534",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-14 10:02:18",
            "date_created" : "2019-09-27 12:26:56",
            "id" : 5534
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Florida State University",
                  "acronym" : "FSU"
               }
            ],
            "country" : "us",
            "url" : "https://www.fsu.edu/",
            "unit" : [
               {
                  "name" : "College of Law",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 30.4392,
               "longitude" : -84.2849
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Fort Hays State University. Users may set up RSS feeds to be alerted to new content.  The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "oai_url" : "http://scholars.fhsu.edu/do/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://scholars.fhsu.edu",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "FHSU Scholars Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 8242
         },
         "system_metadata" : {
            "date_modified" : "2019-12-05 14:45:47",
            "date_created" : "2019-09-27 12:26:45",
            "id" : 5532,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5532",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Fort Hays State University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 38.8733,
               "longitude" : -99.3433
            },
            "url" : "https://www.fhsu.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         }
      },
      {
         "organisation" : {
            "country" : "de",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "latitude" : 47.999,
               "longitude" : 7.8421
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de",
                  "name" : "Baden-Wurttemberg"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5529",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-11-20 11:58:47",
            "date_created" : "2019-09-27 12:26:36",
            "id" : 5529,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "description" : "This site provides access to the research outputs of the Baden-Württemberg. Users may set up RSS feeds to be alerted to new content. The interface is available in English and German.",
            "full_text_record_count" : 23,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://opus4.bsz-bw.de/mhfr/oai",
            "url" : "https://opus4.bsz-bw.de",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Bibliotheksservice-Zentrum Baden-Württemberg",
                  "acronym" : "BSZ",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ]
               },
               {
                  "name" : "Library Service Centre Baden-Wurttemberg",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "aggregating",
            "metadata_record_count" : 265,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "de"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5523,
            "date_modified" : "2019-11-01 10:05:13",
            "date_created" : "2019-09-27 12:26:12",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5523"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "longitude" : -83.4604,
               "latitude" : 33.9094
            },
            "url" : "https://www.usg.edu",
            "name" : [
               {
                  "name" : "University System of Georgia",
                  "acronym" : "USG",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "url" : "http://oer.galileo.usg.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://oer.galileo.usg.edu/do/oai",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "GALILEO Open Learning Materials brings together open educational resources throughout the University System of Georgia, including open textbooks and ancillary materials. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 381,
            "type" : "governmental",
            "name" : [
               {
                  "name" : "GALILEO Open Learning Materials",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "learning_objects"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Salamanca",
                  "acronym" : "USAL",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "es",
            "url" : "https://www.usal.es",
            "location" : {
               "longitude" : -5.6676,
               "latitude" : 40.9616
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5517",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-27 12:25:48",
            "date_modified" : "2019-12-05 14:38:43",
            "id" : 5517
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Salamanca.  The interface is available in Spanish and English.",
            "software" : {
               "version" : "5.10",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://gredos.usal.es",
            "oai_url" : "http://gredos.usal.es/oai",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 2770,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Gestion del Repositorio Documental de la Universidad de Salamanca",
                  "acronym" : "GREDOS"
               },
               {
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 112362
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 14520,
            "type" : "governmental",
            "name" : [
               {
                  "name" : "Aragon Virtual Library",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Biblioteca Virtual de Aragon",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "oai_url" : "http://bibliotecavirtual.aragon.es/i18n/oai/oai.cmd",
            "content_subjects" : [
               "18",
               "1"
            ],
            "url" : "http://bibliotecavirtual.aragon.es",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 4703,
            "description" : "This site provides access to the bibliographic heritage of the Aragón library network. It also aims to be an institutional repository, collecting digital publications from its different Departments. It is especially oriented to the digitalization of public domain works. From the beginning to the present, the digitalization of Aragonese-themed works, of Aragonese authors or those linked to the Community.\r\n\r\n\r\nUsers may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "software" : {
               "name_phrases" : []
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ca",
                  "phrase" : "Catalan"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Esperanto",
                  "language" : "en",
                  "value" : "eo"
               },
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               },
               {
                  "phrase" : "Italian",
                  "value" : "it",
                  "language" : "en"
               },
               {
                  "phrase" : "Latin",
                  "value" : "la",
                  "language" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "ca",
               "en",
               "eo",
               "fr",
               "it",
               "la",
               "es"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "value" : "18",
                  "language" : "en"
               },
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "unit" : [
               {
                  "name" : "The Aragon Library",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Biblioteca de Aragón"
               }
            ],
            "url" : "https://www.aragon.es",
            "location" : {
               "latitude" : 41.6563,
               "longitude" : -0.8765
            },
            "name" : [
               {
                  "name" : "Government of Aragon",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Gobierno de Aragon",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5514,
            "date_created" : "2019-09-27 12:25:32",
            "date_modified" : "2019-12-04 12:27:38",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5514"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Governors State University"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -87.7165,
               "latitude" : 41.4481
            },
            "url" : "https://www.govst.edu/"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-27 12:25:25",
            "date_modified" : "2019-11-28 12:17:53",
            "id" : 5513,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5513"
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://opus.govst.edu/do/oai/",
            "url" : "http://opus.govst.edu",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "description" : "This site allows access to the research output of Governors State University Chicago. Users may set up RSS feeds to be alerted to new submissions. Both interface and content is in English only.",
            "metadata_record_count" : 10565,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Governors State University"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5506",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-18 09:52:59",
            "date_created" : "2019-09-27 12:24:58",
            "id" : 5506,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "SLUB",
                  "name" : "Sächsische Landesbibliothek - Staats- und Universitätsbibliothek Dresden (SLUB)",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "de"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "SLUB",
                  "name" : "Saxon State and University Library Dresden"
               }
            ],
            "location" : {
               "latitude" : 51.028,
               "longitude" : 13.7366
            },
            "url" : "https://www.slub-dresden.de",
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "country" : "de"
         },
         "repository_metadata" : {
            "type" : "aggregating",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Qucosa"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 30288,
            "description" : "This is a repository for a number of independent repositories. The interface is available in German and English.",
            "software" : {
               "name_phrases" : []
            },
            "url" : "http://www.qucosa.de/startseite",
            "content_subjects" : [
               "2",
               "24"
            ],
            "oai_url" : "http://hsss.slub-dresden.de/oai/OAI-2.0",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_other" : "Cloudflare",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "This site is a a repository for the scholarship, publications, archives, and creative works of the community at Harding University, Arkansas, USA. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 4,
            "oai_url" : "http://scholarworks.harding.edu/do/oai/",
            "url" : "http://scholarworks.harding.edu",
            "content_subjects" : [
               "22",
               "2",
               "24",
               "25"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Scholar Works at Harding",
                  "acronym" : "HARDING",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 4,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "notes" : "Other special items include: scrapbooks, university bulletins, oral histories and theatre programs & posters",
            "content_subjects_phrases" : [
               {
                  "value" : "22",
                  "language" : "en",
                  "phrase" : "Philosophy and Religion"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "value" : "25",
                  "language" : "en",
                  "phrase" : "Education"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5505",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:27:38",
            "date_created" : "2019-09-27 12:24:41",
            "id" : 5505,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "HARDING",
                  "name" : "Harding University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 35.249,
               "longitude" : -91.7262
            },
            "url" : "https://www.harding.edu"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "PH Schwäbisch GmündUniversity of Education",
                  "name" : "Pädagogische Hochschule Schwäbisch GmündUniversity of Education",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "de"
               },
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "url" : "http://www.ph-gmuend.de",
            "location" : {
               "longitude" : 9.8046,
               "latitude" : 48.7994
            },
            "country" : "de"
         },
         "system_metadata" : {
            "id" : 5487,
            "date_created" : "2019-09-27 12:23:49",
            "date_modified" : "2019-12-05 14:28:28",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5487",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Publication Server of PH Schwäbisch Gmünd"
               },
               {
                  "preferred" : "name",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "name" : "Nserver der PH Schwäbisch Gmünd",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 39,
            "description" : "This site provides access to the research outputs of the University of Education. Users may set up RSS feeds to be alerted to new content. The interface is available in English and German.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "OPUS",
                     "value" : "opus",
                     "language" : "en"
                  }
               ],
               "name" : "opus",
               "version" : "4"
            },
            "oai_url" : "https://phsg.bsz-bw.de/oai",
            "url" : "https://phsg.bsz-bw.de",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 2
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-11-28 12:01:21",
            "date_created" : "2019-09-27 12:23:42",
            "id" : 5483,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5483",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "url" : "https://www.global.hokudai.ac.jp/",
            "location" : {
               "latitude" : 43.0775,
               "longitude" : 141.34
            },
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "name" : "Hokkaido University"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Hokkaido University Collection of Scholarly and Academic Papers",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 62401,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "description" : "This site allows access to the research output of Hokkaido University. The  interface is either in English or Japanese, all content is Japanese.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 69,
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.lib.hokudai.ac.jp",
            "oai_url" : "http://eprints.lib.hokudai.ac.jp/dspace-oai/request",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "ja"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "id",
            "location" : {
               "latitude" : -2.2311,
               "longitude" : 113.889
            },
            "url" : "http://www.iain-palangkaraya.ac.id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Isntitut Agama Islam Negeri Palangka Raya",
                  "acronym" : "IAIN Palangka Raya",
                  "preferred" : "acronym",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "language" : "en",
                        "value" : "id"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 5478,
            "date_modified" : "2019-11-01 10:31:33",
            "date_created" : "2019-09-27 12:22:13",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/5478"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Library IAIN Palangka Raya"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1537,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.16",
               "name" : "eprints"
            },
            "description" : "This site provides access to the research outputs of the Isntitut Agama Islam Negeri Palangka Raya. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1442,
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digilib.iain-palangkaraya.ac.id",
            "oai_url" : "http://digilib.iain-palangkaraya.ac.id/cgi/oai2",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      }
   ]
}

