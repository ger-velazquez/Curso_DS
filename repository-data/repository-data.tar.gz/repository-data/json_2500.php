{
   "items" : [
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3249,
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2015-03-19 15:11:27",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3249"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -71.1103,
               "latitude" : 42.4249
            },
            "unit" : [
               {
                  "name" : "Tisch Library",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.tufts.edu/",
            "country" : "us",
            "name" : [
               {
                  "name" : "Tufts University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Tufts Digital Library"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "datasets",
               "other_special_item_types"
            ],
            "metadata_record_count" : 5248,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "fedora",
                     "language" : "en",
                     "phrase" : "Fedora"
                  }
               ],
               "name" : "fedora"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "The Tufts Digital Library is the result of a collaboration between Digital Collections and Archives (DCA) and Tufts Technology Services Educational and Scholarly Technology Services (ESTS). TDL collections support teaching and research at Tufts University and feature digital resources created by members of the Tufts community of enduring value. Not all materials in the TDL are made available to the public. While many resources in the TDL are part of the DCA’s permanent collections, some are stored under the terms of our long-term storage services",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://dl.tufts.edu/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_requirements" : [
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "not_for_profit_purposes"
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Instituto Peruano de Energía Nuclear",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : -12.0945,
               "longitude" : -77.0602
            },
            "url" : "http://www.ipen.gob.pe/",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:54",
            "date_created" : "2015-03-19 15:01:04",
            "id" : 3248,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3248",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "http://dspace.ipen.gob.pe/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "The Digital Repository of the Peruvian Nuclear Energy Institute - IPEN aims at preservation and dissemination, open access scientific production of the institution and its researchers, postgraduate students, trainees, guest researchers, etc. not only in order to improve visibility and national indicators in S & T, but also as a platform to support nuclear knowledge management. The IPEN in accordance with applicable law recognizes copyright; for that reason, the material published in this repository has the consent of the authors and editors, with some restrictions and can only be used for purposes of disclosure, non-commercial use and may not be modified without permission of the authors.",
            "metadata_record_count" : 620,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositorio Digital del IPEN",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional"
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3247",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3247,
            "date_created" : "2015-03-19 14:35:52",
            "date_modified" : "2019-12-04 12:27:32",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Leon",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "url" : "https://www.unileon.es/",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Fundación Antonio Pereira",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 42.5987,
               "longitude" : -5.5671
            }
         },
         "repository_metadata" : {
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "language" : "en",
                     "value" : "greenstone"
                  }
               ]
            },
            "description" : "This is the Digital Archive of the Antonio Pereira Foundation which provides free access to thousands of documents (newspaper articles, awards, stories, poems, essays, correspondence, proofs, photos, ) about the writer Antonio Pereira.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "21"
            ],
            "oai_url" : "http://193.146.101.123:8383/greenstone3/oaiserver",
            "url" : "http://cabila.unileon.es:8383/greenstone3/library",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "cabila",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 109,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "year_established" : 2014,
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3246",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3246,
            "date_created" : "2015-03-19 14:13:21",
            "date_modified" : "2019-12-04 12:27:32",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "uy",
            "country_phrases" : [
               {
                  "phrase" : "Uruguay",
                  "language" : "en",
                  "value" : "uy"
               }
            ],
            "url" : "http://www.presidencia.gub.uy/",
            "location" : {
               "longitude" : -56.1995,
               "latitude" : -34.9071
            },
            "name" : [
               {
                  "name" : "Presidencia de la Republica",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "notes" : "La coleccion digital Prensa abarca archivos de texto, video y audio de prensa producida por medios de comunicacion y agencias de prensa de varios paises acerca de lo ocurrido durante el periodo dictatorial de la decada de los 70 y 80 en America Latina y sus repercusiones hasta nuestros dias.",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "type" : "governmental",
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Presidencia de la Republica. Secretaria de Derechos Humanos para el Pasado Reciente - Coleccion digital Prensa",
                  "acronym" : "Presidency of the Republic. Human Rights Secretary for the Recent Past - Press Digital Collection",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 115102,
            "description" : "The digital collection includes Press text files, video and audio media produced by media and news agencies of several countries about what happened during the dictatorial period of the decade of the 70s and 80s in Latin America and its impact to our days.",
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "value" : "greenstone",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "19",
               "23"
            ],
            "url" : "http://prensa.sdh.gub.uy/greenstone/cgi-bin/library.cgi?site=localhost&a=p&p=about&c=prensa&l=es&w=utf-8",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 709,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "name" : "Repozytorium Wiedzy Politechniki Wrocławskiej (Knowledge Repository of the Wroclaw University of Technology)",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://repository.pwr.edu.pl/oai/oai.aspx",
            "url" : "http://repozytorium.pwr.edu.pl/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : []
            },
            "description" : "This is the Knowledge Repository, collecting and providing open access to the scientific achievements of employees, graduate students and students from the University of Wroclaw. It is an archive of electronic documents in all fields represented at the University.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "pl"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "Politechnika Wrocławska",
                  "name" : "Wroclaw University of Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "url" : "http://www.pwr.edu.pl/",
            "location" : {
               "latitude" : 51.1188,
               "longitude" : 17.0547
            },
            "country" : "pl"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3245",
            "publicly_visible" : "yes",
            "id" : 3245,
            "date_modified" : "2019-10-17 14:34:54",
            "date_created" : "2015-03-19 13:53:57"
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            }
         }
      },
      {
         "system_metadata" : {
            "id" : 3244,
            "date_created" : "2015-03-19 13:19:49",
            "date_modified" : "2019-10-17 14:34:54",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3244",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institut für Deutsche Sprache"
               }
            ],
            "country" : "de",
            "location" : {
               "longitude" : 8.466,
               "latitude" : 49.4875
            },
            "url" : "http://www1.ids-mannheim.de/",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Language and Literature",
                  "value" : "21",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "de",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "opus",
                     "phrase" : "OPUS"
                  }
               ],
               "version" : "4",
               "name" : "opus"
            },
            "description" : "This is an open Access repository for the Institute for German Language. The interface is available in German or English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://ids-pub.bsz-bw.de/oai",
            "content_subjects" : [
               "21"
            ],
            "url" : "https://ids-pub.bsz-bw.de/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Publikationsserver des Instituts für Deutsche Sprache",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5852,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 37.549,
               "longitude" : -77.4534
            },
            "url" : "http://www.vcu.edu/",
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Virginia Commonwealth University"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3243,
            "date_modified" : "2019-10-17 14:34:54",
            "date_created" : "2015-03-19 10:26:25",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3243",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy" : "undefined",
               "retention_period" : {
                  "period" : "undefined",
                  "period_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No retention period defined"
                     }
                  ]
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "link_between_versions",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "link_between_versions"
                  ]
               },
               "withdrawal" : {
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security"
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "item_page_phrases" : [
                        {
                           "language" : "en",
                           "value" : "tombstone",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ]
            }
         },
         "repository_metadata" : {
            "description" : "Scholars Compass is a publishing platform for the intellectual output of VCU’s academic, research, and administrative communities. Its goal is to provide wide and stable access to the exemplary work of VCU’s faculty, researchers, students, and staff.",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://scholarscompass.vcu.edu/",
            "oai_url" : "http://scholarscompass.vcu.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "VCU Scholars Compass",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 4942,
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "http://www.vcu.edu/",
            "location" : {
               "longitude" : -77.4534,
               "latitude" : 37.549
            },
            "country" : "us",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Virginia Commonwealth University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3242",
            "publicly_visible" : "yes",
            "id" : 3242,
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2015-03-19 10:15:49"
         },
         "repository_metadata" : {
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://dig.library.vcu.edu/cdm/",
            "oai_url" : "http://dig.library.vcu.edu/cgi-bin/oai.exe",
            "content_subjects" : [
               "18",
               "20",
               "21"
            ],
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "language" : "en",
                     "value" : "contentdm"
                  }
               ]
            },
            "description" : "These materials, primarily from VCU Libraries Special Collections and Archives, range in subject matter from African-American history in Virginia to Richmond's past and present, from the comic and cartooning arts to the history of VCU, from medical artifacts to oral histories. Collections are presented in a variety of formats, including photographs, art, text, video, and audio.",
            "metadata_record_count" : 28725,
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "VCU Libraries Digital Collections",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               },
               {
                  "phrase" : "History and Archaeology",
                  "language" : "en",
                  "value" : "20"
               },
               {
                  "phrase" : "Language and Literature",
                  "value" : "21",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-05 14:09:23",
            "date_created" : "2015-03-18 16:57:23",
            "id" : 3241,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3241"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Technology Arts Sciences",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Technische Hochschule Köln",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "country" : "de",
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "latitude" : 50.9407,
               "longitude" : 6.95991
            },
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Institute of Information Science"
               },
               {
                  "name" : "Institut für Informationswissenschaft",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "url" : "https://www.th-koeln.de/en/homepage_26.php"
         },
         "policies" : {
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "description" : "This is the institutional repository of the Institute of Information Science Cologne University of Applied Science. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "opus",
               "name_phrases" : [
                  {
                     "value" : "opus",
                     "language" : "en",
                     "phrase" : "OPUS"
                  }
               ]
            },
            "oai_url" : "http://publiscologne.fh-koeln.de/oai",
            "url" : "https://publiscologne.th-koeln.de/home",
            "content_subjects" : [
               "2"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "PubLIS Cologne - Repository of the Institute of Information Science Cologne University of Applied Science",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "name" : "PubLIS Cologne - Repositorium des Instituts für Informationswissenschaft der Fachhochschule Köln"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 646
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "dspace.funai.edu.ng",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "metadata_record_count" : 256,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of the Federal University Ndufu Alike-Ikwo",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://dspace.funai.edu.ng/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 8.1,
               "latitude" : 6.3333
            },
            "url" : "http://www.funai.edu.ng/",
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "value" : "ng",
                  "language" : "en"
               }
            ],
            "country" : "ng",
            "name" : [
               {
                  "name" : "FEDERAL UNIVERSITY NDUFU-ALIKE IKWO",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2015-03-18 16:36:22",
            "date_modified" : "2019-10-17 14:34:54",
            "id" : 3240,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3240",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1045,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "IAU Scholary Archive Database"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://acikarsiv.aydin.edu.tr/xmlui/",
            "content_languages" : [
               "tr"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This is the institutional repository of İstanbul Aydin University.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ],
            "url" : "http://www.aydin.edu.tr/index_eng.asp",
            "location" : {
               "latitude" : 28.7975,
               "longitude" : 28.7975
            },
            "country" : "tr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "İstanbul Aydin University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3239",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3239,
            "date_modified" : "2019-10-17 14:34:54",
            "date_created" : "2015-03-18 16:17:31",
            "publicly_visible" : "yes"
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "full_text_record_count" : 1420,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://harp.lib.hiroshima-u.ac.jp/hue/oai/request",
            "content_subjects" : [
               "24"
            ],
            "url" : "http://harp.lib.hiroshima-u.ac.jp/hue/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Earmas",
                     "language" : "en",
                     "value" : "earmas"
                  }
               ],
               "name" : "earmas"
            },
            "description" : "This is the institutional repository of Hiroshima University of Economics.",
            "metadata_record_count" : 1605,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Hiroshima University of Economics Academic Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "url" : "http://www.hue.ac.jp/",
            "location" : {
               "latitude" : 34.4487,
               "longitude" : 132.457
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "name" : "Hiroshima University of Economics",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3238",
            "publicly_visible" : "yes",
            "id" : 3238,
            "date_created" : "2015-03-18 16:08:03",
            "date_modified" : "2019-10-17 14:34:54"
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         }
      },
      {
         "repository_metadata" : {
            "full_text_record_count" : 816,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://ndu-rep.repo.nii.ac.jp/",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://ndu-rep.repo.nii.ac.jp/oai",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the university. The site interface is available in Japanese or English",
            "metadata_record_count" : 858,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "The Nippon Dental University Repository"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "notes" : "Only summaries of the theses are available",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3237,
            "date_created" : "2015-03-18 15:58:52",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3237"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "The Nippon Dental University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.ndu.ac.jp/",
            "location" : {
               "longitude" : 139.746,
               "latitude" : 35.6977
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Kherson State University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "ua",
            "url" : "http://www.kspu.edu/",
            "location" : {
               "latitude" : 46.6423,
               "longitude" : 32.5855
            },
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "value" : "ua",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2015-03-18 15:18:49",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3236,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3236",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "oai_url" : "http://ekhsuir.kspu.edu/oai/request?verb=Identify",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ekhsuir.kspu.edu/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "The Electronic Archive Repository of Kherson State University contains scientific publications of the academic staff and students including articles from the scientific reviews (academic periodicals), training development items (academic and methodological papers), and materials of reports and conferences; it also provides free and full-text access to materials on the Internet.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 6644,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Kherson State University Repository"
               }
            ],
            "content_languages" : [
               "ru",
               "uk",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "ru",
                  "language" : "en",
                  "phrase" : "Russian"
               },
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-18 15:09:40",
            "id" : 3235,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3235"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad de La Laguna"
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "url" : "http://www.ull.es/",
            "location" : {
               "longitude" : -16.3286,
               "latitude" : 28.4859
            }
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         },
         "repository_metadata" : {
            "description" : "The main objective of this repository is to provide the scientific and academic dissemination of ULL addition to ensuring their conservation. The collection includes scientific articles, educational materials, theses, EOG and other documents in various digital formats.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://riull.ull.es/oai/request",
            "url" : "http://riull.ull.es/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Universidad de La Laguna",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "metadata_record_count" : 7393,
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3234,
            "date_created" : "2015-03-18 14:58:50",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3234"
         },
         "organisation" : {
            "location" : {
               "longitude" : 31.9946,
               "latitude" : 46.975
            },
            "url" : "http://www.mnau.edu.ua/",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Library of Mykolayiv National Agrarian University"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Mykolayiv National Agrarian University"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            }
         },
         "repository_metadata" : {
            "content_languages" : [
               "ru",
               "uk",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               },
               {
                  "language" : "en",
                  "value" : "uk",
                  "phrase" : "Ukrainian"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://dspace.mnau.edu.ua/jspui/",
            "oai_url" : "http://dspace.mnau.edu.ua/jspui//perl/oai2",
            "content_subjects" : [
               "3",
               "4",
               "6"
            ],
            "software" : {
               "name" : "dspace",
               "version" : "1.8.2",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is the Institutional Repository Mykolayiv State Agrarian University which allows open access to the work of staff and students.",
            "metadata_record_count" : 3935,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of Mykolayiv National Agrarian University"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.repositorio.ufop.br/",
            "content_languages" : [
               "en",
               "es",
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This is the institutional repository of Universidade Federal de Ouro Preto.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 8243,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               },
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório Institucional da Universidade Federal de Ouro Preto",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3233",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-18 14:38:07",
            "id" : 3233
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universidade Federal de Ouro Preto",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "language" : "en",
                  "value" : "br"
               }
            ],
            "location" : {
               "longitude" : -43.509,
               "latitude" : -20.3982
            },
            "url" : "http://www.ufop.br/"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3232",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-18 13:19:45",
            "id" : 3232
         },
         "organisation" : {
            "country" : "hn",
            "country_phrases" : [
               {
                  "value" : "hn",
                  "language" : "en",
                  "phrase" : "Honduras"
               }
            ],
            "url" : "http://www.unah.edu.hn/",
            "name" : [
               {
                  "name" : "Universidad Nacional Autónoma de Honduras - UNAH",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "rules_phrases" : [
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "language" : "en",
                     "value" : "bibliographic_metadata_required"
                  },
                  {
                     "value" : "full_texts_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry",
                     "phrase" : "Items may not be deposited until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "url" : [
                  "http://www.tzibalnaah.unah.edu.hn/page/politicas"
               ],
               "moderation_purposes" : [
                  "author_eligibility"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "language" : "en",
                     "value" : "given_to_third_parties",
                     "phrase" : "given to third parties"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "value" : "some_items_have_different_conditions",
                     "language" : "en",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://www.tzibalnaah.unah.edu.hn/page/politicas"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "value" : "link_required",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher"
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "es",
                     "phrase" : "Spanish"
                  },
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "es",
                  "en"
               ],
               "metadata" : [
                  "publication_status"
               ],
               "url" : [
                  "http://www.tzibalnaah.unah.edu.hn/page/politicas"
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://www.tzibalnaah.unah.edu.hn/page/politicas"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "language" : "en",
                     "value" : "repository_mention_required",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse" : "allowed"
            }
         },
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "El repositorio institucional Tz'ibal Naah cuenta dentro de su contenido con tesis de grado y posgrado de la UNAH, revistas y documentos históricos de Honduras, resultados de investigaciones en áreas especificas y boletines, entre otros.\nTambién se encuentra en su contenido el diario Oficial La Gaceta, publicación que contiene todo lo relacionado a las leyes hondureñas.\nSu contenido es de acceso abierto.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "oai_url" : "http://www.tzibalnaah.unah.edu.hn:8080/oai/request",
            "url" : "http://www.tzibalnaah.unah.edu.hn/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "This is the open access repository of the National University of Honduras which allows open access to the work of staff and students.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2772,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Tz'ibal Naah",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This is the Open repository of Rzeszow University.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repozytorium.ur.edu.pl/",
            "content_languages" : [
               "pl"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repository of Rzeszow University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "metadata_record_count" : 3093,
            "content_languages_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Polish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3231",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 3231,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-18 12:24:29",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Rzeszow",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://www.ur.edu.pl/",
            "location" : {
               "latitude" : 50.0308,
               "longitude" : 22.0159
            },
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "country" : "pl"
         },
         "policies" : {
            "content_policy" : {
               "url" : [
                  "http://repozytorium.ur.edu.pl/page/regulamin"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "submission_policy" : {
               "content_embargo" : "policy_undefined",
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repozytorium.ur.edu.pl/page/regulamin"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://repozytorium.ur.edu.pl/page/regulamin"
               ],
               "closure_policy" : "undefined",
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No retention period defined"
                     }
                  ],
                  "period" : "undefined"
               },
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  },
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "method" : "undefined",
                  "policy_phrases" : [
                     {
                        "value" : "removal_not_normal",
                        "language" : "en",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal"
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "url" : [
                  "http://repozytorium.ur.edu.pl/page/regulamin"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Digital UPAO",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3497,
            "description" : "This is the thesis repository of Private University Antenor Orrego",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.upao.edu.pe/",
            "oai_url" : "http://repositorio.upao.edu.pe/oai/request?verb=Identify",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 2812,
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "notes" : "Repositorio digital de tesis de la Universidad Privada Antenor Orrego",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3230",
            "publicly_visible" : "yes",
            "date_created" : "2015-03-17 15:10:21",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3230
         },
         "organisation" : {
            "location" : {
               "latitude" : -8.1027,
               "longitude" : -79.0247
            },
            "url" : "http://www.upao.edu.pe/paginaindex.asp/",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Universidad Privada Antenor Orrego",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "standard_types_allowed" : [
                     "theses_and_dissertations"
                  ],
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "language" : "en",
                        "value" : "theses_and_dissertations",
                        "phrase" : "Theses and Dissertations"
                     }
                  ]
               }
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "oPUB",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 282,
            "description" : "This is the Repository of the University of Lower Silesia",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "oai_url" : "http://opub.dsw.edu.pl/oai/request?verb=Identify",
            "content_subjects" : [
               "25"
            ],
            "url" : "http://opub.dsw.edu.pl/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "year_established" : 2014,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pl"
            ]
         },
         "system_metadata" : {
            "id" : 3229,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-17 14:50:48",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3229",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 16.9927,
               "latitude" : 51.1149
            },
            "url" : "http://dsw.edu.pl/",
            "country" : "pl",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Lower Silesia",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "DSpace@ArtvinCoruh"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1075,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "4.0",
               "name" : "dspace"
            },
            "description" : "DSpace@ArtvinCoruh is the institutional repository of the Artvin Coruh University. The repository was established in 2014 to facilitate the deposit of digital content at the Artvin Coruh University. DSpace@ArtvinCoruh contains a growing subset of research undertaken at Artvin Coruh University including articles, presentations, theses and dissertations, book chapters, working papers and technical reports.",
            "full_text_record_count" : 2,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://openaccess.artvin.edu.tr/xmlui/",
            "oai_url" : "https://openaccess.artvin.edu.tr/oai/request",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "notes" : "DSpace@ArtvinCoruh, Artvin Çoruh Üniversitesi'nin Kurumsal Akademik Açık Erişim Sistemidir. Sistem, Artvin Çoruh Üniversitesi'nin akademik çıktılarını uluslararası standartlarda dijital ortamda depolamak ve açık erişime sunmak üzere 2014 yılında kurulmuştur. DSpace@ArtvinCoruh, Artvin Çoruh Üniversitesi büyesinde üretilen makale, sunum, tez, kitap, kitap bölümü, rapor gibi akademik çıktılarını içerir.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "tr"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3228,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-17 14:22:33",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3228"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Artvin Çoruh Üniversitesi",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "tr",
            "location" : {
               "latitude" : 41.1828,
               "longitude" : 41.8183
            },
            "url" : "http://www.artvin.edu.tr/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "patents",
               "other_special_item_types"
            ],
            "content_languages" : [
               "fr"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 161670,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Hal - Université Grenoble Alpes",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 9189,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://hal.univ-grenoble-alpes.fr/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://api.archives-ouvertes.fr/oai/saga",
            "software" : {
               "name" : "hal",
               "name_phrases" : [
                  {
                     "value" : "hal",
                     "language" : "en",
                     "phrase" : "HAL"
                  }
               ]
            },
            "description" : "This is the institutional repository of Université Grenoble Alpes."
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Université Grenoble Alpes"
               }
            ],
            "country" : "fr",
            "url" : "http://www.univ-grenoble-alpes.fr/universite-grenoble-alpes--577556.htm",
            "location" : {
               "latitude" : 45.1885,
               "longitude" : 5.7245
            },
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3227,
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2015-03-17 14:09:49",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3227",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "url" : [
                  "http://real-r.mtak.hu/policies.html"
               ],
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "some_or_all_restricted",
                     "phrase" : "Access to some or all full items is restricted"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting" : [
                  "not_allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "value" : "link_required",
                     "language" : "en"
                  },
                  {
                     "value" : "original_copyright_statement_required",
                     "language" : "en",
                     "phrase" : "the original copyright statement is given"
                  },
                  {
                     "phrase" : "the original rights permission statement is given",
                     "language" : "en",
                     "value" : "original_rights_statement_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "language" : "en",
                     "value" : "content_not_changed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "mentioning_the_repository_is_appreciated"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "not_allowed",
                     "language" : "en",
                     "phrase" : "Not Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "No retention period defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "period" : "undefined"
               },
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  },
                  "method_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No deletion method for withdrawn items defined"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "No withdrawal policy defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "method" : "undefined",
                  "policy" : "undefined"
               },
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Library and Information Centre, Hungarian Academy of Sciences"
               }
            ],
            "url" : "http://www.konyvtar.mta.hu/",
            "location" : {
               "latitude" : 47.5008,
               "longitude" : 19.0464
            },
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "value" : "hu",
                  "language" : "en"
               }
            ],
            "country" : "hu"
         },
         "system_metadata" : {
            "date_created" : "2015-03-17 13:51:34",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3226,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3226",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "hu",
               "la"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "phrase" : "History and Archaeology",
                  "language" : "en",
                  "value" : "20"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "hu",
                  "language" : "en",
                  "phrase" : "Hungarian"
               },
               {
                  "language" : "en",
                  "value" : "la",
                  "phrase" : "Latin"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "3",
               "20",
               "22"
            ],
            "url" : "http://real-r.mtak.hu/",
            "oai_url" : "http://real-r.mtak.hu/cgi/oai2",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "description" : "Collection of rare and old books and manuscripts",
            "metadata_record_count" : 837,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "REAL-R",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Sardegna Ricerche",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "it",
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "url" : "http://www.sardegnaricerche.it/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3225",
            "publicly_visible" : "yes",
            "date_created" : "2015-03-17 13:39:21",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3225
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "it"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "P-arch",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 952,
            "description" : "P-arch is the open access institutional repository of the Science and Technology Park of Sardinia.",
            "software" : {
               "version" : "4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "oai_url" : "http://www.p-arch.it/oai/request",
            "url" : "http://www.p-arch.it/",
            "content_subjects" : [
               "2",
               "11"
            ],
            "full_text_record_count" : 645,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "http://acikerisim.usak.edu.tr:8080/xmlui/",
            "content_languages" : [
               "tr",
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Technically Malfunctioning",
                  "language" : "en",
                  "value" : "technically_malfunctioning"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This is the institutional repository of Usak University. The interface is in Turkish and English and contains RSS feeds to alert users to new content.",
            "repository_status" : "technically_malfunctioning",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Uşak Üniversitesi Açık Erişim Arşivi"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Usak University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "tr",
            "url" : "http://www.usak.edu.tr/",
            "location" : {
               "longitude" : 29.396,
               "latitude" : 38.6782
            },
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3224,
            "date_created" : "2015-03-17 13:02:49",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3224"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "url" : "http://www.lib.nagoya-su.ac.jp",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Nagoya Management Junior College Library"
               }
            ],
            "location" : {
               "latitude" : 35.2196,
               "longitude" : 137.031
            },
            "country" : "jp",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Go to voice browser pageTo content area\tLog in Nagoya Sangyo University and Nagoya Management College"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3223",
            "publicly_visible" : "yes",
            "id" : 3223,
            "date_modified" : "2019-11-26 14:49:19",
            "date_created" : "2015-03-17 12:49:29"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 294,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Nagoya Sangyo University & Nagoya Management Junior College Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "https://Meisandai.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://meisandai.repo.nii.ac.jp/?action=repository_oaipmh&verb=GetRecord&metadataPrefix=junii2&identifier=oai:meisandai.repo.nii.ac.jp:00000517",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese or English.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Rikkyo University Institutional Repository (Rikkyo Roots)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "metadata_record_count" : 13543,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This Site provides access to the research output of the university. The site interface is available in Japanese or English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://rikkyo.repo.nii.ac.jp/"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Rikkyo University"
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "url" : "http://www.rikkyo.ac.jp/",
            "location" : {
               "latitude" : 35.7298,
               "longitude" : 139.703
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3222",
            "publicly_visible" : "yes",
            "date_created" : "2015-03-17 12:34:48",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3222
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 237,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Saitama Institute of Technology Academic Collections",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 232,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "11"
            ],
            "url" : "http://sit.repo.nii.ac.jp/",
            "oai_url" : "http://sit.repo.nii.ac.jp/oai",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "description" : "This is the institutional repository of Saitama Institute of Technology.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "ja",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-17 12:19:12",
            "id" : 3221,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3221"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Saitama Institute of Technology, Japan",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 36.2135,
               "longitude" : 139.24
            },
            "url" : "http://www.sit.ac.jp/"
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            }
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "languages_phrases" : [
                  {
                     "phrase" : "Hungarian",
                     "language" : "en",
                     "value" : "hu"
                  },
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental",
               "languages" : [
                  "hu",
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "http://ludita.uni-nke.hu/opendoar-policy"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://ludita.uni-nke.hu/opendoar-policy"
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher",
                     "phrase" : "This repository is not the publisher; it is merely the online archive"
                  }
               ],
               "harvesting" : [
                  "not_allowed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Not Allowed",
                     "language" : "en",
                     "value" : "not_allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://ludita.uni-nke.hu/opendoar-policy"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed",
                  "software_emulation"
               ],
               "url" : [
                  "http://ludita.uni-nke.hu/opendoar-policy"
               ],
               "third_party_collaborations" : [
                  "migrate_file_formats",
                  "software_emulation",
                  "record_preservation_metadata",
                  "offsite_backups"
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Convert or migrate file formats"
                  },
                  {
                     "value" : "software_emulation",
                     "language" : "en",
                     "phrase" : "develop and implement software emulations for old file formats"
                  },
                  {
                     "value" : "record_preservation_metadata",
                     "language" : "en",
                     "phrase" : "Record preservation metadata"
                  },
                  {
                     "value" : "offsite_backups",
                     "language" : "en",
                     "phrase" : "Backup items in external archives"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed"
                  },
                  {
                     "language" : "en",
                     "value" : "software_emulation",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "not_retained",
                     "url_retention_phrases" : [
                        {
                           "value" : "not_retained",
                           "language" : "en",
                           "phrase" : "Not at all"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "publisher_rules",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "No retention period defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "period" : "undefined"
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "language" : "en",
                        "value" : "errata_may_be_included"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "value" : "original_bitstream_retained",
                     "language" : "en",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ]
            },
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "rules_phrases" : [
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "phrase" : "Eligible depositors must deposit full texts of all their publications",
                     "language" : "en",
                     "value" : "full_texts_required"
                  },
                  {
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "item_relevance",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://ludita.uni-nke.hu/opendoar-policy"
               ],
               "depositors" : [
                  "employees"
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "content_embargo" : "restricted_until_embargo_expiry"
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-17 10:48:22",
            "id" : 3220,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3220"
         },
         "organisation" : {
            "url" : "http://uni-nke.hu/",
            "location" : {
               "latitude" : 47.4814,
               "longitude" : 19.0851
            },
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "language" : "en",
                  "value" : "hu"
               }
            ],
            "country" : "hu",
            "name" : [
               {
                  "name" : "National University of Public Service",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "hu",
                  "phrase" : "Hungarian"
               }
            ],
            "notes" : "Theses are summarized and some items are not not available.",
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "hu"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "Ludovika Digit ális Tudástár és Archívum",
                  "name" : "Ludovika Digital Knowledge Repository and Archive (LUDITA)",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 4610,
            "description" : "LUDITA is a digital knowledge repository which represents the intellectual wealth and research productivity of the National University of Public Service and is able to store and makes documents, which were made during the educational and research work and worthy of preserve, being researchable in full text and other multimedia formats.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "oai_url" : "http://ludita.uni-nke.hu/oai/request",
            "url" : "https://ludita.uni-nke.hu/ludita",
            "content_subjects" : [
               "23"
            ],
            "full_text_record_count" : 22,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "http://www.uqtr.ca",
            "location" : {
               "latitude" : 46.3474,
               "longitude" : -72.5775
            },
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "value" : "ca",
                  "language" : "en"
               }
            ],
            "country" : "ca",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Université du Québec à Trois‐Rivières",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3219",
            "publicly_visible" : "yes",
            "id" : 3219,
            "date_created" : "2015-03-17 10:28:57",
            "date_modified" : "2019-12-16 09:50:52"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Cognitio",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 7293,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.12",
               "name" : "eprints"
            },
            "description" : "This repository provides access to Université du Québec à Trois-Rivières' research outputs (professors, researchers, postgraduate students). The interface is available in French.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 5116,
            "oai_url" : "http://depot-e.uqtr.ca/cgi/oai2",
            "url" : "http://depot-e.uqtr.ca",
            "content_subjects" : [
               "1"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "fr"
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Algeria",
                  "value" : "dz",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 36.381,
               "longitude" : 3.89361
            },
            "url" : "http://www.univ-bouira.dz/",
            "country" : "dz",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Bouira University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3218,
            "date_created" : "2015-03-17 10:09:49",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3218"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "description" : "The University of Bouira offers visitors from Bouira University Digital Space free downloadable files of thesis: doctoral, master, master, courses in different technological and literary disciplines, proceedings of scientific conferences and scientific articles of a high level.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "url" : "http://dspace.univ-bouira.dz:8080/jspui/",
            "content_subjects" : [
               "2",
               "17",
               "3",
               "21",
               "23",
               "24",
               "26"
            ],
            "oai_url" : "http://dspace.univ-bouira.dz:8080/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Bouira University Digital Space",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "metadata_record_count" : 3007,
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "fr",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3217",
            "publicly_visible" : "yes",
            "id" : 3217,
            "date_created" : "2015-03-16 16:52:53",
            "date_modified" : "2019-10-17 14:34:53"
         },
         "organisation" : {
            "url" : "http://untz.ba/",
            "location" : {
               "longitude" : 18.6969,
               "latitude" : 44.5335
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ba",
                  "phrase" : "Bosnia and Herzegovina"
               }
            ],
            "country" : "ba",
            "name" : [
               {
                  "name" : "University of Tuzla",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "url" : "https://phaidra.untz.ba/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This is the institutional repository of the University of Tuzla.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "fedora",
               "name_phrases" : [
                  {
                     "value" : "fedora",
                     "language" : "en",
                     "phrase" : "Fedora"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 15,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Digital Repository of the University of Tuzla (PHAIDRA)",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3216",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3216,
            "date_created" : "2015-03-16 16:34:35",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Tokyo University of Information Sciences, Japan",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 35.6368,
               "longitude" : 140.203
            },
            "url" : "http://www.tuis.ac.jp/"
         },
         "repository_metadata" : {
            "content_subjects" : [
               "27"
            ],
            "oai_url" : "http://tuis.repo.nii.ac.jp/oai",
            "url" : "https://tuis.repo.nii.ac.jp/",
            "full_text_record_count" : 486,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides open access to the research output of Tokyo University of Information Sciences. The site interface is available in Japanese or English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 582,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "TUIS Academic Repository"
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Library and Information Science",
                  "value" : "27",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Hiroshima Shudo University Institutional Ripository System (広島修道大学リポジトリ)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2180,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This is the Institutional Repository for Hiroshima Shudo University.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja",
               "en"
            ],
            "url" : "https://shudo-u.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-16 16:19:12",
            "id" : 3215,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3215"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Hiroshima Shudo University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 132.405,
               "latitude" : 34.4333
            },
            "url" : "http://www.shudo-u.ac.jp/"
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2015-03-16 13:00:49",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3214,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3214",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "MINES ParisTech - École nationale supérieure des mines de Paris"
               }
            ],
            "country" : "fr",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "France"
               }
            ],
            "location" : {
               "longitude" : 2.3399,
               "latitude" : 48.8449
            },
            "url" : "http://www.mines-paristech.fr/"
         },
         "repository_metadata" : {
            "content_languages" : [
               "fr"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "year_established" : 2009,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "oai_url" : "https://api.archives-ouvertes.fr/oai/ensmp",
            "content_subjects" : [
               "11"
            ],
            "url" : "https://hal-mines-paristech.archives-ouvertes.fr/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 4571,
            "description" : "Launched in September 2009, HAL-MINES ParisTech aims to reference and provide access to the whole academic publications of its 18 laboratories specialized in 5 main research fields : Earth sciences and environment, Energy and processes, Mechanical and materials engineering, Mathematics and systems, and Economics, management, society. About 290 scholars and 380 PhD students make their research at MINES ParisTech in a close partnership with industry.",
            "software" : {
               "name" : "hal",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "hal",
                     "phrase" : "HAL"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 20998,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "HAL-MINES ParisTech"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 542,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Akita Prefectural University Institutional Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://akita-pu.repo.nii.ac.jp/",
            "content_subjects" : [
               "2"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This is the institutional repository for Akita Prefectural University"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            }
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "http://www.akita-pu.ac.jp/index.htm",
            "location" : {
               "longitude" : 140.042,
               "latitude" : 39.805
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Akita Prefectural University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3213",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-16 12:50:53",
            "id" : 3213
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the College. The site interface is available in Japanese or English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "22"
            ],
            "url" : "https://icabs.repo.nii.ac.jp/",
            "content_languages" : [
               "ja"
            ],
            "name" : [
               {
                  "name" : "ICPBS Digital Collections",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "metadata_record_count" : 359,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "International College for Postgraduate Buddhist Studies",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "http://www.icabs.ac.jp/",
            "location" : {
               "latitude" : 35.7196,
               "longitude" : 139.738
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3212",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-16 12:40:51",
            "id" : 3212
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3211",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2015-03-16 12:27:19",
            "date_modified" : "2019-11-06 13:39:30",
            "id" : 3211,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "url" : "http://www.nagano-nct.ac.jp/",
            "location" : {
               "longitude" : 138.234,
               "latitude" : 36.6781
            },
            "country" : "jp",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Nagano National College of Technology"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "metadata_record_count" : 956,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "Repository of NNCT",
                  "name" : "Repository of National Institute of Technology"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://nagano-nct.repo.nii.ac.jp/oai",
            "url" : "https://nagano-nct.repo.nii.ac.jp",
            "content_subjects" : [
               "11"
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "description" : "This is the Institutional Repository of Nagano National College of Technology."
         }
      },
      {
         "policies" : {
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Central University of Technology",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "za",
            "country_phrases" : [
               {
                  "phrase" : "South Africa",
                  "language" : "en",
                  "value" : "za"
               }
            ],
            "location" : {
               "latitude" : -29.1167,
               "longitude" : 26.2167
            },
            "url" : "http://www.cut.ac.za/"
         },
         "system_metadata" : {
            "id" : 3210,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-16 11:38:21",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3210",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 1329,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CUT Institutional Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://ir.cut.ac.za/",
            "content_subjects" : [
               "17",
               "24",
               "10",
               "11"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "DSpace is a digital service that collects, preserves, and distributes digital material. Repositories are important tools for preserving an organization's legacy; they facilitate digital preservation and scholarly communication.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2015-03-16 11:24:48",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3209,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3209"
         },
         "organisation" : {
            "country" : "jp",
            "url" : "http://www.grips.ac.jp/",
            "location" : {
               "latitude" : 35.6687,
               "longitude" : 139.725
            },
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "name" : "National Graduate Institute for Policy Studies",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://grips.repo.nii.ac.jp"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Insitutional Repository at the National Graduate Institute for Policy Studies",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1181,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "description" : "This site provides open access to outcomes created through education and\nresearch activities at the Institution. The site interface is available in Japanese and English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 650,
            "url" : "https://grips.repo.nii.ac.jp/",
            "oai_url" : "https://grips.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "24",
               "26"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 7672,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Thesis and Dissertation Repository of Universidade Federal de Goiás",
                  "acronym" : "TEDE"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.bc.ufg.br/tede/",
            "content_languages" : [
               "en",
               "es",
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "4.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidade Federal de Goiás",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ],
            "location" : {
               "longitude" : -49.2558,
               "latitude" : -16.6068
            },
            "url" : "http://www.ufg.br/"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 16:36:10",
            "id" : 3208,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3208"
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja",
               "en"
            ],
            "url" : "https://mdu.repo.nii.ac.jp/",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of Matsumoto Dental University.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1987,
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Matsumoto Dental University Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3207",
            "publicly_visible" : "yes",
            "id" : 3207,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 16:18:30"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Matsumo Dental University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 137.94,
               "latitude" : 36.128
            },
            "url" : "http://www.mdu.ac.jp/",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This is the institutional repository of Seisen University.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://seisen.repo.nii.ac.jp/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Seisen University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "metadata_record_count" : 531,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 139.728,
               "latitude" : 35.6295
            },
            "url" : "http://www.seisen-u.ac.jp/index.php",
            "country" : "jp",
            "name" : [
               {
                  "name" : "Seisen University, Japan",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3206",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2015-03-13 16:04:09",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3206,
            "publicly_visible" : "yes"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://kitakyu.repo.nii.ac.jp/",
            "content_languages" : [
               "ja",
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The site interface is available in Japanese of English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "metadata_record_count" : 57,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "RUKSOR(Repository of University of Kitakyushu Stacked by Original Resources)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "date_created" : "2015-03-13 15:54:48",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3205,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3205",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "url" : "http://www.kitakyu-u.ac.jp/",
            "location" : {
               "latitude" : 33.8442,
               "longitude" : 130.879
            },
            "name" : [
               {
                  "name" : "The University of Kitakyushu, Japan",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja",
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Creative Repository of Electro-Communications",
                  "acronym" : "C-RECS",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 9255,
            "description" : "This site provides access to the research output of the University. The interface is available in Japanese.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "url" : "https://uec.repo.nii.ac.jp/",
            "content_subjects" : [
               "11"
            ],
            "oai_url" : "http://uec.repo.nii.ac.jp/oai",
            "full_text_record_count" : 4856,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Electro-Communications",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "url" : "http://www.uec.ac.jp/eng/",
            "location" : {
               "latitude" : 35.6506,
               "longitude" : 139.541
            },
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3204",
            "publicly_visible" : "yes",
            "id" : 3204,
            "date_created" : "2015-03-13 15:36:49",
            "date_modified" : "2019-10-17 14:34:53"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "metadata_record_count" : 1183,
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Florida Law Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "url" : "http://scholarship.law.ufl.edu/",
            "content_subjects" : [
               "26"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This is the UF Law Repository, hosting open-access, full-text faculty scholarship for faculty members of the law school.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            }
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "http://www.law.ufl.edu/",
            "country" : "us",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Florida Levin College of Law",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3203",
            "publicly_visible" : "yes",
            "id" : 3203,
            "date_created" : "2015-03-13 15:22:15",
            "date_modified" : "2019-10-17 14:34:53"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3202",
            "publicly_visible" : "yes",
            "date_created" : "2015-03-13 15:04:34",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3202
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Nagoya City University,Japan",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "location" : {
               "latitude" : 35.1399,
               "longitude" : 136.936
            },
            "url" : "http://www.nagoya-cu.ac.jp/1.htm/"
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This is the institutional repository of Nagoya City University.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://ncu.repo.nii.ac.jp/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Nagoya City University Repositories",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1527
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "fr"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "hal",
                     "language" : "en",
                     "phrase" : "HAL"
                  }
               ],
               "name" : "hal"
            },
            "description" : "Hal-Lille3 is an open archive for deposition and consultation of scientific publications of the University of Lille 3 (journal articles, book chapters, conference proceedings, theses, etc.).",
            "full_text_record_count" : 2094,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://hal.univ-lille3.fr/",
            "oai_url" : "https://api.archives-ouvertes.fr/oai/univ-lille3",
            "content_subjects" : [
               "17",
               "23"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "HAL - Lille 3"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 9889,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2015-03-13 14:49:41",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3201,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3201",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "fr",
            "url" : "http://www.univ-lille3.fr/",
            "country_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "France"
               }
            ],
            "name" : [
               {
                  "name" : "Université de Lille 3 Sciences humaines et sociales",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ]
            }
         },
         "organisation" : {
            "country" : "in",
            "country_phrases" : [
               {
                  "value" : "in",
                  "language" : "en",
                  "phrase" : "India"
               }
            ],
            "url" : "http://vidyasagar.ac.in",
            "location" : {
               "latitude" : 22.4333,
               "longitude" : 87.3333
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Vidyasagar University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3200,
            "date_created" : "2015-03-13 13:55:49",
            "date_modified" : "2019-11-05 16:44:41",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3200"
         },
         "repository_metadata" : {
            "description" : "This is the Institutional Repository of Vidyasagar University. . Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "6.2",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://inet.vidyasagar.ac.in:8080/jspui",
            "oai_url" : "http://inet.vidyasagar.ac.in:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "Dspace@VU",
                  "name" : "Institutional Repository of Vidyasagar University"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 1427,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            }
         },
         "organisation" : {
            "url" : "http://www.lib.sojo-u.ac.jp/",
            "location" : {
               "longitude" : 130.696,
               "latitude" : 32.8316
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "name" : "Sojo University Library",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3199,
            "date_created" : "2015-03-13 13:18:20",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3199"
         },
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "url" : "https://sojo-u.repo.nii.ac.jp/",
            "content_subjects" : [
               "1",
               "2",
               "17",
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository for Sojo university",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "metadata_record_count" : 170,
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Sojo University Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Iida Womans junior College",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 35.5032,
               "longitude" : 137.833
            },
            "url" : "http://www.iidawjc.ac.jp/"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 13:06:00",
            "id" : 3198,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3198",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja",
               "en",
               "de",
               "zh"
            ],
            "url" : "https://iidawjc.repo.nii.ac.jp/",
            "content_subjects" : [
               "10",
               "25"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Iida Woman's junior College Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               },
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 133
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3197",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 12:54:59",
            "id" : 3197
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Kyoto Womens University (京都女子大学) Japan"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 34.9886,
               "longitude" : 135.78
            },
            "url" : "http://www.kyoto-wu.ac.jp/",
            "country" : "jp"
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Japanese and English.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja",
               "en"
            ],
            "url" : "http://repo.kyoto-wu.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Kyoto Women's University Academic Information Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2133
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            }
         },
         "system_metadata" : {
            "id" : 3196,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 12:07:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3196",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Tuzla",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Bosnia and Herzegovina",
                  "language" : "en",
                  "value" : "ba"
               }
            ],
            "url" : "http://untz.ba/",
            "location" : {
               "longitude" : 18.6969,
               "latitude" : 44.5335
            },
            "country" : "ba"
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "fedora",
                     "language" : "en",
                     "phrase" : "Fedora"
                  }
               ],
               "name" : "fedora"
            },
            "description" : "System “E-theses\" is assigned for search and download of doctoral dissertations. It is a part of the Digital repository – PHAIDRA, system for indexing and archiving of scientific and professional papers. According to copyright policy, repository contains only dissertations with signed statements in which candidate authorizes University to upload his dissertation in Digital repository, and indicates license conditions. Dissertations are searchable within “E-theses” or within the PHAIDRA.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eteze.untz.ba/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "E-theses of the University of Tuzla (PHAIDRA)"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 124,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "notes" : "Theses are written in Bosnian",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2015-03-13 11:58:09",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3195,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3195"
         },
         "organisation" : {
            "country" : "tr",
            "url" : "http://www.izu.edu.tr/",
            "location" : {
               "latitude" : 41.0306,
               "longitude" : 28.7829
            },
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Istanbul Sabahattin Zaim University"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_languages" : [
               "tr",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://openaccess.izu.edu.tr:8080/xmlui/oai",
            "url" : "http://openaccess.izu.edu.tr/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "DSpace @ IZU, Istanbul Sabahattin Zaim University Open Access System. This system produced by IZU members of scientific materials (books, theses, journals, articles, etc.) collect the digital media stored on international standards and academic output has been created to provide open access.",
            "metadata_record_count" : 103,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "DSpace@IZU"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Gaziantep Üniversitesi",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "tr",
            "location" : {
               "latitude" : 37.0351,
               "longitude" : 37.3168
            },
            "url" : "http://www.gantep.edu.tr/",
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3194",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2015-03-13 11:38:38",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3194,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "tr",
               "en"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "GAUN@DSpace",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 34,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "4.1",
               "name" : "dspace"
            },
            "description" : "The Gaziantep University Academic Open Access System is provides access to the scientific studies of the University Academic Personnel (articles, convention / conference proceedings, theses, posters, etc.)",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://acikerisim.gantep.edu.tr:8080/oai/request",
            "url" : "http://acikerisim.gantep.edu.tr:8080/xmlui/"
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "system_metadata" : {
            "id" : 3193,
            "date_created" : "2015-03-13 11:22:15",
            "date_modified" : "2019-12-04 12:27:32",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3193",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Stellenbosch University"
               }
            ],
            "url" : "http://www.sun.ac.za/",
            "location" : {
               "longitude" : 18.8586,
               "latitude" : -33.9322
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "za",
                  "phrase" : "South Africa"
               }
            ],
            "country" : "za"
         },
         "repository_metadata" : {
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "18",
               "20",
               "21"
            ],
            "oai_url" : "http://digital.lib.sun.ac.za/oai",
            "url" : "http://digital.lib.sun.ac.za/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "Digital Collections showcases digital content from the Library and Information Service’s unique digital collections and repositories. It offers a single connection point to various collections of primary resources as well as digital research output. In support of digital scholarship, sharing our valuable resources and promoting intellectual collaboration the Library and Information Service offers free online access to these digital collections. This initiative forms part of the Library’s commitment to enriching its digital resources and supporting, developing and contributing to high-level scholarly publication output.",
            "metadata_record_count" : 12891,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "SUNDigital Collections",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "18",
                  "phrase" : "Fine and Performing Arts"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Language and Literature",
                  "value" : "21",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Afyon Kocatepe University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5490,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "description" : "This is the institutional repository of Afyon Kocatepe University which allows open access to the academic output of the University.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 8,
            "url" : "http://acikerisim.aku.edu.tr/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://acikerisim.aku.edu.tr/oai/request",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en",
               "tr"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Afyon Kocatepe Üniversitesi"
               }
            ],
            "country" : "tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "url" : "http://www.aku.edu.tr/anasayfa/eng/index.htm",
            "location" : {
               "longitude" : 30.5326,
               "latitude" : 38.8128
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 11:02:37",
            "id" : 3192,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3192"
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3191",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-13 10:08:31",
            "id" : 3191
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad del Pacífico",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "url" : "http://www.up.edu.pe/",
            "location" : {
               "latitude" : -12.0464,
               "longitude" : -77.0428
            },
            "country" : "pe"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1582,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio de la Universidad del Pacífico"
               }
            ],
            "oai_url" : "http://repositorio.up.edu.pe/oai/request?verb=Identify",
            "content_subjects" : [
               "24"
            ],
            "url" : "http://repositorio.up.edu.pe/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "The Institutional Repository of the University of the Pacific is a virtual tool that aims to store, retain, preserve and disseminate scientific and intellectual creation of the members of the University of the Pacific.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "es"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "uk"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "metadata_record_count" : 2603,
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "KhNUIAIR",
                  "name" : "Kharkov National University of Internal Affairs Institutional Repository (KhNUIAIR)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Репозиторий Харьковского национального университета внутренних дел",
                  "language" : "uk",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "uk",
                        "language" : "en",
                        "phrase" : "Ukrainian"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dspace.univd.edu.ua/oai/request?verb=Identify",
            "url" : "http://dspace.univd.edu.ua/xmlui/",
            "full_text_record_count" : 840,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Ukrainian.",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Kharkov National University of Internal Affairs",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://univd.edu.ua/",
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2015-03-12 16:32:00",
            "date_modified" : "2019-10-17 14:34:53",
            "id" : 3190,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3190"
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://eprints.dinus.ac.id/",
            "oai_url" : "http://eprints.dinus.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 14323,
            "description" : "This is the institutional repository of Universitas Dian Nuswantoro",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 17658,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Udinus Repo",
                  "acronym" : "UDiNus Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "id"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            }
         },
         "organisation" : {
            "country" : "id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "url" : "http://dinus.ac.id/",
            "location" : {
               "longitude" : 110.409,
               "latitude" : -6.9808
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universitas Dian Nuswantoro",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3189,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 16:03:32",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3189"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "Repositorio de Investigación y Educación Artísticas del Instituto Nacional de Bellas Artes",
                  "name" : "INBA Digital",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 461,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "INBA Digital is the institutional repository of the Instituto Nacional de Bellas Artes in México. Its mission is to archive, preserve and disseminate the academic production of the Research Centers and Professional Schools of Dance, Theatre, Music and Visual Arts. It is an Open Access Repository.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://inbadigital.bellasartes.gob.mx:8080/jspui/",
            "oai_url" : "http://www.inbadigital.bellasartes.gob.mx:8080/xmlui/dspace-oai",
            "content_subjects" : [
               "18"
            ]
         },
         "policies" : {
            "submission_policy" : {
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "language" : "en",
                     "value" : "displayed_or_performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "value" : "content_not_changed",
                     "language" : "en",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://www.inbadigital.bellasartes.gob.mx/politicas.html"
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed",
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats"
                  }
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "method" : "undefined",
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security"
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "version_control" : {
                  "earlier_versions" : [
                     "link_between_versions"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "link_between_versions",
                        "language" : "en",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "unusual_files_not_guaranteed"
               ],
               "closure_policy" : "undefined"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "url" : [
                  "http://http://www.inbadigital.bellasartes.gob.mx/politicas.html"
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Instituto Nacional de Bellas Artes",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "mx",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "mx",
                  "phrase" : "Mexico"
               }
            ],
            "location" : {
               "latitude" : 19.4326,
               "longitude" : -99.1332
            },
            "url" : "http://www.bellasartes.gob.mx/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3188",
            "publicly_visible" : "yes",
            "id" : 3188,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 15:18:43"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3187",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 14:41:16",
            "id" : 3187,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "zw",
            "country_phrases" : [
               {
                  "phrase" : "Zimbabwe",
                  "value" : "zw",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -17.35,
               "longitude" : 30.2
            },
            "url" : "http://www.cut.ac.zw/",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chinhoyi University of Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "metadata_record_count" : 46,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "CUTScholar Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://scholar.cut.ac.zw/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "CUTIR, the institutional repository of Chinhoyi University of Technology. CUTIR is administered by the Library, and its aim is to collect, organize, manage, store, preserve, publish and make accessible worldwide, the knowledge assets or intellectual output of the university's researchers, staff and post-graduate students."
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Midlands State University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1994,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.6"
            },
            "description" : "The repository is a digital collection of the research output of the Midlands State University community",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://ir.msu.ac.zw:8080/oai/request",
            "url" : "http://ir.msu.ac.zw:8080/xmlui/",
            "content_subjects" : [
               "1"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Midlands State University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.msu.ac.zw/",
            "location" : {
               "latitude" : -19.5166,
               "longitude" : 29.8401
            },
            "country_phrases" : [
               {
                  "phrase" : "Zimbabwe",
                  "value" : "zw",
                  "language" : "en"
               }
            ],
            "country" : "zw"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3186",
            "publicly_visible" : "yes",
            "id" : 3186,
            "date_created" : "2015-03-12 14:13:48",
            "date_modified" : "2019-10-17 14:34:53"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "description" : "INRS space is the institutional digital repository of the National Institute of Scientific Research . It contains theses and dissertations, as well as reports and other documents that INRS has the right to broadcast. It conforms to the standards of the Open Archive Initiative (OAI), applied by the digital repository of this type. The documents filed therein are more easily identifiable and accessible in the best web tools, which favors their circulation and, therefore, the visibility and impact of the work for which they are derived.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://espace.inrs.ca/cgi/oai2-etdms?verb=Identify",
            "content_subjects" : [
               "2"
            ],
            "url" : "http://espace.inrs.ca/",
            "name" : [
               {
                  "name" : "Espace INRS",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5898,
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "fr"
            ],
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3185",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 3185,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 12:35:19",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "http://www.inrs.ca/",
            "location" : {
               "latitude" : 46.8033,
               "longitude" : -71.2428
            },
            "country_phrases" : [
               {
                  "value" : "ca",
                  "language" : "en",
                  "phrase" : "Canada"
               }
            ],
            "country" : "ca",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Institut national de la recherche scientifique",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Tennessee at Chattanooga",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "http://www.utc.edu/",
            "location" : {
               "longitude" : -85.3,
               "latitude" : 35.0333
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3184",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3184,
            "date_created" : "2015-03-12 12:22:08",
            "date_modified" : "2019-12-04 12:27:32",
            "publicly_visible" : "yes"
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "metadata_record_count" : 3322,
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "UTC Digital Collections",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://digital-collections.library.utc.edu/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://cdm16877.contentdm.oclc.org/oai/oai.php",
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "value" : "contentdm",
                     "language" : "en",
                     "phrase" : "CONTENTdm"
                  }
               ]
            },
            "description" : "University of Tennessee at Chattanooga Digital Collections provides free and open access to cultural heritage resources that document Chattanooga, Tennessee, and the South, including the history of the university.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 3183,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 11:58:05",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3183",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.utc.edu/",
            "location" : {
               "longitude" : -85.3,
               "latitude" : 35.0333
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "University of Tennessee at Chattanooga",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "UTC Scholar",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1682,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "description" : "UTC Scholar provides open access to the University of Tennessee at Chattanooga’s research, creative works, and publications.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 526,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://scholar.utc.edu/do/oai/",
            "url" : "http://scholar.utc.edu/",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad de Medellín",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3892,
            "description" : "This is the institutional repository of Universidad de Medellin.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "oai_url" : "http://repository.udem.edu.co/oai/request",
            "url" : "http://repository.udem.edu.co/",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 1799,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es",
               "en"
            ]
         },
         "system_metadata" : {
            "id" : 3182,
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 11:49:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3182",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "url" : "http://www.udem.edu.co/",
            "location" : {
               "longitude" : -75.6109,
               "latitude" : 6.23193
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad de Medellín"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Royal Netherlands Institute for Sea Research",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "nl",
                  "language" : "en",
                  "phrase" : "Netherlands"
               }
            ],
            "location" : {
               "latitude" : 53.0024,
               "longitude" : 4.7861
            },
            "url" : "http://www.nioz.nl/",
            "country" : "nl"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:53",
            "date_created" : "2015-03-12 11:20:50",
            "id" : 3181,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3181",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "types_included" : {
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "language" : "en",
                        "value" : "journal_articles",
                        "phrase" : "Journal Articles"
                     },
                     {
                        "phrase" : "Conference and Workshop Papers",
                        "language" : "en",
                        "value" : "conference_and_workshop_papers"
                     },
                     {
                        "language" : "en",
                        "value" : "unpub_reports_and_working_papers",
                        "phrase" : "Unpublished Reports and Working Papers"
                     }
                  ],
                  "standard_types_allowed" : [
                     "journal_articles",
                     "conference_and_workshop_papers",
                     "unpub_reports_and_working_papers"
                  ]
               },
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "multi_institution_subject",
               "versions_phrases" : [
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "value" : "multi_institution_subject",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Dutch",
                  "language" : "en",
                  "value" : "nl"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "language" : "en",
                  "value" : "3"
               },
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "nl"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "NIOZ Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 3127,
            "description" : "The NIOZ Repository provides access to the institute’s research output. It currently contains over a thousand items that have been published since 2011.",
            "software" : {
               "name" : "other",
               "name_other" : "IMIS",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "oai_url" : "http://www.vliz.be/imis/nioz/imis.php",
            "content_subjects" : [
               "3",
               "6",
               "7"
            ],
            "url" : "http://www.nioz.nl/repository",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1867
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "it",
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Italian",
                  "language" : "en",
                  "value" : "it"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "oai_url" : "http://www.giambattistavico.it/oai",
            "content_subjects" : [
               "22"
            ],
            "url" : "http://www.giambattistavico.it/",
            "full_text_record_count" : 2,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "The “Vico Portal” is a project of the Institute for the history of philosophical and scientific thought in modern age (ISPF) of the Italian National Council of Research. The Portal aims to be the broadest collection of Vichian resources and materials on the Internet. It collects all the relevant electronic publications edited by the Institute - such as Vico’s works (anastatic reproductions and critical editions), bibliographies, digital reproductions of the “Bollettino del Centro di studi vichiani” and of ancient and modern works - as well as links to other trusted open access editions, directories and resources. The OAI Base provides metadata and links to our own resources.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Drupal",
                     "value" : "drupal",
                     "language" : "en"
                  }
               ],
               "name" : "drupal"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 118,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Portale Vico",
                  "acronym" : "Biblioteca digitale vichiana"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "url" : "http://www.ispf.cnr.it/",
            "location" : {
               "latitude" : 26.142,
               "longitude" : -81.7948
            },
            "country" : "it",
            "name" : [
               {
                  "name" : "ISPF-CNR",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3180,
            "date_created" : "2015-03-12 11:01:41",
            "date_modified" : "2019-10-17 14:34:53",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3180"
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Austrian Centre for Digital Humanities, University of Graz",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "at",
            "location" : {
               "longitude" : 15.4578,
               "latitude" : 47.0707
            },
            "url" : "http://informationsmodellierung.uni-graz.at/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "at",
                  "phrase" : "Austria"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3179",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2015-03-12 10:38:27",
            "id" : 3179,
            "publicly_visible" : "yes"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "content_policy" : {
               "languages" : [
                  "de"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages_phrases" : [
                  {
                     "phrase" : "German",
                     "value" : "de",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "standard_types_allowed" : [
                     "datasets",
                     "other_special_item_types"
                  ],
                  "standard_types_allowed_phrases" : [
                     {
                        "phrase" : "Datasets",
                        "value" : "datasets",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "other_special_item_types",
                        "phrase" : "Other Special Item Types"
                     }
                  ],
                  "all" : "false"
               },
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "software" : {
               "name" : "fedora",
               "name_phrases" : [
                  {
                     "value" : "fedora",
                     "language" : "en",
                     "phrase" : "Fedora"
                  }
               ]
            },
            "description" : "GAMS is a data repository for scientific content to ensure the long-term preservation, access to and reusability of the content in different usage scenarios. \nIt supports the electronic dissemination of research data and related metadata, with special emphasis on the arts and humanities.",
            "full_text_record_count" : 21736,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://gams.uni-graz.at/oaiprovider",
            "url" : "http://gams.uni-graz.at/",
            "content_subjects" : [
               "17"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "GAMS - Asset Management System for the Humanities",
                  "acronym" : "GAMS (Geisteswissenschaftliches Asset Management System)"
               }
            ],
            "type" : "disciplinary",
            "metadata_record_count" : 28394,
            "content_types_phrases" : [
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "de"
            ],
            "content_types" : [
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "ko"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Korean",
                  "language" : "en",
                  "value" : "ko"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 2803,
            "oai_url" : "http://kdidp.kdevelopedia.org/ItemHandler",
            "url" : "https://www.kdevelopedia.org/Resources.do#.VQBvr-Q0Uyo",
            "content_subjects" : [
               "19"
            ],
            "software" : {
               "name_phrases" : []
            },
            "description" : "This is the repository of K-Developedia that provides open access to the full-text resources on Korea's development experiences.",
            "metadata_record_count" : 27526,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "K-Developedia(KDI School) Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3178",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-11 16:38:18",
            "id" : 3178
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "KDI School",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "kr",
                  "phrase" : "Korea, Republic of"
               }
            ],
            "location" : {
               "latitude" : 37.592,
               "longitude" : 127.047
            },
            "url" : "http://www.kdischool.ac.kr/",
            "country" : "kr"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            }
         }
      },
      {
         "policies" : {
            "data_policy" : {
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://repo.iain-tulungagung.ac.id/policies.html"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "language" : "en",
                        "value" : "changes_not_permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "withdrawn_items" : {
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "yes",
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ]
            },
            "submission_policy" : {
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items may not be deposited until any embargo period has expired",
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "url" : [
                  "http://repo.iain-tulungagung.ac.id/policies.html"
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry",
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://repo.iain-tulungagung.ac.id/policies.html"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "value" : "requires_permission",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "working_drafts",
                     "phrase" : "working drafts"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "peer-review status",
                     "language" : "en",
                     "value" : "peer_review_status"
                  },
                  {
                     "value" : "publication_status",
                     "language" : "en",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://repo.iain-tulungagung.ac.id/policies.html"
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3177",
            "publicly_visible" : "yes",
            "id" : 3177,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-11 16:14:23"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "url" : "http://www.iain-tulungagung.ac.id/",
            "location" : {
               "longitude" : 111.928,
               "latitude" : -8.07836
            },
            "country" : "id",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "IAIN Tulungagung",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "description" : "The Institutional Repository of IAIN Tulungagung (IRIT) is a digital collection of the IAIN Tulungagung's research outputs. \r\n\r\nIAIN Tulungagung's Library (http://digilib.iain-tulungagung.ac.id) is responsible for establishing, collaborating, managing, maintaining and disseminating the content of IRIT.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "url" : "http://repo.iain-tulungagung.ac.id/",
            "oai_url" : "http://repo.iain-tulungagung.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institutional Repository of IAIN Tulungagung"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 4726,
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "id"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 3763,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "repository.iit",
                  "name" : "Illinois Institute of Technology’s institutional repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "datasets",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://repository.iit.edu/",
            "content_subjects" : [
               "3",
               "11"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "Repository.iit supports cross-disciplinary collaboration by collecting, preserving, disseminating, and providing persistent and reliable access to all faculty, staff, and student digital research and scholarship. Supported and maintained by the Paul V. Galvin Library, repository.iit also preserves library and archival collections, and serves as a living archive for other materials representing the many diverse aspects of the IIT community.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2015-03-11 15:20:44",
            "date_modified" : "2019-12-04 12:27:32",
            "id" : 3175,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3175"
         },
         "organisation" : {
            "location" : {
               "longitude" : -87.6267,
               "latitude" : 41.8343
            },
            "url" : "http://web.iit.edu/",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Illinois Institute of Technology",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "languages" : [
                  "en"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            }
         }
      },
      {
         "policies" : {
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "value" : "ca",
                  "language" : "en"
               }
            ],
            "url" : "http://www.icscanada.edu/",
            "location" : {
               "latitude" : 43.6589,
               "longitude" : -79.3966
            },
            "country" : "ca",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institute for Christian Studies",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3174,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-11 15:08:44",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3174",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 581,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institute for Christian Studies",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://ir.icscanada.edu/icsir/",
            "oai_url" : "http://ir.icscanada.edu/icsir/oai",
            "content_subjects" : [
               "22"
            ],
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Open Repository"
            },
            "description" : "The repository for the Institute of Christian Sciences facilitates access to our research, creative works, and publications by collecting, sharing and archiving content selected and deposited by students and staff.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "learning_objects"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               }
            ],
            "notes" : "Currently only holds learning objects"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Уральский государственный педагогический университет",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://uspu.ru/",
            "location" : {
               "latitude" : 56.88,
               "longitude" : 60.6144
            },
            "country_phrases" : [
               {
                  "value" : "ru",
                  "language" : "en",
                  "phrase" : "Russian Federation"
               }
            ],
            "country" : "ru"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3173,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-11 14:37:29",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3173"
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            }
         },
         "repository_metadata" : {
            "content_languages" : [
               "ru"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://elar.uspu.ru/oai/request",
            "url" : "http://elar.uspu.ru/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This is the institutional repository of the Ural State Pedagogical University. The interface is in English and Russian and it has RSS feeds to inform users of new items.",
            "metadata_record_count" : 8618,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Electronic archive USPU",
                  "acronym" : "Электронный архив УРГПУ",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2015-03-11 14:17:21",
            "date_modified" : "2019-10-17 14:34:52",
            "id" : 3172,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3172",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Iran, Islamic Republic of",
                  "value" : "ir",
                  "language" : "en"
               }
            ],
            "url" : "http://bpums.ac.ir/",
            "location" : {
               "longitude" : 50.8345,
               "latitude" : 28.9796
            },
            "country" : "ir",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Bushehr University of Medical Sciences",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Bushehr University of Medical Sciences Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 6021,
            "description" : "Bushehr University of Medical Sciences (BPUMS) (Persian: دانشگاه علوم پزشکی بوشهر‎), is a public medical school in Bushehr Province, Iran. BPUMS is one of the oldest and largest universities in Iran, dating back to 29 years ago. Bushehr University of Medical Sciences administers all public hospitals in and around the city of Bushehr.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "url" : "http://eprints.bpums.ac.ir/",
            "oai_url" : "http://eprints.bpums.ac.ir/cgi/oai2",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Persian (Farsi)",
                  "language" : "en",
                  "value" : "fa"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "fa",
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "notes" : "Repositorio Institucional de Acceso Abierto de la U.A.S.L.P. que almacena y organiza la documentación y producción universitaria de índole científica, académica y administrativa, con el propósito de preservarla en formato digital y facilitar su acceso y visibilidad global.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://ninive.uaslp.mx/jspui/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ninive.uaslp.mx/oai/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is the Repositorio Institucional de Acceso Abierto de la U.A.S.L.P which preserves and allows open access to the scientific, academic and administrative work of the University.",
            "metadata_record_count" : 2044,
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Institucional Nínive",
                  "acronym" : "Ninive",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3171",
            "publicly_visible" : "yes",
            "id" : 3171,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-11 13:54:13"
         },
         "organisation" : {
            "country" : "mx",
            "url" : "http://www.uaslp.mx/Spanish/Paginas/default.aspx",
            "location" : {
               "latitude" : 22.5937,
               "longitude" : -101.25
            },
            "country_phrases" : [
               {
                  "phrase" : "Mexico",
                  "language" : "en",
                  "value" : "mx"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Autónoma de San Luis Potosí",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository contains educational resources produced by the Center for Innovation in Teaching and Learning (formerly DELTS) and other educational support units within the province’s public K-12, university and college systems. It is a provincial repository providing access to digitized primary learning objects created for teaching and learning in Newfoundland. Some items need special software to function correctly. The site is well supported with guidance documentation. Some items are available only to members of private communities. Users may set up RSS feeds to be alerted to new content. The interface is in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "https://linney.mun.ca/pages/home.php",
            "content_subjects" : [
               "17",
               "2",
               "23"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Linney",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 7030
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3170",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3170,
            "date_created" : "2015-03-11 13:30:34",
            "date_modified" : "2019-12-04 12:27:32",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Memorial University of Newfoundland",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "latitude" : 47.5703,
               "longitude" : -52.7318
            },
            "url" : "http://www.mun.ca/",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "value" : "ca",
                  "language" : "en"
               }
            ],
            "country" : "ca"
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Kamianets-Podilsky National Ivan Ohienko University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "value" : "ua",
                  "language" : "en"
               }
            ],
            "url" : "http://kpnu.edu.ua/",
            "location" : {
               "longitude" : 26.5868,
               "latitude" : 48.6751
            },
            "country" : "ua"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3169",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3169,
            "date_created" : "2015-03-11 13:11:15",
            "date_modified" : "2019-12-04 12:27:32",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages" : [
               "uk"
            ],
            "repository_status" : "technically_malfunctioning",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "notes" : "Інституційний репозитарій Кам'янець-Подільського національного університету ElarKPNU",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ],
            "content_types" : [
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "learning_objects",
               "other_special_item_types"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Technically Malfunctioning",
                  "language" : "en",
                  "value" : "technically_malfunctioning"
               }
            ],
            "oai_url" : "http://dspace.kpnu.edu.ua:8080/jspui/dspace-oai",
            "url" : "http://dspace.kpnu.edu.ua:8080/jspui/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is the Institutional Repository Kamenetz-Podolsk National University ElarKPNU. ElarKРNU, інституційний репозитарій Кам’янець-Подільського національного університету імені Івана Огієнка, базується на програмному забезпеченні DSpace.",
            "metadata_record_count" : 1687,
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "ElarKPNU: Electroniс Archive of Kamianets-Podilsky National Ivan Ohienko University",
                  "acronym" : "Електронний архів Кам'янець-Подільського національного університету імені Івана Огієнка",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3168,
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2015-03-11 12:33:51",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3168"
         },
         "organisation" : {
            "country" : "gb",
            "url" : "https://research.guildhe.ac.uk",
            "location" : {
               "longitude" : -0.1297,
               "latitude" : 51.5258
            },
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "CREST",
                  "name" : "Guild HE Research"
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "not_allowed",
                     "language" : "en",
                     "phrase" : "Not Allowed"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "some_or_all_restricted",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://collections.crest.ac.uk/policies.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "phrase" : "the original copyright statement is given",
                     "language" : "en",
                     "value" : "original_copyright_statement_required"
                  },
                  {
                     "language" : "en",
                     "value" : "original_rights_statement_required",
                     "phrase" : "the original rights permission statement is given"
                  },
                  {
                     "value" : "content_not_changed",
                     "language" : "en",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en",
                     "phrase" : "This repository is not the publisher; it is merely the online archive"
                  }
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "some_or_all_restricted",
                     "phrase" : "Access to some or all full items is restricted"
                  }
               ],
               "harvesting" : [
                  "not_allowed"
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "item_page" : [
                        "tombstone",
                        "link_to_replacement",
                        "explanation_of_withdrawal"
                     ],
                     "url_retention" : "trainsient",
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Transiently",
                           "language" : "en",
                           "value" : "trainsient"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "value" : "tombstone",
                           "language" : "en",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        },
                        {
                           "phrase" : "URLs will contain a link to a replacement version, where available",
                           "language" : "en",
                           "value" : "link_to_replacement"
                        },
                        {
                           "value" : "explanation_of_withdrawal",
                           "language" : "en",
                           "phrase" : "URLs will contain a note explaining the reasons for withdrawal"
                        }
                     ]
                  },
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "value" : "publisher_rules",
                        "language" : "en"
                     },
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request"
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ],
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "The items persistent URL will always link to the latest version",
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest"
                     },
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "value" : "link_between_versions",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "earlier_versions" : [
                     "persistent_urls_link_to_latest",
                     "link_between_versions"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               }
            },
            "submission_policy" : {
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "language" : "en",
                     "value" : "no_policy"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "language" : "en",
                     "value" : "policy_undefined"
                  }
               ],
               "url" : [
                  "http://collections.crest.ac.uk/policies.html"
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor"
            },
            "metadata_policy" : {
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://collections.crest.ac.uk/policies.html"
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "requires_permission",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "version_type_and_date",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://collections.crest.ac.uk/policies.html"
               ],
               "metadata" : [
                  "version_type_and_date",
                  "publication_status"
               ],
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "description" : "GuildHE Research Repositories is a joint repository for research outputs designed to capture the work of individuals and institutions who are Members of the Consortium for Research Excellence, Support and Training (CREST – visit www.crest.ac.uk for more information about the CREST community). In the spirit of interdisciplinary collaboration, it showcases research collectively across the institutions and specialist areas, including food security, agriculture, sustainable engineering, art, design, media, performing arts, health, sport, ageing, social welfare, education, the humanities and business studies.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.16"
            },
            "oai_url" : "https://repository.guildhe.ac.uk/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repository.guildhe.ac.uk",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "aggregating",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "GuildHE Research Repositories",
                  "acronym" : "CREST",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Software",
                  "value" : "software",
                  "language" : "en"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 12949,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "software",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "hu",
                  "language" : "en",
                  "phrase" : "Hungarian"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "hu",
               "en"
            ],
            "name" : [
               {
                  "name" : "SOE Repository of Dissertations",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 529,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "version" : "3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "Repository for Doctoral theses of the University of Sopron.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://doktori.nyme.hu/cgi/oai2",
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "http://doktori.nyme.hu/"
         },
         "system_metadata" : {
            "id" : 3167,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-10 16:52:20",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3167",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "University of Sopron",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 47.6817,
               "longitude" : 16.5845
            },
            "url" : "http://www.nyme.hu/",
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "language" : "en",
                  "value" : "hu"
               }
            ],
            "country" : "hu"
         },
         "policies" : {
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This is the institutional repository of Federal University Ndufu-Alike Ikwo, Ebonyi State, Nigeria.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1",
               "2",
               "17",
               "23",
               "10",
               "11"
            ],
            "url" : "http://dspace.funai.edu.ng/xmlui/",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "FEDERAL UNIVERSITY NDUFU-ALIKE IKWO REPOSITORY ARCHIVE"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "metadata_record_count" : 256,
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "FEDERAL UNIVERSITY NDUFU-ALIKE IKWO"
               }
            ],
            "country" : "ng",
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "value" : "ng",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 6.3333,
               "longitude" : 8.1
            },
            "url" : "http://www.funai.edu.ng/"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3165,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-10 16:01:27",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3165"
         }
      },
      {
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-10 15:38:04",
            "id" : 3164,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3164",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Universidad de Deusto",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "url" : "http://www.biblioteca.deusto.es/",
            "location" : {
               "longitude" : -2.9386,
               "latitude" : 43.2712
            }
         },
         "repository_metadata" : {
            "content_languages" : [
               "gl"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Galician",
                  "value" : "gl",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "oai_url" : "http://loyola.biblioteca.deusto.es/oai/request",
            "url" : "http://loyola.biblioteca.deusto.es/",
            "content_subjects" : [
               "20",
               "22"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "The Digital Library of Loyola allows access to the full text of digitised ancient books and documents from the Library University of Duetso and the Sanctualry of Loyola.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 1447,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteca Universitaria de Deusto - Repositorio Loyola"
               }
            ]
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Instituto Politécnico de Beja",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portugal"
               }
            ],
            "location" : {
               "latitude" : 38.0153,
               "longitude" : -7.8627
            },
            "url" : "http://www.ipbeja.pt/",
            "country" : "pt"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3163",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3163,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-10 14:47:04",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "pt"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "description" : "This is the dogital repository of Instituto Politécnico de Beja whInstituto Politécnico de Beja which contains the work of staff and students. Some items are not accessible without login.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "url" : "https://repositorio.ipbeja.pt/",
            "content_subjects" : [
               "2",
               "17",
               "8",
               "10",
               "25",
               "11"
            ],
            "oai_url" : "https://repositorio.ipbeja.pt/oai/request?verb=Identify/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 20,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Repositório Digital IPBeja",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 896
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3162",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-03-10 14:18:40",
            "id" : 3162
         },
         "organisation" : {
            "country" : "pt",
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 41.5454,
               "longitude" : -8.4265
            },
            "url" : "https://www.hospitaldebraga.pt/",
            "name" : [
               {
                  "name" : "Hospital de Braga",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "metadata_record_count" : 1132,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositório Científico do Hospital de Braga",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en",
               "pt"
            ],
            "url" : "http://repositorio.hospitaldebraga.pt/",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "this is the Institutional repository of the Hospital de Braga which was established with the aim of storing, centralize, promote and provide access to the scientific production of the institution in digital format.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "3.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://roam.macewan.ca/about/terms_of_use"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed"
               ],
               "withdrawal" : {
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "searchable" : "no"
                  },
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ]
               },
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "value" : "migrate_file_formats",
                     "language" : "en"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "value" : "unusual_files_not_guaranteed",
                     "language" : "en"
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed_for_indexing",
                  "allowed_for_citation_analysis"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "language" : "en",
                     "value" : "given_to_third_parties"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed_for_indexing",
                     "language" : "en",
                     "phrase" : "Allowed transiently for full-text indexing"
                  },
                  {
                     "phrase" : "Allowed transiently for citation analysis",
                     "value" : "allowed_for_citation_analysis",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study"
               ],
               "reuse_conditions" : [
                  "some_items_have_different_conditions"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "url" : [
                  "http://roam.macewan.ca/about/terms_of_use#access"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy"
            },
            "submission_policy" : {
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  }
               ],
               "url" : [
                  "http://roam.macewan.ca/about"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students"
               ],
               "rules" : [
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "value" : "full_texts_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://roam.macewan.ca/about/terms_of_use#content"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "false",
                  "standard_types_excluded" : [],
                  "special_types_excluded" : [
                     "administrative items"
                  ],
                  "standard_types_excluded_phrases" : []
               },
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "MacEwan University"
               }
            ],
            "location" : {
               "longitude" : -113.508,
               "latitude" : 53.5463
            },
            "url" : "http://macewan.ca/",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "country" : "ca"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3161,
            "date_created" : "2015-03-10 13:40:38",
            "date_modified" : "2019-10-17 14:34:52",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3161"
         },
         "repository_metadata" : {
            "content_subjects" : [
               "17",
               "18",
               "24",
               "10",
               "25"
            ],
            "url" : "http://roam.macewan.ca/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "value" : "25",
                  "language" : "en",
                  "phrase" : "Education"
               }
            ],
            "description" : "A digital collection of research, scholarship, and creative works by MacEwan University faculty, students, and staff.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "islandora",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "islandora",
                     "phrase" : "islandora"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1114,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Research Online at MacEwan",
                  "acronym" : "RO@M",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the institution. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.4.1"
            },
            "url" : "https://eprints.glos.ac.uk/",
            "oai_url" : "http://eprints.glos.ac.uk/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 2045,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "University of Gloucestershire, Research Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "software",
                  "phrase" : "Software"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 4881,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "software",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "year_established" : 2014
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "language" : "en",
                     "value" : "repository_mention_required"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "url" : [
                  "https://eprints.glos.ac.uk/policies.html"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "value" : "requires_permission",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "url" : [
                  "https://eprints.glos.ac.uk/policies.html"
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "peer_review_status",
                     "phrase" : "peer-review status"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ]
            },
            "submission_policy" : {
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  },
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "value" : "bibliographic_metadata_required",
                     "language" : "en"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://eprints.glos.ac.uk/policies.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal"
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "errata_may_be_included",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "https://eprints.glos.ac.uk/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  },
                  {
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "language" : "en",
                     "value" : "displayed_or_performed"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "https://eprints.glos.ac.uk/policies.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "value" : "content_not_changed",
                     "language" : "en"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3160",
            "publicly_visible" : "yes",
            "id" : 3160,
            "date_created" : "2015-02-27 14:33:37",
            "date_modified" : "2019-12-04 12:27:32"
         },
         "organisation" : {
            "location" : {
               "latitude" : 51.8994,
               "longitude" : -2.0783
            },
            "url" : "http://www.glos.ac.uk/Pages/default.aspx",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "University of Gloucestershire",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "value" : "by",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 27.5615,
               "latitude" : 53.9045
            },
            "url" : "http://www.bspu.by/",
            "country" : "by",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Belarusian State Pedagogical University named Maxim Tank"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3159,
            "date_created" : "2015-02-18 16:52:56",
            "date_modified" : "2019-10-17 14:34:52",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3159",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Biology and Biochemistry",
                  "language" : "en",
                  "value" : "4"
               },
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               },
               {
                  "value" : "21",
                  "language" : "en",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "value" : "8",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "ru"
            ],
            "name" : [
               {
                  "name" : "Belarusian State Pedagogical University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 10700,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "4.2"
            },
            "description" : "This site provides access to the research outputs of this institution. The interface is available in Russian.",
            "full_text_record_count" : 6030,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "4",
               "20",
               "21",
               "22",
               "8",
               "9",
               "24",
               "25",
               "26",
               "14",
               "29"
            ],
            "url" : "http://elib.bspu.by/",
            "oai_url" : "http://elib.bspu.by/oai/request"
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2015-02-10 13:14:52",
            "id" : 3158,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3158",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Cape Town",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "za",
            "url" : "http://www.uct.ac.za/",
            "unit" : [
               {
                  "name" : "University of Cape Town Libraries",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : -33.9579,
               "longitude" : 18.4601
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "za",
                  "phrase" : "South Africa"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "13",
                  "phrase" : "Civil Engineering"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "year_established" : 2014,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://open.uct.ac.za/",
            "content_subjects" : [
               "2",
               "17",
               "24",
               "10",
               "25",
               "26",
               "13"
            ],
            "oai_url" : "http://open.uct.ac.za/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "3.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research outputs of the institution.",
            "metadata_record_count" : 25689,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "OpenUCT"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://repository.thehealthwell.info/content/policies"
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "language" : "en",
                     "value" : "multi_institution_subject"
                  }
               ],
               "subjects" : [
                  "10"
               ],
               "repository_type" : "multi_institution_subject",
               "versions" : [
                  "submitted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "value" : "submitted_versions",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "metadata_phrases" : [
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://repository.thehealthwell.info/content/policies"
               ],
               "subjects_phrases" : [
                  {
                     "language" : "en",
                     "value" : "10",
                     "phrase" : "Health and Medicine"
                  }
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone",
                        "link_to_replacement",
                        "explanation_of_withdrawal"
                     ],
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        },
                        {
                           "value" : "link_to_replacement",
                           "language" : "en",
                           "phrase" : "URLs will contain a link to a replacement version, where available"
                        },
                        {
                           "language" : "en",
                           "value" : "explanation_of_withdrawal",
                           "phrase" : "URLs will contain a note explaining the reasons for withdrawal"
                        }
                     ]
                  }
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "language" : "en"
                     },
                     {
                        "phrase" : "The items persistent URL will always link to the latest version",
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://repository.thehealthwell.info/content/policies"
               ],
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repository.thehealthwell.info/content/policies"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "mentioning_the_repository_is_appreciated"
               ]
            },
            "submission_policy" : {
               "rules_phrases" : [
                  {
                     "phrase" : "Eligible depositors must deposit full texts of all their publications",
                     "value" : "full_texts_required",
                     "language" : "en"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "value" : "author_eligibility",
                     "language" : "en"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "full_texts_required"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "url" : [
                  "http://repository.thehealthwell.info/content/policies"
               ]
            }
         },
         "system_metadata" : {
            "id" : 3157,
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2014-12-09 16:46:28",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3157",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "ie",
                  "language" : "en",
                  "phrase" : "Ireland"
               }
            ],
            "location" : {
               "latitude" : 53.3419,
               "longitude" : -6.2577
            },
            "url" : "http://www.publichealth.ie/",
            "country" : "ie",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Institute of Public Health in Ireland",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "unpub_reports_and_working_papers",
               "datasets",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://repository.thehealthwell.info/oai",
            "url" : "http://repository.thehealthwell.info/",
            "content_subjects" : [
               "10"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Drupal",
                     "language" : "en",
                     "value" : "drupal"
                  }
               ],
               "name" : "drupal"
            },
            "description" : "This site provides access to health information. The majority of the content is metadata only, providing access to resources held externally. The interface is available in various languages.",
            "metadata_record_count" : 3672,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "All Ireland Public Health Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "governmental"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3156",
            "publicly_visible" : "yes",
            "id" : 3156,
            "date_created" : "2014-11-18 16:29:03",
            "date_modified" : "2019-10-17 14:34:52"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "BSUIR",
                  "name" : "Belarusian State University of Informatics and Radioelectronics"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "language" : "en",
                  "value" : "by"
               }
            ],
            "url" : "http://www.bsuir.by/",
            "location" : {
               "longitude" : 27.5937,
               "latitude" : 53.9188
            },
            "country" : "by"
         },
         "policies" : {
            "content_policy" : {
               "languages" : [
                  "en",
                  "ru"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "subjects" : [
                  "11",
                  "14",
                  "15"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Russian",
                     "value" : "ru",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://libeldoc.bsuir.by/help/OpenDOAR.html"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "value" : "version_type_and_date",
                     "language" : "en"
                  },
                  {
                     "phrase" : "peer-review status",
                     "language" : "en",
                     "value" : "peer_review_status"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "subjects_phrases" : [
                  {
                     "value" : "11",
                     "language" : "en",
                     "phrase" : "Technology General"
                  },
                  {
                     "phrase" : "Computers and IT",
                     "language" : "en",
                     "value" : "14"
                  },
                  {
                     "language" : "en",
                     "value" : "15",
                     "phrase" : "Electrical and Electronic Engineering"
                  }
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ]
            },
            "metadata_policy" : {
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "requires_permission",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "https://libeldoc.bsuir.by/help/OpenDOAR.html"
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "submission_policy" : {
               "url" : [
                  "https://libeldoc.bsuir.by/help/OpenDOAR.html"
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "value" : "migrate_file_formats",
                     "language" : "en"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed"
                  },
                  {
                     "value" : "software_emulation",
                     "language" : "en",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "value" : "publisher_rules",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Falsified research",
                        "language" : "en",
                        "value" : "falsified_research"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "indefinite"
                  },
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "deleted",
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ]
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "errata_may_be_included",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "earlier_versions_may_be_withdrawn",
                        "language" : "en",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     }
                  ],
                  "policy" : [
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "original_bitstream_retained",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed",
                  "software_emulation"
               ],
               "url" : [
                  "https://libeldoc.bsuir.by/help/OpenDOAR.html"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://libeldoc.bsuir.by/help/OpenDOAR.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed transiently for full-text indexing",
                     "language" : "en",
                     "value" : "allowed_for_indexing"
                  },
                  {
                     "phrase" : "Allowed transiently for citation analysis",
                     "language" : "en",
                     "value" : "allowed_for_citation_analysis"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting" : [
                  "allowed_for_indexing",
                  "allowed_for_citation_analysis"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "language" : "en",
                     "value" : "given_to_third_parties",
                     "phrase" : "given to third parties"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "version" : "3.2",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is an institutional repository of the Belarusian State University of Informatics and Radioelectronics. The interface is available in Russian and English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 16,
            "url" : "http://libeldoc.bsuir.by/",
            "oai_url" : "http://libeldoc.bsuir.by/oai/request",
            "content_subjects" : [
               "2",
               "21",
               "8",
               "9",
               "24",
               "28",
               "14"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Belarusian State University of Informatics and Radioelectronics Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 9287,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "value" : "21",
                  "language" : "en",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "language" : "en",
                  "value" : "9"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Management and Planning",
                  "language" : "en",
                  "value" : "28"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "ru",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2014-11-12 09:54:03",
            "id" : 3155,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3155"
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.sfasu.edu/",
            "location" : {
               "longitude" : -94.6469,
               "latitude" : 31.6212
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Stephen F. Austin State University"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "SFA ScholarWorks",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 8604,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name" : "other"
            },
            "description" : "This site is an institutional repository. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 3352,
            "content_subjects" : [
               "2",
               "17",
               "3",
               "18",
               "8",
               "24",
               "25"
            ],
            "oai_url" : "http://scholarworks.sfasu.edu/do/oai/",
            "url" : "http://scholarworks.sfasu.edu/",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 15437,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "ScholarWorks at Central Washington University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://digitalcommons.cwu.edu/",
            "content_subjects" : [
               "2",
               "17",
               "20",
               "24",
               "25"
            ],
            "oai_url" : "http://digitalcommons.cwu.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This is an institutional repository. The interface is available in English. Some content is not available as full-text.",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "value" : "25",
                  "language" : "en",
                  "phrase" : "Education"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "date_created" : "2014-10-24 09:25:02",
            "date_modified" : "2019-12-04 12:27:32",
            "id" : 3154,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3154",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "James E. Brooks Library",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.cwu.edu/",
            "location" : {
               "longitude" : -120.544,
               "latitude" : 47
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Central Washington University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "url" : "http://repository.neelain.edu.sd:8080/xmlui",
            "oai_url" : "http://repository.neelain.edu.sd:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This is the digital repository of Neelain University research. The interface is in English and Arabic and contains RSS feeds to alert users to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.6"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 10051,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Neelain Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3153",
            "publicly_visible" : "yes",
            "id" : 3153,
            "date_created" : "2014-08-28 09:56:40",
            "date_modified" : "2020-01-28 18:49:54"
         },
         "organisation" : {
            "country" : "sd",
            "country_phrases" : [
               {
                  "value" : "sd",
                  "language" : "en",
                  "phrase" : "Sudan"
               }
            ],
            "url" : "http://neelain.edu.sd",
            "location" : {
               "longitude" : 32.5145,
               "latitude" : 15.6026
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Al-Neelain University"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3152",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2014-08-26 12:13:03",
            "id" : 3152,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Imperial College London",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "https://www.imperial.ac.uk/",
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Imperial College Chemistry"
               }
            ],
            "location" : {
               "latitude" : 51.488,
               "longitude" : -0.172
            },
            "country" : "gb"
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "5",
                  "language" : "en",
                  "phrase" : "Chemistry and Chemical Technology"
               }
            ],
            "notes" : "Some files may need extra software to be read.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "datasets"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://spectradspace.lib.imperial.ac.uk:8443/oai/request?verb=Identify",
            "url" : "https://spectradspace.lib.imperial.ac.uk:8443/",
            "content_subjects" : [
               "5"
            ],
            "software" : {
               "version" : "1.8.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "Open Access repository for Chemistry. The interface is in English and includes RSS feeds to alert users to new content.",
            "metadata_record_count" : 161420,
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "name" : [
               {
                  "name" : "DSpace at Imperial College London",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "url" : "http://www.missouribotanicalgarden.org/",
            "location" : {
               "longitude" : -90.2629,
               "latitude" : 38.6169
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Missouri Botanical Garden",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3151",
            "publicly_visible" : "yes",
            "date_created" : "2014-08-26 11:41:14",
            "date_modified" : "2019-10-17 14:34:52",
            "id" : 3151
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "url" : [
                  "http://www.botanicus.org/Copyright.aspx"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "standard_types_allowed_phrases" : [
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "value" : "books_chapters_and_sections",
                        "language" : "en"
                     }
                  ],
                  "all" : "false",
                  "standard_types_allowed" : [
                     "books_chapters_and_sections"
                  ]
               }
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "de",
               "la",
               "es"
            ],
            "url" : "http://www.botanicus.org/",
            "content_subjects" : [
               "4"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ],
            "description" : "Botanicus is a freely accessible resource to historic botanical literature from the Missouri Botanical Garden Library. The interface is in English and it contains an RSS feed to alert users to new additions.",
            "metadata_record_count" : 2081,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               },
               {
                  "language" : "en",
                  "value" : "la",
                  "phrase" : "Latin"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Botanicus Digital Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "type" : "disciplinary"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "id"
            ],
            "name" : [
               {
                  "name" : "Digital Library of UIN Sunan Ampel",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 17199,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.12",
               "name" : "eprints"
            },
            "description" : "This is the Digital Library of UIN Sunan Ampel. The interface is in Indonesian and contains RSS feeds to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://digilib.uinsby.ac.id/",
            "oai_url" : "http://digilib.uinsby.ac.id/cgi/oai2",
            "content_subjects" : [
               "17",
               "22",
               "23",
               "26"
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "item_page_phrases" : [
                        {
                           "value" : "tombstone",
                           "language" : "en",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ]
                  },
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "value" : "software_emulation",
                     "language" : "en"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "language" : "en",
                     "value" : "original_bitstream_retained",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "language" : "en",
                        "value" : "errata_may_be_included"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "url" : [
                  "http://digilib.uinsby.ac.id/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy" : "transfer_to_appropriate_archive"
            },
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "url" : [
                  "http://digilib.uinsby.ac.id/policies.html"
               ],
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "language" : "en",
                     "value" : "given_to_third_parties",
                     "phrase" : "given to third parties"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "language" : "en",
                     "value" : "item_relevance",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "depositors" : [
                  "community_members"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "no_deposit_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items may not be deposited until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://digilib.uinsby.ac.id/policies.html"
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://digilib.uinsby.ac.id/policies.html"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "language" : "en",
                     "value" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://digilib.uinsby.ac.id/policies.html"
               ],
               "commercial_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required"
               ]
            }
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2014-08-26 11:11:01",
            "id" : 3150,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3150",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "UIN Sunan Ampel Surabaya"
               }
            ],
            "country" : "id",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Library UIN Sunan Ampel Surabaya",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.uinsby.ac.id/",
            "location" : {
               "longitude" : 112.714,
               "latitude" : -7.2535
            },
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Hungarian",
                  "value" : "hu",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "datasets"
            ],
            "content_languages" : [
               "hu"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "metadata_record_count" : 244,
            "type" : "disciplinary",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "KDK Repository"
               }
            ],
            "url" : "http://openarchive.tk.mta.hu/",
            "oai_url" : "http://openarchive.tk.mta.hu/cgi/oai2",
            "content_subjects" : [
               "23"
            ],
            "full_text_record_count" : 70,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "The Research Documentation Centre of the Centre for Social Sciences at the Hungarian Academy of Sciences provides information on and access to research conducted at the Centre. The metadata and some of the documents of the Research Documentation Centre (RDC) are available to all visitors, but many are restricted to registered users. The interface can be set to many languages and contains RSS feeds to alert users of new content.",
            "software" : {
               "version" : "3.3.12",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3149,
            "date_modified" : "2019-10-17 14:34:52",
            "date_created" : "2014-08-26 10:45:36",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3149"
         },
         "organisation" : {
            "country" : "hu",
            "location" : {
               "latitude" : 47.4979,
               "longitude" : 19.0402
            },
            "url" : "http://kdk.tk.mta.hu/",
            "country_phrases" : [
               {
                  "value" : "hu",
                  "language" : "en",
                  "phrase" : "Hungary"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Centre for Social Sciences, Hungarian Academy of Sciences",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Yahoo",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "us",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Flickr",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 37.3688,
               "longitude" : -122.036
            },
            "url" : "http://www.yahoo.com/company",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3148",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:32",
            "date_created" : "2014-08-22 16:33:17",
            "id" : 3148,
            "publicly_visible" : "yes"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse" : "individually_tagged",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "individually_tagged",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "url" : [
                  "https://www.flickr.com/commons/usage/"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "submission_policy" : {
               "url" : [
                  "https://www.flickr.com/commons/register/"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "https://www.flickr.com/commons/usage/"
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "multi_institution_subject",
                     "phrase" : "Multi-institution subject-based repository"
                  }
               ],
               "url" : [
                  "https://www.flickr.com/commons/usage/"
               ],
               "types_included" : {
                  "standard_types_allowed" : [
                     "other_special_item_types"
                  ],
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "value" : "other_special_item_types",
                        "language" : "en",
                        "phrase" : "Other Special Item Types"
                     }
                  ]
               },
               "repository_type" : "multi_institution_subject"
            }
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "History and Archaeology",
                  "language" : "en",
                  "value" : "20"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "notes" : "Users are invited to help catalogue these images by adding tags and leaving comments.",
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "year_established" : 2008,
            "description" : "This is a digital archive on flickr which shares images from the world's public photography archives which are all believed to have no known copyright restrictions. Participating Institutions include the Library of Congress, the British Library, the National Library of Wales, the Smithsonian Institute, Australian War Memorial collection and many others.",
            "software" : {
               "name_phrases" : []
            },
            "url" : "https://www.flickr.com/commons",
            "content_subjects" : [
               "20",
               "23",
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "aggregating",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "The Commons",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         }
      }
   ]
}

