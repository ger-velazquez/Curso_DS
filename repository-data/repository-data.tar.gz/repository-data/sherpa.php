<?php


for ($i=0;$i<5300;$i=$i+100) {
	echo "Downloading offset $i \n";
	$json = file_get_contents("https://v2.sherpa.ac.uk/cgi/retrieve?item-type=repository&format=Json&limit=100&offset=".$i."&order=-id&api-key=1BCC313A-F65C-11E9-B0C9-472934F985F6");
	file_put_contents("json_".$i.".php", $json);
}
?>
