{
   "items" : [
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.10"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Belgrade. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "24"
            ],
            "oai_url" : "http://rhinosec.fb.bg.ac.rs/oai/request",
            "url" : "http://rhinosec.fb.bg.ac.rs",
            "content_languages" : [
               "sr"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "RhinoSec - Repository of the Faculty of Security Studies"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "sr",
                  "phrase" : "Serbian"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "url" : [
                  "http://rhinosec.fb.bg.ac.rs/Files/policy-rhinosec-en.html"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse" : "allowed"
            },
            "content_policy" : {
               "languages" : [
                  "sr"
               ],
               "url" : [
                  "http://rhinosec.fb.bg.ac.rs/Files/policy-rhinosec-en.html"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "types_included" : {
                  "special_types_excluded" : [
                     "http://rhinosec.fb.bg.ac.rs/Files/policy-rhinosec-en.html"
                  ],
                  "standard_types_excluded_phrases" : [
                     {
                        "value" : "software",
                        "language" : "en",
                        "phrase" : "Software"
                     },
                     {
                        "phrase" : "Patents",
                        "value" : "patents",
                        "language" : "en"
                     }
                  ],
                  "all" : "false",
                  "standard_types_excluded" : [
                     "software",
                     "patents"
                  ]
               },
               "languages_phrases" : [
                  {
                     "value" : "sr",
                     "language" : "en",
                     "phrase" : "Serbian"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "preservation_policy" : {
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "url" : [
                  "http://rhinosec.fb.bg.ac.rs/Files/policy-rhinosec-en.html"
               ],
               "withdrawal" : {
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "publisher_rules",
                        "language" : "en",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "url_retention" : "indefinite"
                  }
               }
            },
            "data_policy" : {
               "url" : [
                  "http://rhinosec.fb.bg.ac.rs/Files/policy-rhinosec-en.html"
               ],
               "reuse_phrases" : [
                  {
                     "value" : "individually_tagged",
                     "language" : "en",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "individually_tagged"
            },
            "submission_policy" : {
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  },
                  {
                     "value" : "employees",
                     "language" : "en",
                     "phrase" : "Employees"
                  }
               ],
               "url" : [
                  "http://rhinosec.fb.bg.ac.rs/Files/policy-rhinosec-en.html"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9514",
            "publicly_visible" : "yes",
            "id" : 9514,
            "date_created" : "2020-02-03 09:19:33",
            "date_modified" : "2020-02-03 09:32:27"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Belgrade",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Универзитет у Београду",
                  "language_phrases" : [
                     {
                        "phrase" : "Serbian",
                        "value" : "sr",
                        "language" : "en"
                     }
                  ],
                  "language" : "sr"
               }
            ],
            "country" : "rs",
            "country_phrases" : [
               {
                  "phrase" : "Serbia",
                  "value" : "rs",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 44.8184,
               "longitude" : 20.4574
            },
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Faculty of Security Studies"
               }
            ],
            "url" : "http://fb.bg.ac.rs"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the Secretaría de Educación del Distrito Bogotá. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://repositoriosed.educacionbogota.edu.co/oai/request",
            "url" : "https://repositoriosed.educacionbogota.edu.co",
            "content_subjects" : [
               "25"
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional Secretaría de Educación del Distrito"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         },
         "organisation" : {
            "country" : "co",
            "location" : {
               "longitude" : -74.1019,
               "latitude" : 4.64978
            },
            "url" : "https://www.educacionbogota.edu.co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "name" : [
               {
                  "name" : "Secretaría de Educación del Distrito Bogotá"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2020-02-03 09:05:01",
            "date_modified" : "2020-02-03 09:07:37",
            "id" : 9513,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9513"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9512",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 9512,
            "date_created" : "2020-02-03 08:53:54",
            "date_modified" : "2020-02-03 08:58:48",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "at",
            "url" : "http://www.uni-mozarteum.at",
            "location" : {
               "latitude" : 47.8039,
               "longitude" : 13.0433
            },
            "country_phrases" : [
               {
                  "phrase" : "Austria",
                  "value" : "at",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Mozarteum University"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "language" : "de",
                  "name" : "Universität Mozarteum"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Institutional Repository of the Mozarteum University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Das Repositorium der Universität Mozarteum",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "17"
            ],
            "url" : "http://repository.moz.ac.at",
            "content_languages" : [
               "de"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Mozarteum University. The interface is available in English and German.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "de"
            ],
            "content_subjects" : [
               "18"
            ],
            "oai_url" : "https://zenodo.org/oai2d",
            "url" : "https://www.zenodo.org/communities/zhdk",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "version" : "Zenodo",
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "18",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "description" : "This site provides access to the research outputs of Zurich University of the Arts (Zürcher Hochschule der Künste).  The interface is available in English.",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "ZHdK Open Publications in the Arts Repository",
                  "acronym" : "ZOPAR"
               }
            ],
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "id" : 9511,
            "date_created" : "2020-02-03 08:44:08",
            "date_modified" : "2020-02-03 08:45:48",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9511",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "de",
            "location" : {
               "longitude" : 8.53556,
               "latitude" : 47.3828
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "name" : [
               {
                  "name" : "Zurich University of the Arts",
                  "acronym" : "ZHdK",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "Zürcher Hochschule der Künste",
                  "acronym" : "Zürcher Hochschule der Künste",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2020-02-03 08:14:25",
            "date_modified" : "2020-02-03 08:25:47",
            "id" : 9510,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9510",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "hr",
            "url" : "http://www.uaos.unios.hr",
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "The Academy of Arts and Culture in Osijek"
               },
               {
                  "language" : "hr",
                  "language_phrases" : [
                     {
                        "phrase" : "Croatian",
                        "value" : "hr",
                        "language" : "en"
                     }
                  ],
                  "name" : "Akademije za umjetnost i kulturu u Osijeku"
               }
            ],
            "location" : {
               "latitude" : 45.5587,
               "longitude" : 18.7054
            },
            "country_phrases" : [
               {
                  "value" : "hr",
                  "language" : "en",
                  "phrase" : "Croatia"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "UNIOS",
                  "name" : "University of Osijek"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "islandora",
                     "phrase" : "islandora"
                  }
               ],
               "name" : "islandora"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Osijek's Academy of Arts and Culture.  The interface is available in English and Bosnian.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "https://repozitorij.aukos.unios.hr",
            "content_subjects" : [
               "17"
            ],
            "oai_url" : "https://repozitorij.aukos.unios.hr/oai",
            "content_languages" : [
               "hr"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Repository of the Academy of Arts and Culture in Osijek"
               },
               {
                  "name" : "Repozitorij Akademije za umjetnost i kulturu u Osijeku",
                  "language" : "hr",
                  "language_phrases" : [
                     {
                        "phrase" : "Croatian",
                        "language" : "en",
                        "value" : "hr"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Croatian",
                  "language" : "en",
                  "value" : "hr"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.0",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Unidad de Planeación Minero Energética.  The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "11"
            ],
            "url" : "https://bdigital.upme.gov.co",
            "oai_url" : "https://bdigital.upme.gov.co",
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "acronym" : "Repositorio UMPE",
                  "name" : "Repositorio Unidad de Planeación Minero Energética",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es"
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Unidad de Planeación Minero Energética",
                  "acronym" : "UMPE"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "url" : "https://www1.upme.gov.co",
            "location" : {
               "longitude" : -74.1102,
               "latitude" : 4.66156
            },
            "country" : "co"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9508",
            "publicly_visible" : "yes",
            "date_modified" : "2020-01-30 08:52:23",
            "date_created" : "2020-01-30 08:50:12",
            "id" : 9508
         }
      },
      {
         "organisation" : {
            "country" : "co",
            "location" : {
               "latitude" : 4.78222,
               "longitude" : -74.0439
            },
            "url" : "https://www.escuelaing.edu.co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "name" : [
               {
                  "name" : "Escuela Colombiana de Ingeniería Julio Garavito",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2020-01-30 08:41:00",
            "date_modified" : "2020-01-30 08:43:14",
            "id" : 9507,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9507",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio de Escuela Colombiana de Ingeniería Julio Garavito"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "13",
                  "language" : "en",
                  "phrase" : "Civil Engineering"
               },
               {
                  "value" : "15",
                  "language" : "en",
                  "phrase" : "Electrical and Electronic Engineering"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Escuela Colombiana de Ingeniería Julio Garavito. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "CRIS-5.8.0",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "url" : "https://repositorio.escuelaing.edu.co",
            "oai_url" : "https://repositorio.escuelaing.edu.co/oai/request",
            "content_subjects" : [
               "13",
               "15",
               "16"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "DSpace@KKU Kirikkale",
                  "name" : "Kırıkkale Üniversitesi Akademik Arşiv Sistemi",
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.4 SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Kırıkkale Üniversitesi. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://acikerisim.kku.edu.tr/oai/request",
            "url" : "http://acikerisim.kku.edu.tr/xmlui/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "tr"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9506",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9506,
            "date_created" : "2020-01-29 09:07:46",
            "date_modified" : "2020-01-29 09:09:12",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "tr",
            "location" : {
               "latitude" : 39.874,
               "longitude" : 33.4461
            },
            "url" : "https://kku.edu.tr",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "name" : [
               {
                  "name" : "Kırıkkale Üniversitesi",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ar",
               "en"
            ],
            "url" : "https://dspace.alquds.edu",
            "oai_url" : "https://dspace.alquds.edu/oai/request",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of Al-Quds University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Arabic"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Al-Quds University Digital Repository"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "date_modified" : "2020-01-29 09:01:31",
            "date_created" : "2020-01-29 08:59:06",
            "id" : 9505,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9505",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.alquds.edu",
            "location" : {
               "longitude" : 35.261,
               "latitude" : 31.7571
            },
            "country_phrases" : [
               {
                  "phrase" : "Palestine, State of",
                  "language" : "en",
                  "value" : "ps"
               }
            ],
            "country" : "ps",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Al-Quds University"
               },
               {
                  "language" : "ar",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ar",
                        "phrase" : "Arabic"
                     }
                  ],
                  "name" : "جامعة القدس"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "http://www.unsm.edu.pe",
            "location" : {
               "latitude" : -6.503,
               "longitude" : -76.3806
            },
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Nacional de San Martin",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9504,
            "date_created" : "2020-01-29 08:53:54",
            "date_modified" : "2020-01-29 08:55:34",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9504"
         },
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "oai_url" : "http://repositorio.unsm.edu.pe/oai/request",
            "url" : "http://repositorio.unsm.edu.pe",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de San Martín - Tarapoto. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Universidad Nacional de San Martín - Tarapoto"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9503,
            "date_modified" : "2020-01-28 18:26:55",
            "date_created" : "2020-01-28 18:25:13",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9503"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Waikato"
               }
            ],
            "country" : "nz",
            "country_phrases" : [
               {
                  "value" : "nz",
                  "language" : "en",
                  "phrase" : "New Zealand"
               }
            ],
            "unit" : [
               {
                  "name" : "Department of Computer Science",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : -37.7869,
               "longitude" : 175.314
            },
            "url" : "https://www.waikato.ac.nz"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "The New Zealand Digital Library",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               }
            ],
            "description" : "The New Zealand Digital Library project is a research programme at The University of Waikato.  The library contains several document collections, including historical documents, humanitarian and development information, computer science technical reports and bibliographies, literary works, and magazines.  The interface is available in English.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "17",
               "23",
               "14"
            ],
            "url" : "http://puka.cs.waikato.ac.nz",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               },
               {
                  "phrase" : "Civil Engineering",
                  "language" : "en",
                  "value" : "13"
               },
               {
                  "phrase" : "Electrical and Electronic Engineering",
                  "language" : "en",
                  "value" : "15"
               },
               {
                  "phrase" : "Mechanical Engineering and Materials",
                  "value" : "16",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad de los Llanos.  The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "https://repositorio.unillanos.edu.co",
            "content_subjects" : [
               "17",
               "10",
               "3",
               "24",
               "25",
               "13",
               "15",
               "16"
            ],
            "oai_url" : "https://repositorio.unillanos.edu.co/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Universidad de los Llanos",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               },
               {
                  "name" : "Digital Repository of Universidad de los Llanos",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "location" : {
               "longitude" : -73.5852,
               "latitude" : 4.075
            },
            "url" : "https://www.unillanos.edu.co",
            "country" : "co",
            "name" : [
               {
                  "name" : "Universidad de los Llanos",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9501,
            "date_modified" : "2020-01-27 10:27:51",
            "date_created" : "2020-01-27 10:21:01",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9501"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9498",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9498,
            "date_created" : "2020-01-23 09:40:23",
            "date_modified" : "2020-01-23 09:45:42",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "IBERO",
                  "name" : "Corporación Universitaria Iberoamericana"
               }
            ],
            "country" : "co",
            "location" : {
               "latitude" : 4.65011,
               "longitude" : -74.057
            },
            "url" : "https://www.ibero.edu.co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ]
         },
         "repository_metadata" : {
            "url" : "http://repositorio.iberoamericana.edu.co",
            "oai_url" : "http://repositorio.iberoamericana.edu.co/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Corporación Universitaria Iberoamericana. The interface is available in English and Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional - Corporación Universitaria Iberoamericana",
                  "acronym" : "Repositorio Institucional - IBERO",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9497",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9497,
            "date_created" : "2020-01-23 09:18:26",
            "date_modified" : "2020-01-23 09:20:41",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de",
                  "acronym" : "HRW",
                  "name" : "Hochschule Ruhr West"
               }
            ],
            "country" : "de",
            "location" : {
               "latitude" : 51.4275,
               "longitude" : 6.85882
            },
            "url" : "https://www.hochschule-ruhr-west.de",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de",
                  "acronym" : "HRW",
                  "name" : "HochschulRepositoriumimWesten"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "description" : "This site provides access to the research outputs of Hochschule Ruhr West. Users may set up RSS feeds to be alerted to new content. The interface is available in English and German.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "OPUS",
                     "value" : "opus",
                     "language" : "en"
                  }
               ],
               "name" : "opus"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "oai_url" : "https://repositorium.hs-ruhrwest.de/oai",
            "url" : "https://repositorium.hs-ruhrwest.de",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "KrimPub - Publication Server of the Centre for Criminology"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "language" : "de",
                  "name" : "KrimPub - Dokumentenserver der Kriminologischen Zentralstelle"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://krimpub.krimz.de/oai",
            "content_subjects" : [
               "26",
               "29"
            ],
            "url" : "https://krimpub.krimz.de",
            "content_languages" : [
               "de"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "OPUS",
                     "language" : "en",
                     "value" : "opus"
                  }
               ],
               "name" : "opus"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "description" : "The document server KrimPub, operated by the Centre for Criminology (KrimZ) , is a platform for publishing digital documents that originate from the KrimZ as well as from German justice administrations and related institutions, bear relevance to criminological research and documentation.  The interface is available in English and German."
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9496",
            "publicly_visible" : "yes",
            "date_created" : "2020-01-23 09:08:15",
            "date_modified" : "2020-01-23 09:11:10",
            "id" : 9496
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de",
                  "name" : "Kriminologische Zentralstelle"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "longitude" : 8.2499,
               "latitude" : 50.0741
            },
            "url" : "https://www.krimz.de",
            "country" : "de"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Digitaler Lesesaal zur Staedtepartnerschaft Ludwigsburg und Montbéliard",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ]
               },
               {
                  "name" : "Jumelage Montbéliard-Ludwigsburg: Salle de lecture en ligne",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "language" : "en",
                        "value" : "fr"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research resources from the Deutsch-Französisches Institut (dfi). The interface is available in French and German.",
            "software" : {
               "name" : "opus",
               "name_phrases" : [
                  {
                     "phrase" : "OPUS",
                     "value" : "opus",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "fr",
               "de"
            ],
            "content_subjects" : [
               "19",
               "20"
            ],
            "oai_url" : "https://ludwigsburg-montbeliard.bsz-bw.de/oai",
            "url" : "https://ludwigsburg-montbeliard.bsz-bw.de",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9495",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2020-01-23 08:59:43",
            "date_created" : "2020-01-22 16:43:12",
            "id" : 9495,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "latitude" : 48.8976,
               "longitude" : 9.18521
            },
            "url" : "https://www.dfi.de",
            "country" : "de",
            "name" : [
               {
                  "name" : "Deutsch-Französisches Institut",
                  "acronym" : "dfi",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ]
               },
               {
                  "name" : "Institut Franco-Allemand",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "location" : {
               "latitude" : 8.78778,
               "longitude" : -75.8578
            },
            "url" : "https://www.unicordoba.edu.co",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad de Córdoba"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9494",
            "publicly_visible" : "yes",
            "id" : 9494,
            "date_modified" : "2020-01-22 09:04:42",
            "date_created" : "2020-01-22 08:59:14"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio de la Universidad de Córdoba"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad de Córdoba. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "https://repositorio.unicordoba.edu.co",
            "oai_url" : "https://repositorio.unicordoba.edu.co/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "rs",
                  "language" : "en",
                  "phrase" : "Serbia"
               }
            ],
            "location" : {
               "latitude" : 44.8051,
               "longitude" : 20.4736
            },
            "country" : "rs",
            "name" : [
               {
                  "name" : "Jewish Digital Library Association",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Јеврејска дигитална библиотека",
                  "language_phrases" : [
                     {
                        "phrase" : "Serbian",
                        "language" : "en",
                        "value" : "sr"
                     }
                  ],
                  "language" : "sr"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9493,
            "date_modified" : "2020-01-22 08:51:17",
            "date_created" : "2020-01-22 08:48:46",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9493",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.10",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "value" : "22",
                  "language" : "en"
               }
            ],
            "description" : "The Jewish Digital Library Association is non-governmental and non-profit association founded to collect, present, promote and preserve the general Jewish religious and world heritage, culture, literature, history, language and in particular, to promote various library materials and literature about the Holocaust.  The interface is available in English and Serbian.",
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "20",
               "21",
               "22"
            ],
            "oai_url" : "http://jevrejskadigitalnabiblioteka.rs/oai/request",
            "url" : "http://jevrejskadigitalnabiblioteka.rs",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Jewish Digital Library"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "sr",
                        "language" : "en",
                        "phrase" : "Serbian"
                     }
                  ],
                  "language" : "sr",
                  "name" : "Јеврејска дигитална библиотека"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2020-01-22 08:38:43",
            "date_modified" : "2020-01-22 08:40:56",
            "id" : 9492,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9492"
         },
         "organisation" : {
            "location" : {
               "latitude" : 36.3759,
               "longitude" : 127.386
            },
            "url" : "https://www.ibs.re.kr",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "IBS",
                  "name" : "Institute for Basic Science",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               },
               {
                  "name" : "기초과학연구원",
                  "language" : "ko",
                  "language_phrases" : [
                     {
                        "value" : "ko",
                        "language" : "en",
                        "phrase" : "Korean"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Institute for Basic Science (IBS). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "2"
            ],
            "url" : "https://pr.ibs.re.kr",
            "oai_url" : "https://pr.ibs.re.kr/oai/request",
            "name" : [
               {
                  "name" : "IBS Publications Repository"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Çukurova University Institutional Repository",
                  "acronym" : "DSpace@Çukuorva",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "acronym" : "DSpace@Çukuorva",
                  "name" : "Çukurova Üniversitesi Akademik Arşiv Sistemi",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "tr"
               }
            ],
            "oai_url" : "http://openaccess.cu.edu.tr/oai/request",
            "url" : "http://openaccess.cu.edu.tr",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "tr"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of Çukurova University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "6.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Çukurova University"
               },
               {
                  "name" : "Çukurova Üniversitesi",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "value" : "tr",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "url" : "https://www.cu.edu.tr",
            "location" : {
               "longitude" : 35.3549,
               "latitude" : 37.0594
            }
         },
         "system_metadata" : {
            "id" : 9491,
            "date_modified" : "2020-01-20 08:43:17",
            "date_created" : "2020-01-20 08:41:42",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9491",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Bayburt University Institutional Repository",
                  "acronym" : "DSpace@Bayburt",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred" : "acronym",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Bayburt Üniversitesi Akademik Arşiv Sistemi",
                  "acronym" : "DSpace@Bayburt"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Bayburt University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "oai_url" : "https://openaccess.bayburt.edu.tr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://openaccess.bayburt.edu.tr",
            "content_languages" : [
               "en",
               "tr"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9489",
            "publicly_visible" : "yes",
            "date_created" : "2020-01-17 15:57:49",
            "date_modified" : "2020-01-19 13:55:27",
            "id" : 9489
         },
         "organisation" : {
            "url" : "https://www.bayburt.edu.tr",
            "location" : {
               "longitude" : 40.2307,
               "latitude" : 40.2511
            },
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "country" : "tr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Bayburt University"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ],
                  "language" : "tr",
                  "name" : "Bayburt Üniversitesi"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositório Institucional da Universidade do Estado do Amazonas",
                  "acronym" : "Repositório Institucional UEA",
                  "preferred" : "name",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.0",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research outputs of the Universidade do Estado do Amazonas. The interface is available in English, Portuguese and Dutch.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorioinstitucional.uea.edu.br",
            "content_subjects" : [
               "17"
            ],
            "oai_url" : "http://repositorioinstitucional.uea.edu.br/oai/request",
            "content_languages" : [
               "pt"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9488,
            "date_created" : "2020-01-14 12:01:33",
            "date_modified" : "2020-01-14 12:05:18",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9488"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "http://www1.uea.edu.br",
            "location" : {
               "longitude" : -67.3324,
               "latitude" : -8.77624
            },
            "country" : "br",
            "name" : [
               {
                  "name" : "Universidade do Estado do Amazonas",
                  "acronym" : "UEA",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "pt",
                        "phrase" : "Portuguese"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Banco de España"
               }
            ],
            "country" : "es",
            "url" : "https://www.bde.es",
            "location" : {
               "latitude" : 40.4183,
               "longitude" : -3.69472
            },
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2020-01-14 11:40:01",
            "date_created" : "2020-01-14 11:35:29",
            "id" : 9487,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9487"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Biblioteca del Banco de España",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "url" : "https://repositorio.bde.es",
            "oai_url" : "https://repositorio.bde.es/oai/request",
            "content_subjects" : [
               "24"
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Banco de España. The interface is available in English and Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "rules" : [
                  "bibliographic_metadata_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "rules_phrases" : [
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted"
                  }
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "url" : [
                  "https://brts.md/wp-content/uploads/2019/05/Politica_Acces_INCE_RI_englez-2.pdf"
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "https://brts.md/wp-content/uploads/2019/05/Politica_Acces_INCE_RI_englez-2.pdf"
               ],
               "types_included" : {
                  "special_types_allowed" : [
                     "Didactic documents"
                  ],
                  "standard_types_allowed" : [
                     "journal_articles",
                     "conference_and_workshop_papers",
                     "theses_and_dissertations",
                     "books_chapters_and_sections",
                     "other_special_item_types"
                  ],
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "phrase" : "Journal Articles",
                        "value" : "journal_articles",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Conference and Workshop Papers",
                        "language" : "en",
                        "value" : "conference_and_workshop_papers"
                     },
                     {
                        "phrase" : "Theses and Dissertations",
                        "value" : "theses_and_dissertations",
                        "language" : "en"
                     },
                     {
                        "value" : "books_chapters_and_sections",
                        "language" : "en",
                        "phrase" : "Books, Chapters and Sections"
                     },
                     {
                        "phrase" : "Other Special Item Types",
                        "language" : "en",
                        "value" : "other_special_item_types"
                     }
                  ]
               },
               "repository_type" : "institutional_or_departmental"
            }
         },
         "system_metadata" : {
            "id" : 9486,
            "date_created" : "2020-01-10 12:17:14",
            "date_modified" : "2020-01-10 12:28:27",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9486",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "md",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "md",
                  "phrase" : "Moldova"
               }
            ],
            "url" : "https://ince.md",
            "location" : {
               "longitude" : 28.7986,
               "latitude" : 47.0287
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "NIER",
                  "name" : "National Institute for Economic Research",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "acronym" : "INCE",
                  "name" : "Institutul Național de Cercetări Economice",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Romanian",
                        "value" : "ro",
                        "language" : "en"
                     }
                  ],
                  "language" : "ro",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repository Socio-Economic Sciences - National Institute for Economic Research",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "ro",
                  "language" : "en",
                  "phrase" : "Romanian"
               },
               {
                  "value" : "ru",
                  "language" : "en",
                  "phrase" : "Russian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "description" : "This site provides access to the research outputs of the National Institute for Economic Research. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "ro",
               "ru"
            ],
            "oai_url" : "http://dspace.ince.md/oai/request",
            "content_subjects" : [
               "24"
            ],
            "url" : "http://dspace.ince.md",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Beilstein Archives"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://www.beilstein-archives.org",
            "content_subjects" : [
               "4",
               "5",
               "9"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Belstein Publishing System",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Biology and Biochemistry",
                  "value" : "4",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "5",
                  "phrase" : "Chemistry and Chemical Technology"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "value" : "9",
                  "language" : "en"
               }
            ],
            "description" : "This is a free archive and distribution service for unpublished preprints in the fields of organic chemistry and nanotechnology. It is managed and funded by the Beilstein-Institut, A non-profit institute dedicated to the advancement of the chemical sciences. Users may set up eAlerts or an RSS feed to be alerted about new content. The interface is in English."
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9484",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2020-01-09 10:51:51",
            "date_modified" : "2020-01-13 09:19:13",
            "id" : 9484,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "location" : {
               "latitude" : 50.126,
               "longitude" : 8.62508
            },
            "url" : "https://www.beilstein-institut.de",
            "country" : "de",
            "name" : [
               {
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "name" : "Beilstein-Institut"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "standard_reasons" : [
                     "publisher_rules",
                     "legal_requirement_proven",
                     "other"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "value" : "publisher_rules",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "other",
                        "language" : "en",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "withdrawn_items" : {
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ]
                  },
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder but this is strongly discouraged",
                        "value" : "removal_at_request_discouraged",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request_discouraged",
                  "method" : "deleted",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are deleted entirely from the database",
                        "language" : "en",
                        "value" : "deleted"
                     }
                  ]
               },
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "version_control" : {
                  "earlier_versions" : [
                     "link_between_versions"
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "language" : "en",
                        "value" : "link_between_versions"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ]
               },
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "url" : [
                  "https://www.portico.org/our-work/preservation-approach",
                  "https://www.portico.org/wp-content/uploads/2017/12/Portico-Content-Modification-and-Deletion-Policy.pdf"
               ]
            }
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : 51.5248,
               "longitude" : -0.133583
            },
            "url" : "https://www.ucl.ac.uk",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "acronym" : "UCL",
                  "name" : "University College London",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9483",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9483,
            "date_created" : "2020-01-08 09:09:17",
            "date_modified" : "2020-01-08 09:14:02",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://rdr.ucl.ac.uk",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Figshare"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to datsets from University College London (UCL). The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "acronym" : "UCL RDR",
                  "name" : "University College London Research Data Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "content_types" : [
               "datasets"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2020-01-06 09:23:59",
            "date_created" : "2020-01-06 09:19:03",
            "id" : 9480,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9480",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ae",
            "url" : "https://www.aus.edu",
            "location" : {
               "latitude" : 25.3097,
               "longitude" : 55.4906
            },
            "country_phrases" : [
               {
                  "value" : "ae",
                  "language" : "en",
                  "phrase" : "United Arab Emirates"
               }
            ],
            "name" : [
               {
                  "name" : "American University of Sharjah",
                  "acronym" : "AUS",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "url" : [
                  "https://dspace.aus.edu:8443/xmlui/page/submission-policies"
               ],
               "depositors_phrases" : [
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ]
            }
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "DSpace at AUS",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "https://dspace.aus.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "American University of Sharjah\r\n\r\nThis site provides access to the research outputs of the American University of Sharjah. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "url" : "https://www.erbakan.edu.tr",
            "location" : {
               "longitude" : 32.4317,
               "latitude" : 37.8573
            },
            "country" : "tr",
            "name" : [
               {
                  "name" : "Necmettin Erbakan University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ],
                  "name" : "Necmettin Erbakan Üniversitesi"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2020-01-06 08:39:47",
            "date_modified" : "2020-01-06 09:06:13",
            "id" : 9479,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9479"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://acikerisim.erbakan.edu.tr",
            "oai_url" : "https://acikerisim.erbakan.edu.tr/oai/request",
            "content_languages" : [
               "en",
               "tr"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of Necmettin Erbakan University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "name" : [
               {
                  "acronym" : "DSpace@Erbakan",
                  "name" : "Necmettin Erbakan University Institutional Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "name" : "Necmettin Erbakan Üniversitesi Akademik Arşiv Sistemi",
                  "acronym" : "DSpace@Erbakan"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Siirt University"
               },
               {
                  "name" : "Siirt Üniversitesi",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr"
               }
            ],
            "country" : "tr",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "url" : "http://www.siirt.edu.tr",
            "location" : {
               "longitude" : 41.8502,
               "latitude" : 37.9631
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2020-01-06 08:28:04",
            "date_modified" : "2020-01-06 08:32:47",
            "id" : 9478,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9478"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Siirt University Institutional Repository",
                  "acronym" : "DSpace@Siirt",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr",
                  "preferred" : "name",
                  "acronym" : "DSpace@Siirt",
                  "name" : "Siirt Üniversitesi Akademik Arşiv Sistemi",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en",
               "tr"
            ],
            "content_subjects" : [
               "18",
               "22",
               "10",
               "3",
               "24",
               "25",
               "28",
               "13",
               "15",
               "16"
            ],
            "url" : "https://acikerisim.siirt.edu.tr",
            "oai_url" : "https://acikerisim.siirt.edu.tr/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of Siirt University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "value" : "22",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "value" : "28",
                  "language" : "en",
                  "phrase" : "Management and Planning"
               },
               {
                  "language" : "en",
                  "value" : "13",
                  "phrase" : "Civil Engineering"
               },
               {
                  "phrase" : "Electrical and Electronic Engineering",
                  "language" : "en",
                  "value" : "15"
               },
               {
                  "language" : "en",
                  "value" : "16",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "acronym" : "DSpace@Medipol",
                  "name" : "İstanbul Medipol University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "tr",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "DSpace@Medipol",
                  "name" : "İstanbul Medipol Üniversitesi Akademik Arşiv Sistemi"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en",
               "tr"
            ],
            "content_subjects" : [
               "18",
               "10",
               "2",
               "23",
               "11"
            ],
            "oai_url" : "https://acikerisim.medipol.edu.tr/oai/request",
            "url" : "https://acikerisim.medipol.edu.tr",
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of İstanbul Medipol University. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 41.091,
               "longitude" : 29.0914
            },
            "url" : "https://www.medipol.edu.tr",
            "country" : "tr",
            "name" : [
               {
                  "name" : "İstanbul Medipol University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "İstanbul Medipol Üniversitesi",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9477",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2020-01-06 08:20:02",
            "date_created" : "2020-01-06 08:14:41",
            "id" : 9477,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Management and Planning",
                  "value" : "28",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Le Cordon Bleu. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "url" : "http://repositorio.ulcb.edu.pe",
            "content_subjects" : [
               "24",
               "28"
            ],
            "oai_url" : "http://repositorio.ulcb.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Universidad Le Cordon Bleu",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9476,
            "date_created" : "2020-01-02 12:45:09",
            "date_modified" : "2020-01-02 12:47:23",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9476"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "url" : "https://www.ulcb.edu.pe",
            "location" : {
               "latitude" : -12.0986,
               "longitude" : -77.0563
            },
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Le Cordon Bleu"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 9474,
            "date_created" : "2020-01-02 12:19:17",
            "date_modified" : "2020-01-02 12:22:03",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9474",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "FH Vorarlberg - University of Applied Sciences",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "https://www.fhv.at",
            "location" : {
               "longitude" : 9.74418,
               "latitude" : 47.4061
            },
            "country_phrases" : [
               {
                  "phrase" : "Austria",
                  "value" : "at",
                  "language" : "en"
               }
            ],
            "country" : "at"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "name" : "Online Publikationsserver der FH Vorarlberg"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "url" : "https://opus.fhv.at",
            "software" : {
               "version" : "4.6.3",
               "name" : "opus",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "opus",
                     "phrase" : "OPUS"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Fachhochschule Vorarlberg, University of Applied Sciences. Users may set up RSS feeds to be alerted to new content. The interface is available in German."
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://183.82.11.228:8282/jspui",
            "oai_url" : "http://183.82.11.228:8282/oai/request",
            "content_subjects" : [
               "10"
            ],
            "software" : {
               "version" : "5.10.0 - SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Deccan College of Medical Sciences. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Deccan College of Medical Sciences - CRIS",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country" : "in",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "in",
                  "phrase" : "India"
               }
            ],
            "url" : "http://deccancollegeofmedicalsciences.com",
            "location" : {
               "longitude" : 78.4918,
               "latitude" : 17.3465
            },
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Deccan College of Medical Sciences"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2020-01-02 11:12:43",
            "date_modified" : "2020-01-03 10:45:50",
            "id" : 9470,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9470"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Figshare"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research datasets from The University of Sheffield.  The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://orda.shef.ac.uk/",
            "content_subjects" : [
               "17",
               "10",
               "2",
               "23",
               "11"
            ],
            "url" : "https://orda.shef.ac.uk/",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Online Research Data",
                  "acronym" : "ORDA",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "datasets"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               }
            ]
         },
         "organisation" : {
            "country" : "gb",
            "location" : {
               "latitude" : 53.3836,
               "longitude" : -1.4879
            },
            "url" : "https://www.sheffield.ac.uk",
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "The University of Sheffield"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2020-01-02 11:00:23",
            "date_created" : "2020-01-02 10:58:47",
            "id" : 9469,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9469",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "subjects" : [
                  "13",
                  "15",
                  "16"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "standard_types_excluded" : [
                     "datasets",
                     "learning_objects",
                     "software",
                     "patents"
                  ],
                  "all" : "false",
                  "standard_types_excluded_phrases" : [
                     {
                        "value" : "datasets",
                        "language" : "en",
                        "phrase" : "Datasets"
                     },
                     {
                        "phrase" : "Learning Objects",
                        "language" : "en",
                        "value" : "learning_objects"
                     },
                     {
                        "language" : "en",
                        "value" : "software",
                        "phrase" : "Software"
                     },
                     {
                        "language" : "en",
                        "value" : "patents",
                        "phrase" : "Patents"
                     }
                  ]
               },
               "url" : [
                  "https://www.dora.lib4ri.ch/psi/dora_content_policy"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Civil Engineering",
                     "language" : "en",
                     "value" : "13"
                  },
                  {
                     "value" : "15",
                     "language" : "en",
                     "phrase" : "Electrical and Electronic Engineering"
                  },
                  {
                     "language" : "en",
                     "value" : "16",
                     "phrase" : "Mechanical Engineering and Materials"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "https://www.dora.lib4ri.ch/psi/dora_content_policy"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "url" : [
                  "https://www.dora.lib4ri.ch/psi/dora_content_policy"
               ]
            },
            "submission_policy" : {
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "academic_staff",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility"
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Employees",
                     "language" : "en",
                     "value" : "employees"
                  }
               ],
               "url" : [
                  "https://www.dora.lib4ri.ch/psi/dora_content_policy"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9468",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2020-01-02 10:32:13",
            "date_created" : "2020-01-02 10:29:06",
            "id" : 9468,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "https://www.psi.ch",
            "location" : {
               "longitude" : 8.2297,
               "latitude" : 47.5391
            },
            "country_phrases" : [
               {
                  "phrase" : "Switzerland",
                  "language" : "en",
                  "value" : "ch"
               }
            ],
            "country" : "ch",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "PSI",
                  "name" : "Paul Scherrer Institute",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "islandora",
                     "language" : "en",
                     "phrase" : "islandora"
                  }
               ],
               "name" : "islandora"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Civil Engineering",
                  "value" : "13",
                  "language" : "en"
               },
               {
                  "value" : "15",
                  "language" : "en",
                  "phrase" : "Electrical and Electronic Engineering"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "description" : "This site provides access to the research outputs of the Paul Scherrer Institute (PSI). The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "13",
               "15",
               "16"
            ],
            "url" : "https://www.dora.lib4ri.ch/psi",
            "oai_url" : "https://www.dora.lib4ri.ch/psi/oai2",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Digital Object Repository at PSI",
                  "acronym" : "DORA PSI",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "DORA WSL",
                  "name" : "Digital Object Repository at WSL",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Swiss Federal Institute for Forest, Snow and Landscape Research (WSL). The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "islandora",
                     "value" : "islandora",
                     "language" : "en"
                  }
               ],
               "name" : "islandora"
            },
            "content_subjects" : [
               "7"
            ],
            "url" : "https://www.dora.lib4ri.ch/wsl",
            "oai_url" : "https://www.dora.lib4ri.ch/wsl/oai2",
            "content_languages" : [
               "en",
               "fr",
               "de"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en",
                  "fr",
                  "de"
               ],
               "subjects" : [
                  "7"
               ],
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  },
                  {
                     "language" : "en",
                     "value" : "fr",
                     "phrase" : "French"
                  },
                  {
                     "phrase" : "German",
                     "value" : "de",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "standard_types_excluded_phrases" : [
                     {
                        "value" : "datasets",
                        "language" : "en",
                        "phrase" : "Datasets"
                     },
                     {
                        "phrase" : "Learning Objects",
                        "value" : "learning_objects",
                        "language" : "en"
                     },
                     {
                        "value" : "software",
                        "language" : "en",
                        "phrase" : "Software"
                     },
                     {
                        "value" : "patents",
                        "language" : "en",
                        "phrase" : "Patents"
                     }
                  ],
                  "standard_types_excluded" : [
                     "datasets",
                     "learning_objects",
                     "software",
                     "patents"
                  ],
                  "all" : "false"
               },
               "url" : [
                  "https://www.dora.lib4ri.ch/wsl/dora_content_policy"
               ],
               "subjects_phrases" : [
                  {
                     "value" : "7",
                     "language" : "en",
                     "phrase" : "Ecology and Environment"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "https://www.dora.lib4ri.ch/wsl/dora_content_policy"
               ]
            },
            "submission_policy" : {
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance"
               ],
               "url" : [
                  "https://www.dora.lib4ri.ch/wsl/dora_content_policy"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "value" : "author_eligibility",
                     "language" : "en"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ]
            },
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://www.dora.lib4ri.ch/wsl/dora_content_policy"
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9467",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2020-01-02 10:21:36",
            "date_created" : "2020-01-02 10:16:49",
            "id" : 9467,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "WSL",
                  "name" : "Swiss Federal Institute for Forest, Snow and Landscape Research",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "ch",
            "country_phrases" : [
               {
                  "phrase" : "Switzerland",
                  "language" : "en",
                  "value" : "ch"
               }
            ],
            "location" : {
               "latitude" : 47.3607,
               "longitude" : 8.4546
            },
            "url" : "https://www.wsl.ch"
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "url" : [
                  "https://www.dora.lib4ri.ch/empa/dora_content_policy"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ]
            },
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "https://www.dora.lib4ri.ch/empa/dora_content_policy"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "url" : [
                  "https://www.dora.lib4ri.ch/empa/dora_content_policy"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "en",
                  "fr"
               ],
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  },
                  {
                     "phrase" : "French",
                     "language" : "en",
                     "value" : "fr"
                  }
               ],
               "types_included" : {
                  "standard_types_excluded_phrases" : [
                     {
                        "value" : "datasets",
                        "language" : "en",
                        "phrase" : "Datasets"
                     },
                     {
                        "phrase" : "Learning Objects",
                        "value" : "learning_objects",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "software",
                        "phrase" : "Software"
                     },
                     {
                        "phrase" : "Patents",
                        "value" : "patents",
                        "language" : "en"
                     }
                  ],
                  "all" : "false",
                  "standard_types_excluded" : [
                     "datasets",
                     "learning_objects",
                     "software",
                     "patents"
                  ]
               },
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9466",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9466,
            "date_modified" : "2020-01-02 10:13:14",
            "date_created" : "2020-01-02 09:48:53",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Swiss Federal Laboratories for Materials Science and Technology",
                  "acronym" : "Empa",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 8.6123,
               "latitude" : 47.4034
            },
            "url" : "https://www.empa.ch",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ch",
                  "phrase" : "Switzerland"
               }
            ],
            "country" : "ch"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "fr",
               "de"
            ],
            "url" : "https://www.dora.lib4ri.ch/empa",
            "oai_url" : "https://www.dora.lib4ri.ch/empa/oai2",
            "content_subjects" : [
               "11"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "islandora",
                     "phrase" : "islandora"
                  }
               ],
               "name" : "islandora"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Swiss Federal Laboratories for Materials Science and Technology (Empa). The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               },
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "acronym" : "DORA Empa",
                  "name" : "Digital Object Repository at Empa",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "country" : "ch",
            "country_phrases" : [
               {
                  "phrase" : "Switzerland",
                  "value" : "ch",
                  "language" : "en"
               }
            ],
            "url" : "https://www.eawag.ch",
            "location" : {
               "longitude" : 8.6098,
               "latitude" : 47.405
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "Eawag",
                  "name" : "Swiss Federal Institute of Aquatic Science and Technology"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2020-01-02 10:11:42",
            "date_created" : "2020-01-02 09:34:54",
            "id" : 9465,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9465",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "fr",
               "de"
            ],
            "url" : "https://www.dora.lib4ri.ch/eawag",
            "oai_url" : "https://www.dora.lib4ri.ch/eawag/oai2",
            "content_subjects" : [
               "3",
               "4",
               "7"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "islandora",
                     "value" : "islandora",
                     "language" : "en"
                  }
               ],
               "name" : "islandora"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the  Swiss Federal Institute of Aquatic Science and Technology (Eawag). The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "language" : "en",
                  "value" : "3"
               },
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Digital Object Repository at Eawag",
                  "acronym" : "DORA Eawag",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://dspace.gazi.edu.tr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://dspace.gazi.edu.tr",
            "content_languages" : [
               "tr"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.10.0 - SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Gazi University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Gazi University Dspace",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "Gazi Üniversitesi Dspace",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country" : "tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "location" : {
               "longitude" : 39.9292,
               "latitude" : 32.8532
            },
            "url" : "https://gazi.edu.tr",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Gazi University"
               },
               {
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "name" : "Gazi Üniversitesi"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-12-19 09:29:18",
            "date_modified" : "2019-12-19 09:31:36",
            "id" : 9464,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9464"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "sk"
            ],
            "oai_url" : "https://drepo.uniza.sk/oai/request",
            "url" : "https://drepo.uniza.sk",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.4 SNAPSHOT",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Zilina. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Slovak",
                  "value" : "sk",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Repository of University of Zilina",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "Digitálna knižnica Žilinskej univerzity",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "sk",
                        "phrase" : "Slovak"
                     }
                  ],
                  "language" : "sk"
               }
            ],
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "date_created" : "2019-12-19 08:39:41",
            "date_modified" : "2020-01-02 10:34:37",
            "id" : 9463,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9463",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Zilina",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Slovak",
                        "language" : "en",
                        "value" : "sk"
                     }
                  ],
                  "language" : "sk",
                  "name" : "Žilinská univerzita v Žiline"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "sk",
                  "phrase" : "Slovakia"
               }
            ],
            "url" : "http://www.uniza.sk",
            "location" : {
               "longitude" : 18.7565,
               "latitude" : 49.2021
            },
            "country" : "sk"
         }
      },
      {
         "organisation" : {
            "url" : "https://www.unab.edu.pe",
            "location" : {
               "latitude" : -10.7253,
               "longitude" : -77.7695
            },
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Nacional de Barranca"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9462,
            "date_modified" : "2019-12-19 08:32:35",
            "date_created" : "2019-12-19 08:29:44",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9462",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositorio Institucional de la Universidad Nacional de Barranca",
                  "acronym" : "Repositorio Institucional de la UNAB",
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.unab.edu.pe",
            "oai_url" : "http://repositorio.unab.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Barranca. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9461",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9461,
            "date_modified" : "2019-12-19 08:56:00",
            "date_created" : "2019-12-18 09:16:22",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Norwegian Institute of Bioeconomy Research",
                  "acronym" : "NIBIO"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Norwegian",
                        "language" : "en",
                        "value" : "no"
                     }
                  ],
                  "language" : "no",
                  "acronym" : "NIBIO",
                  "name" : "Norsk institutt for bioøkonomi"
               }
            ],
            "url" : "https://nibio.no",
            "location" : {
               "longitude" : 10.7754,
               "latitude" : 59.6657
            }
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "no"
            ],
            "content_subjects" : [
               "3"
            ],
            "oai_url" : "https://nibio.brage.unit.no/nibio-oai/request",
            "url" : "https://nibio.brage.unit.no",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Norsk institutt for bioøkonomi (Norwegian Institute of Bioeconomy Research). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Norwegian.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norwegian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "NIBIO Brage"
               },
               {
                  "name" : "NIBIO Brage",
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "value" : "no",
                        "language" : "en",
                        "phrase" : "Norwegian"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Norway",
                  "value" : "no",
                  "language" : "en"
               }
            ],
            "url" : "https://norceresearch.no",
            "location" : {
               "longitude" : 5.33323,
               "latitude" : 60.3844
            },
            "country" : "no",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "NORCE Norwegian Research Centre"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9459",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-19 09:02:58",
            "date_created" : "2019-12-18 09:02:16",
            "id" : 9459,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "no",
                  "language" : "en",
                  "phrase" : "Norwegian"
               }
            ],
            "content_types" : [
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "NORCE Research Archive"
               },
               {
                  "name" : "NORCE vitenarkiv",
                  "language_phrases" : [
                     {
                        "value" : "no",
                        "language" : "en",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "language" : "no"
               }
            ],
            "content_languages" : [
               "en",
               "no"
            ],
            "oai_url" : "https://norceresearch.brage.unit.no/norceresearch-oai/request",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "url" : "https://norceresearch.brage.unit.no",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the NORCE Norwegian Research Centre. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Norwegian.",
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "version" : "5.5.1 SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Açık Erişim@BUU",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "tr"
            ],
            "oai_url" : "http://acikerisim.uludag.edu.tr/oai/request",
            "url" : "http://acikerisim.uludag.edu.tr",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Bursa Uludag University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.4 SNAPSHOT"
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9458",
            "publicly_visible" : "yes",
            "date_created" : "2019-12-17 09:33:34",
            "date_modified" : "2019-12-17 09:36:06",
            "id" : 9458
         },
         "organisation" : {
            "url" : "http://uludag.edu.tr",
            "location" : {
               "longitude" : 8.531,
               "latitude" : 47.37
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "country" : "tr",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Bursa Uludag University"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr",
                  "name" : "Bursa Uludağ Üniversitesi"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.hebron.edu",
            "content_languages" : [
               "ar",
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Hebron University . Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Arabic"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Hebron University DSpace",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-12-16 08:28:12",
            "date_modified" : "2019-12-16 08:30:42",
            "id" : 9457,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9457",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ps",
            "location" : {
               "latitude" : 31.55,
               "longitude" : 35.092
            },
            "country_phrases" : [
               {
                  "phrase" : "Palestine, State of",
                  "value" : "ps",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Hebron University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "جامعة الخليل",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ar",
                        "phrase" : "Arabic"
                     }
                  ],
                  "language" : "ar"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9456",
            "publicly_visible" : "yes",
            "id" : 9456,
            "date_created" : "2019-12-13 13:46:20",
            "date_modified" : "2019-12-13 13:50:50"
         },
         "organisation" : {
            "country" : "tr",
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ],
            "url" : "https://antalya.edu.tr",
            "location" : {
               "longitude" : 30.6189,
               "latitude" : 37.0519
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Antalya Bilim University"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ],
                  "language" : "tr",
                  "name" : "Antalya Bilim Üniversitesi"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Antalya Bilim University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "cybertesis",
               "version" : "6.4 SNAPSHOT",
               "name_phrases" : [
                  {
                     "phrase" : "Cybertesis",
                     "value" : "cybertesis",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "tr"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://acikerisim.antalya.edu.tr",
            "oai_url" : "http://acikerisim.antalya.edu.tr/oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Antalya Bilim University Institutional Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9455",
            "publicly_visible" : "yes",
            "date_created" : "2019-12-13 13:19:24",
            "date_modified" : "2019-12-13 13:22:14",
            "id" : 9455
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad del Rosario"
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "value" : "co",
                  "language" : "en"
               }
            ],
            "url" : "https://urosario.edu.co",
            "location" : {
               "longitude" : -74.0736,
               "latitude" : 4.6002
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Institucional EdocUR Universidad del Rosario",
                  "acronym" : "Repositorio Institucional EdocUR"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad del Rosario. Users may set up RSS feeds to be alerted to new content. The interface is available in English, Spanish and Portuguese.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt",
               "es"
            ],
            "oai_url" : "https://repository.urosario.edu.co/oai/request",
            "url" : "https://repository.urosario.edu.co",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "PURE",
                     "language" : "en",
                     "value" : "pure"
                  }
               ],
               "name" : "pure"
            },
            "repository_status" : "undetermined",
            "description" : "This site provides access to the research outputs of Solent University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "undetermined",
                  "phrase" : "Undetermined"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://pure.solent.ac.uk",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://pure.solent.ac.uk/ws/oai?",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Solent University Research Portal"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Solent University"
               }
            ],
            "country" : "gb",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "location" : {
               "latitude" : 50.908,
               "longitude" : -1.401
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9451",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9451,
            "date_created" : "2019-11-29 08:46:38",
            "date_modified" : "2019-11-29 08:49:07",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "software"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Heriot-Watt Research Portal"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "software",
                  "language" : "en",
                  "phrase" : "Software"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Heriot-Watt University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "pure",
               "name_phrases" : [
                  {
                     "phrase" : "PURE",
                     "language" : "en",
                     "value" : "pure"
                  }
               ]
            },
            "url" : "https://researchportal.hw.ac.uk",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Heriot-Watt University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "location" : {
               "latitude" : 55.9101,
               "longitude" : -3.3246
            },
            "url" : "https://www.hw.ac.uk",
            "country" : "gb"
         },
         "system_metadata" : {
            "date_modified" : "2019-11-26 08:17:08",
            "date_created" : "2019-11-26 08:13:50",
            "id" : 9450,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9450",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Peruana de las Américas"
               }
            ],
            "location" : {
               "longitude" : -77.0378,
               "latitude" : -12.0632
            },
            "url" : "https://www.ulasamericas.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "country" : "pe"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9449,
            "date_modified" : "2019-11-21 08:45:46",
            "date_created" : "2019-11-21 08:33:26",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9449"
         },
         "repository_metadata" : {
            "url" : "http://repositorio.ulasamericas.edu.pe",
            "oai_url" : "http://repositorio.ulasamericas.edu.pe/oai/request",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Peruana de las Américas. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [],
               "version" : "5.5"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad Peruana de las Américas",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9447,
            "date_modified" : "2019-11-13 18:17:11",
            "date_created" : "2019-11-13 18:07:20",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9447"
         },
         "organisation" : {
            "country" : "tr",
            "location" : {
               "longitude" : 35.5235,
               "latitude" : 38.7046
            },
            "url" : "https://www.erciyes.edu.tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Erciyes University"
               },
               {
                  "name" : "Erciyes Üniversitesi",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "value" : "tr",
                        "language" : "en"
                     }
                  ],
                  "language" : "tr"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Erciyes University - AVESIS",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Erciyes Üniversitesi - AVESIS",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Avesis",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Erciyes University. The interface is available in English and Turkish.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "oai_url" : "https://avesis.erciyes.edu.tr/api/oai2",
            "url" : "https://avesis.erciyes.edu.tr",
            "content_languages" : [
               "tr"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "at",
            "country_phrases" : [
               {
                  "phrase" : "Austria",
                  "language" : "en",
                  "value" : "at"
               }
            ],
            "location" : {
               "longitude" : 16.3298,
               "latitude" : 48.1841
            },
            "url" : "https://www.fteval.at",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Austrian Platform for Research and Technology Policy Evaluation"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de",
                  "name" : "Österreichischen Plattform für Forschungs und Technologiepolitikevaluierung\""
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-11-12 21:20:48",
            "date_modified" : "2019-11-12 21:31:05",
            "id" : 9446,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9446",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Austrian Platform for Research and Technology Policy Evaluation",
                  "acronym" : "fteval",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "de",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Österreichischen Plattform für Forschungs und Technologiepolitikevaluierung\"",
                  "acronym" : "fteval"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "disciplinary",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "content_subjects" : [
               "11"
            ],
            "url" : "https://repository.fteval.at",
            "oai_url" : "https://repository.fteval.at/cgi/oai2",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.15",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Austrian Platform for Research and Technology Policy Evaluation. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Serbian",
                     "language" : "en",
                     "value" : "sr"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages" : [
                  "en",
                  "sr"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "subjects" : [
                  "12"
               ],
               "url" : [
                  "http://raf.arh.bg.ac.rs/Files/policy-raf-sr.html"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Architecture",
                     "value" : "12",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://raf.arh.bg.ac.rs/Files/policy-raf-sr.html"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse" : "allowed"
            },
            "submission_policy" : {
               "rules_phrases" : [
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "value" : "bibliographic_metadata_required",
                     "language" : "en"
                  }
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  },
                  {
                     "value" : "employees",
                     "language" : "en",
                     "phrase" : "Employees"
                  }
               ],
               "url" : [
                  "http://raf.arh.bg.ac.rs/Files/policy-raf-sr.html"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "publisher_rules",
                        "language" : "en",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ]
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "link_between_versions"
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "earlier_versions_may_be_withdrawn",
                        "language" : "en",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     },
                     {
                        "value" : "link_between_versions",
                        "language" : "en",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ],
                  "period" : "indefinitely"
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "individually_tagged",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "individually_tagged",
               "url" : [
                  "http://raf.arh.bg.ac.rs/Files/policy-raf-sr.html"
               ]
            }
         },
         "system_metadata" : {
            "id" : 9445,
            "date_modified" : "2019-11-12 20:12:32",
            "date_created" : "2019-11-12 19:57:52",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9445",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Belgrade",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "УНИВЕРЗИТЕТ У БЕОГРАДУ",
                  "language_phrases" : [
                     {
                        "value" : "sr",
                        "language" : "en",
                        "phrase" : "Serbian"
                     }
                  ],
                  "language" : "sr"
               }
            ],
            "country" : "rs",
            "url" : "https://www.bg.ac.rs",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Faculty of Architecture"
               },
               {
                  "language" : "sr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "sr",
                        "phrase" : "Serbian"
                     }
                  ],
                  "name" : "АРХИТЕКТОНСКИ ФАКУЛТЕТ"
               }
            ],
            "location" : {
               "longitude" : 20.4574,
               "latitude" : 44.8184
            },
            "country_phrases" : [
               {
                  "value" : "rs",
                  "language" : "en",
                  "phrase" : "Serbia"
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.10"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Belgrade's Faculty of Architecture. The interface is available in English and Serbian.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Architecture",
                  "language" : "en",
                  "value" : "12"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "sr"
            ],
            "oai_url" : "http://raf.arh.bg.ac.rs/oai/request",
            "url" : "http://raf.arh.bg.ac.rs",
            "content_subjects" : [
               "12"
            ],
            "name" : [
               {
                  "acronym" : "RAF",
                  "name" : "Repository of the Faculty of Architecture",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "sr",
                  "phrase" : "Serbian"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "ng",
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "language" : "en",
                  "value" : "ng"
               }
            ],
            "url" : "https://aauekpoma.edu.ng",
            "location" : {
               "longitude" : 6.08455,
               "latitude" : 6.74463
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Ambrose Alli University",
                  "acronym" : "AAU",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-11-08 16:03:44",
            "date_modified" : "2019-11-08 16:06:05",
            "id" : 9444,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9444",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Ambrose Alli University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://154.68.224.61:8080/oai/request",
            "url" : "http://154.68.224.61:8080",
            "content_languages" : [
               "en",
               "fr"
            ],
            "name" : [
               {
                  "name" : "Ambrose Alli University Ekpoma Institutional Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "year_established" : 2014,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "pt",
               "es"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "CIC-Digital"
               }
            ],
            "oai_url" : "https://digital.cic.gba.gob.ar/oai/request",
            "url" : "https://digital.cic.gba.gob.ar",
            "content_subjects" : [
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This is the  Institutional Repository of the Comisión de Investigaciones Científicas de la Provincia de Buenos Aires. The interface is available in English, Spanish and Portuguese.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Comisión de Investigaciones Científicas de la Provincia de Buenos Aires",
                  "acronym" : "CIC",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Argentina"
               }
            ],
            "url" : "http://www.cic.gba.gob.ar",
            "location" : {
               "longitude" : -57.981,
               "latitude" : -34.8983
            },
            "country" : "ar"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9441",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-11-12 21:14:29",
            "date_created" : "2019-11-07 08:44:49",
            "id" : 9441,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "https://repository.libertadores.edu.co",
            "oai_url" : "https://repository.libertadores.edu.co/oai/request",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "6",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universitaria Los Libertadores. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio Fundación Universitaria Los Libertadores"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Fundación universitaria Los libertadores",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "location" : {
               "latitude" : 4.65164,
               "longitude" : -74.0657
            },
            "url" : "https://www.ulibertadores.edu.co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "country" : "co"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9440,
            "date_created" : "2019-11-06 10:14:55",
            "date_modified" : "2019-11-06 10:17:59",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9440"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "DSpace@Kavram",
                  "name" : "İzmir Kavram Vocational School Institutional Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               },
               {
                  "acronym" : "DSpace@Kavram",
                  "name" : "İzmir Kavram Meslek Yüksekokulu Akademik Arşiv Sistemi",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ],
                  "language" : "tr",
                  "preferred" : "acronym"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "description" : "This site provides access to the research outputs of İzmir Kavram Vocational School . Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "url" : "http://openaccess.kavram.edu.tr",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://openaccess.kavram.edu.tr/oai/request",
            "content_languages" : [
               "en",
               "tr"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "organisation" : {
            "country" : "tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 38.4235,
               "longitude" : 27.1514
            },
            "url" : "https://www.kavram.edu.tr",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "İzmir Kavram Vocational School"
               },
               {
                  "name" : "İzmir Kavram Meslek Yüksekokulu",
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9439",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9439,
            "date_modified" : "2019-11-05 08:06:39",
            "date_created" : "2019-11-05 08:04:24",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "Kırşehir Ahi Evran University Institutional Repository",
                  "acronym" : "DSpace@Kırşehir"
               },
               {
                  "acronym" : "DSpace@Kırşehir",
                  "name" : "Kırşehir Ahi Evran Üniversitesi Akademik Arşiv Sistemi",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr",
                  "preferred" : "acronym"
               }
            ],
            "content_languages" : [
               "tr"
            ],
            "url" : "http://openaccess.ahievran.edu.tr",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://openaccess.ahievran.edu.tr/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of Kırşehir Ahi Evran University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9438",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-04 11:20:12",
            "date_created" : "2019-11-04 11:18:53",
            "id" : 9438
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Kırşehir Ahi Evran University"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "value" : "tr",
                        "language" : "en"
                     }
                  ],
                  "language" : "tr",
                  "name" : "Kırşehir Ahi Evran Üniversitesi"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 39.1401,
               "longitude" : 34.1236
            },
            "country" : "tr"
         }
      },
      {
         "organisation" : {
            "country" : "tr",
            "url" : "https://www.ege.edu.tr",
            "location" : {
               "longitude" : 27.2117,
               "latitude" : 38.4539
            },
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ],
            "name" : [
               {
                  "name" : "Ege University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "value" : "tr",
                        "language" : "en"
                     }
                  ],
                  "language" : "tr",
                  "name" : "Ege Üniversitesi"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9436,
            "date_created" : "2019-11-04 10:36:31",
            "date_modified" : "2019-11-04 10:55:54",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9436",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Ege University Institutional Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of Ege University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "tr"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://acikerisim.ege.edu.tr",
            "oai_url" : "http://acikerisim.ege.edu.tr/oai/request"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9430,
            "date_modified" : "2019-11-01 09:27:56",
            "date_created" : "2019-11-01 09:26:00",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9430"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Autónoma de Chiriquí",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Panama",
                  "language" : "en",
                  "value" : "pa"
               }
            ],
            "location" : {
               "latitude" : 8.3104,
               "longitude" : -82.8301
            },
            "url" : "http://www.unachi.ac.pa",
            "country" : "pa"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Repositorio Institucional JÄ DIMIKE"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad Autónoma de Chiriquí. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "oai_url" : "http://jadimike.unachi.ac.pa/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://jadimike.unachi.ac.pa"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Southern Ndebele",
                  "value" : "nr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "RI-UDELAS",
                  "name" : "Repositorio Institucional de UDELAS",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "acronym"
               }
            ],
            "content_languages" : [
               "nr"
            ],
            "url" : "http://repositorio2.udelas.ac.pa",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio2.udelas.ac.pa/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Especializada de las Américas. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional"
         },
         "policies" : {
            "metadata_policy" : {
               "url" : [
                  "http://repositorio2.udelas.ac.pa/politicas"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse" : "allowed"
            },
            "content_policy" : {
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "es",
                     "phrase" : "Spanish"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "es"
               ],
               "url" : [
                  "http://repositorio2.udelas.ac.pa/politicas"
               ]
            },
            "submission_policy" : {
               "url" : [
                  "http://repositorio2.udelas.ac.pa/politicas"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors" : [
                  "academic_staff"
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "third_party_collaborations_phrases" : [
                  {
                     "value" : "offsite_backups",
                     "language" : "en",
                     "phrase" : "Backup items in external archives"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "special_reasons" : [
                     "UDELAS editorial regulations"
                  ],
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "language" : "en",
                        "value" : "falsified_research"
                     },
                     {
                        "language" : "en",
                        "value" : "other",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research",
                     "other"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "functional_preservation" : [
                  "migrate_file_formats"
               ],
               "url" : [
                  "http://repositorio2.udelas.ac.pa/politicas"
               ],
               "third_party_collaborations" : [
                  "offsite_backups"
               ]
            },
            "data_policy" : {
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "value" : "content_not_changed",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repositorio2.udelas.ac.pa/politicas"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "not_for_profit_purposes"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9429",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-11-01 09:16:18",
            "date_created" : "2019-11-01 08:53:05",
            "id" : 9429,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "latitude" : 8.9745,
               "longitude" : -79.5621
            },
            "url" : "http://udelas.ac.pa",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pa",
                  "phrase" : "Panama"
               }
            ],
            "country" : "pa",
            "name" : [
               {
                  "name" : "Universidad Especializada de las Américas",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9428",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9428,
            "date_modified" : "2019-11-05 08:10:25",
            "date_created" : "2019-11-01 08:29:38",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Nacional de Ingeniería",
                  "acronym" : "UNI",
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "ni",
            "country_phrases" : [
               {
                  "phrase" : "Nicaragua",
                  "language" : "en",
                  "value" : "ni"
               }
            ],
            "location" : {
               "latitude" : 12.1328,
               "longitude" : -86.2504
            },
            "unit" : [
               {
                  "name" : "Sistema de Bibliotecas - UNI",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "https://www.uni.edu.ni"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Institucional de la Universidad Nacional de Ingeniería",
                  "acronym" : "RIBUNI"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               },
               {
                  "phrase" : "Civil Engineering",
                  "language" : "en",
                  "value" : "13"
               },
               {
                  "value" : "15",
                  "language" : "en",
                  "phrase" : "Electrical and Electronic Engineering"
               },
               {
                  "language" : "en",
                  "value" : "16",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Ingeniería (UNI). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.11",
               "name" : "eprints"
            },
            "oai_url" : "http://ribuni.uni.edu.ni/cgi/oai2",
            "content_subjects" : [
               "21",
               "13",
               "15",
               "16"
            ],
            "url" : "http://ribuni.uni.edu.ni",
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "acronym",
                  "acronym" : "UNAN",
                  "name" : "Universidad Nacional Autónoma de Nicaragua, León",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 12.4374,
               "longitude" : -86.879
            },
            "url" : "https://www.unanleon.edu.ni",
            "country_phrases" : [
               {
                  "value" : "ni",
                  "language" : "en",
                  "phrase" : "Nicaragua"
               }
            ],
            "country" : "ni"
         },
         "system_metadata" : {
            "id" : 9427,
            "date_modified" : "2019-11-01 08:20:48",
            "date_created" : "2019-11-01 08:18:41",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9427",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional UNAN - León"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "oai_url" : "http://riul.unanleon.edu.ni:8080/oai/request",
            "url" : "http://riul.unanleon.edu.ni:8080/jspui",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad Nacional Autónoma de Nicaragua. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "AMOLF Institutional Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the research outputs of AMOLF.  The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "https://ir.amolf.nl",
            "content_subjects" : [
               "2",
               "11"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "AMOLF",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "nl",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "nl",
                  "phrase" : "Netherlands"
               }
            ],
            "url" : "https://amolf.nl",
            "location" : {
               "latitude" : 52.3565,
               "longitude" : 4.94877
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9423,
            "date_created" : "2019-10-29 11:36:46",
            "date_modified" : "2019-10-29 11:37:43",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9423"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Advanced Research Center for Nanolithography (ARCNL). The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "13",
                  "phrase" : "Civil Engineering"
               },
               {
                  "phrase" : "Electrical and Electronic Engineering",
                  "value" : "15",
                  "language" : "en"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "13",
               "15",
               "16"
            ],
            "url" : "https://ir.arcnl.nl",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Advanced Research Center for Nanolithography",
                  "acronym" : "ARCNL",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9422,
            "date_modified" : "2019-10-29 11:26:25",
            "date_created" : "2019-10-29 11:15:33",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9422",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "nl",
            "url" : "https://arcnl.nl",
            "location" : {
               "longitude" : 4.94905,
               "latitude" : 52.3571
            },
            "country_phrases" : [
               {
                  "value" : "nl",
                  "language" : "en",
                  "phrase" : "Netherlands"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "ARCNL",
                  "name" : "Advanced Research Center for Nanolithography"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "REDI - Digital Repository of ANII, Uruguay",
                  "name" : "REDI - Digital Repository of the National Agency of Research and Innovation",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               },
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "REDI - Repositorio Digital de ANII, Uruguay",
                  "name" : "REDI - Repositorio Digital de la Agencia Nacional de Investigación e Innovación, Uruguay",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "acronym"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Agencia Nacional de Investigación e Innovación (ANII). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://redi.anii.org.uy",
            "oai_url" : "http://redi.anii.org.uy/oai/request",
            "content_subjects" : [
               "2",
               "11"
            ],
            "content_languages" : [
               "en",
               "es"
            ]
         },
         "organisation" : {
            "country" : "uy",
            "country_phrases" : [
               {
                  "phrase" : "Uruguay",
                  "language" : "en",
                  "value" : "uy"
               }
            ],
            "url" : "https://anii.org.uy",
            "location" : {
               "longitude" : -56.0765,
               "latitude" : -34.8777
            },
            "name" : [
               {
                  "name" : "National Agency of Research and Innovation",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Agencia Nacional de Investigación e Innovación",
                  "acronym" : "ANII"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9421,
            "date_modified" : "2019-10-30 15:40:14",
            "date_created" : "2019-10-29 10:27:45",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9421",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9419",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-10-29 09:27:14",
            "date_modified" : "2019-11-21 09:20:49",
            "id" : 9419,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Evangelical University of El Salvador",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Evangélica de El Salvador",
                  "acronym" : "UEES"
               }
            ],
            "location" : {
               "latitude" : 13.7162,
               "longitude" : -89.2392
            },
            "country_phrases" : [
               {
                  "phrase" : "El Salvador",
                  "value" : "sv",
                  "language" : "en"
               }
            ],
            "country" : "sv"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://dsuees.uees.edu.sv",
            "oai_url" : "http://dsuees.uees.edu.sv/oai/request",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Evangélica de El Salvador. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Institutional Repository of the Evangelical University of El Salvador"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "Repositorio Institucional de la Universidad Evangélica de El Salvador",
                  "acronym" : "Repositorio Institucional RUEES",
                  "preferred" : "acronym",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "name" : "School of Arts and Sciences"
               }
            ],
            "url" : "https://www.rutgers.edu",
            "location" : {
               "longitude" : -74.4481,
               "latitude" : 40.5017
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Rutgers, The State University of New Jersey"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-10-29 09:17:30",
            "date_modified" : "2019-10-29 09:19:54",
            "id" : 9418,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9418",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "value" : "disciplinary",
                  "language" : "en"
               }
            ],
            "description" : "The Rutgers Optimality Archive is a distribution point for research in Optimality Theory and its conceptual affiliates.  The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "21"
            ],
            "url" : "http://roa.rutgers.edu",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "acronym" : "ROA",
                  "name" : "Rutgers Optimality Archive",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Bohdan Khmelnitskiy Melitopol State Pedagogical University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "version" : "3.4.0",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "uk"
            ],
            "oai_url" : "http://eprints.mdpu.org.ua/cgi/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.mdpu.org.ua",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "MDPU Repository",
                  "name" : "Institutional Repository of Bohdan Khmelnitskiy Melitopol State Pedagogical University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Bohdan Khmelnitskiy Melitopol State Pedagogical University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Мелітопольський державний педагогічний університет імені Богдана Хмельницького",
                  "language_phrases" : [
                     {
                        "value" : "uk",
                        "language" : "en",
                        "phrase" : "Ukrainian"
                     }
                  ],
                  "language" : "uk"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "language" : "en",
                  "value" : "ua"
               }
            ],
            "location" : {
               "latitude" : 48.3042,
               "longitude" : 38.0181
            },
            "url" : "https://mdpu.org.ua",
            "country" : "ua"
         },
         "system_metadata" : {
            "id" : 9416,
            "date_modified" : "2019-10-29 08:48:51",
            "date_created" : "2019-10-29 08:45:16",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9416",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9415",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9415,
            "date_modified" : "2019-10-25 07:47:58",
            "date_created" : "2019-10-25 07:41:12",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Croatia",
                  "value" : "hr",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 15.9633,
               "latitude" : 45.8149
            },
            "url" : "https://ffzg.unizg.hr",
            "unit" : [
               {
                  "name" : "Faculty of Humanities and Social Sciences",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "FFZG-a",
                  "name" : "Filozofskog fakulteta",
                  "language_phrases" : [
                     {
                        "phrase" : "Croatian",
                        "language" : "en",
                        "value" : "hr"
                     }
                  ],
                  "language" : "hr",
                  "preferred" : "name"
               }
            ],
            "country" : "hr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Zagreb"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "hr",
                        "phrase" : "Croatian"
                     }
                  ],
                  "language" : "hr",
                  "name" : "Sveučilišta u Zagrebu"
               }
            ]
         },
         "repository_metadata" : {
            "url" : "https://repozitorij.ffzg.unizg.hr",
            "oai_url" : "https://repozitorij.ffzg.unizg.hr/oai",
            "content_subjects" : [
               "17",
               "23"
            ],
            "content_languages" : [
               "hr",
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Zagreb. The interface is available in English and Croatian.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "islandora",
                     "phrase" : "islandora"
                  }
               ],
               "name" : "islandora"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Croatian",
                  "language" : "en",
                  "value" : "hr"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Open Repository of the University of Zagreb Faculty of Humanities and Social Sciences",
                  "acronym" : "ODRAZ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "hr",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "hr",
                        "language" : "en",
                        "phrase" : "Croatian"
                     }
                  ],
                  "name" : "otvoreni digitalni repozitorij akademske zajednice FFZG-a",
                  "acronym" : "ODRAZ",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "data.gov.uk",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "datasets"
            ],
            "type" : "governmental",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to open data published by central UK government, local authorities and public bodies. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://data.gov.uk"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "GOV.UK",
                  "name" : "UK Government",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "value" : "gb",
                  "language" : "en"
               }
            ],
            "country" : "gb"
         },
         "system_metadata" : {
            "id" : 9413,
            "date_created" : "2019-10-23 10:28:22",
            "date_modified" : "2019-10-23 10:32:04",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9413",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "location" : {
               "latitude" : 52.5156,
               "longitude" : 13.3258
            },
            "url" : "https://www.fraunhofer.de",
            "country" : "de",
            "name" : [
               {
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "name" : "Fraunhofer-Gesellschaft"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-10-21 09:13:01",
            "date_modified" : "2019-10-21 09:17:37",
            "id" : 9411,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9411"
         },
         "repository_metadata" : {
            "url" : "https://fordatis.fraunhofer.de",
            "content_subjects" : [
               "10",
               "24"
            ],
            "oai_url" : "https://fordatis.fraunhofer.de/oai/request",
            "content_languages" : [
               "en",
               "de"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Fraunhofer-Gesellschaft. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "datasets"
            ],
            "name" : [
               {
                  "name" : "Fordatis",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "10"
            ],
            "url" : "https://www.medrxiv.org",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "value" : "disciplinary",
                  "language" : "en"
               }
            ],
            "description" : "This site is a preprint server for scholarly outputs within health sciences. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "name" : "medRxiv",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9409,
            "date_modified" : "2019-10-18 08:20:50",
            "date_created" : "2019-10-18 08:07:54",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9409",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Cold Spring Harbor Laboratory",
                  "acronym" : "CSHL",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "Yale University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "acronym" : "BMJ",
                  "name" : "British Medical Journals",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9408",
            "publicly_visible" : "yes",
            "id" : 9408,
            "date_modified" : "2019-12-12 15:23:36",
            "date_created" : "2019-10-18 07:52:36"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "nl",
                  "language" : "en",
                  "phrase" : "Netherlands"
               }
            ],
            "location" : {
               "longitude" : 5.1731,
               "latitude" : 52.2354
            },
            "url" : "https://www.beeldengeluid.nl",
            "country" : "nl",
            "name" : [
               {
                  "name" : "Netherlands Institute for Sound and Vision",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Sound and Vision Publications",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Dutch",
                  "value" : "nl",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "description" : "This site provides access to the research outputs of the Netherlands Institute for Sound and Vision. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "nl",
               "en"
            ],
            "content_subjects" : [
               "17"
            ],
            "oai_url" : "https://publications.beeldengeluid.nl/oai",
            "url" : "https://publications.beeldengeluid.nl",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://repository.chuka.ac.ke/oai/request",
            "content_subjects" : [
               "17",
               "10",
               "2",
               "23",
               "11"
            ],
            "url" : "http://repository.chuka.ac.ke",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "description" : "This site provides access to the research outputs of Chuka University. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Chuka University Institutional Repository"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Kenya",
                  "value" : "ke",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 37.6543,
               "latitude" : -0.32006
            },
            "url" : "https://www.chuka.ac.ke",
            "country" : "ke",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chuka University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9406",
            "publicly_visible" : "yes",
            "id" : 9406,
            "date_created" : "2019-10-16 08:32:31",
            "date_modified" : "2019-10-21 14:28:12"
         }
      },
      {
         "organisation" : {
            "country" : "nl",
            "url" : "https://www.wur.nl",
            "location" : {
               "longitude" : 5.6586,
               "latitude" : 51.9671
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "nl",
                  "phrase" : "Netherlands"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Wageningen University & Research"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9405",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 9405,
            "date_modified" : "2019-10-21 14:31:24",
            "date_created" : "2019-10-15 08:34:19",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Research@WUR"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "datasets",
               "patents",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Dutch",
                  "language" : "en",
                  "value" : "nl"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "pure",
                     "language" : "en",
                     "phrase" : "PURE"
                  }
               ],
               "name" : "pure"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Wageningen University & Research.  The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://research.wur.nl",
            "content_languages" : [
               "nl",
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Repositorio Institucional - Universidad Nacional Pedro Ruiz",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the Universidad Pedro Ruiz Gallo. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "10",
               "2",
               "26",
               "11"
            ],
            "url" : "http://repositorio.unprg.edu.pe/",
            "oai_url" : "http://repositorio.unprg.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ]
         },
         "organisation" : {
            "country" : "pe",
            "url" : "http://www.unprg.edu.pe",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad de Pedro Ruiz Gallo"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9404,
            "date_modified" : "2019-10-16 08:17:32",
            "date_created" : "2019-10-15 07:06:34",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9404"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://www.accede.iuacj.edu.uy/oai/request",
            "url" : "http://www.accede.iuacj.edu.uy",
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Instituto Universitario Asociación Cristiana de Jóvenes (IUACJ). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "name" : "ACCEDE"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "id" : 9402,
            "date_created" : "2019-10-14 08:42:20",
            "date_modified" : "2019-10-14 08:45:23",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9402",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "IUACJ",
                  "name" : "Instituto Universitario Asociación Cristiana de Jóvenes"
               }
            ],
            "url" : "http://www.iuacj.edu.uy",
            "location" : {
               "longitude" : -56.173,
               "latitude" : -34.9023
            },
            "country_phrases" : [
               {
                  "phrase" : "Uruguay",
                  "value" : "uy",
                  "language" : "en"
               }
            ],
            "country" : "uy"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "eu",
                  "language" : "en",
                  "phrase" : "Basque"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "HAL e2s UPPA"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://hal-univ-pau.archives-ouvertes.fr",
            "content_languages" : [
               "eu",
               "en",
               "fr"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Université de Pau et des Pays de l'Adour. The interface is available in French and English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "hal",
               "name_phrases" : [
                  {
                     "phrase" : "HAL",
                     "value" : "hal",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UPPA",
                  "name" : "Université de Pau et des Pays de l'Adour",
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "language" : "en",
                        "value" : "fr"
                     }
                  ],
                  "language" : "fr"
               },
               {
                  "name" : "University of Pau and Pays de l'Adour",
                  "acronym" : "UPPA",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "fr",
            "url" : "https://www.univ-pau.fr",
            "location" : {
               "latitude" : 43.3113,
               "longitude" : -0.36349
            },
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-11 14:27:30",
            "date_created" : "2019-10-11 14:22:05",
            "id" : 9401,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9401"
         }
      },
      {
         "system_metadata" : {
            "id" : 9400,
            "date_created" : "2019-10-11 08:11:25",
            "date_modified" : "2019-10-11 08:13:51",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9400",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.monash.edu",
            "location" : {
               "latitude" : -37.9105,
               "longitude" : 145.134
            },
            "country_phrases" : [
               {
                  "value" : "au",
                  "language" : "en",
                  "phrase" : "Australia"
               }
            ],
            "country" : "au",
            "name" : [
               {
                  "name" : "Monash University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "oai_url" : "http://researchmgt.monash.edu/ws/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://research.monash.edu",
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of Monash University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "pure",
               "name_phrases" : [
                  {
                     "phrase" : "PURE",
                     "language" : "en",
                     "value" : "pure"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Monash University Research Portal",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9398",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9398,
            "date_created" : "2019-10-11 08:02:12",
            "date_modified" : "2019-10-11 08:03:03",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Norbert Wiener",
                  "acronym" : "UWIENER",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "country" : "pe",
            "location" : {
               "latitude" : -12.0695,
               "longitude" : -77.0371
            },
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Digital de la Universidad Norbert Wiener",
                  "acronym" : "UWIENER",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.uwiener.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.uwiener.edu.pe",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad Norbert Wiener (UWIENER). Users may set up RSS feeds to be alerted to new content. The interface is available in XXXXXXXX.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional del Ministerio de Cultura"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.3",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Ministerio de Cultura (Ministry of Culture). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.cultura.gob.pe/oai/request",
            "url" : "http://repositorio.cultura.gob.pe",
            "content_subjects" : [
               "17"
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:41",
            "date_created" : "2019-10-11 07:51:16",
            "id" : 9397,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9397",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Ministry of Culture",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Ministerio de Cultura",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "https://www.gob.pe/cultura",
            "location" : {
               "latitude" : -12.0865,
               "longitude" : -77.0021
            },
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "PTB-OAR",
                  "name" : "Physikalisch-Technische Bundesanstalt",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "country" : "de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "location" : {
               "latitude" : 52.2946,
               "longitude" : 10.4622
            },
            "url" : "https://www.ptb.de"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9396",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-11 07:58:39",
            "date_created" : "2019-10-11 07:34:02",
            "id" : 9396,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Open Access Repository of the Physikalisch-Technische Bundesanstalt",
                  "acronym" : "PTB-OAR",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "https://oar.ptb.de",
            "content_languages" : [
               "en",
               "de"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the Physikalisch-Technische Bundesanstalt (PTB-OAR). The PTB is the national metrology institute of the Federal Republic of Germany.  The interface is available in English and German.",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "Custom software built on Symfony Framwework",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Andina Néstor Cáceres Velásquez (UANCV). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.uancv.edu.pe/oai/request",
            "url" : "http://repositorio.uancv.edu.pe",
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Universidad Andina Néstor Cáceres Velásquez",
                  "acronym" : "UANCV",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Andina Néstor Cáceres Velásquez",
                  "acronym" : "UANCV"
               }
            ],
            "country" : "pe",
            "location" : {
               "latitude" : -15.5336,
               "longitude" : -70.1195
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9395",
            "publicly_visible" : "yes",
            "id" : 9395,
            "date_created" : "2019-10-11 07:25:12",
            "date_modified" : "2019-10-11 07:26:06"
         }
      },
      {
         "organisation" : {
            "country" : "br",
            "location" : {
               "latitude" : -23.4273,
               "longitude" : -51.9375
            },
            "url" : "http://www.uem.br",
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ],
            "name" : [
               {
                  "name" : "Universidade Estadual de Maringá",
                  "acronym" : "UEM",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9394",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 9394,
            "date_created" : "2019-10-11 07:13:22",
            "date_modified" : "2019-10-11 07:14:50",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidade Estadual de Maringá (UEM). The interface is available in Spanish, English and Portuguese.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "pt"
            ],
            "url" : "http://repositorio.uem.br:8080/jspui",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Repositório Institucional da Universidade Estadual de Maringá",
                  "acronym" : "RI-UEM",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Instituto Universitario Hospital Italiano de Buenos Aires",
                  "language" : "it",
                  "language_phrases" : [
                     {
                        "phrase" : "Italian",
                        "language" : "en",
                        "value" : "it"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "location" : {
               "longitude" : -58.3772,
               "latitude" : -34.6132
            },
            "url" : "https://www1.hospitalitaliano.org.ar",
            "country" : "ar"
         },
         "system_metadata" : {
            "id" : 9391,
            "date_modified" : "2019-10-14 07:46:25",
            "date_created" : "2019-10-10 07:51:02",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9391",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "TROVARE Repositorio Institucional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://trovare.hospitalitaliano.org.ar",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Instituto Universitario Hospital Italiano de Buenos Aires.  The interface is available in Spanish.",
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "language" : "en",
                     "value" : "greenstone"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:41",
            "date_created" : "2019-10-10 07:31:12",
            "id" : 9390,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9390",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Ministerio de Agricultura y Riego",
                  "acronym" : "MINAGRI"
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Ministry of Agriculture and Irrigation"
               }
            ],
            "location" : {
               "latitude" : -12.0633,
               "longitude" : -77.0394
            },
            "url" : "https://www.gob.pe/minagri",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Ministerio de Agricultura y Riego. The interface is available in Spanish and English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "3"
            ],
            "url" : "http://repositorio.minagri.gob.pe",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "governmental",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "Ministerio de Agricultura y Riego",
                  "name" : "Repositorio Institucional MINAGRI"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "Caltech",
                  "name" : "California Institute of Technology (Caltech) DATA",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "datasets"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [],
               "version" : "TIND"
            },
            "description" : "This site provides access to the research outputs of the California Institute of Technology (Caltech). The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://data.caltech.edu/oai2d",
            "content_subjects" : [
               "11"
            ],
            "url" : "https://data.caltech.edu",
            "content_languages" : [
               "en"
            ]
         },
         "system_metadata" : {
            "id" : 9389,
            "date_created" : "2019-10-10 07:19:37",
            "date_modified" : "2019-11-19 11:33:53",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9389",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 34.1371,
               "longitude" : -118.125
            },
            "url" : "https://www.caltech.edu/",
            "unit" : [
               {
                  "name" : "Caltech Library",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "acronym" : "Caltech",
                  "name" : "California Institute of Technology",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "Biblioteca Virtual - CEDRO",
                  "name" : "Biblioteca Virtual - Centro de Información y Educación para la Prevención del Abuso de Drogas",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               },
               {
                  "name" : "Centre of information and Education for the Prevention of Drug Abuse"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "3.0",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Centro de Información y Educación para la Prevención del Abuso de Drogas (CEDRO). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://repositorio.cedro.org.pe",
            "content_subjects" : [
               "10",
               "29"
            ],
            "oai_url" : "http://repositorio.cedro.org.pe/oai/request",
            "content_languages" : [
               "en",
               "fr",
               "es"
            ]
         },
         "organisation" : {
            "country" : "pe",
            "url" : "http://www.cedro.org.pe",
            "location" : {
               "latitude" : -9.18997,
               "longitude" : -75.0152
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "CEDRO`",
                  "name" : "Centro de Información y Educación para la Prevención del Abuso de Drogas"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9387",
            "publicly_visible" : "yes",
            "date_created" : "2019-10-04 07:57:08",
            "date_modified" : "2019-10-04 08:02:17",
            "id" : 9387
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.upsb.edu.pe",
            "oai_url" : "http://repositorio.upsb.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Privada Sergio Bernales (UPSB). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional - Universidad Privada Sergio Bernales",
                  "acronym" : "UPSB",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9386",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9386,
            "date_created" : "2019-10-03 14:18:53",
            "date_modified" : "2019-10-21 14:12:42",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Privada Sergio Bernales",
                  "acronym" : "UPSB"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "url" : "http://upsb.edu.pe",
            "location" : {
               "latitude" : -13.0727,
               "longitude" : -76.3711
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://samforsk.brage.unit.no/samforsk-oai/request",
            "content_subjects" : [
               "23"
            ],
            "url" : "https://samforsk.brage.unit.no",
            "content_languages" : [
               "en",
               "no"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5.1 SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "description" : "This site provides access to the research outputs of NTNU Samfunnsforskning (NTNU Social Research). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Norwegian.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "no",
                  "language" : "en",
                  "phrase" : "Norwegian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Samforsk Open",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "phrase" : "Norwegian",
                        "value" : "no",
                        "language" : "en"
                     }
                  ],
                  "name" : "NTNU Samfunnsforskning"
               },
               {
                  "name" : "NTNU Social Research",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "no",
            "country_phrases" : [
               {
                  "phrase" : "Norway",
                  "language" : "en",
                  "value" : "no"
               }
            ],
            "location" : {
               "longitude" : 10.465,
               "latitude" : 63.4083
            },
            "url" : "https://samforsk.no"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9385",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9385,
            "date_created" : "2019-10-03 14:05:28",
            "date_modified" : "2019-10-03 14:07:42",
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad San Pedro",
                  "acronym" : "USP"
               }
            ],
            "country" : "pe",
            "location" : {
               "latitude" : -7.16672,
               "longitude" : -78.5132
            },
            "url" : "https://www.usanpedro.edu.pe",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-10-03 10:52:00",
            "date_modified" : "2019-10-21 14:08:22",
            "id" : 9384,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9384",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.usanpedro.edu.pe",
            "oai_url" : "http://repositorio.usanpedro.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Universidad San Pedro. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad San Pedro",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional Toribio Rodríguez de Mendoza. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.untrm.edu.pe",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "oai_url" : "http://repositorio.untrm.edu.pe/oai/request",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "Repositorio Institucional Digital - UNTRM",
                  "name" : "Repositorio Institucional Digital de la Universidad Nacional Toribio Rodríguez de Mendoza"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-10-03 10:44:13",
            "date_modified" : "2019-10-03 10:47:22",
            "id" : 9383,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9383"
         },
         "organisation" : {
            "url" : "https://www.untrm.edu.pe",
            "location" : {
               "longitude" : -77.8692,
               "latitude" : -6.2347
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "acronym" : "UNTRM",
                  "name" : "Universidad Nacional Toribio Rodríguez de Mendoza"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the  Universidad Nacional del Altiplano. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.unap.edu.pe",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "oai_url" : "http://repositorio.unap.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio Institucional Digital de la Universidad Nacional del Altiplano"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9382",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-21 14:06:32",
            "date_created" : "2019-10-03 10:36:36",
            "id" : 9382
         },
         "organisation" : {
            "url" : "https://portal.unap.edu.pe",
            "location" : {
               "longitude" : -70.0157,
               "latitude" : -15.8244
            },
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "name" : "National University of Altiplano",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Nacional del Altiplano"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Repository of the Peruvian Austral University of Cusco",
                  "acronym" : "Repositorio UPAC",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               },
               {
                  "preferred" : "acronym",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio de la Universidad Peruana Austral del Cusco",
                  "acronym" : "Repositorio UPAC"
               },
               {
                  "name" : "Peruvian Austral University of Cusco"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.uaustral.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.uaustral.edu.pe",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Peruana Austral del Cusco (UPAC). Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9381,
            "date_modified" : "2019-10-21 14:02:49",
            "date_created" : "2019-10-01 14:11:18",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9381"
         },
         "organisation" : {
            "country" : "pe",
            "location" : {
               "longitude" : -71.9512,
               "latitude" : -13.5253
            },
            "url" : "http://uaustral.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "UniversidPeruvian Austral University of Cuscoad Peruana Austral del Cusco"
               },
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Peruana Austral del Cusco",
                  "acronym" : "UPAC"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-10-21 13:56:00",
            "date_created" : "2019-10-01 12:49:44",
            "id" : 9380,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9380",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "lt",
            "country_phrases" : [
               {
                  "value" : "lt",
                  "language" : "en",
                  "phrase" : "Lithuania"
               }
            ],
            "url" : "https://www.lsu.lt",
            "location" : {
               "longitude" : 23.9344,
               "latitude" : 54.8983
            },
            "name" : [
               {
                  "name" : "Lithuanian Sports University",
                  "acronym" : "LSU",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Lithuanian",
                        "language" : "en",
                        "value" : "lt"
                     }
                  ],
                  "language" : "lt",
                  "acronym" : "LSU",
                  "name" : "Lietuvos Sporto Universitetas"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "LSU VL",
                  "name" : "Lithuanian Sports University Virtual Library"
               },
               {
                  "language" : "lt",
                  "language_phrases" : [
                     {
                        "value" : "lt",
                        "language" : "en",
                        "phrase" : "Lithuanian"
                     }
                  ],
                  "name" : "Apie LSU virtualią biblioteką",
                  "acronym" : "LSU VB"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "lt",
                  "phrase" : "Lithuanian"
               }
            ],
            "description" : "This site provides access to the research outputs of the Lithuanian Sports University. The interface is available in English and Lithuanian.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "fedora",
                     "phrase" : "Fedora"
                  }
               ],
               "name" : "fedora"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "lt"
            ],
            "content_subjects" : [
               "10"
            ],
            "url" : "https://vb.lsu.lt/repository",
            "oai_url" : "https://vb.lsu.lt/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9379",
            "publicly_visible" : "yes",
            "id" : 9379,
            "date_created" : "2019-10-01 08:42:02",
            "date_modified" : "2019-10-21 13:54:52"
         },
         "organisation" : {
            "location" : {
               "longitude" : 52.6772,
               "latitude" : 36.5309
            },
            "url" : "http://en.mubabol.ac.ir",
            "country_phrases" : [
               {
                  "phrase" : "Iran, Islamic Republic of",
                  "language" : "en",
                  "value" : "ir"
               }
            ],
            "country" : "ir",
            "name" : [
               {
                  "name" : "Babol University of Medical Sciences",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Persian (Farsi)",
                  "value" : "fa",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Repository of Research and Investigative Information",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://eprints.mubabol.ac.ir",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://eprints.mubabol.ac.ir/cgi/oai2",
            "content_languages" : [
               "en",
               "fa"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "2.0",
               "name" : "eprints"
            },
            "description" : "This site provides access to the research outputs of the Babol University of Medical Sciences. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Peruana Santo Tomás de Aquino de Ciencia e Integración. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://repositorio.ust.edu.pe/oai/request",
            "url" : "http://repositorio.ust.edu.pe",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional Universidad Peruana Santo Tomás"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9378",
            "publicly_visible" : "yes",
            "id" : 9378,
            "date_modified" : "2019-09-30 07:28:41",
            "date_created" : "2019-09-30 07:26:13"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "longitude" : -75.214,
               "latitude" : -12.0713
            },
            "url" : "https://www.ust.edu.pe",
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Peruana Santo Tomás",
                  "acronym" : "UST",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Allard Research Commons (Peter A. Allard School of Law)",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://commons.allard.ubc.ca/do/oai/",
            "url" : "https://commons.allard.ubc.ca",
            "content_subjects" : [
               "26"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "description" : "This site allows access to the research output of the Peter A. Allard School of Law. Users may set up RSS feeds to be alerted to new content. Both interface and text are in English only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9374",
            "publicly_visible" : "yes",
            "id" : 9374,
            "date_created" : "2019-09-28 05:16:42",
            "date_modified" : "2019-11-19 11:20:09"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of British Columbia",
                  "acronym" : "UBC",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -123.254,
               "latitude" : 49.2698
            },
            "url" : "https://www.ubc.ca/",
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Peter A. Allard School of Law"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "location" : {
               "longitude" : -87.6283,
               "latitude" : 41.8951
            },
            "url" : "http://www.ala.org",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "name" : "American Library Association",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9366",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9366,
            "date_created" : "2019-09-28 05:16:18",
            "date_modified" : "2019-12-04 12:27:41",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://alair.ala.org",
            "oai_url" : "https://alair.ala.org/oai/openaire",
            "software" : {
               "version" : "5.8",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the American Library Association. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "American Library Association Institutional Repository",
                  "acronym" : "ALAIR",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional"
         }
      }
   ]
}

