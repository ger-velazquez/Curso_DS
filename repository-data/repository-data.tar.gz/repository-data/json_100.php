{
   "items" : [
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9363",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9363,
            "date_modified" : "2019-12-12 15:07:47",
            "date_created" : "2019-09-28 05:16:14",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "American Society for Engineering Education",
                  "acronym" : "ASEE"
               }
            ],
            "location" : {
               "latitude" : 38.9069,
               "longitude" : -77.0451
            },
            "url" : "http://www.asee.org",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "13",
               "15",
               "16"
            ],
            "url" : "https://peer.asee.org",
            "oai_url" : "https://peer.asee.org/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "13",
                  "phrase" : "Civil Engineering"
               },
               {
                  "language" : "en",
                  "value" : "15",
                  "phrase" : "Electrical and Electronic Engineering"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "description" : "The Papers on Engineering Education Repository is a site focused on furthering Engineering Education by supporting American Society for Engineering Education (ASEE) members research and publication needs and being a good custodian of scholarly works.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "PEER",
                  "name" : "Papers on Engineering Education Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Antioch University"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 39.8035,
               "longitude" : -83.9071
            },
            "url" : "https://www.antioch.edu",
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9341,
            "date_created" : "2019-09-28 05:15:07",
            "date_modified" : "2019-12-12 13:23:06",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9341"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Antioch University Repository & Archive",
                  "acronym" : "AURA"
               }
            ],
            "url" : "https://aura.antioch.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://aura.antioch.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Antioch University.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Aomori Public University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "青森公立大学",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Aomori Public University Library"
               },
               {
                  "name" : "青森公立大学図書館",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "url" : "https://www.nebuta.ac.jp",
            "location" : {
               "latitude" : 40.7538,
               "longitude" : 140.772
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9335",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-28 05:14:42",
            "date_modified" : "2019-12-19 15:53:59",
            "id" : 9335,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Aomori Public University Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "青森公立大学学術リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://nebuta.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://nebuta.repo.nii.ac.jp",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Amori Public University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-01 10:59:37",
            "date_created" : "2019-09-28 05:14:05",
            "id" : 9331,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9331"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "The University of Southern Mississippi",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -89.3338,
               "latitude" : 31.3296
            },
            "url" : "https://www.usm.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Aquila Digital Community"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://aquila.usm.edu",
            "oai_url" : "https://aquila.usm.edu/do/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Southern Mississippi. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 05:13:32",
            "date_modified" : "2019-12-11 13:29:28",
            "id" : 9327,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9327"
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.fitnyc.edu",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "FIT Library"
               }
            ],
            "location" : {
               "longitude" : -73.9941,
               "latitude" : 40.7466
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "FIT",
                  "name" : "Fashion Institute of Technology State University of New York"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "AOD",
                  "name" : "Archive on Demand"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "description" : "This site provides access to videos created by the FIT Library at the Fashion Institute of Technology. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "https://archiveondemand.fitnyc.edu",
            "oai_url" : "https://archiveondemand.fitnyc.edu/oai-pmh-repository/request",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-11-21 16:05:44",
            "date_created" : "2019-09-28 05:13:19",
            "id" : 9322,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9322",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Arctic Portal"
               }
            ],
            "country" : "is",
            "country_phrases" : [
               {
                  "phrase" : "Iceland",
                  "language" : "en",
                  "value" : "is"
               }
            ],
            "url" : "https://arcticportal.org"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Arctic Portal Library",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the scope of International Polar Year 2007-2008, the Arctic Council and the University of Arctic. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://library.arcticportal.org",
            "content_subjects" : [
               "2"
            ],
            "oai_url" : "http://library.arcticportal.org/cgi/oai2",
            "content_languages" : [
               "ja"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "UArctic Library"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.16"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://library.vlt.is/cgi/oai2",
            "url" : "http://library.vlt.is",
            "content_subjects" : [
               "1"
            ]
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.uarctic.org",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "University of the Artic",
                  "acronym" : "UArctic",
                  "preferred" : "acronym"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 05:13:18",
            "date_modified" : "2019-11-27 15:37:48",
            "id" : 9321,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9321",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Arizona State Library, Archives and Public Records",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "https://azlibrary.gov",
            "location" : {
               "longitude" : -118.889,
               "latitude" : 33.4046
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:41",
            "date_created" : "2019-09-28 05:13:11",
            "id" : 9318,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9318"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Arizona Memory Project",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "governmental",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "contentdm",
                     "phrase" : "CONTENTdm"
                  }
               ],
               "name" : "contentdm"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "description" : "This site provides access to works in the Arizona Archives, musuems, libraries and other cultural institutions, which is managed by the  Arizona State Library, Archives and Public Records. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://azmemory.azlibrary.gov/oai/oai.php",
            "url" : "https://azmemory.azlibrary.gov"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9314",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9314,
            "date_created" : "2019-09-28 05:12:56",
            "date_modified" : "2019-11-19 11:09:09",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 136.691,
               "latitude" : 35.3814
            },
            "url" : "http://asahibekka-english.mystrikingly.com/",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Asahi University"
               },
               {
                  "name" : "朝日大学",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Asahi University Institutional Repository"
               },
               {
                  "name" : "朝日大学機関リポジトリ"
               }
            ],
            "url" : "https://asahi-u.repo.nii.ac.jp",
            "oai_url" : "https://asahi-u.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the research output of Asahi University. Both interface and text are Japanese only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Asahikawa University Repository"
               },
               {
                  "name" : "旭川大学リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of Asahikawa University. The interface is available in English or Japanese but all text is Japanese only.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://aulib.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://aulib.repo.nii.ac.jp",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Asahikawa University"
               }
            ],
            "url" : "https://www.asahikawa-u.ac.jp/",
            "location" : {
               "longitude" : 142.446,
               "latitude" : 43.8162
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9313",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 05:12:52",
            "date_modified" : "2019-11-25 10:55:40",
            "id" : 9313,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Ashikaga Institute of Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "name" : "足利工業大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 139.397,
               "latitude" : 36.3531
            },
            "url" : "http://www.ashitech.ac.jp",
            "country" : "jp"
         },
         "system_metadata" : {
            "id" : 9312,
            "date_created" : "2019-09-28 05:12:49",
            "date_modified" : "2019-12-11 12:58:38",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9312",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Ashikaga University Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://ashitech.repo.nii.ac.jp/oai",
            "url" : "https://ashitech.repo.nii.ac.jp",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Ashikaga Institute of Technology.  The interface is available in Japanese and English."
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "url" : "https://atomi.repo.nii.ac.jp",
            "oai_url" : "https://atomi.repo.nii.ac.jp/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Atomi University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Atomi University Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "name" : "/ 跡見学園女子大学機関リポジトリ"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9292",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9292,
            "date_created" : "2019-09-28 05:11:32",
            "date_modified" : "2019-11-21 15:51:24",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "location" : {
               "latitude" : 35.8171,
               "longitude" : 139.543
            },
            "url" : "http://www.atomi.ac.jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "name" : [
               {
                  "name" : "Atomi University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Scholarly Commons",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://augusta.openrepository.com/oai/rioxx",
            "url" : "https://augusta.openrepository.com",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the Augusta University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "version" : "5.7",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Augusta University"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://www.augusta.edu",
            "location" : {
               "longitude" : -81.9888,
               "latitude" : 33.4717
            },
            "country" : "us"
         },
         "system_metadata" : {
            "id" : 9290,
            "date_created" : "2019-09-28 05:11:28",
            "date_modified" : "2019-12-19 16:02:51",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9290",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "https://digitalrepository.aurorahealthcare.org",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "https://digitalrepository.aurorahealthcare.org/do/oai/",
            "content_languages" : [
               "en"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Aurora Health Care Digital Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9287,
            "date_modified" : "2019-11-13 14:25:58",
            "date_created" : "2019-09-28 05:11:14",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9287"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Aurora Health Care"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "https://www.aurorahealthcare.org/",
            "country" : "us"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9278,
            "date_modified" : "2019-12-02 09:46:47",
            "date_created" : "2019-09-28 05:10:29",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9278"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Azabu University"
               }
            ],
            "url" : "https://www.azabu-u.ac.jp",
            "location" : {
               "latitude" : 35.575,
               "longitude" : 139.388
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Azabu University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://az.repo.nii.ac.jp",
            "oai_url" : "https://az.repo.nii.ac.jp/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Azabu University Science Information Repository"
               },
               {
                  "name" : "麻布大学学術情報リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "oai_url" : "https://baika.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://baika.repo.nii.ac.jp",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the BAIKA Women's University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "BAIKA Women's University Academic Repository"
               },
               {
                  "name" : "梅花女子大学機関リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 34.843,
               "longitude" : 135.535
            },
            "url" : "https://www.baika.ac.jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "BAIKA Women's University"
               },
               {
                  "name" : "梅花女子大学",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 05:10:24",
            "date_modified" : "2019-12-19 16:06:19",
            "id" : 9275,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9275"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "el",
               "he",
               "la"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digital.blb-karlsruhe.de",
            "oai_url" : "https://digital.blb-karlsruhe.de/oai",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the digitised works from the library. Users may set up RSS feeds to be alerted to new content. The interface is available in English and German.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "el",
                  "language" : "en",
                  "phrase" : "Greek (modern)"
               },
               {
                  "value" : "he",
                  "language" : "en",
                  "phrase" : "Hebrew (modern)"
               },
               {
                  "language" : "en",
                  "value" : "la",
                  "phrase" : "Latin"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Baden State Library",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "acronym" : "BLB",
                  "name" : "Badische Landesbibliothek",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "location" : {
               "longitude" : 8.3991,
               "latitude" : 49.0077
            },
            "url" : "https://www.blb-karlsruhe.de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "country" : "de",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "language" : "de"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:41",
            "date_created" : "2019-09-28 05:09:53",
            "id" : 9264,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9264",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Bangor Public Library"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.bangorpubliclibrary.org",
            "location" : {
               "longitude" : -68.7719,
               "latitude" : 44.8043
            },
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9260,
            "date_created" : "2019-09-28 05:09:37",
            "date_modified" : "2019-12-04 12:27:41",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9260"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://digicom.bpl.lib.me.us",
            "oai_url" : "https://digicom.bpl.lib.me.us/do/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the online collections of the Bangor Public Library. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Bangor Community: Digital Commons@bpl",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9259",
            "publicly_visible" : "yes",
            "id" : 9259,
            "date_created" : "2019-09-28 05:09:35",
            "date_modified" : "2019-11-07 16:47:01"
         },
         "organisation" : {
            "url" : "https://research.bangor.ac.uk/portal/en/",
            "location" : {
               "longitude" : -4.1301,
               "latitude" : 53.2292
            },
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "name" : "Bangor University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Bangor University: eBangor / Prifysgol Bangor",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "description" : "This site allows access to some of the research output and a limited number of historical texts from Bangor University. The site is no longer being updated but may be of use for files which have not been migrated to the new site.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://e.bangor.ac.uk/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://e.bangor.ac.uk",
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 9258,
            "date_created" : "2019-09-28 05:09:34",
            "date_modified" : "2019-12-04 12:27:41",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9258",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "unit" : [
               {
                  "name" : "Bank Street College Library",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 40.8055,
               "longitude" : -73.9663
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Bank Street College of Education"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://cdm16081.contentdm.oclc.org/oai/oai.php",
            "content_subjects" : [
               "17"
            ],
            "url" : "https://cdm16081.contentdm.oclc.org",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               }
            ],
            "description" : "This site provides access to the research outputs of Bank Street College. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "contentdm",
                     "phrase" : "CONTENTdm"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Bank Street College Library - Digital Collections"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "description" : "This site provides access to the research outputs of the Barry University School of Law. Users may set up RSS feeds to be alerted to new content. The interface is available in Enlglish.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "26"
            ],
            "oai_url" : "https://lawpublications.barry.edu/do/oai",
            "url" : "https://lawpublications.barry.edu",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ Barry Law"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Barry University Dwayne O. Andreas School of Law i"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://www.barry.edu/law",
            "location" : {
               "longitude" : -80.1972,
               "latitude" : 25.8788
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9256",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 05:09:09",
            "date_modified" : "2019-12-18 11:13:49",
            "id" : 9256,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://bdc.c3sl.ufpr.br/oai/openaire",
            "url" : "https://bdc.c3sl.ufpr.br",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "pt",
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "6.2",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the scientific research data published by the Federal University of Paraná (UFPR) community and partners. Users may set up RSS feeds to be alerted to new content. The interface is available in Portuguese.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "pt",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório Digital Institucional UFPR - Base de Dadod Científicos"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "id" : 9255,
            "date_modified" : "2019-11-01 13:18:47",
            "date_created" : "2019-09-28 05:09:07",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9255",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UFPR",
                  "name" : "Universidade Federal do Paraná",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ],
                  "language" : "pt",
                  "preferred" : "acronym"
               }
            ],
            "url" : "https://www.ufpr.br/portalufpr",
            "location" : {
               "latitude" : -25.428,
               "longitude" : -49.268
            },
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "value" : "br",
                  "language" : "en"
               }
            ],
            "country" : "br"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Beadle Scholar",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Dakota State University.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://scholar.dsu.edu/do/oai",
            "url" : "https://scholar.dsu.edu",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "unit" : [
               {
                  "name" : "Karl E. Mundt Library"
               }
            ],
            "location" : {
               "latitude" : 44.0124,
               "longitude" : -97.1139
            },
            "url" : "https://dsu.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "acronym" : "DSU",
                  "name" : "Dakota State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9252",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-11 12:44:30",
            "date_created" : "2019-09-28 05:08:18",
            "id" : 9252
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 38.2198,
               "longitude" : -85.703
            },
            "url" : "https://www.bellarmine.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "name" : "Bellarmine University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9247,
            "date_created" : "2019-09-28 05:07:58",
            "date_modified" : "2019-11-21 15:40:44",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9247"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "ScholarWorks@Bellarmine"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://scholarworks.bellarmine.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://scholarworks.bellarmine.edu/do/oai",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Bellarmine University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Belmont Digital Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Belmont University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repository.belmont.edu",
            "oai_url" : "https://repository.belmont.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 36.1355,
               "longitude" : -86.7966
            },
            "unit" : [
               {
                  "name" : "Lila D.Bunch Library"
               },
               {
                  "name" : "Law Library"
               }
            ],
            "url" : "http://www.belmont.edu",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Belmont University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 05:07:52",
            "date_modified" : "2019-11-27 15:12:42",
            "id" : 9246,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9246"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Bennington College Digital Repository"
               }
            ],
            "url" : "https://crossettlibrary.dspacedirect.org",
            "content_subjects" : [
               "18"
            ],
            "oai_url" : "https://crossettlibrary.dspacedirect.org/oai/openaire",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Bennington College. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.8",
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9245",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9245,
            "date_created" : "2019-09-28 05:07:50",
            "date_modified" : "2019-12-04 12:27:41",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "http://www.bennington.edu",
            "location" : {
               "longitude" : -73.2367,
               "latitude" : 42.9248
            },
            "country" : "us",
            "name" : [
               {
                  "name" : "Bennington College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the special collections of the digital library at Biala Podlaska. The interface is available in English or Polish but all text are in Polish only.",
            "software" : {
               "version" : "5.8.3",
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "dlibra"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pl"
            ],
            "oai_url" : "http://www.bbc.mbp.org.pl/dlibra/oai-pmh-repository.xml",
            "url" : "http://www.bbc.mbp.org.pl",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Bialska Biblioteka Cyfrowa",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pl",
                  "phrase" : "Polish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Municipal Public Library in Biała Podlaska",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Miejskiej Biblioteki Publicznej w Białej Podlaskiej",
                  "language" : "pl",
                  "language_phrases" : [
                     {
                        "phrase" : "Polish",
                        "value" : "pl",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "pl",
            "location" : {
               "latitude" : 52.0313,
               "longitude" : 23.1137
            },
            "url" : "http://mbp.org.pl/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pl",
                  "phrase" : "Poland"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9238,
            "date_created" : "2019-09-28 05:07:04",
            "date_modified" : "2019-11-25 10:29:45",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9238",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : 39.638,
               "longitude" : 2.6483
            },
            "url" : "https://www.uib.eu",
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "name" : "University of the Balearic Islands",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Universitat de les Illes Balears"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9232",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 9232,
            "date_created" : "2019-09-28 05:06:33",
            "date_modified" : "2019-11-22 09:14:45",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Biblioteca Digital de les Illes Balears"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ibdigital.uib.es/greenstone/cgi-bin/oaiserver.cgi",
            "url" : "http://ibdigital.uib.es",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of the Balearic Islands and the Balearic Islands. The interface is available in English and Spanish."
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "name" : [
               {
                  "name" : "UMCS Digital Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dlibra.umcs.lublin.pl/dlibra/oai-pmh-repository.xml",
            "url" : "http://dlibra.umcs.lublin.pl/dlibra",
            "content_languages" : [
               "pl"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Maria Curie Sklodowska University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Polish.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9226,
            "date_created" : "2019-09-28 05:05:57",
            "date_modified" : "2019-12-18 10:40:00",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9226"
         },
         "organisation" : {
            "country" : "pl",
            "url" : "https://www.umcs.pl",
            "location" : {
               "longitude" : 22.5405,
               "latitude" : 51.2455
            },
            "country_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Poland"
               }
            ],
            "name" : [
               {
                  "acronym" : "UMCS",
                  "name" : "Maria Curie-Sklodowska University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               },
               {
                  "name" : "Uniwersytet Marii Curie-Skłodowskiej",
                  "acronym" : "UMCS",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language" : "pl",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "Polish",
                        "value" : "pl",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "FMSH",
                  "name" : "Foundation House of Human Sciences"
               },
               {
                  "name" : "Fondation Maison des sciences humaines",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ]
               }
            ],
            "country" : "fr",
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "url" : "http://www.fmsh.fr/",
            "location" : {
               "longitude" : 2.3269,
               "latitude" : 48.8501
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-25 09:59:06",
            "date_created" : "2019-09-28 05:05:29",
            "id" : 9223,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9223"
         },
         "repository_metadata" : {
            "content_languages" : [
               "fr"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "year_established" : 2008,
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://www.bibnum.education.fr/oai/oai2.php",
            "url" : "http://www.bibnum.education.fr",
            "content_subjects" : [
               "2"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "drupal",
                     "language" : "en",
                     "phrase" : "Drupal"
                  }
               ],
               "name" : "drupal",
               "version" : "7"
            },
            "description" : "This site allows access to pre 1950 scientific texts made available by the Foundation House of Human Sciences. The interface and content are French only.",
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Bibnum Education"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "https://www.jccc.edu",
            "location" : {
               "longitude" : -94.7279,
               "latitude" : 38.9257
            },
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Johnson County Community College",
                  "acronym" : "JCCC"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9215",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:27:41",
            "date_created" : "2019-09-28 05:04:59",
            "id" : 9215,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the digital collections of JCCC. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "value" : "contentdm",
                     "language" : "en"
                  }
               ],
               "name" : "contentdm"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "17"
            ],
            "url" : "http://digitallibrary.jccc.edu",
            "oai_url" : "http://digitallibrary.jccc.edu/oai/oai.php",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "JCCC Digital Collections",
                  "name" : "Johnson County Community College Digital Collection",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "description" : "This site allows access to a worldwide gathering of scientific journal entries. The interface is in English only but the articles are in a number of languages.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Cria",
               "name" : "other"
            },
            "content_subjects" : [
               "10",
               "2"
            ],
            "url" : "http://www.bioline.org.br",
            "oai_url" : "http://www.bioline.org.br/oai",
            "content_languages" : [
               "en",
               "fr",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "datasets"
            ],
            "name" : [
               {
                  "name" : "Bioline International",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Bioline International",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "location" : {
               "longitude" : -79.3959,
               "latitude" : 43.6631
            },
            "url" : "http://www.bioline.org.br/",
            "country" : "ca"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9209",
            "publicly_visible" : "yes",
            "id" : 9209,
            "date_modified" : "2019-11-19 10:37:41",
            "date_created" : "2019-09-28 05:04:43"
         }
      },
      {
         "repository_metadata" : {
            "url" : "https://cdm16441.contentdm.oclc.org/digital",
            "content_subjects" : [
               "17"
            ],
            "oai_url" : "https://cdm16441.contentdm.oclc.org/oai/oai.php",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               }
            ],
            "description" : "This site provides access to the online collection and histories of Bismark Junior College and Bismark State College. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "value" : "contentdm",
                     "language" : "en"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Bismarck State College Mystic Memories",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9196",
            "publicly_visible" : "yes",
            "id" : 9196,
            "date_created" : "2019-09-28 05:03:46",
            "date_modified" : "2019-12-16 15:56:32"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Bismark State College",
                  "acronym" : "BSC",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Bismark Junior College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -100.816,
               "latitude" : 46.821
            },
            "url" : "https://bismarckstate.edu",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Ruhr-Universität Bochum",
                  "acronym" : "RUB",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 51.444,
               "longitude" : 7.262
            },
            "url" : "https://www.ruhr-uni-bochum.de/en",
            "country" : "de"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9195,
            "date_modified" : "2019-12-04 12:27:41",
            "date_created" : "2019-09-28 05:03:35",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9195"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               },
               {
                  "phrase" : "Italian",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "name" : [
               {
                  "name" : "Bibliotheksportal - Ruhr-Universität Bochum",
                  "acronym" : "RUB",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "fr",
               "de",
               "it"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://www.ub.rub.de/index",
            "software" : {
               "version" : "8.6.33",
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Imperia"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the digital library discovery service, research outputs, Ebooks and journal database of the  Ruhr-University Bochum in Germany. The interface is available in German and English."
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "North-West University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 27.0947,
               "latitude" : -26.6887
            },
            "url" : "http://www.nwu.ac.za/",
            "country_phrases" : [
               {
                  "phrase" : "South Africa",
                  "language" : "en",
                  "value" : "za"
               }
            ],
            "country" : "za"
         },
         "system_metadata" : {
            "date_modified" : "2019-11-28 09:19:36",
            "date_created" : "2019-09-28 05:03:16",
            "id" : 9190,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9190",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of North-West University, Both interface and content are in English only.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "https://repository.nwu.ac.za",
            "oai_url" : "https://repository.nwu.ac.za/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Boloka Institutional Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "ScholarWorks@BGSU",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://scholarworks.bgsu.edu",
            "oai_url" : "https://scholarworks.bgsu.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Bowling Green State University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9185",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-11-07 13:17:34",
            "date_created" : "2019-09-28 05:02:38",
            "id" : 9185,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 41.38,
               "longitude" : -83.63
            },
            "url" : "https://www.bgsu.edu",
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Bowling Green State University",
                  "acronym" : "BGSU"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Bridgewater College"
               }
            ],
            "country" : "us",
            "url" : "https://www.bridgewater.edu/",
            "location" : {
               "latitude" : 38.3793,
               "longitude" : -78.9694
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9182",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 05:02:28",
            "date_modified" : "2019-11-13 13:40:34",
            "id" : 9182
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "url" : "https://digitalcommons.bridgewater.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.bridgewater.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site allows access to the research output of Bridgewater College. Users may set up RSS feeds to be notified of new content. Interface and all texts are available in English only.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Bridgewater College Digital Commons"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Brooklyn law school"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.brooklaw.edu/",
            "location" : {
               "latitude" : 40.6918,
               "longitude" : -73.9896
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9178",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-11-25 09:41:25",
            "date_created" : "2019-09-28 05:02:01",
            "id" : 9178,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Brooklyn Law School: BrooklynWorks"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "description" : "This site allows access to the research output of Brooklyn Law School. Users may set up RSS feeds to be alerted as to new content. Both the interface and text are in English only.",
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://brooklynworks.brooklaw.edu/do/oai/",
            "content_subjects" : [
               "26"
            ],
            "url" : "https://brooklynworks.brooklaw.edu"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Bucks New University: Bucks Knowledge Archive",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://bucks.collections.crest.ac.uk/cgi/oai2",
            "url" : "https://bucks.collections.crest.ac.uk",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the research output of Bucks New University. Both content and interface are in English only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.16"
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 05:01:53",
            "date_modified" : "2019-11-28 08:46:50",
            "id" : 9175,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9175"
         },
         "organisation" : {
            "country" : "gb",
            "url" : "https://bucks.ac.uk/",
            "location" : {
               "latitude" : 51.6278,
               "longitude" : -0.7532
            },
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "name" : [
               {
                  "name" : "Buckinghamshire New University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9174,
            "date_modified" : "2019-11-15 10:30:28",
            "date_created" : "2019-09-28 05:01:52",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9174"
         },
         "organisation" : {
            "country" : "hu",
            "country_phrases" : [
               {
                  "value" : "hu",
                  "language" : "en",
                  "phrase" : "Hungary"
               }
            ],
            "url" : "https://www.uni-bge.hu",
            "location" : {
               "longitude" : 19.1247,
               "latitude" : 47.508
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Budapest Business School University of Applied Sciences"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "BGE Publikációtár",
                  "language_phrases" : [
                     {
                        "phrase" : "Hungarian",
                        "value" : "hu",
                        "language" : "en"
                     }
                  ],
                  "language" : "hu"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "hu",
                  "phrase" : "Hungarian"
               }
            ],
            "description" : "This site provides access to the research outputs of the Budapest Economic University (BGE). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Hungarian.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "hu"
            ],
            "url" : "http://publikaciotar.repozitorium.bgf.hu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://publikaciotar.repozitorium.bgf.hu/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.8"
            },
            "description" : "This site provides access to the collection of the National Children's Advocacy Center, NCAC. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://calio.dspacedirect.org/oai/openaire",
            "content_subjects" : [
               "10",
               "23"
            ],
            "url" : "https://calio.dspacedirect.org",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Child Abuse Library Online",
                  "acronym" : "CALiO",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "National Children's Advocacy Center"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -86.5834,
               "latitude" : 34.7382
            },
            "url" : "https://www.nationalcac.org"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9158",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:40",
            "date_created" : "2019-09-28 05:00:54",
            "id" : 9158
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "CU FIND (Campbell University, Catherine W. Wood School of Nursing)"
               }
            ],
            "url" : "https://cufind.campbell.edu",
            "oai_url" : "https://cufind.campbell.edu/do/oai/",
            "content_subjects" : [
               "10",
               "23",
               "11"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site allows access to the research output of Campbell University. Users may set up RSS feeds to be alerted as to new content. Both interface and texts are in English only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ],
               "name" : "bepress"
            }
         },
         "organisation" : {
            "url" : "https://www.campbell.edu/",
            "location" : {
               "latitude" : 35.4092,
               "longitude" : -78.7394
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "Campbell University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9145",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-28 04:59:24",
            "date_modified" : "2019-11-27 16:28:04",
            "id" : 9145,
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9144",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:59:22",
            "date_modified" : "2019-11-15 09:54:05",
            "id" : 9144
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Cambridge"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "https://www.cam.ac.uk",
            "unit" : [
               {
                  "name" : "Engineering Department",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 52.2043,
               "longitude" : 0.114908
            },
            "country" : "gb"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://publications.eng.cam.ac.uk",
            "content_subjects" : [
               "11"
            ],
            "oai_url" : "http://publications.eng.cam.ac.uk/cgi/oai2",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Cambridge University Engineering Department. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "CUED Publications database"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://library.stritch.edu",
            "location" : {
               "longitude" : -87.91,
               "latitude" : 43.14
            },
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Cardinal Stritch University Library"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9121,
            "date_modified" : "2019-12-18 11:16:59",
            "date_created" : "2019-09-28 04:57:43",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9121",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Cardinal Stritch University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://digitalcommons.stritch.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.stritch.edu/do/oai",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Stritch Shares"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Cartoteca Digital",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name"
               },
               {
                  "name" : "Digital Maplibrary"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.10.0",
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "value" : "contentdm",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the documents of the Map Library of Catalonia.  The interface is available in Spanish and English and Catalan.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://cartotecadigital.icc.cat",
            "oai_url" : "http://cartotecadigital.icc.cat/cgi-bin/oai.exe",
            "content_subjects" : [
               "19"
            ],
            "content_languages" : [
               "es"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9117",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9117,
            "date_modified" : "2019-12-11 12:31:17",
            "date_created" : "2019-09-28 04:57:26",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Institute Cartografic i Geologic de Catalunya",
                  "acronym" : "ICGC",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "country" : "es",
            "location" : {
               "latitude" : 41.3702,
               "longitude" : 2.1555
            },
            "url" : "https://www.icgc.cat",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9105",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:56:01",
            "date_modified" : "2019-11-01 12:13:22",
            "id" : 9105
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Cherkasy State Technological University",
                  "acronym" : "ChSTU"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "uk",
                        "language" : "en",
                        "phrase" : "Ukrainian"
                     }
                  ],
                  "language" : "uk",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "ChSTU",
                  "name" : "Черкаський державний технологічний університет"
               },
               {
                  "preferred" : "name",
                  "language" : "ru",
                  "language_phrases" : [
                     {
                        "phrase" : "Russian",
                        "language" : "en",
                        "value" : "ru"
                     }
                  ],
                  "name" : "Черкасский государственный технологический университет",
                  "acronym" : "ChSTU",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "https://chdtu.edu.ua",
            "location" : {
               "latitude" : 49.421,
               "longitude" : 32.098
            },
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "language" : "en",
                  "value" : "ua"
               }
            ],
            "country" : "ua"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ru",
                  "language" : "en",
                  "phrase" : "Russian"
               },
               {
                  "language" : "en",
                  "value" : "uk",
                  "phrase" : "Ukrainian"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "ChSTU repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Репозиторій ЧДТУ",
                  "language_phrases" : [
                     {
                        "phrase" : "Ukrainian",
                        "language" : "en",
                        "value" : "uk"
                     }
                  ],
                  "language" : "uk",
                  "preferred" : "name"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Репозиторий ЧГТУ",
                  "language_phrases" : [
                     {
                        "phrase" : "Russian",
                        "language" : "en",
                        "value" : "ru"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "ru"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "ru",
               "uk"
            ],
            "url" : "http://er.chdtu.edu.ua",
            "oai_url" : "http://er.chdtu.edu.ua/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Cherkasy State Technological  University in Cherkasy Oblast, Ukraine.\r\nThe interface is fully available in  Ukranian."
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Chiba Keizai University & Chiba Keizai Junior College Institutional Repository"
               },
               {
                  "name" : "千葉経済大学・千葉経済大学短期大学部機関リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://lib.cku.repo.nii.ac.jp/oai",
            "url" : "https://lib.cku.repo.nii.ac.jp",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Chiba Keizai University & Chiba Keizai Junior College. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9098",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9098,
            "date_modified" : "2019-12-02 10:27:20",
            "date_created" : "2019-09-28 04:55:19",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 35.6195,
               "longitude" : 140.116
            },
            "url" : "https://www.cku.ac.jp/top.html",
            "country" : "jp",
            "name" : [
               {
                  "name" : "Chiba Keizai University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Chiba Keizai Junior College"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "CUC",
                  "name" : "Chiba University of Commerce",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "url" : "https://www.cuc.ac.jp",
            "location" : {
               "longitude" : 139.907,
               "latitude" : 35.7417
            },
            "country" : "jp"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9097",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:55:16",
            "date_modified" : "2019-11-21 14:55:00",
            "id" : 9097
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Chiba University of Commerce Academic Repository"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "name" : "千葉商科大学学術リポジトリ"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://cuc.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://cuc.repo.nii.ac.jp",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Chiba University of Commerce.  The interface is available in English and Japanese."
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Chikushi Jogakuen University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "url" : "https://chikushi-u.repo.nii.ac.jp",
            "oai_url" : "https://chikushi-u.repo.nii.ac.jp/oai",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Chikushi Jogakuen University Repository"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "筑紫女学園大学リポジトリ"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9096",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 04:55:14",
            "date_modified" : "2019-11-27 14:49:27",
            "id" : 9096,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Chikushi Jogakuen University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "location" : {
               "latitude" : 33.513,
               "longitude" : 130.537
            },
            "url" : "https://www.chikushi.ac.jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9093",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-11-01 11:17:42",
            "date_created" : "2019-09-28 04:55:05",
            "id" : 9093,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "CIST",
                  "name" : "Chitose Institute of Science and Technology",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "name" : "公立千歳科学技術大学"
               }
            ],
            "location" : {
               "longitude" : 141.7,
               "latitude" : 42.7976
            },
            "url" : "https://www.chitose.ac.jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Chitose Institute of Science and Technology. Users may set up RSS feeds to be alerted to new content. The interface is available in Japanese.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "oai_url" : "https://cist.repo.nii.ac.jp/oai",
            "url" : "https://cist.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chitose Institute of Science and Technology Academic Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja",
                  "name" : "千歳科学技術大学学術機関リポジトリ"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Chubu Gakuin University Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja",
                  "name" : "中部学院大学・中部学院大学短期大学部学術機関リポジトリ"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of Chubu Gakuin University. The interface is available in English or Japanese but all text is Japanese only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://chubu-gu.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://chubu-gu.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ]
         },
         "organisation" : {
            "country" : "jp",
            "location" : {
               "latitude" : 35.4585,
               "longitude" : 136.898
            },
            "url" : "https://www.chubu-gu.ac.jp/",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Chubu Gakuin University"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "中部学院大学"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-19 10:10:30",
            "date_created" : "2019-09-28 04:54:57",
            "id" : 9089,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9089"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9088,
            "date_modified" : "2019-11-25 09:30:07",
            "date_created" : "2019-09-28 04:54:44",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9088"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Chukyo university",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "中京大学"
               }
            ],
            "location" : {
               "longitude" : 136.966,
               "latitude" : 35.1383
            },
            "url" : "https://www.chukyo-u.ac.jp/english/",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site allows access to the research output of Chukyo University. The interface is available in English or Japanese but all article text is Japanese only.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "url" : "https://chukyo-u.repo.nii.ac.jp",
            "oai_url" : "https://chukyo-u.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Chukyo University Repository for Academic Resources",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "中京大学学術情報リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of Chukyogakuin University.  The interface is available in Japanese & English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "oai_url" : "https://chukyogakuin.repo.nii.ac.jp/oai",
            "url" : "https://chukyogakuin.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Chukyogakuin University Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "name" : "中京学院大学リポジトリ",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "ja",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.chukyogakuin-u.ac.jp",
            "location" : {
               "latitude" : 35.4679,
               "longitude" : 137.489
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chukyo Gakuin University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "中京学院大学",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9087",
            "publicly_visible" : "yes",
            "id" : 9087,
            "date_modified" : "2019-12-11 11:59:58",
            "date_created" : "2019-09-28 04:54:41"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Chuo Gakuin University.  The interface is available in Japanese and English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://cgu.repo.nii.ac.jp",
            "oai_url" : "https://cgu.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Chuo Gakuin University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language" : "ja",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "中央学院大学学術機関リポジトリ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chuo Gakuin University"
               },
               {
                  "name" : "中央学院大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "location" : {
               "longitude" : 140.019,
               "latitude" : 35.8828
            },
            "url" : "https://www.cgu.ac.jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9086",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9086,
            "date_modified" : "2019-12-13 11:22:46",
            "date_created" : "2019-09-28 04:54:39",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Chuo University Academic Information Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "中央大学学術リポジトリ"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://chuo-u.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://chuo-u.repo.nii.ac.jp",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site allows access to the research output of Chuo University. The interface is in Japanese or English with most of the content in Japanese."
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9085",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-27 16:14:18",
            "date_created" : "2019-09-28 04:54:36",
            "id" : 9085
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Chuo University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "中央大学"
               }
            ],
            "url" : "https://www.chuo-u.ac.jp/",
            "location" : {
               "latitude" : 35.7085,
               "longitude" : 139.749
            },
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Ciencia Unisalle"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad de La Salle. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "oai_url" : "https://ciencia.lasalle.edu.co/do/oai",
            "url" : "https://ciencia.lasalle.edu.co",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "country" : "mx",
            "location" : {
               "latitude" : 19.4076,
               "longitude" : -99.1822
            },
            "url" : "https://www.lasalle.edu.co",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "mx",
                  "phrase" : "Mexico"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad de Salle"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9084,
            "date_modified" : "2019-12-04 12:27:40",
            "date_created" : "2019-09-28 04:54:34",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9084"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Clemson University: TigerPrints"
               }
            ],
            "url" : "https://tigerprints.clemson.edu",
            "oai_url" : "https://tigerprints.clemson.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of Clemson University. Users may set up RSS feeds to be alerted to new content. The interface and all text are available in English only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Clemson University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "http://www.clemson.edu/",
            "location" : {
               "latitude" : 34.6735,
               "longitude" : -82.8367
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9077",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 9077,
            "date_modified" : "2019-11-13 13:23:25",
            "date_created" : "2019-09-28 04:53:59",
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Colgate University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 42.8194,
               "longitude" : -75.5364
            },
            "url" : "https://www.colgate.edu/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9070",
            "publicly_visible" : "yes",
            "id" : 9070,
            "date_modified" : "2019-11-27 15:48:55",
            "date_created" : "2019-09-28 04:53:34"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Colgate University: Digital Commons @ Colgate"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site allows access to the research output of Colgate University. Users may set up RSS feeds to be alerted to new content. Both interface and text are in English only.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://commons.colgate.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://commons.colgate.edu/do/oai/"
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://www.usg.edu",
            "location" : {
               "latitude" : 31.1841,
               "longitude" : -81.4847
            },
            "unit" : [
               {
                  "name" : "College of Coastal Georgia",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "University System of Georgia"
               }
            ]
         },
         "system_metadata" : {
            "id" : 9066,
            "date_modified" : "2019-11-27 14:14:35",
            "date_created" : "2019-09-28 04:53:22",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9066",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the \r\nCollege of Coastal Georgia. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://coastalscholar.ccga.edu/oai/openaire",
            "url" : "https://coastalscholar.ccga.edu",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Coastal Scholar Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "The College of Saint Benedict and Saint John's University",
                  "acronym" : "CSB & SJU",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "location" : {
               "latitude" : 45.5812,
               "longitude" : -94.3965
            },
            "url" : "https://www.csbsju.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9065",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-07 12:41:50",
            "date_created" : "2019-09-28 04:53:21",
            "id" : 9065
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "DigitalCommons@CSB/SJU",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the College of Saint Benedict and Saint John's University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://digitalcommons.csbsju.edu/do/oai",
            "url" : "https://digitalcommons.csbsju.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Cross Works",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the College of theHoly Cross. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://crossworks.holycross.edu/do/oai",
            "url" : "https://crossworks.holycross.edu",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.holycross.edu",
            "location" : {
               "longitude" : -71.8083,
               "latitude" : 42.2392
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "College of the Holy Cross"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:53:16",
            "date_modified" : "2019-12-04 12:27:40",
            "id" : 9063,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9063"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Collin College"
               }
            ],
            "country" : "us",
            "url" : "https://www.collin.edu/",
            "location" : {
               "longitude" : -96.6417,
               "latitude" : 33.2182
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9062,
            "date_modified" : "2019-11-13 13:10:20",
            "date_created" : "2019-09-28 04:53:15",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9062"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Collin College: DigitalCommons@Collin"
               }
            ],
            "url" : "https://digitalcommons.collin.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.collin.edu/do/oai/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site grants access to the research output of Collin College. Users may set up RSS feeds to be alerted to new content. Both interface and texts are in English only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Commons@Columbia College Chicago",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digitalcommons.colum.edu",
            "oai_url" : "https://digitalcommons.colum.edu/do/oai",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Columbia College Chigago. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:53:10",
            "date_modified" : "2019-12-18 11:21:00",
            "id" : 9061,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9061"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Columbia College Chicago"
               }
            ],
            "unit" : [
               {
                  "acronym" : "CASPC",
                  "name" : "College Archives & Special Collections"
               }
            ],
            "url" : "https://www.colum.edu",
            "location" : {
               "longitude" : -87.6249,
               "latitude" : 41.8739
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://www.columbia.edu",
            "location" : {
               "latitude" : 40.807,
               "longitude" : -73.961
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Columbia University in the City of New York",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9060,
            "date_modified" : "2019-11-01 11:27:21",
            "date_created" : "2019-09-28 04:53:08",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9060"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of Columbia Law School at Columbia University in the City of New York, USA. This repository's open access content includes published articles, works-in-progress and other research and writing encompassing a wide spectrum of legal and law-related topics. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://scholarship.law.columbia.edu",
            "oai_url" : "https://scholarship.law.columbia.edu/do/oai/",
            "content_subjects" : [
               "26"
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Columbia Law School: Scholarship Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "name" : "Commonwealth of Learning (COL)",
                  "acronym" : "COL",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://oasis.col.org",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://oasis.col.org/oai/openaire",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site allows access to the research output of the Commonwealth of Learning group. The interface is available and most text are in English only."
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9059",
            "publicly_visible" : "yes",
            "id" : 9059,
            "date_created" : "2019-09-28 04:53:05",
            "date_modified" : "2019-11-19 09:52:44"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "COL",
                  "name" : "Commonwealth of Learning"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "location" : {
               "latitude" : 49.226,
               "longitude" : -123.001
            },
            "url" : "https://www.col.org/",
            "country" : "ca"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "CU Commons"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://commons.cu-portland.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://commons.cu-portland.edu/do/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Concordia University. Users may set up RSS feeds to be alerted to new content. The interface is available in Engish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Concordia University"
               }
            ],
            "location" : {
               "longitude" : -122.637,
               "latitude" : 45.5682
            },
            "url" : "https://www.cu-portland.edu",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9046",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 9046,
            "date_modified" : "2019-11-01 12:50:20",
            "date_created" : "2019-09-28 04:52:26",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Connacht-Ulster Alliance Libraries: CUAL Repository"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "datasets"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the the research output of the Connacht-Ulster Alliance Libraries. This is a multiple institution repository with input from several different university's and research institutes. \r\nThe interface and text are mostly in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://research.thea.ie",
            "oai_url" : "https://research.thea.ie/oai/openaire"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9043",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-11-25 09:20:02",
            "date_created" : "2019-09-28 04:52:21",
            "id" : 9043,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "THEA"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9017",
            "publicly_visible" : "yes",
            "id" : 9017,
            "date_modified" : "2019-11-13 11:52:12",
            "date_created" : "2019-09-28 04:50:24"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Czech Academy of Sciences"
               },
               {
                  "name" : "Česká akademie věd",
                  "language_phrases" : [
                     {
                        "phrase" : "Czech",
                        "language" : "en",
                        "value" : "cs"
                     }
                  ],
                  "language" : "cs"
               }
            ],
            "url" : "http://www.avcr.cz/en",
            "location" : {
               "longitude" : 14.4141,
               "latitude" : 50.0816
            },
            "country_phrases" : [
               {
                  "phrase" : "Czechia",
                  "value" : "cz",
                  "language" : "en"
               }
            ],
            "country" : "cz"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "cs"
            ],
            "oai_url" : "http://dlib.lib.cas.cz/cgi/oai2",
            "content_subjects" : [
               "2"
            ],
            "url" : "http://dlib.lib.cas.cz",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the Czech Academy of Sciences. The interface is available in English but all texts are in Czech.",
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "cs",
                  "phrase" : "Czech"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "dKNAV",
                  "name" : "Czech Academy of Sciences: dKNAV"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "cs",
                        "language" : "en",
                        "phrase" : "Czech"
                     }
                  ],
                  "language" : "cs",
                  "acronym" : "dKNAV",
                  "name" : "Knihovna Akademie věd České Republiky"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "disciplinary"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "url" : "https://www.dbges.de",
            "location" : {
               "latitude" : 52.9652,
               "longitude" : -1.1373
            },
            "country" : "de",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "German Soil Science Society"
               },
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "DBG",
                  "name" : "Deutschen Bodenkundlichen Gesellschaft",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "de"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:50:23",
            "date_modified" : "2019-12-18 11:47:14",
            "id" : 9016,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9016"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "name" : "DBGPrints Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "oai_url" : "http://eprints.dbges.de/cgi/oai2",
            "url" : "http://eprints.dbges.de",
            "content_subjects" : [
               "6"
            ],
            "content_languages" : [
               "de"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the German Soil Science Society. Users may set up RSS feeds to be alerted to new content. The interface is available in German and English.",
            "content_subjects_phrases" : [
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.14"
            }
         }
      },
      {
         "organisation" : {
            "country" : "de",
            "url" : "https://www.uni-ulm.de",
            "location" : {
               "latitude" : 48.423,
               "longitude" : 9.955
            },
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Ulm University",
                  "acronym" : "ULM",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "ULM",
                  "name" : "Universität Ulm",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "de"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9015",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 9015,
            "date_created" : "2019-09-28 04:50:22",
            "date_modified" : "2019-10-31 16:12:35",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "DBIS EPub"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://dbis.eprints.uni-ulm.de",
            "oai_url" : "http://dbis.eprints.uni-ulm.de/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3.3.9",
               "name" : "eprints"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Universität Ulm in Baden-Württemberg, Germany. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : -7.7683,
               "longitude" : 110.334
            },
            "url" : "https://www.unisayogya.ac.id/en/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "country" : "id",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Aisyiyah Health Sciences College, Yogyakarta"
               },
               {
                  "name" : "Universitas 'Aisyiyah Yogyakarta",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 04:50:13",
            "date_modified" : "2019-11-27 15:29:44",
            "id" : 9010,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9010",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Digital library at Aisyiyah Health Sciences College, Yogyakarta",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "DIGILIB  at Universitas 'Aisyiyah Yogyakarta (UNISA)",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of the Aisyiyah Health Sciences College, Yogyakarta. The interface is in English but all content is Indonesian.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://digilib.unisayogya.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digilib.unisayogya.ac.id",
            "content_languages" : [
               "id"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "acronym" : "DRCMR eprints",
                  "name" : "E-print repository for the Danish Research Centre for Magnetic Resonance",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "description" : "This site provides access to the research outputs of the Danish Research Centre for Magnetic Resonance. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "content_subjects" : [
               "10"
            ],
            "url" : "http://eprints.drcmr.dk",
            "oai_url" : "http://eprints.drcmr.dk/cgi/oai2",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "DRCMR",
                  "name" : "Danish Research Centre for Magnetic Resonance",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "country" : "dk",
            "location" : {
               "longitude" : 12.4653,
               "latitude" : 55.6495
            },
            "url" : "http://www.drcmr.dk",
            "country_phrases" : [
               {
                  "value" : "dk",
                  "language" : "en",
                  "phrase" : "Denmark"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9008,
            "date_created" : "2019-09-28 04:50:08",
            "date_modified" : "2019-12-02 10:40:39",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9008"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Indoamerica University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Universidad Indoamerica",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "location" : {
               "longitude" : -78.5039,
               "latitude" : -0.1203
            },
            "url" : "http://www.uti.edu.ec",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "country" : "es"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 9007,
            "date_modified" : "2019-11-21 14:47:48",
            "date_created" : "2019-09-28 04:49:55",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9007"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Dspace Indoamerica University"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "DSpace Universidad Indoamerica"
               }
            ],
            "oai_url" : "http://repositorio.uti.edu.ec/oai/openaire",
            "url" : "http://repositorio.uti.edu.ec",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Indoamerica University. The interface is available in English and Spanish.",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Czech",
                  "language" : "en",
                  "value" : "cs"
               }
            ],
            "name" : [
               {
                  "name" : "DSpace at AMU",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "cs"
            ],
            "content_subjects" : [
               "18"
            ],
            "url" : "https://dspace.amu.cz",
            "oai_url" : "https://dspace.amu.cz/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "1.7",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Academy of performing arts in Prague. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9006",
            "publicly_visible" : "yes",
            "id" : 9006,
            "date_modified" : "2019-11-27 14:04:33",
            "date_created" : "2019-09-28 04:49:53"
         },
         "organisation" : {
            "url" : "https://www.amu.cz",
            "location" : {
               "latitude" : 50.0875,
               "longitude" : 14.4019
            },
            "country_phrases" : [
               {
                  "phrase" : "Czechia",
                  "language" : "en",
                  "value" : "cz"
               }
            ],
            "country" : "cz",
            "name" : [
               {
                  "name" : "Academy of performing arts in Prague",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Czech",
                  "language" : "en",
                  "value" : "cs"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "DSpace at Masaryk University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "cs"
            ],
            "oai_url" : "http://dspace.muni.cz/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.muni.cz",
            "software" : {
               "name" : "dspace",
               "version" : "6.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Masaryk University. The interface is available in English and Czech."
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Czechia",
                  "value" : "cz",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 16.605,
               "latitude" : 49.1986
            },
            "url" : "https://www.muni.cz",
            "country" : "cz",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "MUNI",
                  "name" : "Masaryk University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/9005",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:49:49",
            "date_modified" : "2019-11-07 11:45:28",
            "id" : 9005
         }
      },
      {
         "organisation" : {
            "country" : "za",
            "url" : "https://www.dut.ac.za",
            "location" : {
               "longitude" : 31.0072,
               "latitude" : -29.8513
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "za",
                  "phrase" : "South Africa"
               }
            ],
            "name" : [
               {
                  "name" : "Durban University of Technology",
                  "acronym" : "DUT",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 8996,
            "date_created" : "2019-09-28 04:48:56",
            "date_modified" : "2019-12-12 16:10:46",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8996"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.10.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Durban University of Technology. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://openscholar.dut.ac.za/oai/openaire",
            "url" : "http://openscholar.dut.ac.za",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "DUT Open Scholar",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Daemen Digital Commons",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Daemen College. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "url" : "https://digitalcommons.daemen.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.daemen.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 8994,
            "date_modified" : "2019-11-14 15:55:14",
            "date_created" : "2019-09-28 04:48:52",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8994"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.daemen.edu",
            "location" : {
               "latitude" : 42.9648,
               "longitude" : -78.7884
            },
            "name" : [
               {
                  "name" : "Deamen College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8992",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-11-21 14:38:41",
            "date_created" : "2019-09-28 04:48:48",
            "id" : 8992,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 31.7469,
               "longitude" : 130.769
            },
            "url" : "http://www.daiichi-koudai.ac.jp",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Daiichi Institute of Technology"
               },
               {
                  "name" : "第一工業大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Daiichi Institute of Technology Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "第一工業大学リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Daiichi Institute of Technology.  The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://daiichi-koudai.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "11"
            ],
            "url" : "https://daiichi-koudai.repo.nii.ac.jp"
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-28 04:48:45",
            "date_modified" : "2019-11-27 13:49:01",
            "id" : 8991,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8991",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "url" : "http://www.daiichi-cps.ac.jp",
            "location" : {
               "longitude" : 130.419,
               "latitude" : 33.5642
            },
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "name" : "Daiichi Pharmaceutical University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://daiichi-cps.repo.nii.ac.jp/oai",
            "url" : "https://daiichi-cps.repo.nii.ac.jp",
            "content_subjects" : [
               "2"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Daiichi University of Pharmacy. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "name" : [
               {
                  "name" : "Daiichi University of Pharmacy Institutional Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "第一薬科大学機関リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Den-en Chofu University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "url" : "https://www.dcu.ac.jp",
            "location" : {
               "longitude" : 139.524,
               "latitude" : 35.5952
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-14 15:45:15",
            "date_created" : "2019-09-28 04:47:51",
            "id" : 8979,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8979"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Den-en Chofu University Repository",
                  "acronym" : "DCU-Repo"
               },
               {
                  "name" : "田園調布学園大学学術機関リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://dcu.repo.nii.ac.jp/oai",
            "url" : "https://dcu.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Den-en Chofu University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            }
         }
      },
      {
         "system_metadata" : {
            "id" : 8977,
            "date_created" : "2019-09-28 04:47:30",
            "date_modified" : "2019-11-21 14:31:40",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8977",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "es",
            "url" : "https://www.ufv.es",
            "location" : {
               "latitude" : 40.4396,
               "longitude" : -3.8355
            },
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad Francisco de Vitoria",
                  "acronym" : "UFV Madrid",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "name" : "Deposito Digital Francisco de Vitoria",
                  "acronym" : "Deposito Digital UFV",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Francisco de Vitoria. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "http://ddfv.ufv.es",
            "oai_url" : "http://ddfv.ufv.es/oai/openaire",
            "content_subjects" : [
               "10"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "DALNET digital archive"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Detroit Area Library Network. Users may set up RSS feeds to be alerted to new content. The interface is available in English.\r\n\r\nDetroit Area Library Network",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dalnetarchive.org",
            "oai_url" : "http://dalnetarchive.org/oai/openaire",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Wayne State University"
               }
            ],
            "url" : "https://www.dalnet.org",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "acronym" : "DALNET",
                  "name" : "Detroit Area Library Network",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8976",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-27 13:40:42",
            "date_created" : "2019-09-28 04:47:16",
            "id" : 8976
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "url" : "http://www.digizeitschriften.de/en/startseite/",
            "location" : {
               "latitude" : 51.5336,
               "longitude" : 9.9321
            },
            "country" : "de",
            "name" : [
               {
                  "name" : "DigiZeitschriften"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-27 15:10:47",
            "date_created" : "2019-09-28 04:46:45",
            "id" : 8965,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8965"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "DigiMagazines - OAI Frontend"
               },
               {
                  "name" : "DigiZeitschriften",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the special collection books and journals in the collection gathered by DigiZeitschriften. The interface is in English or German but all content is German only.",
            "software" : {
               "name" : "other",
               "version" : "3",
               "name_other" : "TYPO",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "de"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.digizeitschriften.de",
            "oai_url" : "http://www.digizeitschriften.de/oai2",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcollections-wmich.contentdm.oclc.org/oai/oai.php",
            "url" : "https://digitalcollections-wmich.contentdm.oclc.org",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "contentdm",
                     "phrase" : "CONTENTdm"
                  }
               ],
               "name" : "contentdm"
            },
            "description" : "This site provides access to the collections of Michigan University Libraries’.  The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "WMU Libraries' Digital Collections",
                  "name" : "Western Michigan University Libraries' Digital Collections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ]
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Western Michigan University University Libraries"
               }
            ],
            "url" : "https://wmich.edu",
            "location" : {
               "latitude" : 42.6762,
               "longitude" : -85.186
            },
            "name" : [
               {
                  "name" : "Western Michigan University",
                  "acronym" : "WMU",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8963",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:46:20",
            "date_modified" : "2019-12-04 12:27:40",
            "id" : 8963
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Cedarville University Digital Commons"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://digitalcommons.cedarville.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.cedarville.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Cedarville University . Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8962",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 04:46:10",
            "date_modified" : "2019-11-21 13:24:17",
            "id" : 8962,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Cedarville University"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://www.cedarville.edu",
            "location" : {
               "latitude" : 39.7475,
               "longitude" : -83.8111
            }
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8960",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 8960,
            "date_created" : "2019-09-28 04:46:06",
            "date_modified" : "2019-11-07 11:13:42",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "American University Washington College of Law"
               }
            ],
            "country" : "us",
            "url" : "https://www.wcl.american.edu",
            "location" : {
               "longitude" : -77.08,
               "latitude" : 38.945
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://digitalcommons.wcl.american.edu/do/oai",
            "url" : "https://digitalcommons.wcl.american.edu",
            "content_subjects" : [
               "26"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the American Univerisity. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Digital Commons @ American University Washington College of Law",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8959",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 8959,
            "date_modified" : "2019-11-07 16:10:03",
            "date_created" : "2019-09-28 04:46:04",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "latitude" : 42.2937,
               "longitude" : -71.8297
            },
            "url" : "https://www.assumption.edu/",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "Assumption College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://digitalcommons.assumption.edu/do/oai/",
            "url" : "https://digitalcommons.assumption.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site gives access to the research output of Assumption College. Users may set up RSS feeds to be alerted to new content. The interface is available in English only.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ Assumption College"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8958",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 8958,
            "date_modified" : "2019-12-03 16:09:35",
            "date_created" : "2019-09-28 04:46:02",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Biola University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 33.9055,
               "longitude" : 118.018
            },
            "url" : "https://www.biola.edu"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Commons @ Biola",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.biola.edu/do/oai",
            "url" : "https://digitalcommons.biola.edu",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Biola University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ CSUMB (California State University, Monterey Bay)"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digitalcommons.csumb.edu",
            "oai_url" : "https://digitalcommons.csumb.edu/do/oai/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of California State University, at Monterey Bay. Users may set up RSS feeds to be alerted to new content. Both interface and text are available in English only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "California State University, Monterey Bay"
               }
            ],
            "country" : "us",
            "url" : "https://csumb.edu",
            "location" : {
               "latitude" : 36.6501,
               "longitude" : -121.798
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8957",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-11-13 11:01:33",
            "date_created" : "2019-09-28 04:46:00",
            "id" : 8957,
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-31 16:08:55",
            "date_created" : "2019-09-28 04:45:58",
            "id" : 8956,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8956"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "SUNY College Cortland",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "http://www2.cortland.edu/home",
            "location" : {
               "latitude" : 42.597,
               "longitude" : -76.1893
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "https://digitalcommons.cortland.edu/do/oai",
            "url" : "https://digitalcommons.cortland.edu",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the SUNY College Cortland. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Commons @ Cortland",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8955",
            "publicly_visible" : "yes",
            "id" : 8955,
            "date_modified" : "2019-10-31 15:49:17",
            "date_created" : "2019-09-28 04:45:56"
         },
         "organisation" : {
            "location" : {
               "latitude" : 34.148,
               "longitude" : -118.14
            },
            "url" : "https://www.fuller.edu",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "Fuller Theological Seminary",
                  "acronym" : "FULLER",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Digital Commons @ Fuller"
               }
            ],
            "url" : "https://digitalcommons.fuller.edu",
            "oai_url" : "https://digitalcommons.fuller.edu/do/oai/",
            "content_subjects" : [
               "22"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               }
            ],
            "description" : "This site provides access to the research outputs of the Fuller Theological Seminary in Pasedena, California, USA. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            }
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:45:54",
            "date_modified" : "2019-11-19 09:01:30",
            "id" : 8954,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8954"
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://harrisburgu.edu/",
            "location" : {
               "latitude" : 40.2618,
               "longitude" : -76.8803
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Harrisburg university of science and technology"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digitalcommons.harrisburgu.edu",
            "oai_url" : "https://digitalcommons.harrisburgu.edu/do/oai/",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site allows access to the research output of the Harrisburg university of science and technology. Users may set up RSS feeds to be alerted to new content. Interface and text are in English only.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Commons @ Harrisburg University of Science and Technology",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-28 04:45:52",
            "date_modified" : "2019-11-25 08:39:29",
            "id" : 8953,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8953",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Langston University"
               }
            ],
            "location" : {
               "latitude" : 35.9454,
               "longitude" : -97.2629
            },
            "url" : "https://www.langston.edu/",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://dclu.langston.edu/do/oai/",
            "url" : "https://dclu.langston.edu",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the student works and special collections of Langston University. Users may set up RSS feeds to be alerted as to new content, both interface and text are in English only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Digital Commons @ Langston University"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Digital Commons @ Luther Seminary",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Luther Seminary.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "url" : "https://digitalcommons.luthersem.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.luthersem.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8952",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 04:45:50",
            "date_modified" : "2019-12-11 11:41:30",
            "id" : 8952
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Luther Seminary",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "us",
            "location" : {
               "longitude" : -93.1963,
               "latitude" : 44.9847
            },
            "url" : "https://www.luthersem.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of New Jersey Institute of Technology.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digitalcommons.njit.edu",
            "oai_url" : "https://digitalcommons.njit.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Digital Commons @ New Jersey Institute of Technology",
                  "acronym" : "NJIT"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "longitude" : -74.1785,
               "latitude" : 40.7422
            },
            "url" : "https://www.njit.edu",
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "NJIT",
                  "name" : "New Jersey Institute of Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8951",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 8951,
            "date_modified" : "2019-12-13 12:27:56",
            "date_created" : "2019-09-28 04:45:48",
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8950",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 04:45:46",
            "date_modified" : "2019-11-27 14:43:40",
            "id" : 8950,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 43.7594,
               "longitude" : -71.6882
            },
            "url" : "https://www.plymouth.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Plymouth State University"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ Plymouth State University"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.plymouth.edu/do/oai/",
            "url" : "https://digitalcommons.plymouth.edu",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the research output of Plymouth State University. Users may set up RSS feeds to be alerted to new content. Both interface and text are in English only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            }
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8949",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 8949,
            "date_modified" : "2019-11-14 15:36:21",
            "date_created" : "2019-09-28 04:45:44",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Sotheby's Institute of Art",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 51.5186,
               "longitude" : -0.1333
            },
            "url" : "https://www.sothebysinstitute.com",
            "country" : "us"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ SIA"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://digitalcommons.sia.edu/do/oai",
            "url" : "https://digitalcommons.sia.edu",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Sotheby's Institute of Art. Users may set up RSS feeds to be alerted to new content. The interface is available English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://digitalcommons.shawnee.edu/do/oai",
            "url" : "https://digitalcommons.shawnee.edu",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "digital_commons",
               "name_phrases" : [
                  {
                     "value" : "digital_commons",
                     "language" : "en",
                     "phrase" : "Digital Commons"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Shawnee State University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Digital Commons @ Shawnee State University"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8948",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-28 04:45:42",
            "date_modified" : "2019-12-02 11:27:01",
            "id" : 8948,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Shawnee State University",
                  "acronym" : "SSU",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -84.4924,
               "latitude" : 39.9947
            },
            "url" : "https://www.shawnee.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ TRU Library"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://digitalcommons.library.tru.ca",
            "oai_url" : "https://digitalcommons.library.tru.ca/do/oai",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Thompson Rivers University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "id" : 8947,
            "date_created" : "2019-09-28 04:45:39",
            "date_modified" : "2019-11-21 13:12:51",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8947",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "TRU",
                  "name" : "Thompson Rivers University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "ca",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ca",
                  "phrase" : "Canada"
               }
            ],
            "unit" : [
               {
                  "acronym" : "TRU Library",
                  "name" : "Thompson Rivers University Library",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "https://www.tru.ca",
            "location" : {
               "longitude" : -120.366,
               "latitude" : 50.6684
            }
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/8946",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 04:45:36",
            "date_modified" : "2019-11-27 13:14:27",
            "id" : 8946,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University at Buffalo School of Law"
               }
            ],
            "country" : "us",
            "url" : "http://www.law.buffalo.edu",
            "location" : {
               "longitude" : -78.7891,
               "latitude" : 43
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "26"
            ],
            "oai_url" : "https://digitalcommons.law.buffalo.edu/do/oai",
            "url" : "https://digitalcommons.law.buffalo.edu",
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University at Buffalo School of Law. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Japanese.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Digital Commons @ University at Buffalo School of Law"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         }
      }
   ]
}

