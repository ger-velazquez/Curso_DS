{
   "items" : [
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Corporation for Latin American Studies (CIEPLAN)",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cl",
                  "phrase" : "Chile"
               }
            ],
            "url" : "http://www.cieplan.org/",
            "location" : {
               "latitude" : -33.4035,
               "longitude" : -70.6005
            },
            "country" : "cl"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2935",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 2935,
            "date_created" : "2013-12-17 11:57:23",
            "date_modified" : "2019-10-17 14:34:48",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Virtual Library of Cieplan"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "metadata_record_count" : 495,
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "HTML",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "language" : "en",
                  "value" : "19"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "description" : "This is the virtual library of Corporacion de Estudios para Latinoamerica (CIEPLAN). It allows access to the books and papers from CIEPLAN, ranging from academic articles about politics to technical research about Public Policies, Economy and Development. The interface is in Spanish and includes an RSS feed to alert users of new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://www.cieplan.org/biblioteca/index.tpl?categoria=Libro&startat=1&page=1#",
            "content_subjects" : [
               "19",
               "24",
               "26"
            ],
            "content_languages" : [
               "es"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2934",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 2934,
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-12-17 11:22:37",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "New College of Florida",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.ncf.edu/",
            "location" : {
               "latitude" : 27.3844,
               "longitude" : -82.5621
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 8313,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "New College of Florida Digital Collections",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ncf.sobek.ufl.edu/",
            "oai_url" : "http://ncf.sobek.ufl.edu/sobekcm_oai.aspx",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 24,
            "description" : "This is the institutional repository of New College Florida, which contains the work of staff and students. All access to theses is restricted to internal use, but copies may be requested. The college publications archive, reports, records, and photographs are openly accessible. The interface is in English.",
            "software" : {
               "name_other" : "SobekCM",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name" : "other"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://seminolestate.sobek.ufl.edu/sobekcm_oai.aspx",
            "content_subjects" : [
               "17",
               "18"
            ],
            "url" : "http://seminolestate.sobek.ufl.edu/",
            "software" : {
               "name" : "other",
               "name_other" : "SobekCM",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "This is the Seminole State College of Florida Digital Collections library which comprises images from the following collections: Burt Perinchief Collection; Fine Arts Theater Collection; Music Collection; Sports Collection. The interface is in English.",
            "metadata_record_count" : 189,
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Seminole State College of Florida Digital Collections",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "18",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Seminole State College of Florida"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -81.3057,
               "latitude" : 28.7442
            },
            "url" : "http://www.seminolestate.edu/",
            "country" : "us"
         },
         "system_metadata" : {
            "date_created" : "2013-12-17 10:58:48",
            "date_modified" : "2019-12-04 12:27:31",
            "id" : 2933,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2933",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 5741,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universität Paderborn - Digitale Sammlungen",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://digital.ub.uni-paderborn.de/oai",
            "url" : "http://digital.ub.uni-paderborn.de/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_other" : "Visual Library Server",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "The Digital Collections of the University Library Paderborn allow free open access to electronic publications by University faculty and staff and the library's digitized holdings. The material includes pre-20th century books and documents of historical value and documents pertaining to the the history of the University which was founded in 1972.",
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "de",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2932,
            "date_modified" : "2019-10-17 14:34:48",
            "date_created" : "2013-12-17 10:33:40",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2932"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universitätsbibliothek Paderborn",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : 8.7711,
               "latitude" : 51.7068
            },
            "url" : "http://www.uni-paderborn.de/",
            "country" : "de",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universitat Paderborn",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repozytorium PJWSTK / PJIIT Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Polish"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 181,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Polish end English. Users may set up Atom and RSS feeds to be alerted to new content.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "27",
                  "phrase" : "Library and Information Science"
               },
               {
                  "phrase" : "Computers and IT",
                  "language" : "en",
                  "value" : "14"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pl",
               "en"
            ],
            "content_subjects" : [
               "27",
               "14"
            ],
            "url" : "https://repin.pjwstk.edu.pl/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2931",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2931,
            "date_created" : "2013-12-11 11:59:15",
            "date_modified" : "2019-10-17 14:34:48",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Polsko-Japońska Wyższa Szkoła Technik Komputerowych / Polish-Japanese Institute of Information Technology"
               }
            ],
            "country" : "pl",
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "location" : {
               "latitude" : 52.2237,
               "longitude" : 20.9935
            },
            "url" : "http://www.pjwstk.edu.pl/"
         }
      },
      {
         "system_metadata" : {
            "id" : 2930,
            "date_created" : "2013-12-11 10:19:14",
            "date_modified" : "2019-10-17 14:34:48",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2930",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Tsinghua University"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "language" : "en",
                  "value" : "cn"
               }
            ],
            "url" : "http://www.tsinghua.edu.cn/",
            "location" : {
               "latitude" : 39.904,
               "longitude" : 116.408
            },
            "country" : "cn"
         },
         "policies" : {
            "data_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "value" : "some_or_all_restricted",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  }
               ],
               "url" : [
                  "http://ir.lib.tsinghua.edu.cn/oadoc.html"
               ]
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Institutional Repository of Tsinghua University"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               }
            ],
            "metadata_record_count" : 114678,
            "description" : "The Institution Repository of Tsinghua University (THUIR) is designed to capture, preserve and communicate academic digital material produced in teaching and research activities at Tsinghua University. The interface is in Chinese and it includes an RSS feed to alert users to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ir.lib.tsinghua.edu.cn/",
            "oai_url" : "http://ir.lib.tsinghua.edu.cn/oai/request",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Pioneer Open Access Repository"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 2479,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This is the institutional repository of Texas Womans University. The interface is in English and includes RSS feeds to alert users to updates.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://Poar.twu.edu/",
            "oai_url" : "http://poar.twu.edu/oai/request"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2929",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2929,
            "date_modified" : "2019-10-17 14:34:48",
            "date_created" : "2013-12-10 14:36:53",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Texas Womans University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "latitude" : 33.2265,
               "longitude" : -97.1273
            },
            "url" : "http://www.TWU.edu/",
            "country" : "us"
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 1550,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositorio Institucional Escuela de Ingenieria de Antioquia"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "24",
               "11"
            ],
            "oai_url" : "http://repository.eia.edu.co/oai/request",
            "url" : "http://repository.eia.edu.co/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This is the Institutional Repository of the school of Engineering of Antioquia which contains the work of staff and students. The repository manages, disseminates and provides access to electronic full text documents created by the university community. The interface is in Spanish or English and includes RSS feed to alert users to new content.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Escuela de Ingenieria de Antioquia",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : -75.5751,
               "latitude" : 6.2359
            },
            "url" : "http://www.eia.edu.co/",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "country" : "co"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2928",
            "publicly_visible" : "yes",
            "id" : 2928,
            "date_created" : "2013-12-06 11:54:21",
            "date_modified" : "2019-10-17 14:34:48"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "technically_malfunctioning",
                  "language" : "en",
                  "phrase" : "Technically Malfunctioning"
               }
            ],
            "content_subjects" : [
               "23",
               "10"
            ],
            "url" : "https://ctsacorus.org/",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "HUBzero"
            },
            "description" : "This is a collection of resources for community engaged research. The interface is in English.",
            "metadata_record_count" : 151,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "CORUS",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "disciplinary",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "technically_malfunctioning",
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "notes" : "Resources on CORUS support participatory research. These include: evaluation tools, educational modules, proposals for seed funding, organizational strategies and other useful items. Users of the site are encouraged to upload relevant documents, share resources with peers, and engage in discussions with other users about the resources on the site.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-12-06 11:07:34",
            "date_modified" : "2019-12-04 12:27:31",
            "id" : 2926,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2926"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.indianactsi.org/",
            "location" : {
               "longitude" : -86.1581,
               "latitude" : 39.7684
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Indiana Clinical Translational Sciences Institute"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "CSIR-Central Electrochemical Research Institute",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "in",
            "url" : "http://www.cecri.res.in/",
            "location" : {
               "longitude" : 78.8,
               "latitude" : 10.07
            },
            "country_phrases" : [
               {
                  "value" : "in",
                  "language" : "en",
                  "phrase" : "India"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2925,
            "date_modified" : "2019-10-17 14:34:48",
            "date_created" : "2013-12-05 13:03:11",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2925"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Electrical and Electronic Engineering",
                  "language" : "en",
                  "value" : "15"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2640,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "IR@CECRI",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 1176,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://cecri.csircentral.net/",
            "content_subjects" : [
               "15"
            ],
            "oai_url" : "http://cecri.csircentral.net/cgi/oai2",
            "software" : {
               "name" : "eprints",
               "version" : "3.2.8",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This is the institutional repository of The Central Electrochemical Research Institute, Karaikudi. the interface is in English and it includes RSS feeds to alert users to new content."
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "Many items are not available as the full text.",
            "content_languages" : [
               "id"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "The UBM Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 352,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.2.0"
            },
            "description" : "This is the institutional repository of Bunda Mulia University, which allows open access to the work of staff and students. The interface is in English and Indonesian and includes RSS feeds to alert users to new content.",
            "full_text_record_count" : 74,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://repository.ubm.ac.id:8080/cgi/oai2",
            "url" : "http://repository.ubm.ac.id/",
            "content_subjects" : [
               "1"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2924",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:48",
            "date_created" : "2013-12-05 12:36:34",
            "id" : 2924,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Bunda Mulia University"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "location" : {
               "latitude" : -6.13025,
               "longitude" : 106.818
            },
            "url" : "http://www.ubm.ac.id/",
            "country" : "id"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "year_established" : 2009,
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "es"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 4707,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Biblioteca Digital  UMSA",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "url" : "http://bibliotecadigital.umsa.bo/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This is the institutional repository of Universidad Mayor de San Andres which allows open access to the work of staff and students. The interface is in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2923",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-12-05 12:15:34",
            "id" : 2923
         },
         "organisation" : {
            "country" : "bo",
            "country_phrases" : [
               {
                  "phrase" : "Bolivia",
                  "value" : "bo",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -16.499,
               "longitude" : -68.1462
            },
            "url" : "http://www.umsa.bo/",
            "name" : [
               {
                  "name" : "Universidad Mayor de San Andres",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.roca.utfpr.edu.br/jspui/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "The Open Repository Other Collections - ROCA aims to collect, preserve and provide access to the Works Completion of Graduate Course and Specialization produced by students at all campuses of the Federal Technological University of Paraná (UTFPR).\n\nIn addition, it operates in the storage and dissemination of audiovisual production and iconographic records resulting from internal or external to the institution works through examination of the Steering Committee. the interface is in Portuguese and includes RSS feeds to alert users to new content.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 8886,
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório de Outras Coleções Abertas (ROCA)",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2922",
            "publicly_visible" : "yes",
            "id" : 2922,
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-12-05 11:58:56"
         },
         "organisation" : {
            "country" : "br",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "value" : "br",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -25.4284,
               "longitude" : -49.2733
            },
            "url" : "http://www.utfpr.edu.br/",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidade Tecnológica Federal do Paraná"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en",
               "zh"
            ],
            "name" : [
               {
                  "name" : "Digital Commons @ Lingnan University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 14323,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "description" : "Digital Commons @ Lingnan University is the repository of the Lingnan University. Its purpose is to collect and preserve the scholarship and creative works of our community and to share our intellectual life with a global audience. The repository is a service of the Lingnan University Library. The interface is in English and includes an RSS feed to alert users to new content.",
            "full_text_record_count" : 3102,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://commons.ln.edu.hk/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://commons.ln.edu.hk/"
         },
         "policies" : {
            "submission_policy" : {
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "community_members"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "url" : [
                  "http://commons.ln.edu.hk/faq.html"
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor"
            },
            "data_policy" : {
               "url" : [
                  "http://commons.ln.edu.hk/faq.html"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "value" : "removal_at_request",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "removed_from_public_view",
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "language" : "en",
                           "value" : "tombstone",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ]
                  }
               },
               "closure_policy" : "undefined",
               "url" : [
                  "http://commons.ln.edu.hk/faq.html"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               }
            },
            "content_policy" : {
               "url" : [
                  "http://commons.ln.edu.hk/faq.html"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en",
                  "zh"
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Chinese",
                     "value" : "zh",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://commons.ln.edu.hk/faq.html"
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Lingnan University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "hk",
            "location" : {
               "longitude" : 113.982,
               "latitude" : 22.4114
            },
            "url" : "http://www.ln.edu.hk/",
            "country_phrases" : [
               {
                  "value" : "hk",
                  "language" : "en",
                  "phrase" : "Hong Kong"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2921,
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-12-05 11:30:34",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2921",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 411,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Theoreme",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://theoreme.univ-valenciennes.fr/",
            "oai_url" : "http://ent13.univ-valenciennes.fr/ori-oai-repository/OAIHandler",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "other",
               "name_other" : "ORI-OAI",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "This is the institutional repository of the University of Valenciennes and Hainaut-Cambrai (UVHC). It currently only provides access to the doctoral thesis of the institution, but plans to include other types of documents in the future. The interface is in French.",
            "year_established" : 2012,
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "fr"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2920",
            "publicly_visible" : "yes",
            "id" : 2920,
            "date_created" : "2013-12-04 12:19:02",
            "date_modified" : "2019-10-17 14:34:47"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Université de Valenciennes et du Hainaut-Cambrésis",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "fr",
            "location" : {
               "latitude" : 50.3535,
               "longitude" : 3.5111
            },
            "url" : "http://www.univ-valenciennes.fr/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "France"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2919,
            "date_created" : "2013-12-04 11:50:17",
            "date_modified" : "2019-11-20 12:02:53",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2919"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Università degli Studi di Torino",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "it",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italy"
               }
            ],
            "url" : "http://www.unito.it/",
            "location" : {
               "longitude" : 7.689,
               "latitude" : 45.069
            }
         },
         "repository_metadata" : {
            "oai_url" : "http://www.omeka.unito.it/omeka/oai-pmh-repository/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.omeka.unito.it/omeka/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This is a repository that allows open access to the digitised collection from the Union catalogue of the University of Turin. It contains ancient books and documents. The interface is is Italian and includes and RSS feed to update users on new content.",
            "software" : {
               "name" : "omeka",
               "name_phrases" : [
                  {
                     "phrase" : "Omeka",
                     "value" : "omeka",
                     "language" : "en"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1496,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "DigitUnito"
               }
            ],
            "content_languages" : [
               "it"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "it",
                  "language" : "en",
                  "phrase" : "Italian"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "language" : "en",
                  "value" : "pl"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "pl",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 442,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "acronym" : "RePolis",
                  "name" : "Repolis. Silesian University of Technology Digital Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repolis.bg.polsl.pl/oai-pmh-repository.xml",
            "url" : "http://repolis.bg.polsl.pl/",
            "software" : {
               "name" : "dlibra",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dlibra",
                     "phrase" : "dLibra"
                  }
               ]
            },
            "description" : "Repolis is a repository of archived scientific materials created by the staff of Silesian University of Technology.\nRepolis gathers author's materials in every field of knowledge, provided that they fulfil the scientific work criteria, and published by the agreement of the Repolis Science Council. The interface is available in English and Polish and has three RSS feeds to alert users to news, the latest content and planned publications."
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2918",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 2918,
            "date_created" : "2013-12-02 15:57:21",
            "date_modified" : "2019-10-17 14:34:47",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Silesian University of Technology",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "pl",
            "url" : "http://www.polsl.pl/",
            "location" : {
               "longitude" : 18.6754,
               "latitude" : 50.2911
            },
            "country_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Poland"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access"
            }
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access"
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2917",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2013-11-29 12:09:19",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2917,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 135.228,
               "latitude" : 34.7295
            },
            "url" : "http://www.shoin.ac.jp/",
            "name" : [
               {
                  "name" : "Kobe Shoin Womens University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               }
            ],
            "notes" : "Many thesis and dissertations are only available as an abstract.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja",
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Kobe Shoin Women's University Repository KARASHI-DANE",
                  "acronym" : "KARASHI-DANE",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "metadata_record_count" : 1629,
            "description" : "This is the institutional repository for Kobe Shoin Womans University which contains the work of staff and students. The interface is in Japanese or English",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "content_subjects" : [
               "17"
            ],
            "oai_url" : "http://shoin.repo.nii.ac.jp/oai",
            "url" : "https://shoin.repo.nii.ac.jp/",
            "full_text_record_count" : 384,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "organisation" : {
            "country" : "kz",
            "country_phrases" : [
               {
                  "value" : "kz",
                  "language" : "en",
                  "phrase" : "Kazakhstan"
               }
            ],
            "location" : {
               "longitude" : 71.4607,
               "latitude" : 51.1647
            },
            "url" : "http://www.enu.kz/",
            "name" : [
               {
                  "name" : "L.N. Gumilyov Eurasian National University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-11-28 11:30:59",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2916,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2916"
         },
         "repository_metadata" : {
            "url" : "http://repository.enu.kz/",
            "content_subjects" : [
               "2",
               "17",
               "24",
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of L.N Eurasian National University in Kazakhstan which contains the work of staff and students. The interface is in Russian and contains RSS feeds to alert users to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "metadata_record_count" : 12686,
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "ENU repository",
                  "name" : "Repository of L.N. Gumilyov Eurasian National University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ru",
               "en",
               "kk"
            ],
            "notes" : "Data checked 11.03.14",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Kazakh",
                  "language" : "en",
                  "value" : "kk"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "patents"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "id",
            "location" : {
               "latitude" : -0.053902,
               "longitude" : 109.348
            },
            "url" : "http://www.polnep.ac.id/",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Politeknik Negeri Pontianak"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2915",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-28 10:47:26",
            "id" : 2915
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "id"
            ],
            "content_subjects" : [
               "3",
               "24",
               "13",
               "15",
               "16"
            ],
            "url" : "http://repository.polnep.ac.id/",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Civil Engineering",
                  "value" : "13",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "15",
                  "phrase" : "Electrical and Electronic Engineering"
               },
               {
                  "phrase" : "Mechanical Engineering and Materials",
                  "value" : "16",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of the Politeknek Negri Pontianak. The interface is is English and Indonesian and it includes RSS feeds to alert uses to new content.",
            "metadata_record_count" : 1384,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ],
            "name" : [
               {
                  "name" : "POLNEP Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-27 11:10:24",
            "id" : 2914,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2914",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "ph",
            "country_phrases" : [
               {
                  "phrase" : "Philippines",
                  "language" : "en",
                  "value" : "ph"
               }
            ],
            "location" : {
               "latitude" : 6.9136,
               "longitude" : 122.061
            },
            "url" : "http://www.wmsu.edu.ph/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Western Mindanao State University"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "description" : "This is an openly accessible collection of academic work produced by Frede G Moreno, an academic at Western Mindanoa State University.",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://works.bepress.com/frede_moreno/",
            "content_subjects" : [
               "17",
               "23"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "WMSU"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 15
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "NuStone",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "metadata_record_count" : 121,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "value" : "greenstone",
                     "language" : "en",
                     "phrase" : "Greenstone"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "NuStone is the Digital Library of the National University of Science and Technology. It runs on Greenstone and is maintained by the University Library. NuStone includes collections such as Past Exam Papers, Theses and Dissertations, etc.Currently, only the abstracts of theses and dissertations are available, but this is expected to change in the future. Publications to newsletters and and newspaper articles are fully accessible from the author's version. The interface is in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://library.nust.ac.zw/gsdl/cgi-bin/library.cgi",
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "NUST",
                  "name" : "National University of Science and Technology"
               }
            ],
            "country" : "zw",
            "location" : {
               "latitude" : -20.1647,
               "longitude" : 28.642
            },
            "url" : "http://www.nust.ac.zw/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "zw",
                  "phrase" : "Zimbabwe"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2912",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-25 12:14:23",
            "id" : 2912,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "country" : "in",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "in",
                  "phrase" : "India"
               }
            ],
            "location" : {
               "latitude" : 20.5937,
               "longitude" : 78.9629
            },
            "url" : "http://www.ab-a.net/",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "ABA-NET",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 2911,
            "date_created" : "2013-11-25 12:02:01",
            "date_modified" : "2019-12-04 12:27:31",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2911",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "12"
            ],
            "url" : "http://www.architexturez.net/",
            "oai_url" : "http://architexturez.net/oai-pmh",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "Architexturez South Asia aggregates ideas and propositions concerning physical space and the related disciplines in the subcontinent of India. It documents processes, critical texts and nomothetic cases representing conditions obtained in South Asia.\n\nDocuments are stored online for educational purpose, under fair use of the Berne Convention. The interface is in English and has an RSS feed to alert users to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Architexturez",
               "name" : "other"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 200,
            "type" : "disciplinary",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Architexturez South Asia"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Architecture",
                  "language" : "en",
                  "value" : "12"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "year_established" : 1999,
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "notes" : "The CARIANA collection is a database of indigenous knowledge in the Cordilleras. It is a digital collaboration initiated by Benguet State University Library and Information Services through the help of Baguio-Benguet Librarians Association using an open source system and the open access principle.",
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Benguet State University Digital Library",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 872,
            "description" : "Repository for theses, dissertations, university documents, indigenous knowledge in the Cordillera region, and faculty manuals. The interface can be set to many languages.",
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "language" : "en",
                     "value" : "greenstone"
                  }
               ]
            },
            "url" : "http://digilib.bsu.edu.ph/greenstone/cgi-bin/library.cgi",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 16.448,
               "longitude" : 120.578
            },
            "url" : "http://www.bsu.edu.ph/",
            "country_phrases" : [
               {
                  "phrase" : "Philippines",
                  "value" : "ph",
                  "language" : "en"
               }
            ],
            "country" : "ph",
            "name" : [
               {
                  "name" : "Benguet State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2013-11-21 11:24:37",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2910,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2910",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Centre de Développement des Energies Renouvelables",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "dz",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "dz",
                  "phrase" : "Algeria"
               }
            ],
            "url" : "http://www.cder.dz/",
            "location" : {
               "longitude" : 3.042,
               "latitude" : 36.7529
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2909",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2909,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-21 10:28:46",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "fr",
               "en"
            ],
            "notes" : "Journals to which the Centre subscribes are only accessible internally.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "value" : "disciplinary",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 1839,
            "type" : "disciplinary",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Bibliothèque virtuelle des Energies Renouvelables",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "7"
            ],
            "url" : "http://www.cder.dz/vlib/index.php",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows open access to the theses, publications and communications held by the Development Centre for Renewable Energy and also includes the list of all the books in the library centre. The interface is in French.",
            "software" : {
               "name" : "other",
               "name_other" : "PHP MySQL",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ]
            }
         }
      },
      {
         "organisation" : {
            "url" : "http://www.u-paris10.fr/",
            "location" : {
               "latitude" : 48.8566,
               "longitude" : 2.35097
            },
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "country" : "fr",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Université Paris X Nanterre",
                  "acronym" : "UPX"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2908",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2013-11-20 11:25:50",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2908,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "description" : "This is a list of the electronic thesis written by the students of the Universite Paris Ouest Nanterre La Défense. The interface is in French.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "HTML",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "url" : "http://bdr.u-paris10.fr/sid/liste_theses.php",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "fr"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Portail documentaire de l'université de Paris Ouest Nanterre La Défens",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 382
         }
      },
      {
         "system_metadata" : {
            "id" : 2907,
            "date_created" : "2013-11-19 16:13:01",
            "date_modified" : "2019-12-04 12:27:31",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2907",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "br",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "language" : "en",
                  "value" : "br"
               }
            ],
            "url" : "https://www.ufmg.br/",
            "location" : {
               "longitude" : -43.9699,
               "latitude" : -19.8748
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidade Federal de Minas Gerais",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "https://www.ufmg.br/repositoriodigital/",
            "content_languages" : [
               "pt"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This is an open repository, produced in DSpace, to store and disseminate the open academic research collections of Universidade Federal de Minas Gerais based on open access technology. The interface is in Portuguese.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 723,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Repositório Digital da Universidade Federal de Minas Gerais",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2906,
            "date_created" : "2013-11-19 12:40:03",
            "date_modified" : "2019-10-17 14:34:47",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2906"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Netherlands",
                  "value" : "nl",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 52.0705,
               "longitude" : 4.3007
            },
            "url" : "http://www.icc-cpi.int/en_menus/icc/Pages/default.aspx",
            "country" : "nl",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "International Criminal Court",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "zh",
               "en",
               "fr",
               "es"
            ],
            "repository_status" : "fully_functional",
            "notes" : "The Legal Tools Project, each Legal Tool and particular components of each Legal Tool are protected by copyright, neighbouring rights, database rights and/or other applicable law. Any use of the Legal Tools other than as authorized under these Terms and Conditions is prohibited. An agreement button has to be clicked before entering the site.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://www.legal-tools.org/",
            "content_subjects" : [
               "26"
            ],
            "software" : {
               "name_other" : "HTML",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "The International Criminal Court puts the Legal Tools at the disposal of any person who may choose to access this web site under certain terms and conditions of use. The interface is in French, Arabic, Spanish, Chinese and English.",
            "metadata_record_count" : 73132,
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Legal Tools",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "governmental"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2905,
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-11-18 16:53:18",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2905"
         },
         "organisation" : {
            "location" : {
               "latitude" : -12.069,
               "longitude" : -77.0802
            },
            "url" : "http://www.pucp.edu.pe/content/index.php",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Pontificia Universidad Católica del Perú"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site is a university repository providing access to the publication output of Pontifical Catholic University of Peru. the interface is in Spanish. Not all items are full text.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.pucp.edu.pe/index/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio Institucional de la PUCP"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "metadata_record_count" : 33805,
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Iwate Medical University Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "journal_articles"
            ],
            "type" : "institutional",
            "metadata_record_count" : 5493,
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the publication output of the institution. The site interface is available in Japanese or English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ],
            "content_subjects" : [
               "10"
            ],
            "url" : "https://iwatemed.repo.nii.ac.jp/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2904",
            "publicly_visible" : "yes",
            "date_created" : "2013-11-18 16:24:45",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2904
         },
         "organisation" : {
            "country" : "jp",
            "url" : "http://www.iwate-med.ac.jp/",
            "location" : {
               "latitude" : 39.7058,
               "longitude" : 141.152
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Iwate Medical University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "pt",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "An statement about the copyright status and use of the thesis is shown and agreement must be given before the thesis is displayed.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "metadata_record_count" : 8137,
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteca Digital de Teses e Dissertações Eletrônicas da UERJ"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://www.bdtd.uerj.br/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://www.bdtd.uerj.br/tde_oai/oai3.php",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "ETD-db",
               "name" : "other"
            },
            "description" : "This is the digital thesis and dissertation repository of Univesidade do Estado do Rio de Janero. The interface is in Portuguese."
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2903",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2013-11-18 16:02:49",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2903,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universidade do Estado do Rio de Janeiro",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "http://www.uerj.br/",
            "location" : {
               "longitude" : -43.236,
               "latitude" : -22.911
            }
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 876,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "REPOSITÓRIO ABERTO  do Instituto Superior Miguel Torga",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 362,
            "oai_url" : "http://repositorio.ismt.pt/oai/request",
            "url" : "http://repositorio.ismt.pt/",
            "content_subjects" : [
               "17",
               "23",
               "14"
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "The ISMT Repository is an institutional repository of open access publications produced by the academic community of Istituto Superior Miguel Torga which provides open access to theses, articles, communications, posters and other material scientific. The interface is Portuguese and contains RSS feed to alert users to new content.",
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2902",
            "publicly_visible" : "yes",
            "id" : 2902,
            "date_created" : "2013-11-14 10:46:02",
            "date_modified" : "2019-12-04 12:27:31"
         },
         "organisation" : {
            "country" : "pt",
            "url" : "http://www.ismt.pt/",
            "location" : {
               "latitude" : 40.214,
               "longitude" : -8.4135
            },
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Instituto Superior Miguel Torga"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Admiral Makarov National University of Shipbuilding",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "ua",
            "location" : {
               "longitude" : 31.9946,
               "latitude" : 46.975
            },
            "url" : "http://www.nuos.edu.ua/",
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "value" : "ua",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2901,
            "date_created" : "2013-11-14 10:32:30",
            "date_modified" : "2019-10-17 14:34:47",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2901",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "technically_malfunctioning",
            "content_languages" : [
               "uk"
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "uk",
                  "phrase" : "Ukrainian"
               }
            ],
            "description" : "The institutional repository of the National University of Shipbuilding named after Admiral Markov, collects, stores, distributes and provides long-term, continuous and reliable access to the research of staff, undergraduates, postgraduates and students. The interface is in Ukrainian and Russian.",
            "software" : {
               "name" : "dspace",
               "version" : "1.7.2",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "11"
            ],
            "url" : "http://eir.nuos.edu.ua/",
            "oai_url" : "http://eir.nuos.edu.ua/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Technically Malfunctioning",
                  "value" : "technically_malfunctioning",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Electronic Institutional Repository of Admiral Makarov National University of Shipbuilding",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1633
         }
      },
      {
         "organisation" : {
            "country" : "za",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "za",
                  "phrase" : "South Africa"
               }
            ],
            "url" : "http://www.lib.uct.ac.za/",
            "location" : {
               "longitude" : 18.4601,
               "latitude" : -33.9579
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "University of Cape Town Libraries",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2900,
            "date_created" : "2013-11-13 16:27:52",
            "date_modified" : "2019-12-04 12:27:31",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2900"
         },
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "replaced_by_new_url",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "UCTScholar",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 31438,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name" : "digitool",
               "name_phrases" : [
                  {
                     "value" : "digitool",
                     "language" : "en",
                     "phrase" : "DigiTool"
                  }
               ]
            },
            "description" : "This is the institutional repository of the University of Cape Town. The interface is in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "replaced_by_new_url",
                  "phrase" : "Replaced by New URL"
               }
            ],
            "oai_url" : "http://uctscholar.uct.ac.za/OAI-PUB",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://uctscholar.uct.ac.za/"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is the repository for the Institution for the Cultivation of Science. The interface is in English and it includes RSS feed to alert uses to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 3195,
            "url" : "http://arxiv.iacs.res.in:8080/jspui/",
            "oai_url" : "http://arxiv.iacs.res.in:8080/oai/request",
            "content_subjects" : [
               "2"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "IACS Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 8059,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-13 16:10:25",
            "id" : 2899,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2899",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Indian Association for the Cultivation of Science",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "in",
            "url" : "http://www.iacs.res.in/",
            "location" : {
               "latitude" : 22.5726,
               "longitude" : 88.3639
            },
            "country_phrases" : [
               {
                  "phrase" : "India",
                  "language" : "en",
                  "value" : "in"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "conference_and_workshop_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "el",
                  "language" : "en",
                  "phrase" : "Greek (modern)"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "14",
                  "phrase" : "Computers and IT"
               }
            ],
            "content_languages" : [
               "el"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "FOSS Repository"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 326,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "1.8.0.",
               "name" : "dspace"
            },
            "description" : "The FOSS repository includes content produced by the Greek Free / Open Source Software Society (its members, communities and developers) as a result of activities related to Free Software, Open Hardware and Open Content. It provides open access to rich content such as reports, presentations, digital collections, conference proceedings, studies, videos and photos. . Registered users can submit their work online and contribute to the repository. The interface is in English and Greek.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 120,
            "url" : "http://repository.ellak.gr/",
            "content_subjects" : [
               "14"
            ],
            "oai_url" : "http://repository.ellak.gr/ellak_oai/request"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "country" : "gr",
            "country_phrases" : [
               {
                  "value" : "gr",
                  "language" : "en",
                  "phrase" : "Greece"
               }
            ],
            "url" : "http://www.eie.gr/",
            "unit" : [
               {
                  "name" : "National Documentation Centre",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 37.967,
               "longitude" : 23.7461
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "National Hellenic Research Foundation"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-11-13 15:41:53",
            "id" : 2898,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2898",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "it",
                  "language" : "en",
                  "phrase" : "Italy"
               }
            ],
            "url" : "http://www.uniud.it/",
            "location" : {
               "latitude" : 47.37,
               "longitude" : 8.531
            },
            "country" : "it",
            "name" : [
               {
                  "name" : "Università degli studi di Udine",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2897",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2013-11-13 15:17:18",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2897,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "it",
               "en"
            ],
            "url" : "https://dspace-uniud.cilea.it/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "1.6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "OpenUniud is the Institutional Repository of the University of Udine.It allows public access to doctoral theses from 2012 onwards to either the full text or the metadata only depending on the declaration signed by the author stating the reasons for the embargo. The interface is in English and Italian and contains RSS feeds to alert users to new content.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 602,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Italian",
                  "value" : "it",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "OpenUniud",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 10,
            "content_subjects" : [
               "20"
            ],
            "url" : "http://repository.acropolis-education.gr/acr_edu/",
            "oai_url" : "http://repository.acropolis-education.gr/acr_edu_oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "1.8.0",
               "name" : "dspace"
            },
            "description" : "This repository contains educational resources produced by the Information and Education Department of the Acropolis Restoration Service which represent and interpret the archaeological site and the Acropolis Museum. The interface is in English and Greek.",
            "metadata_record_count" : 281,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Software",
                  "value" : "software",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Acropolis Educational Resources Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "el",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "el",
                  "phrase" : "Greek (modern)"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "learning_objects",
               "software",
               "other_special_item_types"
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2896",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 2896,
            "date_created" : "2013-11-13 14:59:55",
            "date_modified" : "2019-12-04 12:27:31",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Hellenic Research Foundation",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "gr",
            "country_phrases" : [
               {
                  "value" : "gr",
                  "language" : "en",
                  "phrase" : "Greece"
               }
            ],
            "url" : "http://www.eie.gr/",
            "location" : {
               "latitude" : 37.967,
               "longitude" : 23.7461
            },
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "National Documentation Centre"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universiti Malaysia Pahang (UMP)",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "my",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "my",
                  "phrase" : "Malaysia"
               }
            ],
            "location" : {
               "latitude" : 3.8231,
               "longitude" : 103.327
            },
            "url" : "http://www.ump.edu.my/"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-12 17:33:57",
            "id" : 2895,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2895",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "notes" : "Not all thesis have the complete text displayed.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "metadata_record_count" : 16939,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "UMP Institutional Repository",
                  "acronym" : "UMP"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://umpir.ump.edu.my/",
            "oai_url" : "http://umpir.ump.edu.my/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3.1.2.1",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "The UMP Institutional Repository provides access to the full text of some of the University publication such as journal articles, conference papers, research papers, thesis and dissertations. The Interface is in English and includes RSS feeds to alert users of new content."
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 3538,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Digital Repository of Hellenic Managing Authority of the Operational Programme \"Education and Lifelong Learning\" (EDULLL)",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "oai_url" : "http://repository.edulll.gr/edulll-oai/request",
            "url" : "http://repository.edulll.gr/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This is an open resource for educational materials, reports, books, conference material and audio visual items",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "el",
                  "phrase" : "Greek (modern)"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages" : [
               "el"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2894",
            "publicly_visible" : "yes",
            "id" : 2894,
            "date_created" : "2013-11-12 16:05:00",
            "date_modified" : "2019-12-04 12:27:31"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "gr",
                  "language" : "en",
                  "phrase" : "Greece"
               }
            ],
            "url" : "http://www.edulll.gr/",
            "location" : {
               "latitude" : 37.9837,
               "longitude" : 23.7293
            },
            "country" : "gr",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Hellenic Managing Authority of the Operational Programme &quot;Education and Lifelong Learning&quot; (EDULLL)"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "el",
                  "language" : "en",
                  "phrase" : "Greek (modern)"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "el",
               "en",
               "fr"
            ],
            "repository_status" : "not_accepting_deposits",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 464,
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Public Central Library of Serres Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "governmental",
            "repository_status_phrases" : [
               {
                  "phrase" : "Not Accepting Deposits",
                  "value" : "not_accepting_deposits",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ebooks.serrelib.gr/serrelib-oai/",
            "url" : "http://ebooks.serrelib.gr/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This is a an open access digital library which contains books, documents and other items relating to the economy, law, education and history of modern Greece and other countries."
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-11-12 15:49:31",
            "id" : 2893,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2893"
         },
         "organisation" : {
            "location" : {
               "latitude" : 37.967,
               "longitude" : 23.7461
            },
            "url" : "http://www.eie.gr/",
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "National Documentation Centre",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Greece",
                  "language" : "en",
                  "value" : "gr"
               }
            ],
            "country" : "gr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "National Hellenic Research Foundation",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "National Hellenic Research Foundation",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "gr",
            "url" : "http://www.eie.gr/",
            "location" : {
               "latitude" : 37.967,
               "longitude" : 23.7461
            },
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Documentation Centre",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gr",
                  "phrase" : "Greece"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2892",
            "publicly_visible" : "yes",
            "id" : 2892,
            "date_created" : "2013-11-12 15:28:54",
            "date_modified" : "2019-10-17 14:34:47"
         },
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "el",
                  "phrase" : "Greek (modern)"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "repository_status" : "not_accepting_deposits",
            "content_languages" : [
               "el"
            ],
            "type" : "governmental",
            "name" : [
               {
                  "name" : "Levadia Central Public Library Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 142,
            "description" : "This is a digitised library which provides open access to books and document relating to the modern History of Greece. The interface is in English and Greek.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "19",
               "20"
            ],
            "url" : "http://ebooks.liblivadia.gr/",
            "oai_url" : "http://ebooks.liblivadia.gr/liblivadia-oai/",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Not Accepting Deposits",
                  "value" : "not_accepting_deposits",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2891",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-11-12 15:09:39",
            "id" : 2891
         },
         "organisation" : {
            "country" : "gr",
            "country_phrases" : [
               {
                  "phrase" : "Greece",
                  "language" : "en",
                  "value" : "gr"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "National Documentation Centre",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 23.7461,
               "latitude" : 37.967
            },
            "url" : "http://www.eie.gr/",
            "name" : [
               {
                  "name" : "National Hellenic Research Foundation",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            }
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "\"Ergani - Historical Archive of Aegean\" Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "metadata_record_count" : 1574,
            "content_languages_phrases" : [
               {
                  "phrase" : "Greek (modern)",
                  "language" : "en",
                  "value" : "el"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "not_accepting_deposits",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "description" : "The Ergani repository contains documented archival material that illustrates 200 years of history and culture in north eastern Aegean. It includes personal letters and diaries reflecting on daily life of the middle class on the island of Lesvos during the 19th and 20th centuries.The interface is in English and Greek",
            "content_subjects_phrases" : [
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Not Accepting Deposits",
                  "language" : "en",
                  "value" : "not_accepting_deposits"
               }
            ],
            "content_subjects" : [
               "20",
               "23"
            ],
            "url" : "http://www.ergani-repository.gr/",
            "content_languages" : [
               "el",
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "The Parthenon Frieze Repository"
               }
            ],
            "type" : "governmental",
            "metadata_record_count" : 137,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "The Parthenon Frieze Repository repository is an organized infrastructure of digital content, that offers free access to cultural material. The repository was carried out by the National Documentation Centre (EKT) and the YSMA-Acropolis Restoration Service of the Hellenic Ministry of Culture and Tourism. The repository provides the possibility of immediate access to images of the frieze as a database for scholars.",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Not Accepting Deposits",
                  "value" : "not_accepting_deposits",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://repository.parthenonfrieze.gr/frieze-oai/",
            "content_subjects" : [
               "20"
            ],
            "url" : "http://repository.parthenonfrieze.gr/",
            "content_types" : [
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Greek (modern)",
                  "language" : "en",
                  "value" : "el"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "not_accepting_deposits",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "content_languages" : [
               "el",
               "en"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2890",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2013-11-12 14:52:47",
            "date_modified" : "2019-12-04 12:27:31",
            "id" : 2890,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "gr",
            "url" : "http://www.eie.gr/",
            "location" : {
               "latitude" : 37.967,
               "longitude" : 23.7461
            },
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Documentation Centre",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "gr",
                  "language" : "en",
                  "phrase" : "Greece"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "National Hellenic Research Foundation",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "zh"
            ],
            "url" : "http://ir.ustb.edu.cn/",
            "content_subjects" : [
               "2",
               "17",
               "21",
               "11",
               "26"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "technically_malfunctioning",
                  "language" : "en",
                  "phrase" : "Technically Malfunctioning"
               }
            ],
            "description" : "This is the institutional repository of Beijing University which provides open access to the work of staff and students. The interface is in Chinese and it includes RSS feeds to alert users to new content.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "21",
                  "language" : "en",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "technically_malfunctioning",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 95207,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of University of Science and Technology Beijing"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.ustb.edu.cn/",
            "location" : {
               "longitude" : 116.354,
               "latitude" : 39.982
            },
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "language" : "en",
                  "value" : "cn"
               }
            ],
            "country" : "cn",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "University of Science and Technology Beijing",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 2889,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-12 13:17:51",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2889",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 8392,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "LSMU DSpace CRIS"
               }
            ],
            "url" : "https://lsmuni.lt/cris",
            "content_subjects" : [
               "10"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "this is the institutional repository for the Lithuanian University of Health Sciences which provides open access to the work of staff and students. The interface is in English.",
            "software" : {
               "version" : "CRIS - 6.3.0 - SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Lithuanian",
                  "language" : "en",
                  "value" : "lt"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en",
               "lt"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-11-12 12:23:04",
            "date_modified" : "2020-01-15 16:04:44",
            "id" : 2888,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2888"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Lithuanian University of Health Sciences",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               },
               {
                  "language" : "lt",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Lithuanian",
                        "value" : "lt",
                        "language" : "en"
                     }
                  ],
                  "name" : "Lietuvos Sveikatos Mokslų Universitetas",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "lt",
                  "phrase" : "Lithuania"
               }
            ],
            "location" : {
               "longitude" : 23.9145,
               "latitude" : 54.8926
            },
            "url" : "https://lsmuni.lt",
            "country" : "lt"
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "http://roarmap.eprints.org/233/"
               ],
               "types_included" : {
                  "standard_types_allowed" : [
                     "journal_articles",
                     "theses_and_dissertations",
                     "books_chapters_and_sections"
                  ],
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "value" : "journal_articles",
                        "language" : "en",
                        "phrase" : "Journal Articles"
                     },
                     {
                        "phrase" : "Theses and Dissertations",
                        "language" : "en",
                        "value" : "theses_and_dissertations"
                     },
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "value" : "books_chapters_and_sections",
                        "language" : "en"
                     }
                  ]
               },
               "repository_type" : "institutional_or_departmental"
            }
         }
      },
      {
         "organisation" : {
            "country" : "ca",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "location" : {
               "longitude" : -123.37,
               "latitude" : 48.43
            },
            "url" : "http://www.uvic.ca/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Victoria"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-11-08 16:15:55",
            "date_modified" : "2019-12-04 12:27:31",
            "id" : 2887,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2887"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This is the digital collection of University of Victoria Libraries which ranges from the latest student theses and faculty publications to manuscripts from centuries past. The interface is in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.uvic.ca/library/featured/collections/index.php",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "University of Victoria Digital collections",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Petra Christian University"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesia"
               }
            ],
            "location" : {
               "latitude" : -7.2653,
               "longitude" : 112.743
            },
            "url" : "http://www.petra.ac.id/",
            "country" : "id"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2886,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-08 15:29:27",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2886"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "Ispektra Digital Collection",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 16436,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               }
            ],
            "description" : "This digital collection contains work of the staff and students of Petra Christian University. The interface is in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Ispektra",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "content_subjects" : [
               "22"
            ],
            "url" : "http://dewey.petra.ac.id/catalog/ft.php/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "fr",
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "HAL Clermont Auvergne",
                  "name" : "HAL Clermont Université"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 44457,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "HAL",
                     "language" : "en",
                     "value" : "hal"
                  }
               ],
               "name" : "hal"
            },
            "description" : "The HAL Clermont Université repository covers all the scientific output deposited in HAL of both universities of Clermont-Ferrand : Blaise Pascal University and Auvergne University. The interface is in French and English and includes an RSS feed.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 5281,
            "url" : "http://hal-clermont-univ.archives-ouvertes.fr/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://api.archives-ouvertes.fr/oai/clermont-univ"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2885",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 2885,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-08 15:14:34",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 3.0873,
               "latitude" : 45.7696
            },
            "url" : "http://www.clermont-universite.fr/",
            "country" : "fr",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "Université Clermont Auvergne",
                  "name" : "Clermont  Université",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               },
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ru",
               "en",
               "fr"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ],
            "description" : "This is the institutional repository for the Polessky State University. This interface is in Russian and it includes RSS feeds to alert users to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://rep.polessu.by/",
            "content_subjects" : [
               "1",
               "4",
               "24",
               "25"
            ],
            "oai_url" : "http://rep.polessu.by/oai/request",
            "full_text_record_count" : 9938,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of Polessky State University (Репозиторий Полесского государственного университета)"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 14491
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Educational establishment “Polessky State University”",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "latitude" : 52.122,
               "longitude" : 26.0906
            },
            "url" : "http://www.polessu.by/",
            "country_phrases" : [
               {
                  "value" : "by",
                  "language" : "en",
                  "phrase" : "Belarus"
               }
            ],
            "country" : "by"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2884",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-08 14:54:10",
            "id" : 2884
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 2908,
            "type" : "disciplinary",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Mertz Digital Collections @ New York Botanical Garden Digital Library"
               }
            ],
            "url" : "http://mertzdigital.nybg.org/",
            "content_subjects" : [
               "6"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ],
            "description" : "This is the digitised collection of selected holding of the Mertz Library. It contains photographs of the New York Botanical Garden, plant literature, seed catalogues, botanical publications and collectors notes. The interface is in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "contentdm",
                     "language" : "en",
                     "phrase" : "CONTENTdm"
                  }
               ],
               "name" : "contentdm"
            }
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "http://www.nybg.org/",
            "location" : {
               "longitude" : -73.886,
               "latitude" : 40.8622
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "New York Botanical Garden"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2883,
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-11-07 13:05:25",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2883"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "notes" : "This is an archive of newspaper and magazine articles about the Canary Isles covering dates from 1763 onwards.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://jable.ulpgc.es/",
            "oai_url" : "http://jable.ulpgc.es/jable/cgi-bin/oai",
            "content_subjects" : [
               "19",
               "20"
            ],
            "software" : {
               "name" : "other",
               "name_other" : "Pandora",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "description" : "Jable collects and preserves newspapers, magazines, newsletters and various periodicals which were made ​​in the Canary Islands; by a Canarian; or about the archipelago. The interface is in Spanish and English.",
            "metadata_record_count" : 2576594,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Jable. Archivo de prensa de Canarias",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "policies" : {
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://biblioteca.ulpgc.es/avisomdc"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "not_allowed",
                     "phrase" : "Not Allowed"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "harvesting" : [
                  "not_allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "ULPGC",
                  "name" : "Universidad de Las Palmas de Gran Canaria",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://www.ulpgc.es/",
            "location" : {
               "latitude" : 28.1248,
               "longitude" : -15.43
            },
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "country" : "es"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2882",
            "publicly_visible" : "yes",
            "id" : 2882,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-07 11:14:48"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "Currently this is a new repository and is still under development. Content will increase in the future.This system is running eprints server software (EPrints 3.3.10) developed at the University of Southampton. For more information see http://www.eprints.org/",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "software" : {
               "version" : "3.4.0",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "description" : "This is the institutional repository of Staffordshire University. The interface is in English and it includes and RSS feed to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 1203,
            "oai_url" : "http://eprints.staffs.ac.uk/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.staffs.ac.uk/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "STORE",
                  "name" : "STORE - Staffordshire Online Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 3814,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2881",
            "publicly_visible" : "yes",
            "id" : 2881,
            "date_modified" : "2019-12-04 12:27:31",
            "date_created" : "2013-11-05 16:24:06"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Staffordshire University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 53.0101,
               "longitude" : -2.1826
            },
            "url" : "http://www.staffs.ac.uk/",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "value" : "gb",
                  "language" : "en"
               }
            ],
            "country" : "gb"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Pwani University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 367,
            "description" : "This institutional repository contains the intellectual output of Pwani University. The interface is in English and includes RSS feeds.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://elibrary.pu.ac.ke/ir/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2880,
            "date_created" : "2013-11-05 15:33:07",
            "date_modified" : "2019-10-17 14:34:47",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2880",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Pwani University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 39.85,
               "latitude" : -3.6333
            },
            "url" : "http://www.pu.ac.ke/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "http://www.pu.ac.ke/",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ke",
                  "phrase" : "Kenya"
               }
            ],
            "country" : "ke"
         },
         "policies" : {
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "full_text_record_count" : 1429,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "6"
            ],
            "oai_url" : "http://repo.kscnet.ru/cgi/oai2",
            "url" : "http://repo.kscnet.ru/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3"
            },
            "description" : "The IVS FEB RAS Repository is the thematic repository of open access for the fields of Earth Sciences: geology, geophysics, geochemistry, hydrogeology, volcanology, petrology, seismology, and geoecology. The interface is in Russian and English, and contains RSS feed to alert users to new content.",
            "metadata_record_count" : 3020,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Institute of Volcanology and Seismology FEB RAS Repository"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "ru"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "patents"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institute of Volcanology and Seismology FEB RAS"
               }
            ],
            "url" : "http://www.kscnet.ru/ivs/",
            "location" : {
               "latitude" : 53.019,
               "longitude" : 158.664
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian Federation"
               }
            ],
            "country" : "ru"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:25:29",
            "date_created" : "2013-11-05 15:02:14",
            "id" : 2878,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2878"
         },
         "policies" : {
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "url" : [
                  "http://repo.kscnet.ru/policies.html"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "value" : "employees",
                     "language" : "en",
                     "phrase" : "Employees"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright_phrases" : [
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "value" : "bibliographic_metadata_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Eligible depositors must deposit full texts of all their publications",
                     "value" : "full_texts_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "value" : "valid_formatting",
                     "language" : "en"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "moderation" : "yes"
            },
            "preservation_policy" : {
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "url" : [
                  "http://repo.kscnet.ru/policies.html"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "third_party_collaborations" : [
                  "migrate_file_formats"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "language" : "en",
                     "value" : "software_emulation"
                  }
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Convert or migrate file formats",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "publisher_rules",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "item_page" : [
                        "tombstone",
                        "link_to_replacement"
                     ],
                     "searchable" : "yes",
                     "item_page_phrases" : [
                        {
                           "language" : "en",
                           "value" : "tombstone",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        },
                        {
                           "phrase" : "URLs will contain a link to a replacement version, where available",
                           "value" : "link_to_replacement",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Transiently",
                           "language" : "en",
                           "value" : "trainsient"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "url_retention" : "trainsient"
                  },
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     },
                     {
                        "phrase" : "The items persistent URL will always link to the latest version",
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "language" : "en",
                     "value" : "some_items_have_different_conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed_for_indexing",
                  "allowed_for_citation_analysis"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "language" : "en",
                     "value" : "displayed_or_performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed_for_indexing",
                     "phrase" : "Allowed transiently for full-text indexing"
                  },
                  {
                     "phrase" : "Allowed transiently for citation analysis",
                     "value" : "allowed_for_citation_analysis",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repo.kscnet.ru/policies.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "value" : "link_required",
                     "language" : "en"
                  },
                  {
                     "value" : "original_copyright_statement_required",
                     "language" : "en",
                     "phrase" : "the original copyright statement is given"
                  },
                  {
                     "language" : "en",
                     "value" : "original_rights_statement_required",
                     "phrase" : "the original rights permission statement is given"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "ru",
                  "en"
               ],
               "subjects" : [
                  "6",
                  "7"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "published_versions"
               ],
               "types_included" : {
                  "standard_types_allowed_phrases" : [
                     {
                        "phrase" : "Journal Articles",
                        "language" : "en",
                        "value" : "journal_articles"
                     },
                     {
                        "phrase" : "Bibliographic References",
                        "value" : "bibliographic_references",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "conference_and_workshop_papers",
                        "phrase" : "Conference and Workshop Papers"
                     },
                     {
                        "language" : "en",
                        "value" : "theses_and_dissertations",
                        "phrase" : "Theses and Dissertations"
                     },
                     {
                        "language" : "en",
                        "value" : "unpub_reports_and_working_papers",
                        "phrase" : "Unpublished Reports and Working Papers"
                     },
                     {
                        "value" : "books_chapters_and_sections",
                        "language" : "en",
                        "phrase" : "Books, Chapters and Sections"
                     },
                     {
                        "phrase" : "Datasets",
                        "language" : "en",
                        "value" : "datasets"
                     },
                     {
                        "value" : "learning_objects",
                        "language" : "en",
                        "phrase" : "Learning Objects"
                     },
                     {
                        "value" : "patents",
                        "language" : "en",
                        "phrase" : "Patents"
                     },
                     {
                        "phrase" : "Other Special Item Types",
                        "value" : "other_special_item_types",
                        "language" : "en"
                     }
                  ],
                  "all" : "false",
                  "standard_types_allowed" : [
                     "journal_articles",
                     "bibliographic_references",
                     "conference_and_workshop_papers",
                     "theses_and_dissertations",
                     "unpub_reports_and_working_papers",
                     "books_chapters_and_sections",
                     "datasets",
                     "learning_objects",
                     "patents",
                     "other_special_item_types"
                  ]
               },
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "ru",
                     "phrase" : "Russian"
                  },
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  }
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://repo.kscnet.ru/policies.html"
               ],
               "subjects_phrases" : [
                  {
                     "value" : "6",
                     "language" : "en",
                     "phrase" : "Earth and Planetary Sciences"
                  },
                  {
                     "phrase" : "Ecology and Environment",
                     "value" : "7",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "publication_status"
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "url" : [
                  "http://repo.kscnet.ru/policies.html"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://41.93.80.3:8080/jspui/",
            "content_subjects" : [
               "23",
               "24",
               "25",
               "26",
               "13"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This repository archives a variety of intellectual output produced by SAUT academic members and its constituent colleges. The interface is in English and includes RSS feeds to alert users to new content.",
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Civil Engineering",
                  "value" : "13",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 311,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "MLRC Instititutional Repository",
                  "name" : "Mario Mgulunde Learning Resource Centre Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tz",
                  "phrase" : "Tanzania, United Republic of"
               }
            ],
            "url" : "http://www.saut.ac.tz/",
            "location" : {
               "longitude" : 32.9,
               "latitude" : -2.5167
            },
            "country" : "tz",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Saint Augustine University of Tanzania (SAUT)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2877",
            "publicly_visible" : "yes",
            "id" : 2877,
            "date_created" : "2013-11-04 17:02:57",
            "date_modified" : "2019-10-17 14:34:47"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "The Academy of Public Administration under the aegis of the President of the Republic of Belarus"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "language" : "en",
                  "value" : "by"
               }
            ],
            "location" : {
               "latitude" : 53.887,
               "longitude" : 27.5382
            },
            "url" : "http://www.pac.by/en",
            "country" : "by"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2876,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-11-04 16:31:43",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2876"
         },
         "repository_metadata" : {
            "url" : "http://rep.pac.by/jspui/",
            "content_subjects" : [
               "24"
            ],
            "content_languages" : [
               "ru"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Trial",
                  "value" : "trial",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of the academy of Public Administration under the Aegis of the President of the Republic of Belarus.",
            "repository_status" : "trial",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "metadata_record_count" : 178,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "The Academy of Public Administration under the aegis of the President of the Republic of Belarus",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 106849,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Temple University Libraries: Digital Colletions",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://digital.library.temple.edu/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site is an institutional repository. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "value" : "contentdm",
                     "language" : "en"
                  }
               ],
               "name" : "contentdm"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "notes" : "Special items include: Sheet music",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Temple University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "us",
            "location" : {
               "longitude" : -75.1458,
               "latitude" : 39.9795
            },
            "url" : "http://www.temple.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2013-10-30 14:52:16",
            "date_modified" : "2019-12-04 12:27:30",
            "id" : 2875,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2875",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "Data checked 18.02.13",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Dhaka University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 815,
            "description" : "This site is an institutional repository. The interface is available in English and includes RSS feeds to alert users to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "1.8.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.library.du.ac.bd/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "url" : [
                  "http://repository.library.du.ac.bd/xmlui/bitstream/handle/123456789/268/Dhaka%20University%20Institutional%20Repository%20Policy.pdf?sequence=1"
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "url" : [
                  "http://repository.library.du.ac.bd/xmlui/bitstream/handle/123456789/268/Dhaka%20University%20Institutional%20Repository%20Policy.pdf?sequence=1"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repository.library.du.ac.bd/xmlui/bitstream/handle/123456789/268/Dhaka%20University%20Institutional%20Repository%20Policy.pdf?sequence=1"
               ],
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed",
                  "software_emulation"
               ],
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed"
                  },
                  {
                     "language" : "en",
                     "value" : "software_emulation",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable" : "no"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view"
               },
               "file_preservation" : [
                  "regular_backups"
               ]
            },
            "submission_policy" : {
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "url" : [
                  "http://repository.library.du.ac.bd/xmlui/bitstream/handle/123456789/268/Dhaka%20University%20Institutional%20Repository%20Policy.pdf?sequence=1"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "language" : "en",
                     "value" : "item_relevance",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2874",
            "publicly_visible" : "yes",
            "id" : 2874,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-10-30 14:40:35"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Dhaka"
               }
            ],
            "country" : "bd",
            "location" : {
               "latitude" : 23.7332,
               "longitude" : 90.3914
            },
            "url" : "http://www.du.ac.bd/",
            "country_phrases" : [
               {
                  "phrase" : "Bangladesh",
                  "value" : "bd",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 2886,
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "d-Commons",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://d-commons.d.umn.edu/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site is an institutional repository. The interface is available in English. Users mat set up RSS feeds to be alerted to new content.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "3.1"
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Minnesota Duluth",
                  "acronym" : "UMD",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "unit" : [
               {
                  "name" : "Kathryn A. Martin Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 46.8201,
               "longitude" : -92.0838
            },
            "url" : "http://www.d.umn.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2873",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-10-30 14:29:57",
            "id" : 2873,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "notes" : "Members are:Nelson Mandela Metropolitan University;    Rhodes University (including Cory, ILAM and SAIAB);     University of Fort Hare; Walter Sisulu University",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "description" : "This is a consortia repository contains the digital collections of the academic institutions in the Eastern Cape, South Africa. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "vital",
                     "language" : "en",
                     "phrase" : "VITAL"
                  }
               ],
               "name" : "vital"
            },
            "oai_url" : "http://vital.seals.ac.za:8080/vital/oai/provider",
            "url" : "http://vital.seals.ac.za",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 234,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "SEALS Digital Commons",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 7804
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2872",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:27:30",
            "date_created" : "2013-10-30 14:26:29",
            "id" : 2872,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "http://www.seals.ac.za/",
            "location" : {
               "latitude" : -33.9781,
               "longitude" : 25.6406
            },
            "country_phrases" : [
               {
                  "value" : "za",
                  "language" : "en",
                  "phrase" : "South Africa"
               }
            ],
            "country" : "za",
            "name" : [
               {
                  "name" : "SEALS Consortium",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "language" : "en",
                  "value" : "3"
               },
               {
                  "phrase" : "Geography and Regional Studies",
                  "language" : "en",
                  "value" : "19"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "description" : "The South Carolina State Documents Depository provides access to publications produced by state agencies and state-supported academic institutions. These publications provide citizens with crucial information about state government, including statistics, annual accountability reports, and data on a wide variety of topics related to the state. Items in the State Documents Depository include both print publications and “born digital” documents often originally published on agency websites. the interface is in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "oai_url" : "http://dc.statelibrary.sc.gov/oai/request",
            "content_subjects" : [
               "3",
               "19",
               "24"
            ],
            "url" : "http://dc.statelibrary.sc.gov/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "South Carolina State Documents Depository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 25526
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:30",
            "date_created" : "2013-10-25 16:59:16",
            "id" : 2871,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2871"
         },
         "organisation" : {
            "location" : {
               "latitude" : 34.0012,
               "longitude" : -81.0278
            },
            "url" : "http://www.statelibrary.sc.gov/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "South Carolina State Library"
               }
            ]
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : 42.3051,
               "longitude" : -83.0675
            },
            "url" : "http://uwindsor.ca",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "country" : "ca",
            "name" : [
               {
                  "name" : "University of Windsor",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2870",
            "publicly_visible" : "yes",
            "date_created" : "2013-10-25 16:53:27",
            "date_modified" : "2019-12-04 12:27:30",
            "id" : 2870
         },
         "repository_metadata" : {
            "url" : "http://scholar.uwindsor.ca",
            "oai_url" : "http://scholar.uwindsor.ca/do/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "The mandate of the Scholarship at UWindsor repository is to enable researchers in our campus community to preserve and provide open access to a wide range of scholarly and creative works. This could include copies of published articles where permitted, conference papers, presentations, theses, videos of talks, musical scores, images and more.\r\n\r\nSince Scholarship at UWindsor is an open access repository, its contents will be freely available to anyone with access to the internet. This enables the work of scholars from the University of Windsor to reach the broadest possible audience and helps to make publicly funded research more publicly accessible.The interface is in English and it includes and RSS to alert users of new content.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 14092,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Scholarship at UWindsor",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "CURVE is the Carleton University institutional repository which holds academic research output and creative work voluntarily deposited by Carleton faculty, staff and students, as well as all dissertations and theses produced at Carleton.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "drupal",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "drupal",
                     "phrase" : "Drupal"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://curve.carleton.ca/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "CURVE - Carleton University Research Virtual Envronment",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 11971
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2869",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-10-25 16:24:00",
            "id" : 2869,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "value" : "ca",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -75.6994,
               "latitude" : 45.3823
            },
            "url" : "http://www.carleton.ca/",
            "country" : "ca",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Carleton University"
               }
            ]
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://publicatio.bibl.u-szeged.hu/policies.html"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "full_texts_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://publicatio.bibl.u-szeged.hu/policies.html"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy" : "undefined",
               "url" : [
                  "http://publicatio.bibl.u-szeged.hu/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "unusual_files_not_guaranteed"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable" : "yes"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "language" : "en",
                        "value" : "falsified_research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ],
                  "method" : "deleted",
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "value" : "removal_not_normal",
                        "language" : "en",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ]
               },
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "value" : "unusual_files_not_guaranteed",
                     "language" : "en"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               }
            },
            "content_policy" : {
               "metadata" : [
                  "publication_status"
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://publicatio.bibl.u-szeged.hu/policies.html"
               ],
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "value" : "working_drafts",
                     "language" : "en"
                  },
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://publicatio.bibl.u-szeged.hu/policies.html"
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-10-25 15:51:12",
            "id" : 2868,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2868"
         },
         "organisation" : {
            "url" : "http://www.u-szeged.hu/",
            "location" : {
               "longitude" : 20.1414,
               "latitude" : 46.253
            },
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "value" : "hu",
                  "language" : "en"
               }
            ],
            "country" : "hu",
            "name" : [
               {
                  "name" : "University of Szeged",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Hungarian",
                  "value" : "hu",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "en",
               "hu"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 8827,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "SZTE Publicatio Repozitórium - SZTE - Repository of Publications",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://publicatio.bibl.u-szeged.hu/cgi/oai2",
            "url" : "http://publicatio.bibl.u-szeged.hu/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of the University of Szeged which contains the work of staff and students. The interface is in Hungarian or English and includes RSS feeds to alert users to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "version" : "3.3.10",
               "name" : "eprints"
            }
         }
      },
      {
         "organisation" : {
            "url" : "http://www.ufasta.edu.ar/",
            "location" : {
               "longitude" : -57.5575,
               "latitude" : -38.0031
            },
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "country" : "ar",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad FASTA"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2867,
            "date_modified" : "2019-10-17 14:34:47",
            "date_created" : "2013-10-25 15:23:56",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2867",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio Digital de la Universidad FASTA",
                  "acronym" : "REDI",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 58,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This is the institutional repository of Universidad FASTA. the interface is in English and Spanish and it includes RSS feed to alert users of new content.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://redi.ufasta.edu.ar:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://redi.ufasta.edu.ar/",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "es"
            ]
         }
      },
      {
         "organisation" : {
            "country" : "ar",
            "url" : "http://www.abuc.org.ar/",
            "location" : {
               "latitude" : -31.4181,
               "longitude" : -64.1884
            },
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Acuerdo de Bibliotecas Universitarias de Córdoba (ABUC)"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-10-25 14:46:39",
            "date_modified" : "2019-10-17 14:34:47",
            "id" : 2866,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2866"
         },
         "repository_metadata" : {
            "metadata_record_count" : 1601,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "name" : "Cor-Ciencia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "aggregating",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 22,
            "oai_url" : "http://www.corciencia.org.ar/cgi/oai2",
            "url" : "http://www.corciencia.org.ar/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.11"
            },
            "description" : "This is the first repository developed by an agreement between university libraries. It contents only science and technology research of the province of Cordoba. many items are not full text.",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "PSU",
                  "name" : "Digital Library of Polotsk State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "name" : "Репозиторий Полоцкого государственного университета",
                  "language" : "ru",
                  "language_phrases" : [
                     {
                        "value" : "ru",
                        "language" : "en",
                        "phrase" : "Russian"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 13470,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "description" : "This repository provides access to the research output and scholarly materials created by community of Polotsk State University. Not all items are available. The kinds of documents included are: manuscripts, multimedia, audio. The interface is in Russian and English. Contains RSS feeds to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 8027,
            "oai_url" : "http://elib.psu.by:8080/oai/request",
            "url" : "http://elib.psu.by",
            "content_subjects" : [
               "1"
            ],
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en",
               "ru"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Polotsk State University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "by",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "by",
                  "phrase" : "Belarus"
               }
            ],
            "url" : "http://www.psu.by/index.php",
            "location" : {
               "latitude" : 55.5333,
               "longitude" : 28.65
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2865",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:30",
            "date_created" : "2013-10-21 16:37:39",
            "id" : 2865,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "description" : "This is the repository of the Korean Citation Index which also provides open access to the full text of some articles.The interface is in Korean and English.",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://www.kci.go.kr/",
            "oai_url" : "http://www.kci.go.kr/kciportal/oai/request",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "KCI (Korea Citation Index) Open Access Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "governmental",
            "metadata_record_count" : 100,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "content_languages" : [
               "ko"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Korean",
                  "language" : "en",
                  "value" : "ko"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "NRF (National Research Foundation of Korea), Korea, Republic of",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "kr",
                  "language" : "en",
                  "phrase" : "Korea, Republic of"
               }
            ],
            "url" : "http://www.nrf.re.kr/",
            "location" : {
               "longitude" : 127.366,
               "latitude" : 36.3851
            },
            "country" : "kr"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2864",
            "publicly_visible" : "yes",
            "id" : 2864,
            "date_created" : "2013-10-21 16:19:23",
            "date_modified" : "2019-10-17 14:34:47"
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2013-10-21 15:53:38",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2863,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2863",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad de Chile"
               }
            ],
            "location" : {
               "longitude" : -69.6094,
               "latitude" : -31.9522
            },
            "url" : "http://www.uchile.cl/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cl",
                  "phrase" : "Chile"
               }
            ],
            "country" : "cl"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Portal de Tesis Latinoamericanas"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               },
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "metadata_record_count" : 500,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provide access to electronic thesis and dissertations produced in 40 Latin American universities.\nThe site use Open Harvester Systems (OHS). The interface is in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "technically_malfunctioning",
            "software" : {
               "name_other" : "OHS (Open Harvester System)",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other",
               "version" : "2.3.2.0"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.tesislatinoamericanas.info/",
            "content_languages" : [
               "es",
               "pt"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Technically Malfunctioning",
                  "language" : "en",
                  "value" : "technically_malfunctioning"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 12715,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ar",
                  "language" : "en",
                  "phrase" : "Arabic"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Bibliothèque Virtuelle de l'université d'Alger"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ar",
               "en"
            ],
            "url" : "http://biblio.univ-alger.dz/jspui/",
            "content_subjects" : [
               "19",
               "20"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               }
            ],
            "description" : "The repository contains the historical books and documents about Algeria from their collection which have been digitised and are openly available. The books date from the early years of printing to the 1930's for books written in the Arabic script and up to 1811 for books written in the Latin alphabet.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2862",
            "publicly_visible" : "yes",
            "id" : 2862,
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-21 15:11:50"
         },
         "organisation" : {
            "country" : "dz",
            "location" : {
               "latitude" : 36.7529,
               "longitude" : 3.042
            },
            "url" : "http://www.univ-alger.dz/",
            "country_phrases" : [
               {
                  "value" : "dz",
                  "language" : "en",
                  "phrase" : "Algeria"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Algiers"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2861",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2861,
            "date_modified" : "2019-12-04 12:27:30",
            "date_created" : "2013-10-21 14:50:17",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "http://www.nasa.gov/centers/goddard/home/index.html",
            "location" : {
               "longitude" : -76.8526,
               "latitude" : 38.9915
            },
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "National Aeronautics and Space Administration, Goddard Space Flight Center",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 4250,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Goddard Library Repository"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "2"
            ],
            "url" : "http://gsfcir.gsfc.nasa.gov/",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "fedora",
                     "phrase" : "Fedora"
                  }
               ],
               "name" : "fedora"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "The Goddard Library Repository is developed and managed by the Goddard Library and is designed to store, distribute, and preserve digital publications and other resources created by NASA Goddard Space Flight Center. The Repository content consists of collections produced or controlled by the Goddard community. A collection is a group of digital objects and metadata related to the work of the Goddard Space Flight Center and the Wallops Flight Facility. The Repository includes items in a variety of formats, including text, images, audio, and video. Types of material that may be in the collections include: journal articles, conference and workshop papers and presentations, book chapters, Goddard Colloquium presentations, case studies, technical reports, images and other media, Goddard publications and historical documents, and special collections of documents related to a specific topic. The interface is in English."
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 4543,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Mykolas Romeris University Institutional Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repository.mruni.eu/",
            "oai_url" : "https://repository.mruni.eu/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "Institutional repository of Mykolas Romeris University manages and preserves the academic works of faculties, graduate students and research groups. The repository offers free and permanent access to collections of University scholarly materials in digital content. The interface is in English and includes RSS feeds to alert users to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "lt",
                  "language" : "en",
                  "phrase" : "Lithuanian"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages" : [
               "lt",
               "en"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country" : "lt",
            "url" : "http://www.mruni.eu/en/",
            "location" : {
               "latitude" : 54.7346,
               "longitude" : 25.2675
            },
            "country_phrases" : [
               {
                  "value" : "lt",
                  "language" : "en",
                  "phrase" : "Lithuania"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Mykolas Romeris University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2860",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-21 14:33:05",
            "id" : 2860
         }
      },
      {
         "repository_metadata" : {
            "description" : "This repository contains the papers, journals, and educational publications of Vinnytsya National Agrarian University. The interface is in Ukrainian and English and contains an RSS feed.",
            "software" : {
               "name" : "other",
               "name_other" : "VNAU`s repository code (php)",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            },
            "url" : "http://repository.vsau.org/",
            "content_subjects" : [
               "3",
               "24",
               "11"
            ],
            "oai_url" : "http://repository.vsau.org/oai/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "VNAU",
                  "name" : "Repository of Vinnytsya National Agrarian University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 12351,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "language" : "en",
                  "value" : "3"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "uk"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "url" : [
                  "http://repository.vsau.org/about.php?lang=en"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "url" : [
                  "http://repository.vsau.org/about.php?lang=en"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined"
            }
         },
         "organisation" : {
            "country" : "ua",
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "location" : {
               "longitude" : 28.4051,
               "latitude" : 49.2098
            },
            "url" : "http://vsau.org/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Vinnytsya National Agrarian University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-10-21 11:37:16",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2858,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2858"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "19"
            ],
            "url" : "http://openarchive.icomos.org/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "value" : "disciplinary",
                  "language" : "en"
               }
            ],
            "description" : "ICOMOS Open Archive is a global archive specialising in the conservation and restoration of monuments, sites and landscapes.\nIt is both the institutional archive of the scientific documentation produced by the International Council on Monuments and Sites (ICOMOS) and also a subject archive open to the entire international scientific community in the field of heritage conservation. Research institutes, organizations, universities and individual researchers involved in the conservation of cultural heritage and related fields, whether members of ICOMOS or not, are encouraged to make use of and contribute to this global Archive. The interface is in English and has an RSS feed.",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 1397,
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "ICOMOS Open Archive",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "value" : "content_not_changed",
                     "language" : "en",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://www.international.icomos.org/centre_documentation/openarchive/user_guide.pdf"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://www.international.icomos.org/centre_documentation/openarchive/user_guide.pdf"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               },
               "version_control" : {
                  "earlier_versions" : [
                     "link_between_versions"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "value" : "errata_may_be_included",
                        "language" : "en",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "link_between_versions",
                        "language" : "en",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "special_reasons" : [
                     "Insulting, discriminatory and other inappropriate content ."
                  ],
                  "method" : "removed_from_public_view",
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        },
                        {
                           "phrase" : "URLs will contain a link to a replacement version, where available",
                           "language" : "en",
                           "value" : "link_to_replacement"
                        },
                        {
                           "language" : "en",
                           "value" : "explanation_of_withdrawal",
                           "phrase" : "URLs will contain a note explaining the reasons for withdrawal"
                        }
                     ],
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone",
                        "link_to_replacement",
                        "explanation_of_withdrawal"
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "language" : "en",
                        "value" : "publisher_rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     },
                     {
                        "phrase" : "Other (specify)",
                        "language" : "en",
                        "value" : "other"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research",
                     "other"
                  ]
               },
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "language" : "en",
                     "value" : "software_emulation"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "language" : "en",
                     "value" : "no_policy"
                  }
               ],
               "url" : [
                  "http://www.international.icomos.org/centre_documentation/openarchive/user_guide.pdf"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "policy_undefined",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "community_members"
               ],
               "content_embargo" : "policy_undefined",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "language" : "en",
                     "value" : "bibliographic_metadata_required"
                  }
               ],
               "moderation" : "no_policy"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "language" : "en",
                     "value" : "requires_permission"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://www.international.icomos.org/centre_documentation/openarchive/user_guide.pdf"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ]
            },
            "content_policy" : {
               "subjects_phrases" : [
                  {
                     "value" : "20",
                     "language" : "en",
                     "phrase" : "History and Archaeology"
                  },
                  {
                     "phrase" : "Architecture",
                     "language" : "en",
                     "value" : "12"
                  }
               ],
               "subjects" : [
                  "20",
                  "12"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "language" : "en",
                     "value" : "multi_institution_subject"
                  }
               ],
               "url" : [
                  "http://www.international.icomos.org/centre_documentation/openarchive/user_guide.pdf"
               ],
               "repository_type" : "multi_institution_subject"
            }
         },
         "system_metadata" : {
            "id" : 2857,
            "date_created" : "2013-10-18 17:23:42",
            "date_modified" : "2019-10-17 14:34:46",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2857",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "fr",
            "url" : "http://www.icomos.org/",
            "location" : {
               "latitude" : 48.8536,
               "longitude" : 2.2953
            },
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "ICOMOS International Secretariat",
                  "acronym" : "ICOMOS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "url" : [
                  "https://pages.shanti.virginia.edu/libra/openaccess/"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "https://pages.shanti.virginia.edu/libra/openaccess/"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions"
               ],
               "types_included" : {
                  "standard_types_allowed" : [
                     "journal_articles",
                     "books_chapters_and_sections"
                  ],
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "value" : "journal_articles",
                        "language" : "en",
                        "phrase" : "Journal Articles"
                     },
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "language" : "en",
                        "value" : "books_chapters_and_sections"
                     }
                  ]
               }
            },
            "submission_policy" : {
               "depositors" : [
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "language" : "en",
                     "value" : "policy_undefined"
                  }
               ],
               "url" : [
                  "https://pages.shanti.virginia.edu/libra/openaccess/"
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor"
            },
            "data_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "url" : [
                  "https://pages.shanti.virginia.edu/libra/openaccess/"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  },
                  "policy" : "undefined",
                  "method" : "undefined",
                  "policy_phrases" : [
                     {
                        "phrase" : "No withdrawal policy defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No deletion method for withdrawn items defined"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted"
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     }
                  ]
               },
               "retention_period" : {
                  "period" : "undefined",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No retention period defined"
                     }
                  ]
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://pages.shanti.virginia.edu/libra/openaccess/"
               ],
               "closure_policy" : "undefined"
            }
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.virginia.edu/",
            "location" : {
               "latitude" : 38.0322,
               "longitude" : -78.4775
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Virginia",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2856",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-18 17:07:57",
            "id" : 2856,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "LIBRA",
                  "name" : "Online Archive of University of Virginia Scholarship",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "metadata_record_count" : 1727,
            "description" : "Libra is the University of Virginia’s institutional repository which contains openly accessible work created by the university community. The interface is in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Fedora",
                     "language" : "en",
                     "value" : "fedora"
                  }
               ],
               "name" : "fedora"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://libra.virginia.edu/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Fordham Law School"
               }
            ],
            "country" : "us",
            "location" : {
               "latitude" : 40.7716,
               "longitude" : -73.9845
            },
            "url" : "http://law.fordham.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-18 16:44:46",
            "id" : 2855,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2855",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "FLASH: The Fordham Law Archive of Scholarship and History"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "metadata_record_count" : 8684,
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "description" : "This is the institutional repository of legal scholarship and historical materials from the Fordham University School of Law in New York City, NY. The interface is in English and contains an RSS feed.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://ir.lawnet.fordham.edu/",
            "content_subjects" : [
               "26"
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CITRU - INBA",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Mexico",
                  "value" : "mx",
                  "language" : "en"
               }
            ],
            "url" : "http://www.citru.bellasartes.gob.mx/",
            "location" : {
               "longitude" : -99.1391,
               "latitude" : 19.3566
            },
            "country" : "mx"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-18 16:12:04",
            "id" : 2854,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2854",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Resena Historica del Teatro en Mexico 2.0-2,1 Sistema de la critica teatral",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "metadata_record_count" : 3274,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Dessarrollo propio",
               "name" : "other"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This is a digital archive of full text collections of critical publications about theatrical performances in Mexico. The interface is in Spanish.",
            "content_subjects_phrases" : [
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "18"
            ],
            "url" : "http://www.resenahistoricateatromexico2021.net/",
            "content_languages" : [
               "es"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2853",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2853,
            "date_created" : "2013-10-18 15:36:51",
            "date_modified" : "2019-12-04 12:27:30",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Salve Regina University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "http://www.salve.edu/",
            "location" : {
               "latitude" : 41.4776,
               "longitude" : -71.3356
            }
         },
         "repository_metadata" : {
            "url" : "http://digitalcommons.salve.edu/fac_staff/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This repository's aim is to collect, preserve, and provide access to the scholarship of the university. Where possible, items in the repository are open access. Collections include faculty publications, image collections, digitised items from the university's archives, senior and master thesis with limited access to doctoral dissertations, and journals published by the university. The interface is in English and it includes an RSS feed.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 51,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Digital Commons @ Salve Regina",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "cs",
                  "language" : "en",
                  "phrase" : "Czech"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "cs"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "Digitální knihovna VUT",
                  "name" : "Digital library of Brno University of Technology",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 56517,
            "description" : "This site provides access to the collections and research output of the institution. The interface is in Czech and includes RSS feeds.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "url" : "https://dspace.vutbr.cz/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://dspace.vutbr.cz/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2852",
            "publicly_visible" : "yes",
            "date_created" : "2013-10-18 15:14:21",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2852
         },
         "organisation" : {
            "country" : "cz",
            "country_phrases" : [
               {
                  "value" : "cz",
                  "language" : "en",
                  "phrase" : "Czechia"
               }
            ],
            "url" : "https://www.vutbr.cz/",
            "location" : {
               "longitude" : 16.6033,
               "latitude" : 49.2018
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Brno University of Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            }
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.11"
            },
            "description" : "This is an institutional repository of Walisongo State Institute for Islamic Studies, one of Islamic State University in Indonesia.The interface is in English and it contains RSS feeds to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://eprints.walisongo.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.walisongo.ac.id/",
            "name" : [
               {
                  "name" : "Walisongo Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 7634,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "ms"
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ms",
                  "language" : "en",
                  "phrase" : "Malay"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2851",
            "publicly_visible" : "yes",
            "id" : 2851,
            "date_created" : "2013-10-18 14:55:26",
            "date_modified" : "2019-10-17 14:34:46"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesia"
               }
            ],
            "url" : "http://www.walisongo.ac.id/",
            "location" : {
               "latitude" : -6.9916,
               "longitude" : 110.349
            },
            "country" : "id",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "IAIN Walisongo Semarang",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "language" : "en",
                  "value" : "19"
               },
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "description" : "BLD is a repository of digital documents, designed to organize, preserve and spread in open access an increasing quantity of documents, which either are part of the collections of the municipal libraries, or are produced or owned by the City Council of Bilbao. The Interface is available in Basques, Castilian and English and includes RSS feeds to alert users of new content.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "http://www.bilbao.net/bld",
            "content_subjects" : [
               "19",
               "20"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "BLD - Bilboko Liburutegi Digitala",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 34075
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2850",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-18 14:21:29",
            "id" : 2850
         },
         "organisation" : {
            "location" : {
               "latitude" : 43.2567,
               "longitude" : -2.9241
            },
            "url" : "http://www.bilbao.net/cs/Satellite/bibliotecasMunicipales/Inicio/es/100049470/Home",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "name" : "Red de Bibliotecas Municipales de Bilbao",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "cs"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Czech",
                  "language" : "en",
                  "value" : "cs"
               }
            ],
            "description" : "This repository contains a bibliography of publications by authors from Tomas Bata University in Zlin. It's focused only on officially rated results of TBU science and research – journal articles, conference papers and monographs. Many items are restricted, with meta-data only available. The interface is in English.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://publikace.k.utb.cz/oai/request",
            "url" : "http://publikace.k.utb.cz/",
            "full_text_record_count" : 981,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional repository of Tomas Bata University Library",
                  "acronym" : "Repository of TBU publications",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 8652
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Czechia",
                  "language" : "en",
                  "value" : "cz"
               }
            ],
            "location" : {
               "longitude" : 17.665,
               "latitude" : 49.2226
            },
            "url" : "http://www.utb.cz/",
            "country" : "cz",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Tomas Bata University in Zlin",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2849,
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-18 14:03:30",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2849",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 18268,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Institutional Repository of Institute of Process Engineering, CAS (IPE-IR）",
                  "acronym" : "CASIPE-IR",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 1,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://ir.ipe.ac.cn/",
            "content_subjects" : [
               "11"
            ],
            "oai_url" : "http://ir.ipe.ac.cn/casirgrid-oai/request",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to output of the institution. Users may set up an RSS feed to be alerted to new content. The interface is available in English and Chinese."
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "IPE-CAS",
                  "name" : "INSTITUTE OF PROCESS ENGINEERING, CAS(中国科学院过程工程研究所）",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "cn",
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "language" : "en",
                  "value" : "cn"
               }
            ],
            "location" : {
               "latitude" : 39.988,
               "longitude" : 116.327
            },
            "url" : "http://www.ipe.cas.cn/"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2847",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 2847,
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-15 16:13:45",
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "country" : "cl",
            "country_phrases" : [
               {
                  "value" : "cl",
                  "language" : "en",
                  "phrase" : "Chile"
               }
            ],
            "url" : "http://www.ciren.cl/web/",
            "location" : {
               "latitude" : -33.4386,
               "longitude" : -70.6157
            },
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Centro de Informatión de Recursos Naturales (CIREN)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2846",
            "publicly_visible" : "yes",
            "id" : 2846,
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-07 14:10:00"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Earth and Planetary Sciences",
                  "language" : "en",
                  "value" : "6"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This is a free and public information service, which gives access to many items, such as texts, reports, and cartographic resources, that provide information related to the use of natural and productive resources in Chile. This service is part of the 'Conversin Digital de la Documentacin de Recursos Naturales y su liberacin al Ciber Espacio' Project, which has been financed by INNOVA Chile-CORFO; and developed by CIREN and the General Water Direction, an organization dependent on the Chilean Ministry of Public Works (MOP). The interface is in Spanish or English and it contains an RSS feed to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://bibliotecadigital.ciren.cl/",
            "content_subjects" : [
               "6",
               "7"
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteca Digital of the Centro de Informatión de Recursos Naturales",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "metadata_record_count" : 19877,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2845",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-07 11:23:17",
            "id" : 2845,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad de las Américas"
               }
            ],
            "country" : "ec",
            "country_phrases" : [
               {
                  "phrase" : "Ecuador",
                  "language" : "en",
                  "value" : "ec"
               }
            ],
            "location" : {
               "latitude" : -0.1625,
               "longitude" : -78.461
            },
            "url" : "http://www.udla.edu.ec/"
         },
         "repository_metadata" : {
            "metadata_record_count" : 8990,
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Digital UDLA"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.udla.edu.ec/",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This is the institutional repository for the University of the Americas, Quito, which provides open access to thesis and dissertations. The interface is in Spanish and includes RSS feeds to alert the user of new content."
         }
      },
      {
         "system_metadata" : {
            "id" : 2844,
            "date_created" : "2013-10-04 14:53:29",
            "date_modified" : "2019-12-04 12:27:30",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2844",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "cr",
            "location" : {
               "longitude" : -84.0167,
               "latitude" : 10.4735
            },
            "url" : "http://www.una.ac.cr/",
            "country_phrases" : [
               {
                  "value" : "cr",
                  "language" : "en",
                  "phrase" : "Costa Rica"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Nacional de Costa Rica",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Académico de la Universidad Nacional de Costa Rica",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 11035,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is the institutional repository of Universidad Nacional de Costa Rica. The interface is in Spanish and contains RSS feed to alert users of new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://www.repositorio.una.ac.cr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.repositorio.una.ac.cr/",
            "content_types" : [
               "journal_articles",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "es"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 16431,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "PANDEMOS"
               }
            ],
            "oai_url" : "http://pandemos.panteion.gr:8080/oaiprovider/",
            "content_subjects" : [
               "17",
               "23"
            ],
            "url" : "http://pandemos.panteion.gr/",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This is the institutional repository and digital archive of Panteion University. The interface is in Greek and English and includes and RSS feed to alert users of new content",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Fedora",
                     "value" : "fedora",
                     "language" : "en"
                  }
               ],
               "name" : "fedora"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Greek (modern)",
                  "value" : "el",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages" : [
               "el",
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2843",
            "publicly_visible" : "yes",
            "id" : 2843,
            "date_modified" : "2019-12-04 12:27:30",
            "date_created" : "2013-10-04 14:15:38"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "PANTEION UNIVERSITY"
               }
            ],
            "country" : "gr",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gr",
                  "phrase" : "Greece"
               }
            ],
            "location" : {
               "latitude" : 37.9557,
               "longitude" : 23.6988
            },
            "url" : "http://www.panteion.gr/"
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 9398,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "ScholarsArchive (Brigham Young University's Institutional Repository)",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://sites.lib.byu.edu/scholarsarchive/research/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "value" : "contentdm",
                     "language" : "en"
                  }
               ],
               "name" : "contentdm"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "ScholarsArchive is Brigham Young University’s institutional repository for the scholarly and creative content produced by the University. ScholarsArchive makes research, publications, and data produced by BYU faculty and students available worldwide."
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Harold B. Lee Library at Brigham Young University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -111.651,
               "latitude" : 40.2507
            },
            "url" : "http://lib.byu.edu/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2842",
            "publicly_visible" : "yes",
            "id" : 2842,
            "date_created" : "2013-10-03 17:25:18",
            "date_modified" : "2019-10-17 14:34:46"
         },
         "policies" : {
            "submission_policy" : {
               "depositors" : [
                  "community_members"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "language" : "en",
                     "value" : "no_policy"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "policy_undefined",
                     "language" : "en",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "url" : [
                  "http://sites.lib.byu.edu/scholarsarchive/policies-2/"
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor"
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "value" : "undefined",
                        "language" : "en"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "method" : "undefined",
                  "policy" : "removal_not_normal",
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "language" : "en",
                        "value" : "publisher_rules"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ]
               },
               "closure_policy" : "undefined",
               "url" : [
                  "http://sites.lib.byu.edu/scholarsarchive/policies-2/"
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "url" : [
                  "http://sites.lib.byu.edu/scholarsarchive/policies-2/"
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "content_policy" : {
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "http://sites.lib.byu.edu/scholarsarchive/policies-2/"
               ],
               "types_included" : {
                  "standard_types_excluded_phrases" : [
                     {
                        "phrase" : "Other Special Item Types",
                        "value" : "other_special_item_types",
                        "language" : "en"
                     }
                  ],
                  "special_types_excluded" : [
                     "popular entertainment or items of current personal information"
                  ],
                  "standard_types_excluded" : [
                     "other_special_item_types"
                  ],
                  "all" : "false"
               },
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://sites.lib.byu.edu/scholarsarchive/policies-2/"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://scholarworks.montana.edu/xmlui/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "ScholarWorks is an open access repository for the capture of the intellectual work of Montana State University (MSU) in support of its teaching, research and service missions. MSU ScholarWorks is a central point of discovery for accessing, collecting, sharing, preserving, and distributing knowledge to the Montana State University community and the world. The interface is in English and it contains RSS feeds for content alert.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 13535,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "ScholarWorks",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2841,
            "date_created" : "2013-10-03 17:11:12",
            "date_modified" : "2019-10-17 14:34:46",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2841"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Montana State University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -111.049,
               "latitude" : 45.6671
            },
            "url" : "http://www.montana.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "policies" : {
            "submission_policy" : {
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  }
               ],
               "quality_control" : "not_checked",
               "quality_control_phrases" : [
                  {
                     "value" : "not_checked",
                     "language" : "en",
                     "phrase" : " is not checked."
                  }
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "content_embargo" : "policy_undefined",
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "community_members"
               ],
               "url" : [
                  "http://scholarworks.montana.edu/docs/"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "value" : "no_policy",
                     "language" : "en",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ]
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "url" : [
                  "http://scholarworks.montana.edu/docs/"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No withdrawal policy defined"
                     }
                  ],
                  "policy" : "undefined",
                  "method" : "undefined",
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No deletion method for withdrawn items defined"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "url" : [
                  "http://scholarworks.montana.edu/docs/"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy" : "transfer_to_appropriate_archive"
            },
            "metadata_policy" : {
               "url" : [
                  "http://scholarworks.montana.edu/docs/"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://scholarworks.montana.edu/docs/"
               ],
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "notes" : "Certain items need a log in and others only have meta data records.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 12121,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "CommonKnowledge",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 3448,
            "url" : "http://commons.pacificu.edu/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://commons.pacificu.edu/do/oai/?",
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            },
            "description" : "CommonKnowledge is the home of the collected scholarship and creative works of Pacific University faculty, staff and students - and of their collaborators from around the world. These open collections, organized and made accessible by the Pacific University Libraries, demonstrate Pacific's commitment to the idea that shared information and academic collaboration are essential to the \"progress of knowledge\" in our global community. the interface is in English and includes an RSS feed to alert users to new content."
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-10-03 17:04:20",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2840,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2840"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "http://www.pacificu.edu/",
            "location" : {
               "longitude" : -123.107,
               "latitude" : 45.525
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Pacific University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "description" : "ISU ReD is a digital repository of the work of faculty, staff, and students at Illinois State University. the interface is in English and it has an RSS feed to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://ir.library.illinoisstate.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ir.library.illinoisstate.edu/",
            "name" : [
               {
                  "name" : "ISU ReD: Research and eData",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1214,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Illinois State University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 40.5114,
               "longitude" : -88.9911
            },
            "url" : "http://illinoisstate.edu/"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2839,
            "date_created" : "2013-10-03 16:32:34",
            "date_modified" : "2019-12-04 12:27:30",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2839"
         },
         "policies" : {
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://ir.library.illinoisstate.edu/guidelines.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "language" : "en",
                     "value" : "content_not_changed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ]
            },
            "preservation_policy" : {
               "closure_policy" : "undefined",
               "url" : [
                  "http://ir.library.illinoisstate.edu/guidelines.html"
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No retention period defined"
                     }
                  ],
                  "period" : "undefined"
               },
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "language" : "en",
                        "value" : "publisher_rules"
                     },
                     {
                        "value" : "other",
                        "language" : "en",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  },
                  "method" : "undefined",
                  "special_reasons" : [
                     "Disputed rights and violation of submission agreement"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "value" : "undefined",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "other"
                  ],
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ]
               }
            },
            "submission_policy" : {
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://ir.library.illinoisstate.edu/guidelines.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting"
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://ir.library.illinoisstate.edu/guidelines.html"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "url" : [
                  "http://ir.library.illinoisstate.edu/guidelines.html"
               ],
               "languages" : [
                  "en"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norwegian"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "no"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Fiskeridirektoratets digitalarkiv",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "governmental",
            "metadata_record_count" : 9692,
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5.1"
            },
            "description" : "This is a repository for the Norwegian Directorate of Fisheries which contains archival material from 1894 onwards. The interface is available in Norwegian and English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "3"
            ],
            "oai_url" : "https://fdir.brage.unit.no/fdir-oai/request",
            "url" : "https://fdir.brage.unit.no"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-10-03 16:08:12",
            "id" : 2838,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2838",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "The Norwegian Directorate of Fisheries",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "value" : "no",
                        "language" : "en",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Fiskeridirektoratet"
               }
            ],
            "country" : "no",
            "url" : "http://fiskeridir.no/",
            "location" : {
               "longitude" : 5.3074,
               "latitude" : 60.3998
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norway"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://data.norge.no/nlod/no"
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "phrase" : "Norwegian",
                     "language" : "en",
                     "value" : "no"
                  }
               ],
               "types_included" : {
                  "standard_types_allowed" : [],
                  "special_types_allowed" : [
                     "archives of Fiskeridirektoratet, the Norwegian Fishing Directorate, from 1895 onwards"
                  ],
                  "standard_types_allowed_phrases" : [],
                  "all" : "false"
               },
               "languages" : [
                  "no"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "subjects_phrases" : [
                  {
                     "language" : "en",
                     "value" : "3",
                     "phrase" : "Agriculture, Food and Veterinary"
                  }
               ],
               "subjects" : [
                  "3"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_requirements" : [
                  "full_citation_required"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties",
                  "stored_in_a_database"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "language" : "en",
                     "value" : "given_to_third_parties",
                     "phrase" : "given to third parties"
                  },
                  {
                     "language" : "en",
                     "value" : "stored_in_a_database",
                     "phrase" : "stored in a database"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  }
               ],
               "url" : [
                  "http://data.norge.no/nlod/no"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  },
                  {
                     "value" : "commercial_purposes",
                     "language" : "en",
                     "phrase" : "commercial purposes"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes",
                  "commercial_purposes"
               ]
            }
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2013-10-02 16:19:05",
            "date_modified" : "2019-12-04 12:27:30",
            "id" : 2837,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2837",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : -58.3816,
               "latitude" : -34.6037
            },
            "url" : "http://prohuertacn@correo.inta.gov.ar/",
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "country" : "ar",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Pro-Huerta"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "governmental",
            "name" : [
               {
                  "name" : "Biblioteca Digital del programa Pro-Huerta (INTA-MDS) / Pro-Huerta's (INTA-MDS) Digital Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 323,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "description" : "This digital library contains the production of Argentine, Pro-Huerta's food production and safety programme program. It contains books and bookets as well as graphics and audiovisual publications. the interface is in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "value" : "greenstone",
                     "language" : "en"
                  }
               ],
               "name" : "greenstone"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "3",
               "7"
            ],
            "url" : "http://prohuerta.inta.gov.ar/biblioteca",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "The RUFORUM Institutional Repository was established to enhance the visibility of the intellectual output of the RUFORUM network, which consists of 32 schools or faculties of agriculture in Eastern, Southern, and Central Africa. All materials included in the repository are either Open Access or Open Educational Resources (OER) which are free to download, distribute, and in the case of OER, to adapt for educational purposes. The interface is in English.",
            "software" : {
               "name" : "drupal",
               "name_phrases" : [
                  {
                     "phrase" : "Drupal",
                     "value" : "drupal",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "3",
               "7"
            ],
            "oai_url" : "http://repository.ruforum.org/oai",
            "url" : "http://repository.ruforum.org/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "RUFORUM Institutional Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 2182,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "year_established" : 2013
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Regional Universities Forum for Capacity Building in Agriculture",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 0.3136,
               "longitude" : 32.5811
            },
            "url" : "http://www.ruforum.org/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ug",
                  "phrase" : "Uganda"
               }
            ],
            "country" : "ug"
         },
         "system_metadata" : {
            "date_created" : "2013-09-30 17:12:25",
            "date_modified" : "2019-12-04 12:27:30",
            "id" : 2836,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2836",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "notes" : ".",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "ResearchOnline@Avondale",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 993,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "ResearchOnline@Avondale is an institutional repository of the research and scholarly output produced by Avondale staff and post-graduate students. The interface is in English and it contains an RSS feed to alert users of new content.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://research.avondale.edu.au/"
         },
         "policies" : {
            "content_policy" : {
               "types_included" : {
                  "all" : "false",
                  "standard_types_excluded" : [
                     "learning_objects"
                  ],
                  "standard_types_excluded_phrases" : [
                     {
                        "language" : "en",
                        "value" : "learning_objects",
                        "phrase" : "Learning Objects"
                     }
                  ]
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "url" : [
                  "http://research.avondale.edu.au/faq.html"
               ],
               "languages" : [
                  "en"
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://research.avondale.edu.au/faq.html"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "url" : [
                  "http://research.avondale.edu.au/faq.html"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "value" : "some_or_all_restricted",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "reuse" : "undefined",
               "access" : "some_or_all_restricted"
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "url" : [
                  "http://research.avondale.edu.au/faq.html"
               ],
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "withdrawal" : {
                  "policy" : "removal_at_request",
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "value" : "indefinite",
                           "language" : "en"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "language" : "en",
                           "value" : "tombstone",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               },
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  }
               ]
            },
            "submission_policy" : {
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors" : [
                  "community_members"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_policy",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "url" : [
                  "http://research.avondale.edu.au/faq.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "policy_undefined",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:46",
            "date_created" : "2013-09-27 15:24:42",
            "id" : 2835,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2835"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "au",
                  "language" : "en",
                  "phrase" : "Australia"
               }
            ],
            "location" : {
               "longitude" : 151.455,
               "latitude" : -33.0705
            },
            "url" : "http://www.avondale.edu.au/",
            "country" : "au",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Avondale College of Higher Education",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2834",
            "publicly_visible" : "yes",
            "date_created" : "2013-09-26 16:16:27",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2834
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 38.4225,
               "longitude" : -82.4308
            },
            "url" : "http://www.marshall.edu/",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Marshall University"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "Marshall Digital Scholar serves to collect, preserve, and provide global access to the scholarly and creative work of faculty, students, and alumni of Marshall University, as well as university publications, images, recordings, archives, and special collections. the interface is in English and it includes an RSS feed to alert users to new content.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://mds.marshall.edu/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Marshall Digital Scholar",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 4243
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2833",
            "publicly_visible" : "yes",
            "date_created" : "2013-09-26 15:44:34",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2833
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Conseil Régional de Bretagne",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "France"
               }
            ],
            "url" : "http://www.bretagne.fr/",
            "location" : {
               "longitude" : -1.66171,
               "latitude" : 48.1378
            },
            "country" : "fr"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "SDX",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "This is digital repository for cultural heritage in the Breton region of France. It contains local government papers and reports and historical documents. The interface is in French.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "19"
            ],
            "url" : "http://www.inventaire.culture.gouv.fr/",
            "content_languages" : [
               "fr"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Inventaire du patrimoine (Région Bretagne)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "metadata_record_count" : 99298,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "UNH Scholars' Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 24693,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "description" : "The Scholars’ Repository, a service of the University Library, is a collection of scholarly and creative works of University of New Hampshire faculty, staff, and students. The items included have been selected by the library or deposited by academic departments, research institutes, and individual contributors. The interface is in English and contains an RSS feed to alert users of new content.",
            "full_text_record_count" : 7,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://scholars.unh.edu/",
            "oai_url" : "http://scholars.unh.edu/do/oai/",
            "content_subjects" : [
               "1"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2013-09-26 14:32:21",
            "date_modified" : "2019-10-17 14:34:46",
            "id" : 2832,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2832"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of New Hampshire",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -70.9264,
               "latitude" : 43.134
            },
            "url" : "http://www.unh.edu/"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Virtual Commons - Bridgewater State University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 7977,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "Virtual Commons is Bridgewater State University’s open-access repository for the scholarly works, research, publications, creative activity, and reports produced by the faculty, students, and staff of Bridgewater State University and its collaborative partners. The interface is in English and includes an RSS feed to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 3750,
            "url" : "http://vc.bridgew.edu/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://vc.bridgew.edu/do/oai/"
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.bridgew.edu/",
            "location" : {
               "longitude" : -70.965,
               "latitude" : 41.9885
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Bridgewater State University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:30",
            "date_created" : "2013-09-26 12:32:52",
            "id" : 2831,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2831"
         },
         "policies" : {
            "preservation_policy" : {
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "closure_policy" : "undefined",
               "url" : [
                  "http://vc.bridgew.edu/faq.html"
               ],
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "other"
                  ],
                  "method" : "removed_from_public_view",
                  "special_reasons" : [
                     "factual inaccuracy"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Other (specify)",
                        "language" : "en",
                        "value" : "other"
                     }
                  ],
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "value" : "no",
                           "language" : "en"
                        }
                     ],
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "no"
                  }
               }
            },
            "submission_policy" : {
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "language" : "en",
                     "value" : "policy_undefined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "url" : [
                  "http://vc.bridgew.edu/faq.html"
               ],
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_policy",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "content_embargo" : "policy_undefined",
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ]
            },
            "content_policy" : {
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "language" : "en",
                     "value" : "working_drafts"
                  },
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "url" : [
                  "http://vc.bridgew.edu/faq.html"
               ]
            }
         }
      }
   ]
}

