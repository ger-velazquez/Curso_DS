{
   "items" : [
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 7736,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Sunderland University Institutional Repository",
                  "acronym" : "SURE",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "oai_url" : "http://sure.sunderland.ac.uk/cgi/oai2",
            "url" : "http://sure.sunderland.ac.uk/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1341,
            "description" : "This site provides access to the research output of the institution. Some content is not available as full-text. Some content is only available to registered users. The interface is available in English. Users may set up an RSS feed to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.4.0",
               "name" : "eprints"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Sunderland",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "gb",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "http://www.sunderland.ac.uk/",
            "location" : {
               "longitude" : -1.3761,
               "latitude" : 54.9084
            }
         },
         "system_metadata" : {
            "date_created" : "2012-02-06 09:09:42",
            "date_modified" : "2019-12-04 12:27:29",
            "id" : 2408,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2408",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://sure.sunderland.ac.uk/policies.html"
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "value" : "valid_formatting",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor"
            },
            "data_policy" : {
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties",
                  "stored_in_a_database"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  },
                  {
                     "value" : "stored_in_a_database",
                     "language" : "en",
                     "phrase" : "stored in a database"
                  }
               ],
               "harvesting" : [
                  "not_allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "value" : "content_not_changed",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://sure.sunderland.ac.uk/policies.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Not Allowed",
                     "value" : "not_allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "url" : [
                  "http://sure.sunderland.ac.uk/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "value" : "original_bitstream_retained",
                     "language" : "en",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "errata_may_be_included",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn"
                     },
                     {
                        "phrase" : "The items persistent URL will always link to the latest version",
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest"
                  ]
               },
               "withdrawal" : {
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable" : "yes"
                  },
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "publisher_rules",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "language" : "en",
                        "value" : "falsified_research"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "removed_from_public_view"
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "value" : "migrate_file_formats",
                     "language" : "en"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed"
                  }
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://sure.sunderland.ac.uk/policies.html"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "working_drafts",
                     "phrase" : "working drafts"
                  },
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "true"
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://sure.sunderland.ac.uk/policies.html"
               ],
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ]
            }
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2407",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2012-02-02 10:10:54",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2407,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Waterbouwkundig Laboratorium (Flanders Hydraulics Research)",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "be",
            "url" : "http://www.waterbouwkundiglaboratorium.be/",
            "location" : {
               "longitude" : 4.4473,
               "latitude" : 51.2037
            },
            "country_phrases" : [
               {
                  "phrase" : "Belgium",
                  "value" : "be",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in Dutch. Users may set up RSS feeds to be alerted to new content.",
            "content_subjects_phrases" : [
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Drupal",
                     "value" : "drupal",
                     "language" : "en"
                  }
               ],
               "version" : "7",
               "name" : "drupal"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "nl",
               "en"
            ],
            "url" : "http://www.waterbouwkundiglaboratorium.be/en/open-fhr-archive",
            "content_subjects" : [
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Open FHR Archive",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "nl",
                  "phrase" : "Dutch"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 1516
         }
      },
      {
         "system_metadata" : {
            "id" : 2405,
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2012-02-01 16:16:18",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2405",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Fundación Juan March",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "es",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Center for Advanced Study in the Social Sciences",
                  "acronym" : "CEACS",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 40.4312,
               "longitude" : -3.6812
            },
            "url" : "http://www.march.es/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish or English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : []
            },
            "oai_url" : "http://digital.march.es/ceacs-ir/oai2",
            "url" : "http://digital.march.es/ceacs-ir/",
            "content_subjects" : [
               "23"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 100,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CEACS Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 2371,
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://repositorio.ibict.br/",
            "oai_url" : "http://repositorio.ibict.br/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish, Portuguese and English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "1.6.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 737,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "RIDI - Repositório Institucional Digital do Ibict",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         },
         "organisation" : {
            "country" : "br",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "http://www.ibict.br/",
            "location" : {
               "longitude" : -47.9292,
               "latitude" : -15.7801
            },
            "name" : [
               {
                  "acronym" : "ibict",
                  "name" : "Instituto Brasileiro de Informação em Ciência e Tecnologia",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2404,
            "date_created" : "2012-02-01 15:15:55",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2404",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "version" : "1.7.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.This repository covers Oceanography and related subjects.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "4",
               "7"
            ],
            "oai_url" : "http://www.repositorio.ieo.es/oai/request",
            "url" : "http://www.repositorio.ieo.es/e-ieo/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "e-ieo",
                  "name" : "Repositorio Institucional Digital del IEO",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 9940,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               }
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Instituto Español de Oceanografía",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 40.4167,
               "longitude" : -3.7003
            },
            "url" : "http://www.ieo.es/inicial.htm",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "country" : "es"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2012-02-01 10:10:11",
            "date_modified" : "2019-12-04 12:27:29",
            "id" : 2403,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2403"
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "content_embargo" : "restricted_until_embargo_expiry",
               "depositors" : [
                  "community_members",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "url" : [
                  "https://rep.bntu.by/bitstream/handle/data/57773/Repository%20of%20BNTU%20Policies.pdf?sequence=1&isAllowed=y"
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  },
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "value" : "bibliographic_metadata_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Eligible depositors must deposit full texts of all their publications",
                     "value" : "full_texts_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "value" : "author_eligibility",
                     "language" : "en"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "value" : "link_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the original copyright statement is given",
                     "language" : "en",
                     "value" : "original_copyright_statement_required"
                  },
                  {
                     "phrase" : "the original rights permission statement is given",
                     "language" : "en",
                     "value" : "original_rights_statement_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "language" : "en",
                     "value" : "content_not_changed"
                  }
               ],
               "url" : [
                  "https://rep.bntu.by/bitstream/handle/data/57773/Repository%20of%20BNTU%20Policies.pdf?sequence=1&isAllowed=y"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "language" : "en",
                     "value" : "some_items_have_different_conditions",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  },
                  {
                     "phrase" : "given to third parties",
                     "language" : "en",
                     "value" : "given_to_third_parties"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "https://rep.bntu.by/bitstream/handle/data/57773/Repository%20of%20BNTU%20Policies.pdf?sequence=1&isAllowed=y"
               ],
               "withdrawal" : {
                  "method" : "deleted",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Not at all",
                           "value" : "not_retained",
                           "language" : "en"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "not_retained",
                     "searchable" : "yes"
                  }
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "language" : "en",
                     "value" : "original_bitstream_retained",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "version_control" : {
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               }
            },
            "metadata_policy" : {
               "url" : [
                  "https://rep.bntu.by/bitstream/handle/data/57773/Repository%20of%20BNTU%20Policies.pdf?sequence=1&isAllowed=y"
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "language" : "en",
                     "value" : "repository_mention_required"
                  }
               ],
               "non_profit_reuse" : "allowed"
            },
            "content_policy" : {
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "url" : [
                  "https://rep.bntu.by/bitstream/handle/data/57773/Repository%20of%20BNTU%20Policies.pdf?sequence=1&isAllowed=y"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "language" : "en",
                     "value" : "version_type_and_date"
                  },
                  {
                     "language" : "en",
                     "value" : "peer_review_status",
                     "phrase" : "peer-review status"
                  },
                  {
                     "phrase" : "publication status",
                     "language" : "en",
                     "value" : "publication_status"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Russian",
                     "language" : "en",
                     "value" : "ru"
                  }
               ],
               "languages" : [
                  "en",
                  "ru"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2402",
            "publicly_visible" : "yes",
            "id" : 2402,
            "date_created" : "2012-01-26 10:10:51",
            "date_modified" : "2019-10-17 14:34:37"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Belarusian National Technical University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "by",
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "value" : "by",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "name" : "Scientific Library of the Belarusian National Technical University"
               }
            ],
            "url" : "http://www.bntu.by/",
            "location" : {
               "longitude" : 27.5907,
               "latitude" : 53.9221
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "ru",
                  "language" : "en",
                  "phrase" : "Russian"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages" : [
               "en",
               "ru"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repository of Belarusian National Technical University (BNTU)"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 51926,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "description" : "This site provides access to the research output of the institution. The interface is in Russian. Users may set up RSS feeds to be alerted to new content.",
            "full_text_record_count" : 16734,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://rep.bntu.by/oai/request",
            "url" : "http://rep.bntu.by",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 35,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CamPuce",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "disciplinary",
            "repository_status_phrases" : [
               {
                  "phrase" : "Trial",
                  "value" : "trial",
                  "language" : "en"
               }
            ],
            "url" : "http://eprints.campuce.org/",
            "oai_url" : "http://eprints.campuce.org/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.2.9"
            },
            "description" : "This site provides access to the research output of academics based in African Countries. Users may set up Atom and RSS feeds to be alerted to new content. The interface is available in English, French and German.",
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "fr",
               "en"
            ],
            "repository_status" : "trial",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2401,
            "date_created" : "2012-01-24 14:14:11",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2401"
         },
         "organisation" : {
            "country" : "cm",
            "country_phrases" : [
               {
                  "value" : "cm",
                  "language" : "en",
                  "phrase" : "Cameroon"
               }
            ],
            "url" : "http://eprints.campuce.org/",
            "location" : {
               "latitude" : 3.89241,
               "longitude" : 11.524
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "CamPuce",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://eprints.campuce.org/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "third_party_collaborations" : [
                  "record_preservation_metadata",
                  "offsite_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "value" : "migrate_file_formats",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "language" : "en",
                     "value" : "software_emulation"
                  }
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Record preservation metadata",
                     "language" : "en",
                     "value" : "record_preservation_metadata"
                  },
                  {
                     "phrase" : "Backup items in external archives",
                     "language" : "en",
                     "value" : "offsite_backups"
                  }
               ],
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "language" : "en",
                        "value" : "publisher_rules"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "item_page" : [
                        "tombstone"
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "value" : "no",
                           "language" : "en"
                        }
                     ]
                  }
               },
               "retention_period" : {
                  "years" : 10,
                  "period_phrases" : [
                     {
                        "value" : "for_years",
                        "language" : "en",
                        "phrase" : "Items will be retained for a specified number of years"
                     }
                  ],
                  "period" : "for_years"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "language" : "en",
                        "value" : "changes_not_permitted"
                     },
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "value" : "errata_may_be_included",
                        "language" : "en"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  },
                  {
                     "value" : "original_bitstream_retained",
                     "language" : "en",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "value" : "some_items_have_different_conditions",
                     "language" : "en",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "language" : "en",
                     "value" : "displayed_or_performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "language" : "en",
                     "value" : "given_to_third_parties"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "url" : [
                  "http://eprints.campuce.org/policies.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "url" : [
                  "http://eprints.campuce.org/policies.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required",
                  "full_texts_required"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  },
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "phrase" : "Eligible depositors must deposit full texts of all their publications",
                     "language" : "en",
                     "value" : "full_texts_required"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "value" : "valid_formatting",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "moderation" : "yes"
            },
            "metadata_policy" : {
               "url" : [
                  "http://eprints.campuce.org/policies.html"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "requires_permission",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  },
                  {
                     "language" : "en",
                     "value" : "fr",
                     "phrase" : "French"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "value" : "working_drafts",
                     "language" : "en",
                     "phrase" : "working drafts"
                  },
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en",
                  "fr"
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "metadata_phrases" : [
                  {
                     "value" : "version_type_and_date",
                     "language" : "en",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "language" : "en",
                     "value" : "peer_review_status"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://eprints.campuce.org/policies.html"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Japanese.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://ir.acc.senshu-u.ac.jp/oai",
            "url" : "http://ir.acc.senshu-u.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "SI-Box",
                  "name" : "Senshu University Institutional Reposigory (専修大学機関リポジトリ )",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 8928,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2400",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 2400,
            "date_created" : "2012-01-24 13:13:01",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 139.555,
               "latitude" : 35.6082
            },
            "url" : "http://www.senshu-u.ac.jp/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Senshu University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "RMIT Research Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 55516,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "software" : {
               "name" : "fez",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "fez",
                     "phrase" : "Fez"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "full_text_record_count" : 5817,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://researchbank.rmit.edu.au/",
            "oai_url" : "http://researchbank.rmit.edu.au/oai.php",
            "content_subjects" : [
               "1"
            ]
         },
         "policies" : {
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_requirements" : [
                  "full_citation_required"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en"
                  },
                  {
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ]
            },
            "submission_policy" : {
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "policy_undefined",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo" : "policy_undefined",
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "moderation_purposes" : [
                  "item_relevance",
                  "valid_formatting"
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "item_relevance",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               }
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "RMIT University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.rmit.edu.au/",
            "location" : {
               "latitude" : -37.8085,
               "longitude" : 144.964
            },
            "country_phrases" : [
               {
                  "value" : "au",
                  "language" : "en",
                  "phrase" : "Australia"
               }
            ],
            "country" : "au"
         },
         "system_metadata" : {
            "date_created" : "2012-01-24 13:13:00",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2399,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2399",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://archive.cmb.ac.lk/research/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "version" : "1.6.1",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. Many items are only provided as an Abstract.",
            "metadata_record_count" : 4214,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "UOC e-Repository"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of Colombo",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "lk",
            "url" : "http://www.cmb.ac.lk/",
            "location" : {
               "longitude" : 79.8591,
               "latitude" : 6.9018
            },
            "country_phrases" : [
               {
                  "phrase" : "Sri Lanka",
                  "value" : "lk",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2012-01-24 12:12:46",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2398,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2398",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Biblioteca Virtual Silverio Lanza",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "governmental",
            "metadata_record_count" : 11,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Digibib",
                     "language" : "en",
                     "value" : "digibib"
                  }
               ],
               "name" : "digibib"
            },
            "description" : "This site provides access to the digital collections of the municipality of Getafe. Users may set up an RSS feed to be alerted to new content. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bibliotecadigital.getafe.es/bvgetafe/i18n/estaticos/contenido.cmd?pagina=estaticos/presentacion",
            "oai_url" : "http://bibliotecadigital.getafe.es/bvgetafe/i18n/oai/oai_bibliotecadigital.getafe.es.cmd"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Ayuntamiento de Getafe"
               }
            ],
            "country" : "es",
            "url" : "http://www.getafe.es/",
            "location" : {
               "longitude" : -3.7321,
               "latitude" : 40.3063
            },
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2397",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2012-01-24 12:12:23",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2397,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://scholarworks.wmich.edu/do/oai/",
            "url" : "http://scholarworks.wmich.edu/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Users may set up RSS feeds to be alerted to new content.",
            "metadata_record_count" : 11903,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "ScholarWorks at WMU",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2012-01-24 12:12:07",
            "id" : 2396,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2396"
         },
         "organisation" : {
            "unit" : [
               {
                  "name" : "Western Michigan University Libraries",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.wmich.edu/",
            "location" : {
               "latitude" : 42.2609,
               "longitude" : -85.6126
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "Western Michigan University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Russian Federation",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "url" : "http://physcon.ru/",
            "location" : {
               "latitude" : 60.068,
               "longitude" : 30.1685
            },
            "country" : "ru",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "IPACS",
                  "name" : "International Physics And Control Society",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2394",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2012-01-20 16:16:25",
            "id" : 2394
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the archives of conferences organised by the society. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "value" : "9",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "4",
               "5",
               "9"
            ],
            "url" : "http://lib.physcon.ru/",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "IPACS Electronic library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "MAnnheim DOCument Server",
                  "acronym" : "MADOC"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 37805,
            "description" : "This is a university repository providing access to the publication output of the institution.It is well supported with background information and documentation. The interface is available in German and English. Some items are not available as full-text.",
            "software" : {
               "version" : "3.3.16",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "url" : "https://madoc.bib.uni-mannheim.de/",
            "oai_url" : "https://madoc.bib.uni-mannheim.de/cgi/oai2",
            "content_subjects" : [
               "8",
               "23",
               "24",
               "26",
               "27"
            ],
            "full_text_record_count" : 5111,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "value" : "27",
                  "language" : "en",
                  "phrase" : "Library and Information Science"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ]
         },
         "organisation" : {
            "country" : "de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Universitätsbibliothek Mannheim",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.uni-mannheim.de/",
            "location" : {
               "latitude" : 49.4831,
               "longitude" : 8.46362
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universität Mannheim",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2393",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2012-01-19 12:12:56",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2393,
            "publicly_visible" : "yes"
         },
         "policies" : {
            "content_policy" : {
               "metadata" : [
                  "version_type_and_date"
               ],
               "url" : [
                  "https://ub-madoc.bib.uni-mannheim.de/policies.html"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "value" : "version_type_and_date",
                     "language" : "en"
                  }
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  },
                  {
                     "value" : "de",
                     "language" : "en",
                     "phrase" : "German"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en",
                  "de"
               ]
            },
            "metadata_policy" : {
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "https://ub-madoc.bib.uni-mannheim.de/policies.html"
               ],
               "commercial_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://ub-madoc.bib.uni-mannheim.de/policies.html",
                  "https://ub-madoc.bib.uni-mannheim.de/terms.html."
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "language" : "en",
                     "value" : "some_items_have_different_conditions",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "url" : [
                  "https://ub-madoc.bib.uni-mannheim.de/policies.html"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "third_party_collaborations" : [
                  "offsite_backups"
               ],
               "version_control" : {
                  "earlier_versions" : [
                     "link_between_versions"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     },
                     {
                        "phrase" : "Items are allocated a checksum to facilitate the detection of alterations",
                        "value" : "items_include_checksums",
                        "language" : "en"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "language" : "en",
                        "value" : "link_between_versions"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed",
                     "items_include_checksums"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  }
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Backup items in external archives",
                     "value" : "offsite_backups",
                     "language" : "en"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "withdrawn_items" : {
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ]
                  }
               }
            },
            "submission_policy" : {
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en"
                  }
               ],
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "moderation_purposes" : [
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "url" : [
                  "https://ub-madoc.bib.uni-mannheim.de/policies.html"
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ]
            }
         }
      },
      {
         "system_metadata" : {
            "id" : 2392,
            "date_created" : "2012-01-19 12:12:32",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2392",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Univerza v Ljubljani",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "si",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Faculty of Education",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "http://www.uni-lj.si/",
            "location" : {
               "longitude" : 14.5039,
               "latitude" : 46.05
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "si",
                  "phrase" : "Slovenia"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "metadata_phrases" : [
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://pefprints.pef.uni-lj.si/policies.html"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Multidisciplinary",
                     "language" : "en",
                     "value" : "1"
                  },
                  {
                     "phrase" : "Science General",
                     "value" : "2",
                     "language" : "en"
                  },
                  {
                     "value" : "17",
                     "language" : "en",
                     "phrase" : "Arts and Humanities General"
                  },
                  {
                     "phrase" : "Education",
                     "language" : "en",
                     "value" : "25"
                  }
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "sl",
                  "en"
               ],
               "subjects" : [
                  "1",
                  "2",
                  "17",
                  "25"
               ],
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "value" : "sl",
                     "language" : "en",
                     "phrase" : "Slovene"
                  },
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "url" : [
                  "http://pefprints.pef.uni-lj.si/policies.html"
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "value" : "requires_permission",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission"
            },
            "preservation_policy" : {
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "language" : "en",
                        "value" : "publisher_rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "value" : "tombstone",
                           "language" : "en",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ]
                  }
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://pefprints.pef.uni-lj.si/policies.html"
               ]
            },
            "data_policy" : {
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  }
               ],
               "url" : [
                  "http://pefprints.pef.uni-lj.si/policies.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  },
                  {
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "submission_policy" : {
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "employees"
               ],
               "url" : [
                  "http://pefprints.pef.uni-lj.si/policies.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "value" : "author_eligibility",
                     "language" : "en"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "quality_control" : "checked_by_subject_specialists",
               "quality_control_phrases" : [
                  {
                     "value" : "checked_by_subject_specialists",
                     "language" : "en",
                     "phrase" : " is checked by internal subject specialists. "
                  }
               ],
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "value" : "18",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "PeFprints",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5460,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Slovene and English. Users may set up Atom and RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 13,
            "content_subjects" : [
               "18",
               "23",
               "25"
            ],
            "oai_url" : "http://pefprints.pef.uni-lj.si/cgi/oai2",
            "url" : "http://pefprints.pef.uni-lj.si/"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "3",
               "14",
               "16"
            ],
            "url" : "http://dspace.nuft.edu.ua/jspui/",
            "oai_url" : "http://dspace.nuft.edu.ua/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "This site provides access to the research output of the institution. The interface is available in Ukrainian, Russian and English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "1.7.1",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               }
            ],
            "metadata_record_count" : 26612,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Electronic National University of Food Technologies Institutional Repository",
                  "acronym" : "eNUFTIR",
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "uk"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "16",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "National University of Food Technologies",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.nuft.edu.ua/",
            "location" : {
               "longitude" : 30.5125,
               "latitude" : 50.4449
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2391",
            "publicly_visible" : "yes",
            "id" : 2391,
            "date_created" : "2012-01-19 12:12:19",
            "date_modified" : "2019-10-17 14:34:37"
         }
      },
      {
         "organisation" : {
            "country" : "hu",
            "location" : {
               "longitude" : 19.0494,
               "latitude" : 47.5005
            },
            "url" : "http://www.ceu.hu/",
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "language" : "en",
                  "value" : "hu"
               }
            ],
            "name" : [
               {
                  "name" : "Central European University",
                  "acronym" : "CEU",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2390",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2012-01-17 11:11:45",
            "id" : 2390,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "ETDs",
                  "name" : "Electronic Theses and Dissertations"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 32000,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the students of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "value" : "22",
                  "language" : "en",
                  "phrase" : "Philosophy and Religion"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "http://www.library.ceu.hu/ETD.html",
            "content_subjects" : [
               "20",
               "7",
               "22",
               "8",
               "23",
               "24",
               "26"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "cy",
                  "language" : "en",
                  "phrase" : "Cyprus"
               }
            ],
            "location" : {
               "latitude" : 35.1264,
               "longitude" : 33.4299
            },
            "url" : "http://www.ucy.ac.cy/",
            "country" : "cy",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "University of Cyprus",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2012-01-16 16:16:53",
            "id" : 2389,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2389"
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "notes" : "Special items include Maps and Translations.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Architecture",
                  "value" : "12",
                  "language" : "en"
               },
               {
                  "phrase" : "Library and Information Science",
                  "value" : "27",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "el"
            ],
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Greek (modern)",
                  "language" : "en",
                  "value" : "el"
               }
            ],
            "description" : "This site provides access to the digital collections of the institution. The interface is available in Greek, French and English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "url" : "http://lekythos.library.ucy.ac.cy/",
            "content_subjects" : [
               "20",
               "21",
               "26",
               "12",
               "27"
            ],
            "oai_url" : "http://lekythos.library.ucy.ac.cy/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 2529,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "LEKYTHOS",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 10520
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Gujarati",
                  "language" : "en",
                  "value" : "gu"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en",
               "gu"
            ],
            "name" : [
               {
                  "name" : "Etheses - A Saurashtra University Library Service",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1064,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "version" : "3.3.6",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Users may set up RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://etheses.saurashtrauniversity.edu/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://etheses.saurashtrauniversity.edu/"
         },
         "system_metadata" : {
            "date_created" : "2012-01-16 15:15:37",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2387,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2387",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "in",
            "location" : {
               "latitude" : 22.3004,
               "longitude" : 70.7429
            },
            "url" : "http://www.saurashtrauniversity.edu/",
            "country_phrases" : [
               {
                  "phrase" : "India",
                  "language" : "en",
                  "value" : "in"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Saurashtra University"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "value" : "errata_may_be_included",
                        "language" : "en",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ]
               },
               "withdrawal" : {
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "value" : "indefinite",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "value" : "no",
                           "language" : "en"
                        }
                     ],
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "no"
                  },
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_at_request",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "value" : "record_preservation_metadata",
                     "language" : "en",
                     "phrase" : "Record preservation metadata"
                  },
                  {
                     "language" : "en",
                     "value" : "offsite_backups",
                     "phrase" : "Backup items in external archives"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "language" : "en",
                     "value" : "software_emulation",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "third_party_collaborations" : [
                  "record_preservation_metadata",
                  "offsite_backups"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://etheses.saurashtrauniversity.edu/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy" : "transfer_to_appropriate_archive"
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "language" : "en",
                     "value" : "some_items_have_different_conditions",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en",
                     "phrase" : "This repository is not the publisher; it is merely the online archive"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed_for_indexing",
                  "allowed_for_citation_analysis"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed transiently for full-text indexing",
                     "language" : "en",
                     "value" : "allowed_for_indexing"
                  },
                  {
                     "language" : "en",
                     "value" : "allowed_for_citation_analysis",
                     "phrase" : "Allowed transiently for citation analysis"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://etheses.saurashtrauniversity.edu/policies.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "phrase" : "the original copyright statement is given",
                     "language" : "en",
                     "value" : "original_copyright_statement_required"
                  },
                  {
                     "language" : "en",
                     "value" : "original_rights_statement_required",
                     "phrase" : "the original rights permission statement is given"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access"
            },
            "submission_policy" : {
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "url" : [
                  "http://etheses.saurashtrauniversity.edu/policies.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  },
                  {
                     "phrase" : "Employees",
                     "language" : "en",
                     "value" : "employees"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  },
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "url" : [
                  "http://etheses.saurashtrauniversity.edu/policies.html"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://etheses.saurashtrauniversity.edu/policies.html"
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "version_type_and_date",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "phrase" : "publication status",
                     "language" : "en",
                     "value" : "publication_status"
                  }
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "multi_institution_subject",
                     "phrase" : "Multi-institution subject-based repository"
                  }
               ],
               "languages" : [
                  "en",
                  "hi",
                  "gu",
                  "sa"
               ],
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  },
                  {
                     "value" : "hi",
                     "language" : "en",
                     "phrase" : "Hindi"
                  },
                  {
                     "value" : "gu",
                     "language" : "en",
                     "phrase" : "Gujarati"
                  },
                  {
                     "phrase" : "Sanskrit (Saṁskṛta)",
                     "value" : "sa",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "standard_types_allowed_phrases" : [
                     {
                        "language" : "en",
                        "value" : "theses_and_dissertations",
                        "phrase" : "Theses and Dissertations"
                     }
                  ],
                  "all" : "false",
                  "standard_types_allowed" : [
                     "theses_and_dissertations"
                  ]
               },
               "versions" : [
                  "submitted_versions",
                  "published_versions"
               ],
               "repository_type" : "multi_institution_subject",
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ]
            }
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 54.3306,
               "longitude" : 10.1475
            },
            "url" : "http://www.geomar.de/",
            "country" : "de",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "GEOMAR",
                  "name" : "Helmholtz-Zentrum für Ozeanforschung Kiel"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2012-01-16 11:11:05",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2386,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2386",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "url" : [
                  "http://oceanrep.geomar.de/policies.html"
               ],
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "language" : "en",
                     "value" : "requires_permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://oceanrep.geomar.de/policies.html"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "yes"
                  },
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "language" : "en",
                        "value" : "falsified_research"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "url" : [
                  "http://oceanrep.geomar.de/policies.html"
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ],
               "url" : [
                  "http://oceanrep.geomar.de/policies.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ]
            },
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "spam_exclusion",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry",
                     "phrase" : "Items may not be deposited until any embargo period has expired"
                  }
               ],
               "url" : [
                  "http://oceanrep.geomar.de/policies.html"
               ],
               "moderation_purposes" : [
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry"
            }
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 33886,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "OceanRep",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://oceanrep.geomar.de/",
            "content_subjects" : [
               "4",
               "5",
               "6",
               "7",
               "9"
            ],
            "oai_url" : "http://oceanrep.geomar.de/cgi/oai2",
            "full_text_record_count" : 10948,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Some items are not available as full-text.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.1.3"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "patents",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               },
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "value" : "9",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "type" : "governmental",
            "name" : [
               {
                  "name" : "NASA Technical Reports Server",
                  "acronym" : "NTRS",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 82162,
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "software" : {
               "name_phrases" : []
            },
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://ntrs.nasa.gov/oai",
            "url" : "http://ntrs.nasa.gov/search.jsp",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 66368,
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "NASA Scientific and Technical Information Program",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.nasa.gov/",
            "location" : {
               "longitude" : -77.0211,
               "latitude" : 38.887
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Aeronautics and Space Administration",
                  "acronym" : "NASA"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2385",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2012-01-16 09:09:35",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2385,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 48552,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Sussex Research Online",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 11274,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://sro.sussex.ac.uk/",
            "oai_url" : "http://sro.sussex.ac.uk/cgi/oai2",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.4.0",
               "name" : "eprints"
            },
            "description" : "This site is the institutional repository for the University of Sussex and makes available a portion of the University's research output. Some items are bibliographic records only, and are not available as full text on this site. The site is well supported with background information on the development of the repository. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "patents"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2384",
            "publicly_visible" : "yes",
            "id" : 2384,
            "date_created" : "2012-01-13 13:13:40",
            "date_modified" : "2019-10-17 14:34:37"
         },
         "organisation" : {
            "url" : "http://www.sussex.ac.uk/",
            "location" : {
               "longitude" : -0.0881,
               "latitude" : 50.8677
            },
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "University of Sussex",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://www.sussex.ac.uk/library/research/sro/policies"
               ],
               "depositors" : [
                  "community_members"
               ],
               "moderation_purposes" : [
                  "author_eligibility"
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "content_embargo" : "restricted_until_embargo_expiry"
            },
            "data_policy" : {
               "reuse" : "individually_tagged",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "value" : "individually_tagged",
                     "language" : "en",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "url" : [
                  "https://www.sussex.ac.uk/webteam/gateway/file.php?name=sussex-research-online-policy-march-2014.pdf&amp;site=269"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "https://www.sussex.ac.uk/webteam/gateway/file.php?name=sussex-research-online---takedown-policy.pdf&amp;site=269"
               ],
               "closure_policy" : "undefined",
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "removal_not_normal",
                        "language" : "en",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "deleted",
                  "policy" : "removal_not_normal",
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "url_retention" : "trainsient",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Transiently",
                           "language" : "en",
                           "value" : "trainsient"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism"
                  ]
               }
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "http://www.sussex.ac.uk/library/research/sro/policies"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "url" : [
                  "http://www.sussex.ac.uk/library/research/sro/policies"
               ]
            }
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : 36.8402,
               "longitude" : -2.4679
            },
            "url" : "http://www.ual.es/",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universidad de Almería",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2382",
            "publicly_visible" : "yes",
            "id" : 2382,
            "date_created" : "2012-01-12 12:12:19",
            "date_modified" : "2019-10-17 14:34:37"
         },
         "repository_metadata" : {
            "metadata_record_count" : 4538,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "riUAL",
                  "name" : "Repositorio Institucional de la Universidad de Almería (Spain)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://repositorio.ual.es/oai/request",
            "url" : "http://repositorio.ual.es/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "6.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the Institution. Interface available in Spanish and English. Users may set up RSS feeds to be alerted to new content.",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ]
         }
      },
      {
         "policies" : {
            "metadata_policy" : {
               "url" : [
                  "http://huveta.hu/documents/metadata_policy.txt"
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "value" : "requires_permission",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "value" : "repository_mention_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "metadata" : [
                  "version_type_and_date"
               ],
               "url" : [
                  "http://huveta.hu/documents/metadata_policy.txt"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "language" : "en",
                     "value" : "version_type_and_date"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "Hungarian",
                     "language" : "en",
                     "value" : "hu"
                  },
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  },
                  {
                     "phrase" : "German",
                     "language" : "en",
                     "value" : "de"
                  }
               ],
               "versions_phrases" : [
                  {
                     "value" : "working_drafts",
                     "language" : "en",
                     "phrase" : "working drafts"
                  },
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "multi_institution_subject",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "language" : "en",
                     "value" : "multi_institution_subject"
                  }
               ],
               "languages" : [
                  "hu",
                  "en",
                  "de"
               ]
            },
            "submission_policy" : {
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "value" : "bibliographic_metadata_required",
                     "language" : "en"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "language" : "en",
                     "value" : "spam_exclusion",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry",
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required"
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "no_deposit_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items may not be deposited until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "url" : [
                  "http://huveta.hu/documents/metadata_policy.txt"
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Not Allowed",
                     "language" : "en",
                     "value" : "not_allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "value" : "link_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "language" : "en",
                     "value" : "content_not_changed"
                  }
               ],
               "url" : [
                  "http://huveta.hu/documents/metadata_policy.txt"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "value" : "some_items_have_different_conditions",
                     "language" : "en",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  },
                  {
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ],
               "harvesting" : [
                  "not_allowed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed",
                  "stored_in_a_database"
               ],
               "access_phrases" : [
                  {
                     "value" : "some_or_all_restricted",
                     "language" : "en",
                     "phrase" : "Access to some or all full items is restricted"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  },
                  {
                     "phrase" : "stored in a database",
                     "language" : "en",
                     "value" : "stored_in_a_database"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "method" : "deleted",
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are deleted entirely from the database",
                        "language" : "en",
                        "value" : "deleted"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "publisher_rules",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "language" : "en",
                           "value" : "no"
                        }
                     ],
                     "searchable" : "no"
                  }
               },
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "value" : "software_emulation",
                     "language" : "en"
                  }
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Record preservation metadata",
                     "language" : "en",
                     "value" : "record_preservation_metadata"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "No retention period defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "period" : "undefined"
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "link_between_versions"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "earlier_versions_may_be_withdrawn",
                        "language" : "en",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     },
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "value" : "link_between_versions",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "third_party_collaborations" : [
                  "record_preservation_metadata"
               ],
               "url" : [
                  "http://huveta.hu/documents/metadata_policy.txt"
               ],
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No closure policy defined"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2381,
            "date_created" : "2012-01-05 11:11:49",
            "date_modified" : "2019-12-10 15:42:59",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2381"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "language" : "en",
                  "value" : "hu"
               }
            ],
            "location" : {
               "latitude" : 47.5032,
               "longitude" : -19.0757
            },
            "url" : "http://www.univet.hu/",
            "country" : "hu",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Veterinary Medicine Budapest"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "HuVetA",
                  "name" : "HuVetA Hungarian Veterinary Archive"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 100,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution, including these, PHD dissertations, articles and historical documents. Some content is only accessible through the intranet of Szent Istvan University, Faculty of Veterinary Science. The interface is available in English.",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://huveta.hu/oai/request",
            "content_subjects" : [
               "3"
            ],
            "url" : "http://huveta.hu",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Hungarian",
                  "value" : "hu",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "content_languages" : [
               "en",
               "hu"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name" : "other"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://diginole.lib.fsu.edu/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "DigiNole Commons: Virtual Repository for Electronic Scholarship",
                  "acronym" : "ViRES",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 64818
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2380",
            "publicly_visible" : "yes",
            "date_created" : "2012-01-04 16:16:11",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2380
         },
         "organisation" : {
            "location" : {
               "latitude" : 30.4421,
               "longitude" : -84.3034
            },
            "url" : "http://www.fsu.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Florida State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in English and Indonesian. Users may set up Atom and RSS feeds to be alerted to new content.",
            "software" : {
               "version" : "3.2.4",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.upnjatim.ac.id/",
            "oai_url" : "http://eprints.upnjatim.ac.id/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "UPN Jatim Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 6639,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "UPN Jatim University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "id",
            "url" : "http://www.upnjatim.ac.id/",
            "location" : {
               "latitude" : -7.3339,
               "longitude" : 112.79
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2379,
            "date_created" : "2012-01-04 15:15:07",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2379",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "value" : "submitted_versions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "types_included" : {
                  "standard_types_allowed" : [
                     "journal_articles",
                     "unpub_reports_and_working_papers",
                     "books_chapters_and_sections"
                  ],
                  "standard_types_allowed_phrases" : [
                     {
                        "language" : "en",
                        "value" : "journal_articles",
                        "phrase" : "Journal Articles"
                     },
                     {
                        "value" : "unpub_reports_and_working_papers",
                        "language" : "en",
                        "phrase" : "Unpublished Reports and Working Papers"
                     },
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "value" : "books_chapters_and_sections",
                        "language" : "en"
                     }
                  ],
                  "all" : "false"
               },
               "url" : [
                  "http://rep.adw-goe.de/guides"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  },
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No withdrawal policy defined"
                     }
                  ],
                  "method" : "undefined",
                  "policy" : "undefined"
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained for a specified number of years",
                        "value" : "for_years",
                        "language" : "en"
                     }
                  ],
                  "years" : 5,
                  "period" : "for_years"
               },
               "version_control" : {
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ]
               },
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "url" : [
                  "http://rep.adw-goe.de/guides"
               ],
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ]
            }
         },
         "organisation" : {
            "url" : "http://adw-goe.de/",
            "location" : {
               "latitude" : 51.5349,
               "longitude" : 9.9372
            },
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "country" : "de",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Akademie der Wissenschaften zu Göttingen",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2378",
            "publicly_visible" : "yes",
            "id" : 2378,
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-12-14 16:16:30"
         },
         "repository_metadata" : {
            "content_languages" : [
               "de"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "notes" : "This repository stands in the tradition of the journal \"Göttingische Zeitungen von Gelehrten Sachen\" (Göttingen News of Scholarly Matters) published since 1739.",
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "oai_url" : "http://rep.adw-goe.de/oai/request",
            "url" : "http://adw-goe.de/startseite/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 2,
            "description" : "This site provides access to the digitised collections of the institution. The interface is available in German or English.",
            "software" : {
               "version" : "1.7.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 1612,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Dokumentenserver der Akademie der Wissenschaften zu Göttingen",
                  "acronym" : "res doctae",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 2377,
            "date_created" : "2011-12-14 15:15:58",
            "date_modified" : "2019-12-04 12:27:28",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2377",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "London School of Hygiene and Tropical Medicine",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "value" : "gb",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -0.128,
               "latitude" : 51.5081
            },
            "url" : "http://www.lshtm.ac.uk/",
            "country" : "gb"
         },
         "policies" : {
            "content_policy" : {
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "value" : "journal_articles",
                        "language" : "en",
                        "phrase" : "Journal Articles"
                     },
                     {
                        "phrase" : "Bibliographic References",
                        "language" : "en",
                        "value" : "bibliographic_references"
                     },
                     {
                        "phrase" : "Conference and Workshop Papers",
                        "language" : "en",
                        "value" : "conference_and_workshop_papers"
                     },
                     {
                        "value" : "theses_and_dissertations",
                        "language" : "en",
                        "phrase" : "Theses and Dissertations"
                     },
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "language" : "en",
                        "value" : "books_chapters_and_sections"
                     },
                     {
                        "phrase" : "Datasets",
                        "value" : "datasets",
                        "language" : "en"
                     },
                     {
                        "value" : "learning_objects",
                        "language" : "en",
                        "phrase" : "Learning Objects"
                     },
                     {
                        "phrase" : "Software",
                        "value" : "software",
                        "language" : "en"
                     },
                     {
                        "value" : "patents",
                        "language" : "en",
                        "phrase" : "Patents"
                     },
                     {
                        "phrase" : "Other Special Item Types",
                        "language" : "en",
                        "value" : "other_special_item_types"
                     }
                  ],
                  "standard_types_allowed" : [
                     "journal_articles",
                     "bibliographic_references",
                     "conference_and_workshop_papers",
                     "theses_and_dissertations",
                     "books_chapters_and_sections",
                     "datasets",
                     "learning_objects",
                     "software",
                     "patents",
                     "other_special_item_types"
                  ]
               },
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "subjects" : [
                  "23",
                  "10"
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "url" : [
                  "http://researchonline.lshtm.ac.uk/policies.html"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "language" : "en",
                     "value" : "version_type_and_date"
                  },
                  {
                     "value" : "peer_review_status",
                     "language" : "en",
                     "phrase" : "peer-review status"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "subjects_phrases" : [
                  {
                     "value" : "23",
                     "language" : "en",
                     "phrase" : "Social Sciences General"
                  },
                  {
                     "value" : "10",
                     "language" : "en",
                     "phrase" : "Health and Medicine"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://researchonline.lshtm.ac.uk/policies.html"
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed"
            },
            "data_policy" : {
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "url" : [
                  "http://researchonline.lshtm.ac.uk/policies.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study"
               ],
               "reuse_conditions" : [
                  "some_items_have_different_conditions"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest",
                     "link_between_versions"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     },
                     {
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest",
                        "phrase" : "The items persistent URL will always link to the latest version"
                     },
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "language" : "en",
                        "value" : "link_between_versions"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  },
                  {
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed",
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats"
                  }
               ],
               "withdrawal" : {
                  "special_reasons" : [
                     "if original submission is superseded by a fuller item e.g. conference paper superseded by journal article, at researcher's request"
                  ],
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     },
                     {
                        "value" : "other",
                        "language" : "en",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "withdrawn_items" : {
                     "item_page" : [
                        "tombstone",
                        "link_to_replacement",
                        "explanation_of_withdrawal"
                     ],
                     "searchable" : "yes",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "language" : "en",
                           "value" : "tombstone",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        },
                        {
                           "language" : "en",
                           "value" : "link_to_replacement",
                           "phrase" : "URLs will contain a link to a replacement version, where available"
                        },
                        {
                           "phrase" : "URLs will contain a note explaining the reasons for withdrawal",
                           "value" : "explanation_of_withdrawal",
                           "language" : "en"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite"
                  },
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research",
                     "other"
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed"
               ],
               "url" : [
                  "http://researchonline.lshtm.ac.uk/policies.html"
               ]
            },
            "submission_policy" : {
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "url" : [
                  "http://researchonline.lshtm.ac.uk/policies.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the repository. The interface is available in English. Some items are not available as full-text. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.16"
            },
            "oai_url" : "http://researchonline.lshtm.ac.uk/cgi/oai2",
            "content_subjects" : [
               "20",
               "10",
               "7",
               "8",
               "23"
            ],
            "url" : "http://researchonline.lshtm.ac.uk/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 25084,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "LSHTM Research Online"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 45734,
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "History and Archaeology",
                  "language" : "en",
                  "value" : "20"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "value" : "8",
                  "language" : "en"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "oai_url" : "http://openarchive.univpm.it/oai/request",
            "url" : "http://www.openarchive.univpm.it/jspui/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "This site provides access to the PhD thesis output of the institution. Some items are not available as full-text. Full-texts are available according to the consent given by each author. Users may set up RSS feeds to be alerted to new content. The interface is available in Italian.",
            "software" : {
               "name" : "dspace",
               "version" : "1.7.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 1390,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "ACUBO (Archivio Aperto di Ateneo)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "it",
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "date_created" : "2011-12-14 15:15:45",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2376,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2376",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "it",
            "url" : "http://www.univpm.it/",
            "location" : {
               "latitude" : 43.6158,
               "longitude" : 13.5187
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italy"
               }
            ],
            "name" : [
               {
                  "name" : "Università Politecnica delle Marche",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2011-12-13 11:11:58",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2375,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2375",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "url" : "http://www.uni-koeln.de/",
            "location" : {
               "longitude" : 6.95991,
               "latitude" : 50.9407
            },
            "unit" : [
               {
                  "name" : "Computer Science Department",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "de",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universität zu Köln",
                  "acronym" : "USB Köln",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "subjects_phrases" : [
                  {
                     "phrase" : "Mathematics and Statistics",
                     "value" : "8",
                     "language" : "en"
                  },
                  {
                     "value" : "14",
                     "language" : "en",
                     "phrase" : "Computers and IT"
                  }
               ],
               "url" : [
                  "http://e-archive.informatik.uni-koeln.de/policies.html"
               ],
               "metadata_phrases" : [
                  {
                     "value" : "peer_review_status",
                     "language" : "en",
                     "phrase" : "peer-review status"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ],
               "subjects" : [
                  "8",
                  "14"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "metadata_policy" : {
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "language" : "en",
                     "value" : "requires_permission"
                  }
               ],
               "url" : [
                  "http://e-archive.informatik.uni-koeln.de/policies.html"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://e-archive.informatik.uni-koeln.de/policies.html"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://e-archive.informatik.uni-koeln.de/policies.html"
               ],
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ]
                  },
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "removal_not_normal",
                        "language" : "en",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal"
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_purposes" : [
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry",
                     "phrase" : "Items may not be deposited until any embargo period has expired"
                  }
               ],
               "url" : [
                  "http://e-archive.informatik.uni-koeln.de/policies.html"
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor"
            }
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the department. The interface is available in English. Users may set up Atom and RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.7"
            },
            "oai_url" : "http://e-archive.informatik.uni-koeln.de/cgi/oai2",
            "content_subjects" : [
               "8",
               "14"
            ],
            "url" : "http://e-archive.informatik.uni-koeln.de/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 225,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "computer science publication server"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 810
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "UTE REPOSITORIO",
                  "name" : "Repositorio de la Universidad Tecnológica Equinoccial",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "metadata_record_count" : 16965,
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "4.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "18",
                  "phrase" : "Fine and Performing Arts"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "language" : "en",
                  "value" : "12",
                  "phrase" : "Architecture"
               },
               {
                  "value" : "27",
                  "language" : "en",
                  "phrase" : "Library and Information Science"
               },
               {
                  "phrase" : "Management and Planning",
                  "language" : "en",
                  "value" : "28"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up an RSS feed to be alerted to new content.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "3",
               "18",
               "7",
               "23",
               "24",
               "10",
               "25",
               "12",
               "27",
               "28",
               "14"
            ],
            "url" : "http://repositorio.ute.edu.ec/",
            "content_languages" : [
               "es"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2374",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 2374,
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-12-13 11:11:40",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Technologica Equinoccial",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "ec",
            "country_phrases" : [
               {
                  "value" : "ec",
                  "language" : "en",
                  "phrase" : "Ecuador"
               }
            ],
            "url" : "http://www.ute.edu.ec/",
            "location" : {
               "latitude" : -0.182,
               "longitude" : -78.4931
            }
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositório Institucional da UFSC",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 106637,
            "description" : "This site provides access to the research and teaching outputs of the institution. The interface is available in Portuguese.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "4.1",
               "name" : "dspace"
            },
            "oai_url" : "http://repositorio.ufsc.br/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.ufsc.br/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_types" : [
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "Special items include Minutes of Meetings",
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UFSC",
                  "name" : "Universidade Federal de Santa Catarina",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "http://www.ufsc.br/",
            "location" : {
               "longitude" : -48.5198,
               "latitude" : -27.5993
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2373",
            "publicly_visible" : "yes",
            "id" : 2373,
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-12-13 11:11:30"
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the digitised collections of the institution. The interface is available in Spanish. Users may set up an RSS feed to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Digibib",
                     "value" : "digibib",
                     "language" : "en"
                  }
               ],
               "name" : "digibib"
            },
            "url" : "http://bibliotecadigital.educarm.es/bidimur/i18n/estaticos/contenido.cmd?pagina=estaticos/presentacion",
            "content_subjects" : [
               "20",
               "24",
               "25"
            ],
            "oai_url" : "http://bibliotecadigital.educarm.es/bidimur/i18n/oai/oai.cmd",
            "full_text_record_count" : 146,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "governmental",
            "name" : [
               {
                  "name" : "Biblioteca Digital Educativa de la Región de Murcia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 633,
            "content_subjects_phrases" : [
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "notes" : "Includes all educational publications produced by the Ministry of Education, Training and Employment since 2000",
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "url" : "http://www.carm.es/web/pagina?IDCONTENIDO=1&amp;IDTIPO=180",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Consejería de Educación, Formación y Empleo",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 37.9834,
               "longitude" : -1.1299
            },
            "country" : "es",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Comunidad Autónoma de la Región de Murcia",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2372",
            "publicly_visible" : "yes",
            "date_created" : "2011-12-13 11:11:20",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2372
         }
      },
      {
         "organisation" : {
            "country" : "it",
            "url" : "http://www.pz.cnr.it/opencms/opencms/",
            "location" : {
               "longitude" : 15.6993,
               "latitude" : 40.6072
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italy"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "CNR Area di Ricerca di Potenza",
                  "acronym" : "CNR",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-12-07 15:15:13",
            "id" : 2371,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2371"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "ArchEnviMat"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "metadata_record_count" : 412,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the National Research Council Research Institutes (IMAA, IMIP and IBAM). Users may set up RSS feeds to be alerted to new content. Some items are not accessible as full-text, or require a log-in. The interface is available in Italian and English.",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "value" : "5",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               },
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               }
            ],
            "software" : {
               "version" : "1.6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "withdrawn_from_use",
            "content_languages" : [
               "it",
               "en"
            ],
            "url" : "http://www.archenvimat.pz.cnr.it/",
            "content_subjects" : [
               "2",
               "4",
               "5",
               "20",
               "6",
               "9"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Withdrawn from use",
                  "value" : "withdrawn_from_use",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 90563,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Digitale Sammlungen - Goethe-Universität Frankfurt am Main",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "oai_url" : "http://sammlungen.ub.uni-frankfurt.de/oai",
            "url" : "http://sammlungen.ub.uni-frankfurt.de/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site is an institutional repository providing access to digitised historical source material from the University Library Johann Christian Senckenberg. The source materials include medieval manuscripts, incunabula, other books and periodicals. The interface is available in German and English.",
            "software" : {
               "name_phrases" : []
            },
            "content_languages_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "de"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-12-07 14:14:41",
            "id" : 2370,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2370"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Johann Wolfgang Goethe-Universität am Main",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 8.65903,
               "latitude" : 50.1152
            },
            "url" : "http://www.uni-frankfurt.de/",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "country" : "de"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "notes" : "Special items include Maps",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "metadata_record_count" : 66877,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Biblioteca Digital de la Comunidad de Madrid",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "governmental",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://www.bibliotecavirtualmadrid.org/bvmadrid_publicacion/i18n/oai/oai.cmd",
            "url" : "http://www.bibliotecavirtualmadrid.org/bvmadrid_publicacion/i18n/estaticos/contenido.cmd?pagina=estaticos/presentacion",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Digibib",
                     "value" : "digibib",
                     "language" : "en"
                  }
               ],
               "name" : "digibib"
            },
            "description" : "This site provides access to the digitised collections of the Community of Madrid from the 12th to 16th Centuries. The interface is available in Spanish. Users may set up an RSS feed to be alerted to new content."
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2368,
            "date_created" : "2011-12-07 14:14:17",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2368"
         },
         "organisation" : {
            "location" : {
               "latitude" : 40.4003,
               "longitude" : -3.6901
            },
            "url" : "http://www.madrid.org/",
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Comunidad de Madrid"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 6766,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "PUblication MAnagement",
                  "acronym" : "PUMAlab",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "aggregating",
            "full_text_record_count" : 3135,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://pumalab.isti.cnr.it/index.php/it",
            "oai_url" : "http://pumaoai.isti.cnr.it/openoai2.php",
            "software" : {
               "name_other" : "OCTOPUS",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "This site provides access to the research outputs of the CNR Institutions. The interface is available in Italian and English. Some content is not available as full-text, these items are clearly indicated.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "it",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "language" : "en",
                  "value" : "aggregating"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "notes" : "Data checked 19.02.14"
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "CNR-ISTI",
                  "name" : "Institute of Information Science and Technology &quot;A. Faedo&quot;",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "value" : "it",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 43.71,
               "longitude" : 10.42
            },
            "url" : "http://www.isti.cnr.it/",
            "country" : "it"
         },
         "system_metadata" : {
            "date_created" : "2011-12-07 11:11:51",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2367,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2367",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "IHEP-IR",
                  "name" : "Knowledge Repository of Institute Of IHEP,CAS(IHEP OpenIR)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 54037,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Many items are not available as full-text.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://ir.ihep.ac.cn",
            "oai_url" : "http://dr.ihep.ac.cn/casirgrid-oai/request",
            "content_subjects" : [
               "9",
               "28",
               "14"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "language" : "en",
                  "value" : "28",
                  "phrase" : "Management and Planning"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "zh",
               "en"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2366",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-12-07 11:11:06",
            "id" : 2366,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "IHEP, CAS",
                  "name" : "Institute of High Energy Physics, Chinese Academy of Sciences (中国科学院高能物理研究所)(IHEP),China",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 23.0894,
               "longitude" : 101.669
            },
            "url" : "http://www.ihep.cas.cn/",
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "value" : "cn",
                  "language" : "en"
               }
            ],
            "country" : "cn"
         }
      },
      {
         "organisation" : {
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "unit" : [
               {
                  "name" : "Biblioteca María Cristina Niño de Michelsen",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "http://www.poligran.edu.co/",
            "location" : {
               "longitude" : -74.0758,
               "latitude" : 4.5981
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institución Universitaria Politécnico Grancolombiano",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2365,
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-12-07 10:10:03",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2365"
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish, English and German.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               },
               {
                  "value" : "8",
                  "language" : "en",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "repository_status" : "trial",
            "software" : {
               "version" : "1.7.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://repository.poligran.edu.co/",
            "content_subjects" : [
               "1",
               "8",
               "24",
               "11",
               "26"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "trial",
                  "language" : "en",
                  "phrase" : "Trial"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio Comunidad Alejandría"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 761
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "content_subjects" : [
               "2",
               "17",
               "22",
               "24",
               "10",
               "25",
               "11",
               "26",
               "28",
               "14"
            ],
            "url" : "http://digitalrepository.smu.edu/",
            "oai_url" : "http://digitalrepository.smu.edu/do/oai/",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "SMU Digital Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               }
            ],
            "metadata_record_count" : 8669,
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "value" : "22",
                  "language" : "en"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "value" : "28",
                  "language" : "en",
                  "phrase" : "Management and Planning"
               },
               {
                  "language" : "en",
                  "value" : "14",
                  "phrase" : "Computers and IT"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2364",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 2364,
            "date_created" : "2011-11-30 16:16:03",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Southern Methodist University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "http://www.smu.edu/",
            "location" : {
               "longitude" : -96.7858,
               "latitude" : 32.8449
            },
            "country" : "us"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        },
                        {
                           "phrase" : "URLs will contain a note explaining the reasons for withdrawal",
                           "value" : "explanation_of_withdrawal",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "searchable" : "no",
                     "item_page" : [
                        "tombstone",
                        "explanation_of_withdrawal"
                     ]
                  },
                  "standard_reasons" : [
                     "legal_requirement_proven"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     }
                  ]
               },
               "closure_policy_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No retention period defined"
                     }
                  ],
                  "period" : "undefined"
               },
               "url" : [
                  "http://digitalrepository.smu.edu/cgi/viewcontent.cgi?article=1000&amp;context=libraries_cul_admin"
               ],
               "closure_policy" : "undefined"
            },
            "submission_policy" : {
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "not_checked",
                     "phrase" : " is not checked."
                  }
               ],
               "quality_control" : "not_checked",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en"
                  }
               ],
               "moderation" : "no_policy",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_policy",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  }
               ],
               "url" : [
                  "http://digitalrepository.smu.edu/cgi/viewcontent.cgi?article=1000&amp;context=libraries_cul_admin"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "policy_undefined"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://digitalrepository.smu.edu/cgi/viewcontent.cgi?article=1000&amp;context=libraries_cul_admin"
               ],
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "standard_types_excluded" : [
                     "datasets"
                  ],
                  "all" : "false",
                  "standard_types_excluded_phrases" : [
                     {
                        "phrase" : "Datasets",
                        "value" : "datasets",
                        "language" : "en"
                     }
                  ]
               }
            }
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2363,
            "date_created" : "2011-11-30 15:15:20",
            "date_modified" : "2019-12-04 12:27:28",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2363"
         },
         "organisation" : {
            "country" : "ar",
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "url" : "https://www.udesa.edu.ar",
            "unit" : [
               {
                  "name" : "Max von Buch Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Biblioteca Max von Buch"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : -58.5299,
               "latitude" : -34.446
            },
            "name" : [
               {
                  "acronym" : "UdeSA",
                  "name" : "University of San Andrés",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "UdeSA",
                  "name" : "Universidad de San Andrés"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "San Andrés Digital Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositorio Digital San Andrés"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5946,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "4.2"
            },
            "description" : "This site is an institutional repository of the Max von Buch Library at University of San Andrés in Argentina providing open access to the scientific and academic digital research output of that institution.  Users may set up an RSS feed to be alerted to new content. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.udesa.edu.ar",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.udesa.edu.ar/oai/request",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "language" : "en",
                  "value" : "ua"
               }
            ],
            "url" : "http://www.kgmtu.edu.ua/",
            "location" : {
               "longitude" : 36.4094,
               "latitude" : 45.2979
            },
            "country" : "ua",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Керченский государственный морской технологический университет",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2362",
            "publicly_visible" : "yes",
            "id" : 2362,
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-11-30 14:14:57"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "acronym" : "eKSMTU-Repository",
                  "name" : "Electronic Kerch State Maritime Technological University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 1843,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Ukrainian, Russian and English. Users may set up RSS feeds to be alerted to new content.",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "1.8.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://kgmtu.edu.ua/jspui/",
            "content_languages" : [
               "uk"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Biology and Biochemistry",
                  "value" : "4",
                  "language" : "en"
               },
               {
                  "phrase" : "Geography and Regional Studies",
                  "language" : "en",
                  "value" : "19"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Architecture",
                  "language" : "en",
                  "value" : "12"
               },
               {
                  "phrase" : "Civil Engineering",
                  "language" : "en",
                  "value" : "13"
               },
               {
                  "phrase" : "Computers and IT",
                  "language" : "en",
                  "value" : "14"
               },
               {
                  "language" : "en",
                  "value" : "29",
                  "phrase" : "Psychology"
               }
            ],
            "metadata_record_count" : 11193,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório Institucional do UniCEUB"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://repositorio.uniceub.br/oai/request",
            "content_subjects" : [
               "4",
               "19",
               "20",
               "24",
               "10",
               "26",
               "12",
               "13",
               "14",
               "29"
            ],
            "url" : "http://repositorio.uniceub.br/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "1.7.1"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Portugeuse."
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Centro Universitário de Brasília",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "br",
            "url" : "http://www.uniceub.br/vestibular/",
            "location" : {
               "longitude" : -47.8936,
               "latitude" : -15.7668
            },
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2361,
            "date_created" : "2011-11-30 14:14:44",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2361",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  },
                  "method_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No deletion method for withdrawn items defined"
                     }
                  ],
                  "method" : "undefined",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_not_normal"
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No retention period defined"
                     }
                  ],
                  "period" : "undefined"
               },
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest",
                        "phrase" : "The items persistent URL will always link to the latest version"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "persistent_urls_link_to_latest"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://www.biblioteka.lu.lv/index.php?id=43715"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "value" : "no_policy",
                     "language" : "en",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "policy_undefined",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "url" : [
                  "http://www.biblioteka.lu.lv/index.php?id=43715"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "content_embargo" : "policy_undefined",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "not_checked",
                     "phrase" : " is not checked."
                  }
               ],
               "quality_control" : "not_checked",
               "rules_phrases" : [
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "moderation" : "no_policy"
            },
            "content_policy" : {
               "url" : [
                  "http://www.biblioteka.lu.lv/index.php?id=43715"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Latvia",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Latvia",
                  "language" : "en",
                  "value" : "lv"
               }
            ],
            "location" : {
               "latitude" : 56.9471,
               "longitude" : 24.1064
            },
            "url" : "http://www.lu.lv/",
            "country" : "lv"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2360",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2011-11-30 14:14:37",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2360,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages" : [
               "lv"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Latvian",
                  "language" : "en",
                  "value" : "lv"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://dspace.lu.lv/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://dspace.lu.lv/dspace/",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Latvian, Spanish, German and English. Users may set up RSS feeds to be alerted to new content.",
            "metadata_record_count" : 36957,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "E-resource repository of the University of Latvia",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "The Keep",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "metadata_record_count" : 74051,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Biology and Biochemistry",
                  "value" : "4",
                  "language" : "en"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Some content is not available as full-text.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://thekeep.eiu.edu/",
            "content_subjects" : [
               "17",
               "4",
               "24"
            ],
            "content_languages" : [
               "en"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2011-11-30 14:14:32",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2359,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2359"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Eastern Illinois University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "http://www.eiu.edu/",
            "location" : {
               "longitude" : -88.1762,
               "latitude" : 39.4961
            },
            "country" : "us"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "CWI Institutional Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 19746,
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Some items are not available as full-text.\r\n\r\nCentrum Wiskunde & Informatica",
            "software" : {
               "name_phrases" : []
            },
            "content_subjects" : [
               "8",
               "14"
            ],
            "url" : "http://repository.cwi.nl/index.php",
            "oai_url" : "http://oai.cwi.nl/oai",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Mathematics and Statistics",
                  "value" : "8",
                  "language" : "en"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Centrum Wiskunde en Informatica",
                  "acronym" : "CWI",
                  "preferred" : "name",
                  "language" : "nl",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "nl",
                        "phrase" : "Dutch"
                     }
                  ]
               }
            ],
            "country" : "nl",
            "location" : {
               "longitude" : 4.953,
               "latitude" : 52.3564
            },
            "url" : "http://www.cwi.nl",
            "country_phrases" : [
               {
                  "phrase" : "Netherlands",
                  "language" : "en",
                  "value" : "nl"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2358,
            "date_created" : "2011-11-30 14:14:25",
            "date_modified" : "2019-11-21 15:02:06",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2358",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "http://www.unict.it/",
            "location" : {
               "latitude" : 37.5025,
               "longitude" : 15.0878
            },
            "country_phrases" : [
               {
                  "value" : "it",
                  "language" : "en",
                  "phrase" : "Italy"
               }
            ],
            "country" : "it",
            "name" : [
               {
                  "name" : "Università degli studi di Catania",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2011-11-30 13:13:59",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2357,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2357",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "ArchivIA",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Italian",
                  "value" : "it",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3192,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the student output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Italian.",
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               },
               {
                  "phrase" : "Biology and Biochemistry",
                  "language" : "en",
                  "value" : "4"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               },
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               },
               {
                  "phrase" : "Earth and Planetary Sciences",
                  "language" : "en",
                  "value" : "6"
               },
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "value" : "22",
                  "language" : "en",
                  "phrase" : "Philosophy and Religion"
               },
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "language" : "en",
                  "value" : "9"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "language" : "en",
                  "value" : "12",
                  "phrase" : "Architecture"
               },
               {
                  "phrase" : "Library and Information Science",
                  "language" : "en",
                  "value" : "27"
               },
               {
                  "value" : "13",
                  "language" : "en",
                  "phrase" : "Civil Engineering"
               },
               {
                  "phrase" : "Psychology",
                  "value" : "29",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "1.6.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "it"
            ],
            "content_subjects" : [
               "3",
               "18",
               "4",
               "5",
               "20",
               "6",
               "21",
               "22",
               "8",
               "9",
               "24",
               "10",
               "26",
               "12",
               "27",
               "13",
               "29"
            ],
            "url" : "http://dspace.unict.it/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 26807,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Hasanuddin University Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://repository.unhas.ac.id/oai/request",
            "url" : "http://repository.unhas.ac.id/",
            "content_subjects" : [
               "3",
               "20",
               "6",
               "21",
               "7",
               "24",
               "10",
               "11",
               "26"
            ],
            "software" : {
               "version" : "1.7.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "phrase" : "History and Archaeology",
                  "value" : "20",
                  "language" : "en"
               },
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Hasanuddin University"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "url" : "http://www.unhas.ac.id/",
            "location" : {
               "longitude" : 119.498,
               "latitude" : -5.1096
            },
            "country" : "id"
         },
         "system_metadata" : {
            "id" : 2356,
            "date_created" : "2011-11-28 11:11:11",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2356",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "learning_objects"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "ELOGeo Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 69,
            "description" : "This site provides access to the outputs of the ELOGeo project, a JISC-funded project based at the Centre for Geospatial Science, University of Nottingham in partnership with Mimas Centre of Excellence, University of Manchester.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "value" : "19",
                  "language" : "en"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "phrase" : "Library and Information Science",
                  "value" : "27",
                  "language" : "en"
               }
            ],
            "repository_status" : "trial",
            "software" : {
               "name" : "dspace",
               "version" : "1.7.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "19",
               "2",
               "8",
               "27"
            ],
            "url" : "http://elogeo.nottingham.ac.uk/xmlui/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "trial",
                  "phrase" : "Trial"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2355",
            "publicly_visible" : "yes",
            "id" : 2355,
            "date_created" : "2011-11-28 10:10:59",
            "date_modified" : "2019-10-17 14:34:37"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Nottingham",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "gb",
            "location" : {
               "latitude" : 52.9382,
               "longitude" : -1.1712
            },
            "url" : "http://www.nottingham.ac.uk/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Nottingham Geospatial Institute",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://bibliotecadigital.univalle.edu.co/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bibliotecadigital.univalle.edu.co/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "The repository integrates the resources of the institution's intellectual output on a single platform. It will eventually also include works by other authors and institutions relating to regional projects. Users may set up RSS feeds to be alerted to new content.",
            "metadata_record_count" : 9968,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Biblioteca Digital de la Universidad del Valle",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2354",
            "publicly_visible" : "yes",
            "id" : 2354,
            "date_created" : "2011-11-21 15:15:16",
            "date_modified" : "2019-10-17 14:34:37"
         },
         "organisation" : {
            "location" : {
               "latitude" : 3.37604,
               "longitude" : -76.533
            },
            "url" : "http://www.univalle.edu.co/estatica/index-desplegables.html",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "country" : "co",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "Univalle",
                  "name" : "Universidad del Valle",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "metadata_record_count" : 1011,
            "type" : "governmental",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "BviaL",
                  "name" : "Biblioteca virtual de obras públicas de Andalucía",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_subjects" : [
               "26",
               "28"
            ],
            "url" : "http://infodigital.opandalucia.es/bvial/",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Management and Planning",
                  "value" : "28",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish and English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            }
         },
         "system_metadata" : {
            "date_created" : "2011-11-16 15:15:47",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2353,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2353",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "es",
            "url" : "http://www.aopandalucia.es/",
            "location" : {
               "longitude" : -5.9963,
               "latitude" : 37.3826
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Agencia de Obra Pública de la Junta de Andalucía",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "26",
               "28"
            ],
            "url" : "http://infodigital.opandalucia.es/oplex/",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "1.6.0",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "28",
                  "phrase" : "Management and Planning"
               }
            ],
            "description" : "This site provides access to digital collection of legislation and technical regulations of roads and railways applicable in the Autonomous Community of Andalucia.The interface is available in Spanish and English.",
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "metadata_record_count" : 1430,
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "OPLex",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "unpub_reports_and_working_papers"
            ]
         },
         "organisation" : {
            "country" : "es",
            "location" : {
               "longitude" : -5.9963,
               "latitude" : 37.3826
            },
            "url" : "http://www.aopandalucia.es/",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Agencia de Obra Pública de la Junta de Andalucía"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2352",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-11-16 15:15:42",
            "id" : 2352
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 13871,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "William & Mary Law School Scholarship Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "oai_url" : "http://scholarship.law.wm.edu/do/oai/",
            "url" : "http://scholarship.law.wm.edu/",
            "content_subjects" : [
               "26"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 9088,
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "William &amp; Mary Law School"
               }
            ],
            "location" : {
               "longitude" : -76.7053,
               "latitude" : 37.2635
            },
            "url" : "http://law.wm.edu/",
            "unit" : [
               {
                  "name" : "Wolf Law Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2351",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-11-16 15:15:36",
            "id" : 2351,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "country" : "ua",
            "url" : "http://npu.edu.ua/",
            "location" : {
               "longitude" : 30.9485,
               "latitude" : 50.7752
            },
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "National Pedagogical Dragomanov University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2350",
            "publicly_visible" : "yes",
            "date_created" : "2011-11-16 15:15:30",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2350
         },
         "repository_metadata" : {
            "oai_url" : "http://enpuir.npu.edu.ua/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://enpuir.npu.edu.ua/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "This site provides access to the research output of the institution. The interface is available in Russian, Ukrainian and English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "1.7.1"
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 17650,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "ENPUIR",
                  "name" : "Electronic Repository of the National Pedagogical Dragomanov University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ru",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "uk"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "learning_objects"
            ],
            "content_subjects" : [
               "4",
               "10"
            ],
            "oai_url" : "http://repo.knmu.edu.ua/oai/request",
            "url" : "http://repo.knmu.edu.ua/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution.The interface is available in Ukrainian",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "3.1"
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 19265,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Kharkov National Medical University Repository (Репозитарий Харьковского национального медицинского университета)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2349",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-11-15 12:12:44",
            "id" : 2349,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "longitude" : 36.2304,
               "latitude" : 49.9935
            },
            "url" : "http://knmu.kharkov.ua/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Kharkov National Medical University"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2011-11-15 11:11:52",
            "date_modified" : "2019-10-17 14:34:37",
            "id" : 2348,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2348",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universitat de Girona",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "url" : "http://www.udg.edu/",
            "location" : {
               "longitude" : 2.827,
               "latitude" : 41.985
            }
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 11569,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "DUGiFonsEspecials - Universitat de Girona",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dugifonsespecials.udg.edu/dspace-oai/request",
            "url" : "http://dugifonsespecials.udg.edu/",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to special collections deposited in the Library of the University of Girona. The interface is in a mixture of Spanish and English. An RSS feed is available to keep users up to date with newly added materials. Some items are not available as full-text."
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Pública de Navarra",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ],
            "url" : "http://www.unavarra.es/",
            "location" : {
               "longitude" : -1.6299,
               "latitude" : 42.8059
            },
            "country" : "es"
         },
         "system_metadata" : {
            "id" : 2347,
            "date_modified" : "2019-10-17 14:34:37",
            "date_created" : "2011-11-15 11:11:45",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2347",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 16492,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Academica-e",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "oai_url" : "http://academica-e.unavarra.es/oai/driver",
            "content_subjects" : [
               "3",
               "11",
               "14"
            ],
            "url" : "http://academica-e.unavarra.es/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 5287,
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               },
               {
                  "phrase" : "Computers and IT",
                  "language" : "en",
                  "value" : "14"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Portuuese and English.",
            "full_text_record_count" : 1010,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.chporto.pt/oaiextended/request",
            "url" : "http://repositorio.chporto.pt/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório Científico do Centro Hospitalar do Porto"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1719,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2346,
            "date_created" : "2011-11-15 11:11:41",
            "date_modified" : "2019-10-17 14:34:37",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2346",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 41.15,
               "longitude" : -8.6102
            },
            "url" : "http://www.chporto.pt/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "country" : "pt",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Centro Hospitalar do Porto"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "hal",
                     "language" : "en",
                     "phrase" : "HAL"
                  }
               ],
               "name" : "hal"
            },
            "description" : "This site provides access to the research outputs of 14 hospitals that make up the University Hospital of Lyon named 'Hospices Civils de Lyon'. The interface is available in French and English. Users may set up an RSS feed to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://hal-hcl.archives-ouvertes.fr/",
            "content_subjects" : [
               "17",
               "5",
               "7",
               "8",
               "23",
               "9",
               "24",
               "10",
               "11",
               "14",
               "29"
            ],
            "oai_url" : "https://api.archives-ouvertes.fr/oai/hcl",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "HAL-HCL"
               }
            ],
            "type" : "aggregating",
            "metadata_record_count" : 8369,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "value" : "5",
                  "language" : "en"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "value" : "9",
                  "language" : "en",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "content_languages" : [
               "fr"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ]
         },
         "organisation" : {
            "country" : "fr",
            "url" : "http://www.chu-lyon.fr/web/",
            "location" : {
               "longitude" : 4.8357,
               "latitude" : 45.764
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "France"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Hospices Civils de Lyon",
                  "acronym" : "HCL"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2345,
            "date_created" : "2011-11-09 11:11:42",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2345"
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "longitude" : -87.0611,
               "latitude" : 41.4731
            },
            "url" : "http://www.valpo.edu/",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Valparaiso University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 2344,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-11-09 11:11:33",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2344",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "4",
               "21",
               "22",
               "9",
               "10",
               "26",
               "29"
            ],
            "url" : "http://scholar.valpo.edu/",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name" : "other"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Language and Literature",
                  "value" : "21",
                  "language" : "en"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "value" : "9",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               },
               {
                  "language" : "en",
                  "value" : "29",
                  "phrase" : "Psychology"
               }
            ],
            "metadata_record_count" : 6935,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "ValpoScholar",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 1369,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Electronic Repository - Central Medical Library - MU, Sofia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://nt-cmb.mu-sofia.bg:8080/jspui/",
            "oai_url" : "http://nt-cmb.medun.acad.bg:8080/oai/request",
            "content_subjects" : [
               "10",
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 3,
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Bulgarian and English.",
            "software" : {
               "version" : "1.6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Bulgarian",
                  "value" : "bg",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages" : [
               "bg"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Medical University, Sofia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Bulgaria",
                  "language" : "en",
                  "value" : "bg"
               }
            ],
            "location" : {
               "latitude" : 42.6965,
               "longitude" : 23.326
            },
            "url" : "http://mu-sofia.bg/",
            "unit" : [
               {
                  "name" : "Central Medical Library",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "bg"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-11-09 10:10:54",
            "id" : 2343,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2343",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "no",
                  "language" : "en",
                  "phrase" : "Norwegian"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en",
               "no"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 2175,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "SNORRe",
                  "name" : "Statistics Norway's Open Research Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://ssb.brage.unit.no",
            "oai_url" : "https://ssb.brage.unit.no/ssb-oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to publications produced by employees of Statistics Norway. The interface is available in Norwegian and English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2342,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-11-07 16:16:10",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2342"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Statistics Norway",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "value" : "no",
                        "language" : "en",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Statistisk sentralbyrå",
                  "acronym" : "SSB"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.ssb.no/",
            "location" : {
               "longitude" : 10.7469,
               "latitude" : 59.922
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norway"
               }
            ],
            "country" : "no"
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 14779,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "eaNUPh",
                  "name" : "Електронний архів Національного фармацевтичного університету (Electronic Archive of the National University of Pharmacy)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://dspace.nuph.edu.ua/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "uk"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Ukrainian and English. Users may set up RSS and Atom feeds to be alerted to new content.",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "1.7.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            }
         },
         "organisation" : {
            "location" : {
               "latitude" : 49.9935,
               "longitude" : 36.2304
            },
            "url" : "http://nuph.edu.ua/",
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua",
            "name" : [
               {
                  "acronym" : "NUPh (НФаУ)",
                  "name" : "National University of Pharmacy (Національного фармацевтичного університету)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2341",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 2341,
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-11-07 16:16:04",
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2340",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 2340,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-11-07 15:15:57",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "http://www.chlc.min-saude.pt/",
            "location" : {
               "latitude" : 38.7069,
               "longitude" : -9.1356
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "country" : "pt",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Centro Hospitalar de Lisboa Central, EPE"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "pt"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "year_established" : 2010,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "oai_url" : "http://repositorio.chlc.min-saude.pt/oaiextended/request",
            "content_subjects" : [
               "10"
            ],
            "url" : "http://repositorio.chlc.min-saude.pt/",
            "full_text_record_count" : 1828,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "Users may set up RSS feeds to be alerted to new content. The interface is available in Portugeuse and English.",
            "software" : {
               "version" : "5.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2965,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório do Centro Hospitalar de Lisboa Central, EPE",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Università degli studi di Ferrara",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "it",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italy"
               }
            ],
            "url" : "http://www.unife.it/",
            "location" : {
               "longitude" : 11.6259,
               "latitude" : 44.8334
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2339",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-11-07 15:15:53",
            "id" : 2339
         },
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required"
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "version_type_and_date",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "value" : "peer_review_status",
                     "language" : "en",
                     "phrase" : "peer-review status"
                  },
                  {
                     "value" : "publication_status",
                     "language" : "en",
                     "phrase" : "publication status"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "language" : "en",
                     "value" : "no_policy"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Employees",
                     "language" : "en",
                     "value" : "employees"
                  }
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "employees"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control" : "checked_by_subject_specialists",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "checked_by_subject_specialists",
                     "phrase" : " is checked by internal subject specialists. "
                  }
               ],
               "moderation" : "no_policy"
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "value" : "content_not_changed",
                     "language" : "en",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy"
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "value" : "migrate_file_formats",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "software_emulation",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "value" : "tombstone",
                           "language" : "en",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ],
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "yes"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "value" : "errata_may_be_included",
                        "language" : "en",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "value" : "for_years",
                        "language" : "en",
                        "phrase" : "Items will be retained for a specified number of years"
                     }
                  ],
                  "years" : 3,
                  "period" : "for_years"
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "language" : "en",
                     "value" : "original_bitstream_retained",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ]
            }
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://eprints.unife.it/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://eprints.unife.it/cgi/oai2",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.10"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "metadata_record_count" : 964,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "EprintsUnife",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "it"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2338",
            "publicly_visible" : "yes",
            "id" : 2338,
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-10-26 11:11:52"
         },
         "organisation" : {
            "url" : "http://www.epimeleia-argentina.org/",
            "location" : {
               "latitude" : -34.6084,
               "longitude" : -58.3732
            },
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "country" : "ar",
            "name" : [
               {
                  "name" : "Asociación Civil Epimeleia Cuidano el Desarrollo Personal",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the digitised collection on material relating to the PCA and counselling. Some content is held on external websites.The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "value" : "greenstone",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "http://bibliotecaparalapersona-epimeleia.com/greenstone/cgi-bin/library.cgi",
            "content_subjects" : [
               "10",
               "29"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Bibloteca para la Persona (Library for the Person)"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "description" : "This site provides access to the collections of the institution. The interface is available in Spanish or English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "greenstone",
                     "phrase" : "Greenstone"
                  }
               ],
               "version" : "2.83",
               "name" : "greenstone"
            },
            "content_subjects" : [
               "1",
               "20",
               "26"
            ],
            "url" : "http://www.bibliotecamuseodelamemoria.cl/gsdl/cgi-bin/library.cgi?l=es",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteca Digital Museo de la Memoria"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2337",
            "publicly_visible" : "yes",
            "id" : 2337,
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-10-26 11:11:00"
         },
         "organisation" : {
            "country" : "cl",
            "location" : {
               "longitude" : -70.6798,
               "latitude" : -33.4406
            },
            "url" : "http://www.museodelamemoria.cl/",
            "country_phrases" : [
               {
                  "phrase" : "Chile",
                  "value" : "cl",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Museo de la Memoria (Museum of Memory and Human Rights)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Metabiblioteca",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "location" : {
               "longitude" : -74.0758,
               "latitude" : 4.5981
            },
            "url" : "http://www.metabiblioteca.org/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2336",
            "publicly_visible" : "yes",
            "date_created" : "2011-10-26 09:09:42",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2336
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               },
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "value" : "22",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "1.8.1"
            },
            "description" : "This site provides access to the digitised collections of this institution. The interface is available in English, Spanish, Portugeuse, French, German and Italian. Users may set up RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://libros.metabiblioteca.org/oai/request",
            "content_subjects" : [
               "2",
               "17",
               "19",
               "20",
               "21",
               "22",
               "23",
               "11",
               "14",
               "29"
            ],
            "url" : "http://libros.metabiblioteca.org/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Metabiblioteca-Biblioteca Digital Libros Abiertos",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 411,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2011-10-26 09:09:22",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2335,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2335",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad EAN"
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "location" : {
               "latitude" : 4.66343,
               "longitude" : -74.055
            },
            "url" : "http://www.ean.edu.co/"
         },
         "repository_metadata" : {
            "content_languages" : [
               "es",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "full_text_record_count" : 103,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.ean.edu.co/oai/request",
            "url" : "http://repository.ean.edu.co/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "1.7.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish, Portugeuse, English and French. Users may set up RSS feeds to be alerted to new content.",
            "metadata_record_count" : 1336,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Biblioteca Digital Minerva",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "3",
               "4",
               "19",
               "6",
               "7",
               "23",
               "24",
               "10",
               "11",
               "26",
               "28"
            ],
            "url" : "http://www.repo.funde.org/",
            "oai_url" : "http://www.repo.funde.org/cgi/oai2",
            "full_text_record_count" : 1248,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This is a subject based institutional repository providing access to information about social economic development generated by the institution. The site interface is available in English and Spanish. Atom and RSS feeds can be set up to alert users of new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.2.7",
               "name" : "eprints"
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1315,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositorio Institucional FUNDE",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "language" : "en",
                  "value" : "19",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "language" : "en",
                  "value" : "6",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Management and Planning",
                  "value" : "28",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "FUNDE",
                  "name" : "Fundación Nacional para el Desarrollo"
               }
            ],
            "country" : "sv",
            "country_phrases" : [
               {
                  "phrase" : "El Salvador",
                  "language" : "en",
                  "value" : "sv"
               }
            ],
            "url" : "http://www.funde.org/",
            "location" : {
               "longitude" : -89.2554,
               "latitude" : 13.7042
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2334",
            "publicly_visible" : "yes",
            "id" : 2334,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-21 09:09:44"
         },
         "policies" : {
            "metadata_policy" : {
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "value" : "repository_mention_required",
                     "language" : "en"
                  }
               ],
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "commercial_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven"
                  ],
                  "withdrawn_items" : {
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "value" : "indefinite",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ],
                     "searchable" : "no",
                     "item_page" : [
                        "tombstone"
                     ]
                  }
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Backup items in external archives",
                     "value" : "offsite_backups",
                     "language" : "en"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "value" : "software_emulation",
                     "language" : "en"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "value" : "errata_may_be_included",
                        "language" : "en",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     }
                  ]
               },
               "third_party_collaborations" : [
                  "offsite_backups"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ]
            },
            "data_policy" : {
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties",
                  "stored_in_a_database"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  },
                  {
                     "value" : "given_to_third_parties",
                     "language" : "en",
                     "phrase" : "given to third parties"
                  },
                  {
                     "phrase" : "stored in a database",
                     "value" : "stored_in_a_database",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  },
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "language" : "en",
                     "value" : "bibliographic_metadata_required"
                  }
               ],
               "moderation" : "yes"
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "phrase" : "Greenstone",
                     "value" : "greenstone",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ],
            "description" : "This site provides access to training materials relating to the treatment of Influenza. The interface is available in English and French.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "10",
               "25"
            ],
            "url" : "http://influenzatraining.org/",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Influenza Training Digital Library",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "learning_objects",
               "other_special_item_types"
            ],
            "metadata_record_count" : 223,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "WHO",
                  "name" : "World Health Organization",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "ch",
            "location" : {
               "latitude" : 46.2327,
               "longitude" : 6.1344
            },
            "url" : "http://www.who.int/",
            "country_phrases" : [
               {
                  "phrase" : "Switzerland",
                  "language" : "en",
                  "value" : "ch"
               }
            ]
         },
         "system_metadata" : {
            "id" : 2333,
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-10-19 12:12:00",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2333",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "url" : "http://www.unesco.org/new/en/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Management of Social Transformations Programme",
                  "acronym" : "MOST",
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 2.3064,
               "latitude" : 48.8502
            },
            "country" : "fr",
            "name" : [
               {
                  "name" : "United Nations Educational, Scientific and Cultural Organisation",
                  "acronym" : "UNESCO",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 2332,
            "date_created" : "2011-10-19 11:11:54",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2332",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 331,
            "type" : "institutional",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "MOST Digital Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1",
               "19",
               "10",
               "26"
            ],
            "url" : "http://digital-library.unesco.org/shs/most/gsdl/cgi-bin/library?c=most&a=p&p=about",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of this institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               },
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "greenstone",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "greenstone",
                     "phrase" : "Greenstone"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Repositorio Digital Académico UC Temuco",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1233,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "1.7.1",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the the research output of the institution. The interface is available in Spanish. Users may set up an RSS feed to be alerted to updates.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositoriodigital.uct.cl/",
            "content_subjects" : [
               "18",
               "22",
               "23",
               "25",
               "11"
            ],
            "oai_url" : "http://repositoriodigital.uct.cl:8080/oai/request",
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "value" : "18",
                  "language" : "en"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "content_languages" : [
               "es"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Universidad Católica de Temuco",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.uctemuco.cl/",
            "location" : {
               "longitude" : -72.6581,
               "latitude" : -38.762
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cl",
                  "phrase" : "Chile"
               }
            ],
            "country" : "cl"
         },
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:28",
            "date_created" : "2011-10-19 11:11:07",
            "id" : 2330,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2330",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "http://thewalters.org/default.aspx",
            "location" : {
               "latitude" : 39.2966,
               "longitude" : -76.6159
            },
            "country" : "us",
            "name" : [
               {
                  "name" : "Walters Art Museum",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2011-10-19 10:10:42",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2329,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2329",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Online Collection",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://art.thewalters.org/",
            "content_subjects" : [
               "17",
               "18",
               "20"
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to digital images of its collections. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2328",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2328,
            "date_modified" : "2019-10-25 13:11:46",
            "date_created" : "2011-10-19 10:10:05",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Hamburg State and University Library",
                  "acronym" : "SUB Hamburg",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               },
               {
                  "acronym" : "SUB Hamburg",
                  "name" : "Staats- und Universitätsbibliothek Hamburg",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "language" : "de"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de",
                  "acronym" : "DFG",
                  "name" : "Deutsche Forschungsgemeinschaft"
               }
            ],
            "country" : "de",
            "url" : "http://www.sub.uni-hamburg.de",
            "location" : {
               "longitude" : 9.9849,
               "latitude" : 53.5649
            },
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "description" : "This site provides access to political science research from German speaking countries. The collection consists of grey literature as well as articles and working papers. The interface is available in German.",
            "software" : {
               "name" : "opus",
               "version" : "3.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "opus",
                     "phrase" : "OPUS"
                  }
               ]
            },
            "oai_url" : "http://edoc.vifapol.de/opus/oai2/oai2.php",
            "url" : "http://edoc.vifapol.de/opus",
            "content_subjects" : [
               "26"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "de",
                  "language_phrases" : [
                     {
                        "value" : "de",
                        "language" : "en",
                        "phrase" : "German"
                     }
                  ],
                  "name" : "eDoc.ViFaPol",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 5482
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "undefined",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2327,
            "date_created" : "2011-10-19 09:09:57",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2327"
         },
         "organisation" : {
            "country" : "in",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "in",
                  "phrase" : "India"
               }
            ],
            "url" : "http://www.inflibnet.ac.in/",
            "location" : {
               "longitude" : 72.6299,
               "latitude" : 23.193
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "INFLIBNET",
                  "name" : "Information and Library Network Center",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "hi",
               "gu"
            ],
            "repository_status" : "fully_functional",
            "notes" : "data checked 24.03.14",
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Hindi",
                  "value" : "hi",
                  "language" : "en"
               },
               {
                  "value" : "gu",
                  "language" : "en",
                  "phrase" : "Gujarati"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://shodhganga.inflibnet.ac.in/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "version" : "1.8.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides users with access to the student research of several institutions within India. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "metadata_record_count" : 196538,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "ShodhGanga: A reservoir of Indian theses",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "aggregating"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio Digital RIBEI"
               }
            ],
            "type" : "aggregating",
            "metadata_record_count" : 2159,
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.2.7"
            },
            "description" : "This site is a multi institutional repository containing information on international studies. Users may set up Atom and RSS feeds to be alerted to new content. The interface is available in english, spanish and portuguese.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 2118,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://biblioteca.ribei.org/cgi/oai2",
            "url" : "http://biblioteca.ribei.org/",
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "es",
               "pt"
            ]
         },
         "policies" : {
            "submission_policy" : {
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  },
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "value" : "valid_formatting",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "value" : "full_citation_required",
                     "language" : "en",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "language" : "en",
                     "value" : "original_copyright_statement_required",
                     "phrase" : "the original copyright statement is given"
                  },
                  {
                     "phrase" : "the original rights permission statement is given",
                     "value" : "original_rights_statement_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "language" : "en",
                     "value" : "software_emulation"
                  }
               ],
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "value" : "removal_not_normal",
                        "language" : "en",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ],
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ]
                  }
               },
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "language" : "en",
                        "value" : "link_between_versions"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "value" : "errata_may_be_included",
                        "language" : "en"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "link_between_versions"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ]
            },
            "metadata_policy" : {
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "commercial_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "language" : "en",
                     "value" : "repository_mention_required"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Red Iberoamericana de Estudios Internacionales"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "url" : "http://www.realinstitutoelcano.org/wps/portal/rielcano/RIBEI",
            "location" : {
               "longitude" : -3.6801,
               "latitude" : 40.4314
            },
            "country" : "es"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2326",
            "publicly_visible" : "yes",
            "id" : 2326,
            "date_created" : "2011-10-17 10:10:48",
            "date_modified" : "2019-10-17 14:34:36"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Geography and Regional Studies",
                  "language" : "en",
                  "value" : "19"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               },
               {
                  "language" : "en",
                  "value" : "6",
                  "phrase" : "Earth and Planetary Sciences"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "patents",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese and contains RSS feeds to alert users of new content. Some items are not available as full-text.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "19",
               "5",
               "6"
            ],
            "url" : "http://ir.gig.ac.cn:8080/",
            "oai_url" : "http://ir.gig.ac.cn:8080/casirgrid-oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Institutional Repository of Guangzhou Institute of Geochemistry,CAS(GIGCAS OpenIR)",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 6752
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2325,
            "date_created" : "2011-10-13 10:10:50",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2325"
         },
         "organisation" : {
            "country" : "cn",
            "country_phrases" : [
               {
                  "value" : "cn",
                  "language" : "en",
                  "phrase" : "China"
               }
            ],
            "url" : "http://www.gig.cas.cn/",
            "location" : {
               "longitude" : 113.352,
               "latitude" : 23.153
            },
            "name" : [
               {
                  "name" : "Guangzhou Institute of Geochemistry, Chinese Academy of Science (中国科学院广州地球化学研究所)",
                  "acronym" : "GIGCAS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2323,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-12 11:11:13",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2323"
         },
         "organisation" : {
            "country" : "cn",
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "value" : "cn",
                  "language" : "en"
               }
            ],
            "url" : "http://www.cas.cn/",
            "unit" : [
               {
                  "acronym" : "CIB",
                  "name" : "Chengdu Institute of Biology (成都生物研究所)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : 104.053,
               "latitude" : 30.654
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "phrase" : "Biology and Biochemistry",
                  "language" : "en",
                  "value" : "4"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some content is not available as Full-text.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "3",
               "4",
               "7",
               "14"
            ],
            "url" : "http://210.75.237.14/",
            "oai_url" : "http://210.75.237.14/casirgrid-oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Institutional Repository of Chengdu Institute of Biology, CAS",
                  "acronym" : "CIB OpenIR"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "metadata_record_count" : 6111
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://repository.lib.eduhk.hk/",
            "content_subjects" : [
               "17",
               "21",
               "7",
               "22",
               "8",
               "23",
               "25",
               "26",
               "29"
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "21",
                  "language" : "en",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               },
               {
                  "value" : "22",
                  "language" : "en",
                  "phrase" : "Philosophy and Religion"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Psychology",
                  "language" : "en",
                  "value" : "29"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to research output of the institution. Some items are not available as full-text. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "CRIS-5.3.1-SNAPSHOT",
               "name" : "dspace"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               }
            ],
            "metadata_record_count" : 22318,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "name" : [
               {
                  "name" : "EdUHK Research Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.eduhk.hk/",
            "location" : {
               "longitude" : 114.194,
               "latitude" : 22.4668
            },
            "country_phrases" : [
               {
                  "value" : "hk",
                  "language" : "en",
                  "phrase" : "Hong Kong"
               }
            ],
            "country" : "hk",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Education University of Hong Kong"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-12 10:10:01",
            "id" : 2322,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2322",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "value" : "removal_at_request",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "other"
                  ],
                  "special_reasons" : [
                     "inappropriate"
                  ],
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "other",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "withdrawn_items" : {
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "yes",
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               },
               "closure_policy" : "undefined",
               "url" : [
                  "http://repository.ied.edu.hk/about/SubmissionGuide.pdf"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "version_control" : {
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ]
               },
               "retention_period" : {
                  "period" : "undefined",
                  "period_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No retention period defined"
                     }
                  ]
               }
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "language" : "en",
                     "value" : "no_policy"
                  }
               ],
               "url" : [
                  "http://repository.ied.edu.hk/about/SubmissionGuide.pdf"
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "policy_undefined",
                     "language" : "en",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  }
               ],
               "depositors" : [
                  "academic_staff"
               ],
               "content_embargo" : "policy_undefined",
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "moderation" : "no_policy"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "standard_types_allowed" : [
                     "journal_articles",
                     "bibliographic_references",
                     "conference_and_workshop_papers",
                     "books_chapters_and_sections",
                     "learning_objects"
                  ],
                  "standard_types_allowed_phrases" : [
                     {
                        "value" : "journal_articles",
                        "language" : "en",
                        "phrase" : "Journal Articles"
                     },
                     {
                        "language" : "en",
                        "value" : "bibliographic_references",
                        "phrase" : "Bibliographic References"
                     },
                     {
                        "phrase" : "Conference and Workshop Papers",
                        "language" : "en",
                        "value" : "conference_and_workshop_papers"
                     },
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "value" : "books_chapters_and_sections",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Learning Objects",
                        "value" : "learning_objects",
                        "language" : "en"
                     }
                  ],
                  "all" : "false"
               },
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "http://repository.ied.edu.hk/about/SubmissionGuide.pdf"
               ]
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Open Access Publishing in European Networks",
                  "acronym" : "OAPEN",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 4.88748,
               "latitude" : 52.373
            },
            "url" : "http://www.oapen.org/",
            "country_phrases" : [
               {
                  "phrase" : "Netherlands",
                  "value" : "nl",
                  "language" : "en"
               }
            ],
            "country" : "nl"
         },
         "system_metadata" : {
            "id" : 2321,
            "date_created" : "2011-10-11 15:15:52",
            "date_modified" : "2019-11-11 10:58:18",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2321",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "OAPEN Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "aggregating",
            "metadata_record_count" : 10289,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "software" : {
               "name_other" : "ARNO",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "This site provides access to open access book publications. The interface is available in English.\r\n\r\nThe reuse rights for each individual book is descibed on the landing page. All metadata (https://www.oapen.org/content/metadata) is available under a CC0 license",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "17",
               "21",
               "2",
               "8",
               "23",
               "24",
               "26",
               "27"
            ],
            "oai_url" : "https://dataprovider.oapen.org/cgi/oapen",
            "url" : "http://www.oapen.org",
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               },
               {
                  "phrase" : "Italian",
                  "language" : "en",
                  "value" : "it"
               },
               {
                  "value" : "la",
                  "language" : "en",
                  "phrase" : "Latin"
               }
            ],
            "repository_status" : "fully_functional",
            "notes" : "The content is available in a variety of languages.  Metadata is available in: ONIX – XML, MARCXML, CSV, and Excel-optimised XML (but not OAI-PMH).",
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "value" : "8",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "phrase" : "Library and Information Science",
                  "language" : "en",
                  "value" : "27"
               }
            ],
            "content_languages" : [
               "en",
               "de",
               "it",
               "la"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2320",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2011-10-11 15:15:15",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2320,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "latitude" : 45.764,
               "longitude" : 4.8357
            },
            "url" : "http://www.mom.fr/",
            "country_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "France"
               }
            ],
            "country" : "fr",
            "name" : [
               {
                  "acronym" : "MOM",
                  "name" : "Maison de lOrient et de la Méditerranée",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 156,
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "DIGIMOM",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "disciplinary",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://www.mom.fr/digimom/",
            "oai_url" : "http://oai.mom.fr/digimom/oai",
            "content_subjects" : [
               "19",
               "20"
            ],
            "software" : {
               "name_phrases" : []
            },
            "description" : "This site provides access to digitised books. The collection focuses on Egyptology and Greco-Latin civilisation. The interface is available in French.",
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "fr"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "19",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2319",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2011-10-11 15:15:01",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2319,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institute of Development Studies"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "http://www.ids.ac.uk/",
            "unit" : [
               {
                  "name" : "Publications Team, Knowledge, Impact and Policy",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : -0.0901,
               "latitude" : 50.866
            },
            "country" : "gb"
         },
         "policies" : {
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "policy_undefined",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "depositors" : [
                  "community_members"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting"
               ],
               "content_embargo" : "policy_undefined",
               "quality_control" : "checked_by_subject_specialists",
               "quality_control_phrases" : [
                  {
                     "value" : "checked_by_subject_specialists",
                     "language" : "en",
                     "phrase" : " is checked by internal subject specialists. "
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "language" : "en",
                     "value" : "item_relevance",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  }
               ],
               "moderation" : "yes"
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "closure_policy" : "undefined",
               "closure_policy_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ],
                  "method" : "undefined",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "policy" : "removal_not_normal"
               }
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               }
            }
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 13858,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "IDS OpenDocs",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "19",
               "23"
            ],
            "url" : "https://opendocs.ids.ac.uk/opendocs",
            "oai_url" : "http://opendocs.ids.ac.uk/oai/",
            "full_text_record_count" : 10862,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "OpenDocs is the Institutional Repository for research outputs of members and partner organisations (research centres and consortia) of the Institute of Development Studies (IDS). The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.10",
               "name" : "dspace"
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "19",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "organisation" : {
            "country" : "pl",
            "country_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Poland"
               }
            ],
            "url" : "http://www.ilawa.pl/_portal",
            "location" : {
               "latitude" : 53.596,
               "longitude" : 19.5684
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Iława",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2011-10-11 13:13:58",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2318,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2318"
         },
         "repository_metadata" : {
            "description" : "This site provides access to digitised articles on local issues. The interface is available in Polish and English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dlibra",
                     "language" : "en",
                     "phrase" : "dLibra"
                  }
               ],
               "version" : "4",
               "name" : "dlibra"
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ibc.ilawa.pl/dlibra/oai-pmh-repository.xml",
            "url" : "http://ibc.ilawa.pl/dlibra",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "governmental",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Iława Biblioteka Cyrfrowa (Iława Digital Library)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3397,
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pl"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "value" : "pl",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Science (中国科学院)"
               }
            ],
            "country" : "cn",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ],
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Institute of Computing Technology (计算技术研究所)",
                  "acronym" : "ICT"
               }
            ],
            "url" : "http://www.cas.cn/",
            "location" : {
               "latitude" : 39.9062,
               "longitude" : 116.43
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2317,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-11 13:13:41",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2317"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of Institute of Computing Technology, CAS",
                  "acronym" : "ICT OpenIR"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 2375,
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "oai_url" : "http://159.226.40.250/casirgrid-oai/request",
            "url" : "http://159.226.40.250/",
            "content_subjects" : [
               "14"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "zh"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               },
               {
                  "language" : "en",
                  "value" : "28",
                  "phrase" : "Management and Planning"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 15458,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of Institute of Automation, CAS",
                  "acronym" : "SIA OpenIR"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 18,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://210.72.131.170/casirgrid-oai/request",
            "url" : "http://210.72.131.170/",
            "content_subjects" : [
               "11",
               "28"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese."
         },
         "organisation" : {
            "country" : "cn",
            "location" : {
               "longitude" : 123.495,
               "latitude" : 41.8109
            },
            "unit" : [
               {
                  "name" : "Institute of Automation (沈阳自动化研究所)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.cas.cn/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "acronym" : "CAS"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2316",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 2316,
            "date_created" : "2011-10-11 13:13:29",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible" : "yes"
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "ar",
                     "phrase" : "Arabic"
                  },
                  {
                     "phrase" : "English",
                     "value" : "en",
                     "language" : "en"
                  },
                  {
                     "value" : "fr",
                     "language" : "en",
                     "phrase" : "French"
                  },
                  {
                     "value" : "zh",
                     "language" : "en",
                     "phrase" : "Chinese"
                  }
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "language" : "en",
                     "value" : "working_drafts"
                  },
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type" : "multi_institution_subject",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "languages" : [
                  "ar",
                  "en",
                  "fr",
                  "zh"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "value" : "multi_institution_subject",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "url" : [
                  "http://khartoumspace.uofk.edu/policies"
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "version_type_and_date",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "phrase" : "publication status",
                     "language" : "en",
                     "value" : "publication_status"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://khartoumspace.uofk.edu/policies"
               ],
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ]
            },
            "submission_policy" : {
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "employees"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "url" : [
                  "http://khartoumspace.uofk.edu/policies"
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "value" : "author_eligibility",
                     "language" : "en"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher",
                     "phrase" : "This repository is not the publisher; it is merely the online archive"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "harvesting" : [
                  "allowed_for_indexing",
                  "allowed_for_citation_analysis"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed transiently for full-text indexing",
                     "language" : "en",
                     "value" : "allowed_for_indexing"
                  },
                  {
                     "phrase" : "Allowed transiently for citation analysis",
                     "value" : "allowed_for_citation_analysis",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "some_or_all_restricted",
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://khartoumspace.uofk.edu/policies"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "value" : "content_not_changed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://khartoumspace.uofk.edu/policies"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  },
                  {
                     "language" : "en",
                     "value" : "software_emulation",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ]
                  }
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest",
                     "link_between_versions"
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     },
                     {
                        "value" : "persistent_urls_link_to_latest",
                        "language" : "en",
                        "phrase" : "The items persistent URL will always link to the latest version"
                     },
                     {
                        "language" : "en",
                        "value" : "link_between_versions",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ]
            }
         },
         "system_metadata" : {
            "date_modified" : "2020-01-28 18:33:17",
            "date_created" : "2011-10-11 13:13:21",
            "id" : 2315,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2315",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "University of Khartoum",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               },
               {
                  "name" : "جامعة الخرطوم‎",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "ar",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Arabic",
                        "value" : "ar",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "sd",
            "location" : {
               "longitude" : 32.5322,
               "latitude" : 15.5501
            },
            "url" : "https://www.uofk.edu",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "sd",
                  "phrase" : "Sudan"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "ar",
               "en"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Arabic",
                  "value" : "ar",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "oai_url" : "http://khartoumspace.uofk.edu/oai/request",
            "url" : "http://khartoumspace.uofk.edu",
            "content_subjects" : [
               "17",
               "10",
               "2",
               "23",
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1497,
            "description" : "This site provides access to the research output of the institution. The interface is available in English and contains RSS feeds to alert users to new content.",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 8395,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "University of Khartoum Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "url" : "http://scholars.wlu.ca/",
            "content_subjects" : [
               "2",
               "17",
               "4",
               "19",
               "5",
               "20",
               "7",
               "22",
               "8",
               "23",
               "26",
               "29"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research out of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Biology and Biochemistry",
                  "value" : "4",
                  "language" : "en"
               },
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "value" : "5",
                  "language" : "en",
                  "phrase" : "Chemistry and Chemical Technology"
               },
               {
                  "value" : "20",
                  "language" : "en",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               },
               {
                  "value" : "8",
                  "language" : "en",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 7076,
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Scholars Commons @ Laurier",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "url" : [
                  "scholars.wlu.ca/policies.html#policies-2"
               ]
            },
            "preservation_policy" : {
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "value" : "unusual_files_not_guaranteed",
                     "language" : "en"
                  }
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "special_reasons" : [
                     "Violations of university policies"
                  ],
                  "method" : "removed_from_public_view",
                  "withdrawn_items" : {
                     "item_page_phrases" : [
                        {
                           "language" : "en",
                           "value" : "tombstone",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        },
                        {
                           "phrase" : "URLs will contain a note explaining the reasons for withdrawal",
                           "language" : "en",
                           "value" : "explanation_of_withdrawal"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone",
                        "explanation_of_withdrawal"
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     },
                     {
                        "language" : "en",
                        "value" : "other",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "falsified_research",
                     "other"
                  ]
               },
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "unusual_files_not_guaranteed"
               ],
               "url" : [
                  "http://scholars.wlu.ca/policies.html#policies-7"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "url" : [
                  "http://scholars.wlu.ca/policies.html#policies-1"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "value" : "content_not_changed",
                     "language" : "en",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "some_items_have_different_conditions"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "some_items_have_different_conditions",
                     "language" : "en",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "language" : "en",
                     "value" : "registered_students"
                  },
                  {
                     "phrase" : "Employees",
                     "language" : "en",
                     "value" : "employees"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "scholars.wlu.ca/policies.html#policies-2"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "content_embargo" : "policy_undefined",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation" : "no_policy"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Wilfrid Laurier University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ca",
                  "phrase" : "Canada"
               }
            ],
            "url" : "http://www.wlu.ca/",
            "location" : {
               "longitude" : -80.5261,
               "latitude" : 43.4739
            },
            "country" : "ca"
         },
         "system_metadata" : {
            "date_created" : "2011-10-11 11:11:49",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2314,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2314",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "DBS Esource",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 2640,
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "value" : "27",
                  "language" : "en",
                  "phrase" : "Library and Information Science"
               },
               {
                  "phrase" : "Management and Planning",
                  "value" : "28",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "29",
                  "phrase" : "Psychology"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "1.7.1",
               "name" : "dspace"
            },
            "content_subjects" : [
               "17",
               "21",
               "24",
               "27",
               "28",
               "29"
            ],
            "url" : "http://esource.dbs.ie/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2313",
            "publicly_visible" : "yes",
            "date_created" : "2011-10-11 11:11:33",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2313
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Ireland",
                  "value" : "ie",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -6.2675,
               "latitude" : 53.3441
            },
            "url" : "http://www.dbs.ie/",
            "country" : "ie",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Dublin Business School",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2011-10-10 15:15:42",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2312,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2312"
         },
         "organisation" : {
            "country" : "cn",
            "location" : {
               "latitude" : 39.9062,
               "longitude" : 116.43
            },
            "url" : "http://www.psych.ac.cn/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ],
            "name" : [
               {
                  "name" : "Chinese Academy Of Sciences, Institute of Psychology (中国科学院心理研究所)(PSYCH), China",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "10",
               "29"
            ],
            "oai_url" : "http://ir.psych.ac.cn/casirgrid-oai/request",
            "url" : "http://ir.psych.ac.cn/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 116,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "PSYCH OpenIR",
                  "name" : "Institutional Repository of Institute of Psychology, CAS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 13450,
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Psychology",
                  "language" : "en",
                  "value" : "29"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-10 14:14:25",
            "id" : 2311,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2311",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "acronym" : "CAS",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "cn",
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "language" : "en",
                  "value" : "cn"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "ICCAS",
                  "name" : "Institute of Chemistry (化学研究所)"
               }
            ],
            "url" : "http://www.cas.cn/",
            "location" : {
               "longitude" : 116.43,
               "latitude" : 39.9062
            }
         },
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "ICCAS OpenIR",
                  "name" : "Institutional Repository of Institute of Chemistry, CAS",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               }
            ],
            "metadata_record_count" : 5341,
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "oai_url" : "http://159.226.64.105/casirgrid-oai/request",
            "content_subjects" : [
               "5",
               "9",
               "16"
            ],
            "url" : "http://159.226.64.105/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "5",
                  "phrase" : "Chemistry and Chemical Technology"
               },
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "language" : "en",
                  "value" : "16",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://210.77.73.110/",
            "content_subjects" : [
               "9"
            ],
            "oai_url" : "http://210.77.73.110/casirgrid-oai/request",
            "name" : [
               {
                  "acronym" : "IMP OpenIR",
                  "name" : "Institutional Repository of Institute of Modern Physics, CAS",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5505,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "9",
                  "language" : "en",
                  "phrase" : "Physics and Astronomy"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "acronym" : "CAS"
               }
            ],
            "country" : "cn",
            "location" : {
               "longitude" : 103.835,
               "latitude" : 36.1142
            },
            "unit" : [
               {
                  "acronym" : "IMP",
                  "name" : "Institute of Modern Physics (近代物理研究所)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://www.cas.cn/",
            "country_phrases" : [
               {
                  "value" : "cn",
                  "language" : "en",
                  "phrase" : "China"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2310",
            "publicly_visible" : "yes",
            "id" : 2310,
            "date_created" : "2011-10-10 14:14:18",
            "date_modified" : "2019-10-17 14:34:36"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "acronym" : "CAS",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "cn",
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Xi'an Institute of Optics and Precision Mechanics (西安光学精密机械研究所)",
                  "acronym" : "XIOPM"
               }
            ],
            "url" : "http://www.cas.cn/",
            "location" : {
               "longitude" : 108.978,
               "latitude" : 34.2591
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2309",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 2309,
            "date_created" : "2011-10-10 14:14:12",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents"
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "value" : "5",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 8126,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "OPT-IR",
                  "name" : "Institutional Repository of Xi'an Institute of Optics and Precision Mechanics, CAS"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "5",
               "9",
               "11"
            ],
            "oai_url" : "http://ir.opt.ac.cn/casirgrid-oai/request",
            "url" : "http://ir.opt.ac.cn/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese."
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ],
            "location" : {
               "longitude" : 108.978,
               "latitude" : 34.2591
            },
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Institute of Earth Environment (地球环境研究所)",
                  "acronym" : "IEE",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.cas.cn/",
            "country" : "cn",
            "name" : [
               {
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "acronym" : "CAS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2011-10-10 13:13:59",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2308,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2308",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects" : [
               "7",
               "11"
            ],
            "url" : "http://ir.ieecas.cn/",
            "oai_url" : "http://ir.ieecas.cn/casirgrid-oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "IEECAS OpenIR",
                  "name" : "Institutional Repository of Institute of Earth Environment, CAS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3714
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "cn",
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "value" : "cn",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institute of Coal Chemistry (山西煤炭化学研究所)",
                  "acronym" : "SXICC"
               }
            ],
            "url" : "http://www.cas.cn/",
            "location" : {
               "latitude" : 37.5551,
               "longitude" : 112.499
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-10 13:13:31",
            "id" : 2307,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2307"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "SXICC OpenIR",
                  "name" : "Institutional Repository of Institute of Coal Chemistry, CAS"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 4780,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "technically_malfunctioning",
                  "phrase" : "Technically Malfunctioning"
               }
            ],
            "oai_url" : "http://ir.sxicc.ac.cn/casirgrid-oai/request",
            "url" : "http://ir.sxicc.ac.cn/",
            "content_subjects" : [
               "2",
               "5",
               "11"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "technically_malfunctioning",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "value" : "5",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "zh",
               "en"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Science (中国科学院)"
               }
            ],
            "country" : "cn",
            "location" : {
               "longitude" : 121.672,
               "latitude" : 29.8807
            },
            "unit" : [
               {
                  "acronym" : "NIMTE",
                  "name" : "Ningbo Institute of Material Technology & Engineering (宁波材料技术与工程研究所)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.cas.cn/",
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "value" : "cn",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-10 13:13:11",
            "id" : 2306,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2306",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://ir.nimte.ac.cn/",
            "content_subjects" : [
               "11",
               "16"
            ],
            "oai_url" : "http://ir.nimte.ac.cn/casirgrid-oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "metadata_record_count" : 4443,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institutional Repository of Ningbo Institute of Material Technology & Engineering, CAS",
                  "acronym" : "NIMTE OpenIR",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               },
               {
                  "phrase" : "Mechanical Engineering and Materials",
                  "language" : "en",
                  "value" : "16"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "patents"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "zh",
               "en"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "value" : "5",
                  "language" : "en"
               },
               {
                  "value" : "9",
                  "language" : "en",
                  "phrase" : "Physics and Astronomy"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "patents",
               "other_special_item_types"
            ],
            "url" : "http://159.226.238.44/",
            "content_subjects" : [
               "5",
               "9"
            ],
            "oai_url" : "http://159.226.238.44/casirgrid-oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 34014,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "DICP-IR",
                  "name" : "Institutional Repository of Dalian Institute of Chemical Physics, CAS"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2305",
            "publicly_visible" : "yes",
            "date_created" : "2011-10-10 11:11:58",
            "date_modified" : "2019-12-04 12:27:28",
            "id" : 2305
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "cn",
                  "language" : "en",
                  "phrase" : "China"
               }
            ],
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Dalian Institute of Chemical Physics (大连化学物理研究所)",
                  "acronym" : "DICP"
               }
            ],
            "url" : "http://www.cas.cn/",
            "location" : {
               "latitude" : 38.927,
               "longitude" : 121.645
            },
            "country" : "cn",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Science (中国科学院)"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 2304,
            "date_created" : "2011-10-10 11:11:47",
            "date_modified" : "2019-10-17 14:34:36",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2304"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Sciences (中国科学院)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "China",
                  "language" : "en",
                  "value" : "cn"
               }
            ],
            "location" : {
               "latitude" : 39.9062,
               "longitude" : 116.43
            },
            "url" : "http://www.cas.cn/",
            "unit" : [
               {
                  "acronym" : "RCEES",
                  "name" : "Research Center for Eco-Environmental Sciences (生态环境研究中心)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "cn"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://159.226.240.226/casirgrid-oai/request",
            "url" : "http://159.226.240.226/",
            "content_subjects" : [
               "3",
               "19",
               "5",
               "7"
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some content is not available as full-text.",
            "metadata_record_count" : 20468,
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "RCEES OpenIR",
                  "name" : "Institutional Repository of Research Center for Eco-Environmental Sciences, CAS"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "zh"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "language" : "en",
                  "value" : "19",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations",
               "patents"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "4",
               "19",
               "7"
            ],
            "url" : "http://210.77.90.120/",
            "oai_url" : "http://210.77.90.120/casirgrid-oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 7532,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Institutional Repository of South China Sea Institute of Oceanology, CAS",
                  "acronym" : "scsio-IR",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Biology and Biochemistry",
                  "value" : "4",
                  "language" : "en"
               },
               {
                  "phrase" : "Geography and Regional Studies",
                  "language" : "en",
                  "value" : "19"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "zh",
                  "language" : "en",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         },
         "system_metadata" : {
            "date_created" : "2011-10-10 11:11:39",
            "date_modified" : "2019-10-17 14:34:36",
            "id" : 2303,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2303",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 113.155,
               "latitude" : 23.0894
            },
            "url" : "http://www.cas.cn/",
            "unit" : [
               {
                  "acronym" : "SCSIO",
                  "name" : "South China Sea Institute of Oceanology (南海海洋研究所)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ],
            "country" : "cn",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "CAS",
                  "name" : "Chinese Academy of Science (中国科学院)"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "patents"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Institutional Repository of Northwest Institute of Plateau Biology, CAS",
                  "acronym" : "NWIPB OpenIR",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "metadata_record_count" : 5166,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Biology and Biochemistry",
                  "language" : "en",
                  "value" : "4"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese. Some items are not available as full-text.",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "CSpace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_subjects" : [
               "4"
            ],
            "url" : "http://ir.nwipb.ac.cn",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Chinese Academy of Science (中国科学院)",
                  "acronym" : "CAS",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "cn",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cn",
                  "phrase" : "China"
               }
            ],
            "location" : {
               "longitude" : 101.669,
               "latitude" : 36.5997
            },
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "NWIPB",
                  "name" : "Northwest Institute of Plateau Biology (西北高原生物研究所)",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://www.cas.cn/"
         },
         "system_metadata" : {
            "id" : 2302,
            "date_modified" : "2019-10-17 14:34:36",
            "date_created" : "2011-10-10 11:11:31",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/2302",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      }
   ]
}

