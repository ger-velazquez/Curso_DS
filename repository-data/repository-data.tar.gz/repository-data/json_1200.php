{
   "items" : [
      {
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:18",
            "date_created" : "2019-07-10 09:32:02",
            "id" : 4633,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4633",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ru",
            "country_phrases" : [
               {
                  "phrase" : "Russian Federation",
                  "value" : "ru",
                  "language" : "en"
               }
            ],
            "url" : "https://ssau.ru/",
            "name" : [
               {
                  "name" : "Samara University",
                  "language" : "ru",
                  "language_phrases" : [
                     {
                        "value" : "ru",
                        "language" : "en",
                        "phrase" : "Russian"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ru",
                        "phrase" : "Russian"
                     }
                  ],
                  "language" : "ru",
                  "name" : "Institutional Repository Samara University"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               },
               {
                  "phrase" : "Civil Engineering",
                  "language" : "en",
                  "value" : "13"
               },
               {
                  "phrase" : "Electrical and Electronic Engineering",
                  "value" : "15",
                  "language" : "en"
               },
               {
                  "phrase" : "Mechanical Engineering and Materials",
                  "language" : "en",
                  "value" : "16"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides long-term and reliable open access to the results of university research. Access to some resources require a login.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://repo.ssau.ru/",
            "content_subjects" : [
               "25",
               "11",
               "13",
               "15",
               "16"
            ],
            "content_languages" : [
               "ru"
            ]
         }
      },
      {
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_at_request",
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "closure_policy_phrases" : [
                  {
                     "value" : "undefined",
                     "language" : "en",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "closure_policy" : "undefined"
            },
            "data_policy" : {
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ]
            },
            "submission_policy" : {
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  }
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "non_profit_reuse" : "allowed"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "subjects_phrases" : [
                  {
                     "value" : "1",
                     "language" : "en",
                     "phrase" : "Multidisciplinary"
                  }
               ],
               "subjects" : [
                  "1"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Rongo University"
               }
            ],
            "country" : "ke",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ke",
                  "phrase" : "Kenya"
               }
            ],
            "location" : {
               "longitude" : 34.6107,
               "latitude" : -0.8257
            },
            "url" : "http://rongovarsity.ac.ke/"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4631",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:25:30",
            "date_created" : "2019-07-10 09:07:56",
            "id" : 4631,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "url" : "http://repository.rongovarsity.ac.ke",
            "content_subjects" : [
               "10",
               "3",
               "7"
            ],
            "oai_url" : "http://repository.rongovarsity.ac.ke/oai/request?verb=ListRecords&metadataPrefix=oai_dc",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Rongo University Repository"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_other" : "AçıkArşiv",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "tr"
            ],
            "oai_url" : "https://acikarsiv.com/Home/Oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://acikarsiv.com/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Açık Erişim ve Kurumsal Arşiv",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 39.9325,
               "longitude" : 32.8315
            },
            "url" : "http://app.parantezteknoloji.com.tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "country" : "tr",
            "name" : [
               {
                  "name" : "Parantez Teknoloji Eğitim Bilişim Ltd. Şti",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 4628,
            "date_modified" : "2019-10-17 14:35:18",
            "date_created" : "2019-07-10 08:47:53",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4628",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "id",
            "location" : {
               "longitude" : 106.827,
               "latitude" : -6.17476
            },
            "url" : "https://www.cips-indonesia.org/",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Center for Indonesian Policy Studies",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "language" : "en",
                        "value" : "id"
                     }
                  ],
                  "language" : "id"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-07-10 08:46:49",
            "date_modified" : "2019-10-17 14:35:18",
            "id" : 4627,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4627",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name_other" : "Neliti",
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "id"
            ],
            "oai_url" : "https://repository.cips-indonesia.org/oai",
            "url" : "https://repository.cips-indonesia.org/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Center for Indonesian Policy Studies Institutional Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "id",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "language" : "id"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr",
                  "name" : "OpenKnowledge Ecology Repository"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "language" : "en",
                  "value" : "7"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://arsiv.ekoloji.org.tr/oai/request",
            "url" : "http://arsiv.ekoloji.org.tr",
            "content_subjects" : [
               "7"
            ],
            "content_languages" : [
               "tr"
            ]
         },
         "system_metadata" : {
            "id" : 4626,
            "date_created" : "2019-07-10 08:27:38",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4626",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "OpenKnowledge Ecology Repository"
               }
            ],
            "url" : "http://ekolojikolektifi.org/",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "country" : "tr"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "3.1",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ir.cuea.edu/jspui/",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "The Catholic University of Eastern Africa Digital Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4625",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4625,
            "date_created" : "2019-07-10 08:04:59",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "ke",
            "location" : {
               "latitude" : 47.37,
               "longitude" : 8.531
            },
            "url" : "http://www.cuea.edu/",
            "country_phrases" : [
               {
                  "phrase" : "Kenya",
                  "value" : "ke",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Catholic University of Eastern Africa"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ],
            "name" : [
               {
                  "name" : "Електронний репозиторій ХНАУ ім. В.В. Докучаєва",
                  "language" : "uk",
                  "language_phrases" : [
                     {
                        "value" : "uk",
                        "language" : "en",
                        "phrase" : "Ukrainian"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "uk"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.knau.kharkov.ua/jspui/",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-07-10 08:03:04",
            "id" : 4624,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4624"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "HNAU",
                  "language" : "uk",
                  "language_phrases" : [
                     {
                        "phrase" : "Ukrainian",
                        "value" : "uk",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "ua",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "url" : "https://knau.kharkov.ua/"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "10",
               "2",
               "8",
               "9",
               "14",
               "15",
               "16"
            ],
            "url" : "https://repozitorij.vub.hr/",
            "content_languages" : [
               "hr",
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "drupal",
                     "language" : "en",
                     "phrase" : "Drupal"
                  }
               ],
               "version" : "7",
               "name" : "drupal"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "value" : "8",
                  "language" : "en"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "language" : "en",
                  "value" : "9"
               },
               {
                  "language" : "en",
                  "value" : "14",
                  "phrase" : "Computers and IT"
               },
               {
                  "language" : "en",
                  "value" : "15",
                  "phrase" : "Electrical and Electronic Engineering"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Croatian",
                  "language" : "en",
                  "value" : "hr"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Repository of Bjelovar University of Applied Sciences"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-07-10 07:46:53",
            "id" : 4623,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4623"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Bjelovar University of Applied Sciences"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Croatia",
                  "value" : "hr",
                  "language" : "en"
               }
            ],
            "url" : "https://vub.hr/",
            "location" : {
               "longitude" : 16.8421,
               "latitude" : 45.8996
            },
            "country" : "hr"
         }
      },
      {
         "organisation" : {
            "country" : "ng",
            "url" : "https://www.com.ui.edu.ng/",
            "unit" : [
               {
                  "name" : "College of Medicine",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ng",
                  "phrase" : "Nigeria"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "University of Ibadan"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-07-10 07:38:44",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4622,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4622",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "ADHL",
                  "name" : "African Digital Health Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://adhlui.com.ui.edu.ng/oai/request",
            "content_subjects" : [
               "10"
            ],
            "url" : "http://adhlui.com.ui.edu.ng/",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "A repository of theses and dissertations from the College of Medicine, University of Ibadan, Nigeria funded by the Office of Global AIDS/U.S. Department of State and the U.S. National Library of Medicine / National Institutes of Health. The ADHL is a collaborative initiative of medical librarians in Kenya, Mali, Nigeria, Zambia and Zimbabwe.",
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universitat Oberta de Catalunya"
               }
            ],
            "country" : "es",
            "url" : "https://www.uoc.edu",
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4618",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4618,
            "date_created" : "2019-07-09 14:07:20",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ca",
               "en",
               "es"
            ],
            "url" : "http://openaccess.uoc.edu/webapps/o2/",
            "oai_url" : "http://openaccess.uoc.edu/webapps/dspace_rei_oai/request?",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Catalan",
                  "value" : "ca",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "name" : "L'Oberta en Obert"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "id" : 4616,
            "date_created" : "2019-07-09 14:10:49",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4616",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "https://btsau.edu.ua/en/",
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua",
            "name" : [
               {
                  "name" : "Bila Tserkva National Agrarian University"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "An electronic archive that collects, systematizes, preserves documents of scientific, educational and methodical purpose, created by employees of any structural subdivision of BNAU, postgraduate students or students of the University, by their archiving and self-archiving, as well as providing them with permanent free full-text access over the Internet.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "uk"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://rep.btsau.edu.ua",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Institutional Repository of Bila Tserkva National Agrarian University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Інституційний Репозитарій Білоцерківського НАУ",
                  "language" : "uk",
                  "language_phrases" : [
                     {
                        "phrase" : "Ukrainian",
                        "language" : "en",
                        "value" : "uk"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "uk",
                  "phrase" : "Ukrainian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "nl",
                  "language" : "en",
                  "phrase" : "Dutch"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "VU Research Portal"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://research.vu.nl/ws/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://research.vu.nl/",
            "content_languages" : [
               "nl",
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "pure",
               "name_phrases" : [
                  {
                     "value" : "pure",
                     "language" : "en",
                     "phrase" : "PURE"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site is a university repository providing access to the publication output of the Vrije Universiteit Amsterdam. The site interface is in English. VU Research Portal is integrated in NARCIS, the gateway to scholarly information in The Netherlands, which is part of DANS (Data Archiving and Networked Services), an institute of KNAW and NWO.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "Dutch",
                     "value" : "nl",
                     "language" : "en"
                  }
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "language" : "en",
                     "value" : "working_drafts"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "multi_institution_subject",
               "subjects" : [
                  "1"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "language" : "en",
                     "value" : "multi_institution_subject"
                  }
               ],
               "languages" : [
                  "nl"
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Multidisciplinary",
                     "value" : "1",
                     "language" : "en"
                  }
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "value" : "version_type_and_date",
                     "language" : "en"
                  },
                  {
                     "value" : "peer_review_status",
                     "language" : "en",
                     "phrase" : "peer-review status"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "language" : "en",
                     "value" : "repository_mention_required",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  }
               ],
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request_discouraged",
                        "phrase" : "Items may be removed at the request of the author/copyright holder but this is strongly discouraged"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_at_request_discouraged",
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "value" : "no",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "value" : "indefinite",
                           "language" : "en"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ],
                     "item_page" : [
                        "tombstone"
                     ],
                     "searchable" : "no"
                  }
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "language" : "en",
                        "value" : "errata_may_be_included"
                     },
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     }
                  ],
                  "policy" : [
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions"
               ]
            },
            "submission_policy" : {
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  },
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "valid layout and format",
                     "value" : "valid_formatting",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required"
               ],
               "moderation_purposes" : [
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "academic_staff",
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Employees",
                     "language" : "en",
                     "value" : "employees"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ]
            }
         },
         "organisation" : {
            "url" : "http://www.vu.nl/",
            "country_phrases" : [
               {
                  "phrase" : "Netherlands",
                  "language" : "en",
                  "value" : "nl"
               }
            ],
            "country" : "nl",
            "name" : [
               {
                  "name" : "Vrije Universiteit Amsterdam",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4612,
            "date_created" : "2019-06-28 10:05:44",
            "date_modified" : "2019-11-28 12:34:39",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4612"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-06-25 09:23:24",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4611,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4611"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "location" : {
               "longitude" : 29.8977,
               "latitude" : 39.4788
            },
            "url" : "http://www.dpu.edu.tr",
            "country" : "tr",
            "name" : [
               {
                  "name" : "Kütahya Dumlupınar University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Kütahya Dumlupınar University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "tr"
            ],
            "url" : "http://openaccess.dpu.edu.tr",
            "oai_url" : "http://openaccess.dpu.edu.tr/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish and English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://openaccess.biruni.edu.tr/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://openaccess.biruni.edu.tr",
            "content_languages" : [
               "en",
               "tr"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish or English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Biruni University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 28.9202,
               "latitude" : 41.0036
            },
            "url" : "https://www.biruni.edu.tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "country" : "tr",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Biruni University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-06-25 09:16:29",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4610,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4610"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Balıkesir University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "tr",
            "url" : "http://www.balikesir.edu.tr",
            "location" : {
               "latitude" : 39.5413,
               "longitude" : 28.007
            },
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4609",
            "publicly_visible" : "yes",
            "id" : 4609,
            "date_created" : "2019-06-25 09:04:45",
            "date_modified" : "2019-12-04 12:27:37"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Balıkesir University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish and English.",
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "tr"
            ],
            "url" : "http://dspace.balikesir.edu.tr",
            "oai_url" : "http://dspace.balikesir.edu.tr/oai",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://openaccess.amasya.edu.tr",
            "oai_url" : "http://openaccess.amasya.edu.tr/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "tr"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DigiTool",
                     "value" : "digitool",
                     "language" : "en"
                  }
               ],
               "version" : "6.2",
               "name" : "digitool"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish or English.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Amasya University Institutional Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ]
         },
         "organisation" : {
            "country" : "tr",
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ],
            "url" : "https://www.amasya.edu.tr",
            "location" : {
               "longitude" : 35.8053,
               "latitude" : 40.6535
            },
            "name" : [
               {
                  "name" : "Amasya University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4608",
            "publicly_visible" : "yes",
            "id" : 4608,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-06-25 08:53:35"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Nacional Hermilio Valdizán"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -9.9492,
               "longitude" : -76.2496
            },
            "url" : "https://www.unheval.edu.pe/portal/"
         },
         "system_metadata" : {
            "id" : 4607,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-06-20 07:37:45",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4607",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.unheval.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio de la Universidad Nacional Hermilio Valdizán"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "EUSpace"
               }
            ],
            "url" : "http://repository.elizadeuniversity.edu.ng/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4606",
            "publicly_visible" : "yes",
            "id" : 4606,
            "date_created" : "2019-06-19 08:32:28",
            "date_modified" : "2019-10-17 14:35:17"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Elizade University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "ng",
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "language" : "en",
                  "value" : "ng"
               }
            ],
            "url" : "https://www.elizadeuniversity.edu.ng/"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ko",
                  "language" : "en",
                  "phrase" : "Korean"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "KREi Repository"
               }
            ],
            "content_languages" : [
               "ko"
            ],
            "url" : "http://repository.krei.re.kr/",
            "oai_url" : "http://repository.krei.re.kr/oai",
            "content_subjects" : [
               "3",
               "24"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Korean.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "value" : "3",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               }
            ],
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4605",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4605,
            "date_created" : "2019-06-19 08:12:17",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "kr",
            "url" : "http://www.krei.re.kr/",
            "country_phrases" : [
               {
                  "phrase" : "Korea, Republic of",
                  "value" : "kr",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "한국농촌경제연구원",
                  "language" : "ko",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Korean",
                        "language" : "en",
                        "value" : "ko"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Korea Rural Economic Institute"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "br",
            "url" : "http://www.fieb.org.br/senai/",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "language" : "en",
                  "value" : "br"
               }
            ],
            "name" : [
               {
                  "name" : "Senai Bahia"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4604",
            "publicly_visible" : "yes",
            "id" : 4604,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-06-18 12:42:29"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositório da produção científica e intelectual do SENAI CIMATEC"
               }
            ],
            "content_languages" : [
               "en",
               "pt"
            ],
            "url" : "http://repositoriosenaiba.fieb.org.br/",
            "oai_url" : "http://repositoriosenaiba.fieb.org.br/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "organisation" : {
            "location" : {
               "longitude" : 106.878,
               "latitude" : 61138.8
            },
            "url" : "http://www.unj.ac.id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "country" : "id",
            "name" : [
               {
                  "name" : "Universitas Negeri Jakarta"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-21 09:25:45",
            "date_created" : "2019-06-18 12:39:01",
            "id" : 4603,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4603"
         },
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repository Universitas Negeri Jakarta",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in a mixture of English and Indonesian.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "id"
            ],
            "url" : "http://repository.unj.ac.id/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.unj.ac.id/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Arabic and English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "oai_url" : "http://repository.fue.edu.eg/oai/request?verb=Identify",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.fue.edu.eg",
            "name" : [
               {
                  "name" : "Future Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "FUE Digital Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4601",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4601,
            "date_modified" : "2019-12-04 12:27:37",
            "date_created" : "2019-06-18 12:25:12",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Future University in Egypt"
               }
            ],
            "country" : "eg",
            "country_phrases" : [
               {
                  "phrase" : "Egypt",
                  "language" : "en",
                  "value" : "eg"
               }
            ],
            "url" : "https://www.fue.edu.eg/",
            "location" : {
               "latitude" : 30.0272,
               "longitude" : 31.4917
            }
         }
      },
      {
         "organisation" : {
            "country" : "ni",
            "url" : "http://www.uam.edu.ni/",
            "location" : {
               "latitude" : 12.1085,
               "longitude" : -86.2571
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ni",
                  "phrase" : "Nicaragua"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad Americana"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-06-18 12:10:44",
            "id" : 4600,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4600"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://biblioteca.uam.edu.ni/oai/request",
            "url" : "http://biblioteca.uam.edu.ni/xmlui/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.6"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "name" : "Repositorio Universitario - UAM",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Polish",
                        "language" : "en",
                        "value" : "pl"
                     }
                  ],
                  "language" : "pl",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repozytorium Politechniki Krakowskiej"
               },
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of the Cracow University of Technology",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "pl"
            ],
            "url" : "https://repozytorium.biblos.pk.edu.pl/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Polish, German and English.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4599",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-06-18 10:28:42",
            "id" : 4599,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "name" : "Cracow University of Technology",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "pl",
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "url" : "https://www.pk.edu.pl/index.php?lang=en"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ar",
               "zh",
               "cs",
               "da",
               "nl",
               "en",
               "fi",
               "fr",
               "de",
               "el",
               "hu",
               "it",
               "pl",
               "pt",
               "ro",
               "ru",
               "es",
               "sv",
               "tr"
            ],
            "url" : "http://di.umons.ac.be/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research output of the institution. The interface is available in French and English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ar",
                  "language" : "en",
                  "phrase" : "Arabic"
               },
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "phrase" : "Czech",
                  "value" : "cs",
                  "language" : "en"
               },
               {
                  "value" : "da",
                  "language" : "en",
                  "phrase" : "Danish"
               },
               {
                  "phrase" : "Dutch",
                  "language" : "en",
                  "value" : "nl"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Finnish",
                  "value" : "fi",
                  "language" : "en"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               },
               {
                  "phrase" : "Greek (modern)",
                  "value" : "el",
                  "language" : "en"
               },
               {
                  "phrase" : "Hungarian",
                  "value" : "hu",
                  "language" : "en"
               },
               {
                  "value" : "it",
                  "language" : "en",
                  "phrase" : "Italian"
               },
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Polish"
               },
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               },
               {
                  "phrase" : "Romanian",
                  "value" : "ro",
                  "language" : "en"
               },
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "sv",
                  "language" : "en",
                  "phrase" : "Swedish"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "phrase" : "Software",
                  "language" : "en",
                  "value" : "software"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "value" : "fr",
                        "language" : "en"
                     }
                  ],
                  "language" : "fr",
                  "preferred" : "acronym",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "DI-UMONS",
                  "name" : "Dépôt institutionnel de l’université de Mons"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "software",
               "patents"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4598,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-06-18 10:15:52",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4598"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Mons",
                  "acronym" : "UMONS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ],
            "country" : "be",
            "url" : "https://web.umons.ac.be/en/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "be",
                  "phrase" : "Belgium"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "fr"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://hal-anses.archives-ouvertes.fr/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "hal",
                     "language" : "en",
                     "phrase" : "HAL"
                  }
               ],
               "name" : "hal"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in French or English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "HAL Anses"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4597,
            "date_created" : "2019-06-06 14:44:52",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4597"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "acronym",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Agence nationale de sécurité sanitaire de l’alimentation, de l’environnement et du travail",
                  "acronym" : "ANSES"
               }
            ],
            "url" : "https://www.anses.fr/fr",
            "country_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "France"
               }
            ],
            "country" : "fr"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "fr"
            ],
            "content_subjects" : [
               "17",
               "10",
               "2"
            ],
            "url" : "https://hal.sorbonne-universite.fr/",
            "software" : {
               "name" : "hal",
               "name_phrases" : [
                  {
                     "value" : "hal",
                     "language" : "en",
                     "phrase" : "HAL"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research output of the institution. The interface is available in French or English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Software",
                  "value" : "software",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "HAL Sorbonne Université"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "software",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4596",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-04 12:27:37",
            "date_created" : "2019-06-06 14:37:01",
            "id" : 4596,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "fr",
            "url" : "https://www.sorbonne-universite.fr/",
            "country_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "France"
               }
            ],
            "name" : [
               {
                  "name" : "Sorbonne Université"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "hr",
            "location" : {
               "longitude" : 15.9856,
               "latitude" : 45.8116
            },
            "url" : "http://www.ijf.hr/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "hr",
                  "phrase" : "Croatia"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institute of Public Finance, Zagreb"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-05-31 10:35:13",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4579,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4579",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "hr",
               "en"
            ],
            "url" : "https://repozitorij.ijf.hr/en",
            "oai_url" : "https://repozitorij.ijf.hr/oai",
            "content_subjects" : [
               "24"
            ],
            "software" : {
               "name" : "islandora",
               "name_phrases" : [
                  {
                     "phrase" : "islandora",
                     "language" : "en",
                     "value" : "islandora"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Croatian or English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Croatian",
                  "language" : "en",
                  "value" : "hr"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Repository of the Institute of Public Finance, Zagreb"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Dataverse UNIMI"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "datasets"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "Dataverse",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://dataverse.unimi.it/oai?verb=Identify",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://dataverse.unimi.it/",
            "content_languages" : [
               "en",
               "it"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universita degli Studi di Milano",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "it",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "it",
                        "language" : "en",
                        "phrase" : "Italian"
                     }
                  ]
               }
            ],
            "url" : "http://www.unimi.it/",
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "country" : "it"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4578",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-05-31 10:22:56",
            "id" : 4578
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "Oracle",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research output of the instituton. The interface is available in German or English. Some full text content is available from third party sites.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://www.hzdr.de/publications/OAI-PMH",
            "url" : "https://www.hzdr.de/robis",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "ROBIS"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "software",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Software",
                  "value" : "software",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4577,
            "date_created" : "2019-05-31 10:08:28",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4577"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "language" : "en",
                        "value" : "de"
                     }
                  ],
                  "language" : "de",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Helmholtz-Zentrum Dresden-Rossendorf"
               }
            ],
            "location" : {
               "longitude" : 8.531,
               "latitude" : 47.37
            },
            "url" : "https://www.hzdr.de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "country" : "de"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://dspace.umh.es/handle/11000/6",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "1.7.2",
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish and English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "name" : "RediUMH"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4575",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 4575,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-05-31 09:49:05",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Miguel Hernandez",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name"
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4573,
            "date_modified" : "2019-12-04 12:27:37",
            "date_created" : "2019-05-22 09:16:48",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4573"
         },
         "organisation" : {
            "url" : "https://www.cssd.ac.uk/",
            "unit" : [
               {
                  "name" : "Central Research and Creativity Online",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 51.5443,
               "longitude" : -0.1742
            },
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Royal Central School of Speech and Drama",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "content_embargo" : "no_deposit_until_embargo_expiry",
               "copyright" : [
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items may not be deposited until any embargo period has expired",
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry"
                  }
               ],
               "url" : [
                  "http://crco.cssd.ac.uk/policies.html"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "spam_exclusion",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ],
               "url" : [
                  "http://crco.cssd.ac.uk/policies.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "value" : "general_policy",
                     "language" : "en",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "not_for_profit_purposes"
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "withdrawal" : {
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "withdrawn_items" : {
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "url_retention" : "indefinite"
                  },
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "language" : "en",
                        "value" : "changes_not_permitted"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "url" : [
                  "http://crco.cssd.ac.uk/policies.html"
               ]
            },
            "content_policy" : {
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "peer_review_status",
                     "phrase" : "peer-review status"
                  }
               ],
               "url" : [
                  "http://crco.cssd.ac.uk/policies.html"
               ],
               "subjects_phrases" : [
                  {
                     "language" : "en",
                     "value" : "18",
                     "phrase" : "Fine and Performing Arts"
                  },
                  {
                     "phrase" : "Architecture",
                     "value" : "12",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "peer_review_status"
               ],
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "subjects" : [
                  "18",
                  "12"
               ],
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               }
            },
            "metadata_policy" : {
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://crco.cssd.ac.uk/policies.html"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "value" : "requires_permission",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Central Research and Creativity Online",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://crco.cssd.ac.uk",
            "oai_url" : "http://crco.cssd.ac.uk/cgi/oai2",
            "content_subjects" : [
               "18",
               "12"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "3.4.0",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository provides access to the research output of the institution. Some content may not be available as full-text. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "value" : "18",
                  "language" : "en"
               },
               {
                  "phrase" : "Architecture",
                  "language" : "en",
                  "value" : "12"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Munzur University Institutional Repository"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "tr"
            ],
            "oai_url" : "http://acikerisim.munzur.edu.tr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://acikerisim.munzur.edu.tr",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish or English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Munzur University"
               }
            ],
            "country" : "tr",
            "location" : {
               "latitude" : 39.0459,
               "longitude" : 39.5172
            },
            "url" : "https://www.munzur.edu.tr",
            "country_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkey"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-04-30 09:42:58",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4572,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4572",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "bibliographic_references",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Phaidra - Repository of the University of Veterinary Medicine, Vienna",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               },
               {
                  "value" : "it",
                  "language" : "en",
                  "phrase" : "Italian"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in English, German or Italian. Some items are not available as full text or are restricted. Special items include protocols",
            "software" : {
               "name" : "fedora",
               "name_phrases" : [
                  {
                     "value" : "fedora",
                     "language" : "en",
                     "phrase" : "Fedora"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de",
               "it"
            ],
            "url" : "https://phaidra.vetmeduni.ac.at",
            "content_subjects" : [
               "3"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4570",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 4570,
            "date_modified" : "2020-01-23 09:25:45",
            "date_created" : "2019-04-30 09:00:31",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "at",
            "url" : "https://www.vetmeduni.ac.at",
            "location" : {
               "longitude" : 16.37,
               "latitude" : 48.2545
            },
            "country_phrases" : [
               {
                  "value" : "at",
                  "language" : "en",
                  "phrase" : "Austria"
               }
            ],
            "name" : [
               {
                  "name" : "Vetmeduni Vienna",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4569",
            "publicly_visible" : "yes",
            "id" : 4569,
            "date_modified" : "2019-12-04 12:27:37",
            "date_created" : "2019-04-30 08:32:35"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Free University of Bozen - Bolzano"
               }
            ],
            "url" : "http://www.unibz.it",
            "country_phrases" : [
               {
                  "value" : "it",
                  "language" : "en",
                  "phrase" : "Italy"
               }
            ],
            "country" : "it"
         },
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "fr",
               "de",
               "it"
            ],
            "url" : "https://bia.unibz.it",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.6",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               },
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "it",
                  "phrase" : "Italian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Software",
                  "language" : "en",
                  "value" : "software"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "software",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "BIA",
                  "name" : "Bozen - Bolzano Institutional Archive"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "CBS",
                  "name" : "Copenhagen Business School",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "dk",
            "country_phrases" : [
               {
                  "phrase" : "Denmark",
                  "language" : "en",
                  "value" : "dk"
               }
            ],
            "location" : {
               "longitude" : 12.5308,
               "latitude" : 55.6816
            },
            "url" : "http://uk.cbs.dk/"
         },
         "system_metadata" : {
            "date_created" : "2019-04-30 08:25:49",
            "date_modified" : "2019-12-04 12:27:37",
            "id" : 4568,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4568",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "CBS Research Portal"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "pure",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "pure",
                     "phrase" : "PURE"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://research.cbs.dk/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "PlantaRum - Repository of the Institute for Plant Protection and Environment",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "sr",
                  "phrase" : "Serbian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Serbian and English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "software" : {
               "version" : "5.10",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "sr"
            ],
            "oai_url" : "http://plantarum.izbis.bg.ac.rs/oai",
            "url" : "http://plantarum.izbis.bg.ac.rs",
            "content_subjects" : [
               "4",
               "7"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Institute for Plant Protection and Environment",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "rs",
            "location" : {
               "latitude" : 44.7808,
               "longitude" : 20.4486
            },
            "url" : "http://www.izbis.bg.ac.rs",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "rs",
                  "phrase" : "Serbia"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-04-30 08:20:04",
            "date_modified" : "2019-12-04 12:25:31",
            "id" : 4567,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4567",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  },
                  {
                     "phrase" : "Serbian",
                     "value" : "sr",
                     "language" : "en"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en",
                  "sr"
               ],
               "url" : [
                  "http://plantarum.izbis.bg.ac.rs/Files/policy-plantarum-en.html"
               ],
               "subjects" : [
                  "7"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Ecology and Environment",
                     "value" : "7",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://plantarum.izbis.bg.ac.rs/Files/policy-plantarum-en.html"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "submission_policy" : {
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "depositors" : [
                  "academic_staff"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "rules" : [
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "url" : [
                  "http://plantarum.izbis.bg.ac.rs/Files/policy-plantarum-en.html"
               ],
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "individually_tagged",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "value" : "individually_tagged",
                     "language" : "en",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "url" : [
                  "http://plantarum.izbis.bg.ac.rs/Files/policy-plantarum-en.html"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "method" : "removed_from_public_view",
                  "special_reasons" : [
                     "Research containing major errors"
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ],
                     "searchable" : "no"
                  },
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "language" : "en",
                        "value" : "removal_not_normal"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "national_security",
                     "falsified_research"
                  ]
               },
               "url" : [
                  "http://plantarum.izbis.bg.ac.rs/Files/policy-plantarum-en.html"
               ],
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "link_between_versions"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn"
                     },
                     {
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified",
                        "value" : "link_between_versions",
                        "language" : "en"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "language" : "en",
                        "value" : "changes_not_permitted"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               }
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Iğdır Üniversitesi",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "tr"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "country" : "tr"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-24 09:52:19",
            "id" : 4565,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4565",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "tr"
            ],
            "content_subjects" : [
               "17",
               "18",
               "22",
               "10",
               "2",
               "3",
               "23",
               "24",
               "11"
            ],
            "url" : "http://acikerisim.igdir.edu.tr:8080/xmlui/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "4.1"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "value" : "22",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish, German or English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "name" : "Igdir Universitesi Acik Erisim Sistemi",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Bond University"
               }
            ],
            "url" : "http://www.bond.edu.au/",
            "location" : {
               "longitude" : 153.412,
               "latitude" : -28.0755
            },
            "country_phrases" : [
               {
                  "phrase" : "Australia",
                  "language" : "en",
                  "value" : "au"
               }
            ],
            "country" : "au"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-24 09:25:14",
            "id" : 4563,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4563"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Bond University Research Portal",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://research.bond.edu.au/",
            "oai_url" : "https://pure.bond.edu.au/ws/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "pure",
                     "language" : "en",
                     "phrase" : "PURE"
                  }
               ],
               "name" : "pure"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Erzincan Binali Yıldırım University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Turkish or English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "tr"
            ],
            "content_subjects" : [
               "24"
            ],
            "oai_url" : "http://earsiv.erzincan.edu.tr/oai",
            "url" : "http://earsiv.erzincan.edu.tr",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4562",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-24 09:06:10",
            "id" : 4562
         },
         "organisation" : {
            "location" : {
               "longitude" : 39.5149,
               "latitude" : 39.7463
            },
            "url" : "http://www.ebyu.edu.tr/tr/",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "country" : "tr",
            "name" : [
               {
                  "preferred" : "name",
                  "name" : "Erzincan Binali Yıldırım University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "Ardahan University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://openaccess.ardahan.edu.tr/oai",
            "content_subjects" : [
               "2",
               "23",
               "24"
            ],
            "url" : "http://openaccess.ardahan.edu.tr",
            "content_languages" : [
               "tr"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the ersearch output of the institution. The interface is available in Turkish or English.",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Ardahan University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "location" : {
               "latitude" : 41.1313,
               "longitude" : 42.7804
            },
            "url" : "https://www.ardahan.edu.tr/",
            "country" : "tr"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4561,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-24 08:59:46",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4561"
         }
      },
      {
         "organisation" : {
            "country" : "es",
            "url" : "http://www.irta.cat",
            "location" : {
               "longitude" : 2.1693,
               "latitude" : 41.6134
            },
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "IRTA",
                  "name" : "Institut de Recerca i Tecnologia Agroalimentaries",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4560",
            "publicly_visible" : "yes",
            "id" : 4560,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-08 10:17:31"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This repository hosts the research output of the institution. The interface is available in Catalan, Spanish and English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositori.irta.cat/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ca",
               "en",
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "name" : "IRTA Pubpro",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Catalan",
                  "value" : "ca",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "cl",
            "country_phrases" : [
               {
                  "value" : "cl",
                  "language" : "en",
                  "phrase" : "Chile"
               }
            ],
            "url" : "https://www.uach.cl/",
            "location" : {
               "longitude" : -73.2518,
               "latitude" : -39.8061
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "UACh",
                  "name" : "Universidad Austral de Chile",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4559",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:37",
            "date_created" : "2019-04-05 12:54:03",
            "id" : 4559
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://rea.uach.cl/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://rea.uach.cl/oai/request",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Recursos Educativos Abiertos - Universidad Austral de Chile",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Open Educational Resources at the Austral University of Chile",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               },
               {
                  "phrase" : "Ukrainian",
                  "value" : "uk",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "elarTSATU",
                  "name" : "Electronic Institutional Repository of the Tavria State Agrotechnological University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://elar.tsatu.edu.ua/oai/request?verb=Identify",
            "url" : "http://elar.tsatu.edu.ua/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "ru",
               "uk"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Ukrainian, Russian and English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4558,
            "date_created" : "2019-04-05 12:48:38",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4558",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Tavria State Agrotechnological University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "uk",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Ukrainian",
                        "language" : "en",
                        "value" : "uk"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "ТАВРІЙСЬКИЙ ДЕРЖАВНИЙ АГРОТЕХНОЛОГІЧНИЙ УНІВЕРСИТЕТ"
               }
            ],
            "country" : "ua",
            "url" : "http://www.tsatu.edu.ua",
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Mimasaka University & Mimasaka Junior College",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "url" : "http://mimasaka.jp/",
            "location" : {
               "latitude" : 35.0766,
               "longitude" : 134.008
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-04-05 12:42:45",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4557,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4557",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://mimasaka.repo.nii.ac.jp/",
            "content_languages" : [
               "en",
               "ja"
            ],
            "name" : [
               {
                  "name" : "Mimasaka University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-05 12:30:08",
            "id" : 4556,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4556"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "St. Kliment Ohridski University, Bitola",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "acronym" : "UKLO",
                  "name" : "Универзитет „Св. Климент Охридски“ - Битола",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Macedonian",
                        "value" : "mk",
                        "language" : "en"
                     }
                  ],
                  "language" : "mk",
                  "preferred" : "name"
               }
            ],
            "country" : "mk",
            "url" : "http://www.uklo.edu.mk/",
            "location" : {
               "latitude" : 41.032,
               "longitude" : 21.3297
            },
            "country_phrases" : [
               {
                  "phrase" : "North Macedonia",
                  "language" : "en",
                  "value" : "mk"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "mk",
                  "phrase" : "Macedonian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "UKLO repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.uklo.edu.mk/",
            "content_languages" : [
               "en",
               "mk"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.upoli.edu.ni/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio UPOLI",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Politecnica de Nicaragua",
                  "acronym" : "UPOLI",
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               },
               {
                  "name" : "Polytechnical Univeristy of Nicaragua",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "ni",
            "country_phrases" : [
               {
                  "value" : "ni",
                  "language" : "en",
                  "phrase" : "Nicaragua"
               }
            ],
            "url" : "https://www.upoli.edu.ni/",
            "location" : {
               "longitude" : -86.2207,
               "latitude" : 12.1381
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-05 12:18:05",
            "id" : 4555,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4555"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "https://archined.ined.fr/",
            "content_languages" : [
               "en",
               "fr"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in French and English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_other" : "Polaris OS",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "French"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "name" : "L'archive ouverte de L'Ined",
                  "acronym" : "ARCHined",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language" : "fr",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 2.40884,
               "latitude" : 48.858
            },
            "url" : "https://www.ined.fr/",
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "country" : "fr",
            "name" : [
               {
                  "acronym" : "INDED",
                  "name" : "Institut national d'études démographiques",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr",
                  "preferred" : "name"
               },
               {
                  "name" : "National Institute of Demographic Studies",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4554",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-04-05 12:12:10",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4554,
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4553,
            "date_created" : "2019-04-05 10:40:41",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4553"
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://www.newhaven.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "University of New Haven",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "digital_commons",
                     "phrase" : "Digital Commons"
                  }
               ],
               "name" : "digital_commons"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcommons.newhaven.edu",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Digital Commons @ New Haven",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "http://biblioteca.cenicafe.org/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Repository of the National Coffee Research Centre",
                  "acronym" : "CENICAFE",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "CENICAFE",
                  "name" : "Repositorio digital del Centro Nacional de Investigaciones de Cafe"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Centro nacional de investigaciones de Café, Manizales",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -75.509,
               "latitude" : 5.08
            },
            "url" : "http://www.cenicafe.org/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "co",
                  "phrase" : "Colombia"
               }
            ],
            "country" : "co"
         },
         "system_metadata" : {
            "id" : 4552,
            "date_created" : "2019-04-05 10:32:47",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4552",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 137.185,
               "latitude" : 34.9547
            },
            "url" : "http://www.okazaki-u.ac.jp/",
            "country" : "jp",
            "name" : [
               {
                  "name" : "Okazaki Women's University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-05 10:24:29",
            "id" : 4551,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4551"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Academic Repository of Okazaki Women's University and Okazaki Women's Junior College",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://okazaki.repo.nii.ac.jp/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4550",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-04-05 09:52:58",
            "date_modified" : "2019-12-04 12:27:37",
            "id" : 4550,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "India",
                  "value" : "in",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 23.2133,
               "longitude" : 72.6852
            },
            "url" : "http://iitgn.ac.in",
            "country" : "in",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Indian Institute of Technology Gandhinagar",
                  "acronym" : "IIT"
               }
            ]
         },
         "repository_metadata" : {
            "url" : "https://repository.iitgn.ac.in",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.iitgn.ac.in/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "4.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "IIT Gandhinagar Digital Repository",
                  "acronym" : "IITDR",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "notes" : "Other Special items include photographic presentations",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4549,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-05 09:33:22",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4549"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Ar-Raniry State Islamic University, Banda Aceh",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universitas Islam Negeri Ar-Raniry Banda Aceh",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "value" : "id",
                        "language" : "en"
                     }
                  ],
                  "language" : "id",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "location" : {
               "longitude" : 95.367,
               "latitude" : 5.57765
            },
            "url" : "http://ar-raniry.ac.id",
            "country" : "id"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repository.ar-raniry.ac.id/",
            "content_languages" : [
               "id"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Institutional Repository of UIN Ar-Raniry, Banda Aceh",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Knowledge Bank of the Health Systems Research Institute",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "คลังข้อมูลและความรู้ระบบสุขภาพ",
                  "language" : "th",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "th",
                        "phrase" : "Thai"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "th",
                  "language" : "en",
                  "phrase" : "Thai"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Thai.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "th"
            ],
            "url" : "http://kb.hsri.or.th",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://kb.hsri.or.th:8080/dspace-oai"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4548,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-05 09:25:54",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4548"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Health Systems Research Institute",
                  "acronym" : "HSRI",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Thai",
                        "value" : "th",
                        "language" : "en"
                     }
                  ],
                  "language" : "th",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "สถาบันวิจัยระบบสาธารณสุข"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "th",
                  "phrase" : "Thailand"
               }
            ],
            "url" : "https://www.hsri.or.th",
            "location" : {
               "latitude" : 13.8516,
               "longitude" : 100.531
            },
            "country" : "th"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4547",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-05 09:20:07",
            "id" : 4547,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "UFAM",
                  "name" : "Universidade Federal do Amazonas, Manaus",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "pt"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Federal University of the Amazon, Manaus"
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "http://ufam.edu.br/",
            "location" : {
               "longitude" : -59.975,
               "latitude" : -3.10032
            }
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://200.129.163.19:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://riu.ufam.edu.br/",
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Portugese.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "acronym" : "RIU",
                  "name" : "Repositório Institucional da UFAM",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ],
                  "language" : "pt",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4545",
            "publicly_visible" : "yes",
            "id" : 4545,
            "date_created" : "2019-04-04 14:36:21",
            "date_modified" : "2019-10-17 14:35:17"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "url" : "https://unir.net",
            "country" : "es",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Internacional de La Rioja, Logroño",
                  "acronym" : "UNIR"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 7133,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Repository of the International University of La Rioja",
                  "acronym" : "Re-UNIR",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "oai_url" : "https://reunir.unir.net/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://reunir.unir.net",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.6"
            },
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages" : [
               "es"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Acervo Digital Institucional en Seguridad Social",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://biblioteca.ciess.org/adiss/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_other" : "CWIS",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish."
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Centro Interamericano de Estudios de Seguridad Social",
                  "acronym" : "CIESS"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "mx",
                  "phrase" : "Mexico"
               }
            ],
            "url" : "http://ciess.org",
            "country" : "mx"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4544",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-04 14:29:24",
            "id" : 4544,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Digital Repository of the University of Peradeniya",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dlib.pdn.ac.lk/"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Peradeniya"
               }
            ],
            "url" : "http://www.pdn.ac.lk/",
            "location" : {
               "latitude" : 7.2566,
               "longitude" : 80.5966
            },
            "country_phrases" : [
               {
                  "value" : "lk",
                  "language" : "en",
                  "phrase" : "Sri Lanka"
               }
            ],
            "country" : "lk"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4542,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-04 10:18:40",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4542"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "islandora",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "islandora",
                     "phrase" : "islandora"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://mediateca.inah.gob.mx/islandora_74/islandora/search",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "name" : "INAH - Mediateca",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Instituto Nacional de Antropología e Historia",
                  "acronym" : "INAH",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "mx",
            "country_phrases" : [
               {
                  "phrase" : "Mexico",
                  "language" : "en",
                  "value" : "mx"
               }
            ],
            "url" : "http://www.inah.gob.mx",
            "location" : {
               "longitude" : -99.1652,
               "latitude" : 19.4264
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4541",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-04-04 08:39:24",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4541,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "description" : "The interface is in Latvian.",
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de",
               "lv"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://academia.lndb.lv/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "aggregating",
            "name" : [
               {
                  "name" : "Academia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               },
               {
                  "phrase" : "Latvian",
                  "language" : "en",
                  "value" : "lv"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4540,
            "date_created" : "2019-04-03 15:38:14",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4540"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "lv",
                  "phrase" : "Latvia"
               }
            ],
            "url" : "http://lnb.lv/",
            "location" : {
               "latitude" : 47.37,
               "longitude" : 8.531
            },
            "country" : "lv",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "National Library of Latvia",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4539",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 4539,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-03 15:00:42",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "url" : "http://www.kandagaigo.ac.jp/kuis/",
            "location" : {
               "latitude" : 35.6572,
               "longitude" : 40.0439
            },
            "name" : [
               {
                  "name" : "Kanda University of International Studies",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "url" : [
                  "http://kuis.libguides.com/copyright_asKUIS"
               ]
            }
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Academic and Scholarly Repository of KUIS"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://kuis.repo.nii.ac.jp/",
            "oai_url" : "http://kuis.repo.nii.ac.jp/oai",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This repository hosts the research output of the institution. The interface is available in Japanese.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://alejandria.poligran.edu.co/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Alejandria - Repositorio Comunidad Politécnico Grancolombiano",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "date_created" : "2019-04-03 13:58:24",
            "date_modified" : "2019-10-17 14:35:17",
            "id" : 4538,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4538",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.poligran.edu.co",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "co",
                  "phrase" : "Colombia"
               }
            ],
            "country" : "co",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "name" : "Politecnico Grancolombiano, Bogotá",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4537,
            "date_created" : "2019-04-03 13:54:26",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4537"
         },
         "organisation" : {
            "country" : "lt",
            "url" : "http://www.mab.lt/en/home",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "lt",
                  "phrase" : "Lithuania"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Wroblewski Library of the Lithuanian Academy of Sciences, Vilnius"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "url" : "https://elibrary.mab.lt/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "lt"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of the Wroblewski Library, Lithuanian Academy of Sciences"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Lithuanian",
                  "language" : "en",
                  "value" : "lt"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "ua",
            "url" : "http://www.zgia.zp.ua/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Zaporizhzhya State Engineering Academy",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4536",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 4536,
            "date_created" : "2019-04-03 13:41:23",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ],
            "name" : [
               {
                  "name" : "Zaporizhzhya State Engineering Academy Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "uk"
            ],
            "url" : "http://dspace.zsea.edu.ua/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English, Ukrainian and Russian."
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "2",
               "6",
               "7"
            ],
            "url" : "http://siam.invemar.org.co/documentos",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Environmental Marine Information System Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-03 13:26:48",
            "id" : 4535,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4535",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "José Benito Vives de Andréis Marine and Coastal Research Institute, Santa Marta"
               }
            ],
            "location" : {
               "longitude" : -74.2211,
               "latitude" : 11.2404
            },
            "url" : "http://www.invemar.org.co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "country" : "co"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Hacettepe University, Ankara",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "Hacettepe Üniversitesi",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "tr"
               }
            ],
            "country" : "tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "url" : "http://www.hacettepe.edu.tr/",
            "location" : {
               "latitude" : 39.9334,
               "longitude" : 32.8597
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4534",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 4534,
            "date_created" : "2019-04-03 13:12:20",
            "date_modified" : "2019-10-17 14:35:17",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Turkish",
                  "value" : "tr",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Hacettepe University Thesis Archive",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "tr"
            ],
            "url" : "http://bbytezarsivi.hacettepe.edu.tr/jspui",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site hosts an archive of research theses from the institution. The interface is in Turkish."
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Toyama Science Museum Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "http://repo.tsm.toyama.toyama.jp/oai",
            "url" : "http://repo.tsm.toyama.toyama.jp/",
            "content_subjects" : [
               "2",
               "3",
               "4",
               "5",
               "6",
               "7",
               "8",
               "9"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Biology and Biochemistry",
                  "value" : "4",
                  "language" : "en"
               },
               {
                  "value" : "5",
                  "language" : "en",
                  "phrase" : "Chemistry and Chemical Technology"
               },
               {
                  "phrase" : "Earth and Planetary Sciences",
                  "language" : "en",
                  "value" : "6"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "value" : "8",
                  "language" : "en"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "value" : "9",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4533",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-03 08:53:40",
            "id" : 4533,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "http://www.tsm.toyama.toyama.jp/",
            "location" : {
               "latitude" : 36.6809,
               "longitude" : 137.212
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Toyama Science Museum"
               },
               {
                  "name" : "富山市科学博物館",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "ja",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 4532,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-04-03 08:42:26",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4532",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.kpu.edu.rs/cms/",
            "location" : {
               "latitude" : 44.8558,
               "longitude" : 20.387
            },
            "country_phrases" : [
               {
                  "phrase" : "Serbia",
                  "language" : "en",
                  "value" : "rs"
               }
            ],
            "country" : "rs",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Criminal Investigation and Police Studies",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  },
                  {
                     "value" : "sr",
                     "language" : "en",
                     "phrase" : "Serbian"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "subjects_phrases" : [
                  {
                     "phrase" : "Science General",
                     "value" : "2",
                     "language" : "en"
                  }
               ],
               "subjects" : [
                  "2"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://jakov.kpu.edu.rs/Files/policy-jakov-en.html"
               ],
               "languages" : [
                  "en",
                  "sr"
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://jakov.kpu.edu.rs/Files/policy-jakov-en.html"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed"
            },
            "data_policy" : {
               "url" : [
                  "http://jakov.kpu.edu.rs/Files/policy-jakov-en.html"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "individually_tagged",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "individually_tagged",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://jakov.kpu.edu.rs/Files/policy-jakov-en.html"
               ],
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "earlier_versions_may_be_withdrawn",
                        "language" : "en",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     },
                     {
                        "language" : "en",
                        "value" : "link_between_versions",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "link_between_versions"
                  ]
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "indefinite"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     },
                     {
                        "language" : "en",
                        "value" : "other",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "special_reasons" : [
                     "Research containing major errors"
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "national_security",
                     "falsified_research",
                     "other"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal"
               }
            },
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "moderation" : "yes",
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "url" : [
                  "http://jakov.kpu.edu.rs/Files/policy-jakov-en.html"
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "academic_staff"
               ]
            }
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "sr",
                  "language" : "en",
                  "phrase" : "Serbian"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Jakov - Repository of the University of Criminal Investigation and Police Studies, Belgrade"
               }
            ],
            "url" : "http://jakov.kpu.edu.rs/",
            "oai_url" : "http://jakov.kpu.edu.rs/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "sr"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Serbian and English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            }
         }
      },
      {
         "organisation" : {
            "country" : "ug",
            "country_phrases" : [
               {
                  "phrase" : "Uganda",
                  "value" : "ug",
                  "language" : "en"
               }
            ],
            "url" : "http://bsu.ac.ug",
            "location" : {
               "longitude" : 30.6942,
               "latitude" : -0.604317
            },
            "name" : [
               {
                  "name" : "Bishop Stuart University, Mbarara"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4531,
            "date_modified" : "2019-10-17 14:35:17",
            "date_created" : "2019-03-29 15:59:58",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4531",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "BSUSpace",
                  "name" : "Bishop Stuart University Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://ir.bsu.ac.ug",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Repositorio Digital Institucional Universidad de Buenos Aires",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "pt",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "pt",
                        "phrase" : "Portuguese"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "greenstone",
                     "phrase" : "Greenstone"
                  }
               ],
               "name" : "greenstone"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositoriouba.sisbi.uba.ar",
            "content_languages" : [
               "en",
               "es"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "University of Buenos Aires",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "ar",
            "location" : {
               "latitude" : -34.5997,
               "longitude" : -58.373
            },
            "url" : "http://www.uba.ar/",
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4530,
            "date_created" : "2019-03-29 15:50:48",
            "date_modified" : "2019-12-04 12:27:36",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4530"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4529",
            "publicly_visible" : "yes",
            "id" : 4529,
            "date_created" : "2019-03-29 15:34:02",
            "date_modified" : "2019-10-17 14:35:17"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Korea Polar Research Institute",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "kr",
            "country_phrases" : [
               {
                  "phrase" : "Korea, Republic of",
                  "value" : "kr",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 37.3689,
               "longitude" : 126.647
            },
            "url" : "http://www.kopri.re.kr/"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Korean",
                  "value" : "ko",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "KOPRI",
                  "name" : "Korean Polar Research Institute Repository"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.kopri.re.kr/",
            "content_languages" : [
               "en",
               "ko"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Wakayama University Academic Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "和歌山大学学術リポジトリ"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "http://repository.center.wakayama-u.ac.jp/",
            "oai_url" : "http://repository.center.wakayama-u.ac.jp/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Japanese.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Wakayama University"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "location" : {
               "longitude" : 135.152,
               "latitude" : 34.2659
            },
            "url" : "http://wakayama-u.ac.jp",
            "country" : "jp"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4527",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-29 14:21:19",
            "id" : 4527,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Iran University of Medical Sciences",
                  "acronym" : "IUMS",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Iran, Islamic Republic of",
                  "value" : "ir",
                  "language" : "en"
               }
            ],
            "url" : "http://www.iums.ac.ir",
            "location" : {
               "latitude" : 35.7486,
               "longitude" : 51.3805
            },
            "country" : "ir"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-29 14:01:54",
            "id" : 4526,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4526"
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "url" : "http://eprints.iums.ac.ir/",
            "content_subjects" : [
               "10"
            ],
            "content_languages" : [
               "en",
               "fa"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of the Iran University of Medical Sciences, Tehran"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "fa",
                  "phrase" : "Persian (Farsi)"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         }
      },
      {
         "organisation" : {
            "location" : {
               "longitude" : 33.777,
               "latitude" : -13.9502
            },
            "url" : "https://ubuntunet.net/",
            "country_phrases" : [
               {
                  "phrase" : "Malawi",
                  "value" : "mw",
                  "language" : "en"
               }
            ],
            "country" : "mw",
            "name" : [
               {
                  "name" : "UbuntuNet Alliance"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:36",
            "date_created" : "2019-03-29 13:53:08",
            "id" : 4525,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4525"
         },
         "repository_metadata" : {
            "description" : "UbuntuNet contains proceedings, papers, presentations, memoranda of understanding and other core documents of the UbuntuNet Alliance. The site's interface is in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repository.ubuntunet.net",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "UbuntuNet Alliance Repository"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-03-29 11:46:48",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4524,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4524"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "es",
                  "acronym" : "CONACYT",
                  "name" : "Consejo Nacional de Ciencia y Tecnologia",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               },
               {
                  "name" : "National Council for Science and Technology",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "mx",
            "country_phrases" : [
               {
                  "phrase" : "Mexico",
                  "value" : "mx",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -99.1817,
               "latitude" : 19.3646
            },
            "url" : "http://www.conacyt.mx"
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "aggregating",
                  "language" : "en",
                  "phrase" : "Aggregating"
               }
            ],
            "description" : "The Repositorio Nacional is a digital platform that provides access to the full text of various academic, scientific and technologicalresources and information without subscription, registration or payment requirements. It includes: scientific journal articles, theses from institutions of higher education, research protocols, memoirs of congresses and patents, as well as other academic documents that are produced in Mexico with public funds. The interface is available in Spanish and English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "https://repositorionacionalcti.mx/",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Nacional"
               },
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "National Repository of Mexico"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects"
            ],
            "type" : "aggregating",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "SIOR",
                  "name" : "Social Impact Open Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "SIOR (Social Impact Open Repository) is an open access repository to display, share and store the social impact of research results. Achieving impact is a growing demand from society to science and to scientists, but this information had not yet been systematically gathered and registered. SIOR is the first open access worldwide registry on social impact, a non-profit initiative to enhance scientific research with social impact.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "es"
            ],
            "url" : "http://sior.ub.edu",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4523,
            "date_created" : "2019-03-29 11:38:23",
            "date_modified" : "2019-10-17 14:35:16",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4523",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Barcelona"
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "url" : "http://www.ub.edu",
            "location" : {
               "latitude" : 41.3851,
               "longitude" : 2.1753
            }
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-29 11:21:09",
            "id" : 4522,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4522",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ir",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ir",
                  "phrase" : "Iran, Islamic Republic of"
               }
            ],
            "location" : {
               "latitude" : 36.3196,
               "longitude" : 59.5296
            },
            "url" : "http://www.mums.ac.ir",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Mashhad University of Medical Sciences",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Mashhad University of Medical Sciences Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "fa",
                  "phrase" : "Persian (Farsi)"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "fa"
            ],
            "url" : "http://eprints.mums.ac.ir/",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "co",
            "location" : {
               "latitude" : 4.6066,
               "longitude" : -74.0678
            },
            "url" : "http://www.utadeo.edu.co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "value" : "co",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Bogotá Jorge Tadeo Lozano",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-03-29 10:29:58",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4521,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4521",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution.\r\nThe interface is available in Spanish, Portugese and English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://expeditiorepositorio.utadeo.edu.co/tadeo/oai",
            "url" : "http://expeditiorepositorio.utadeo.edu.co",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "pt",
               "es"
            ],
            "name" : [
               {
                  "name" : "Expeditio",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "ua",
            "location" : {
               "longitude" : 28.4966,
               "latitude" : 49.2419
            },
            "url" : "http://vspu.edu.ua/",
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "language" : "en",
                  "value" : "ua"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Vinnytsia Mykhailo Kotsiubynskyi State Pedagogical University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-29 10:14:10",
            "id" : 4520,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4520"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Інституційний репозитарій Вінницького державного педагогічного університету імені Михайла Коцюбинського",
                  "acronym" : "IrVSPU",
                  "language" : "uk",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "Ukrainian",
                        "language" : "en",
                        "value" : "uk"
                     }
                  ]
               },
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Institutional Repository of Vinnitsa State Pedagogical University named after Mikhail Kotsyubinsky"
               }
            ],
            "url" : "http://library.vspu.net/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "uk"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Ukrainian and Russian.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "ArODES - Haute école spécialisée de Suisse occidentale",
                  "acronym" : "HES-SO"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in German, French or English. Some content is not available as open access.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "invenio",
                     "language" : "en",
                     "value" : "invenio"
                  }
               ],
               "name" : "invenio"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "https://arodes.hes-so.ch/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "HES-SOUniversity of Applied Sciences and Arts Western Switzerland",
                  "acronym" : "HES-SO"
               },
               {
                  "acronym" : "HES-SO",
                  "name" : "Haute école spécialisée de Suisse occidentale",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "fr"
               },
               {
                  "language" : "de",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "de",
                        "phrase" : "German"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "HES-SO Fachhochschule Westschweiz",
                  "acronym" : "HES-SO"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ch",
                  "phrase" : "Switzerland"
               }
            ],
            "url" : "https://www.hes-so.ch/",
            "country" : "ch"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4519",
            "publicly_visible" : "yes",
            "id" : 4519,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-29 10:03:09"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "10"
            ],
            "url" : "https://soar.usa.edu",
            "oai_url" : "https://soar.usa.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "SOAR@USA: Scholarship and Open Access Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "USA",
                  "name" : "University of St. Augustine for Health Sciences"
               }
            ],
            "country" : "us",
            "location" : {
               "latitude" : 29.8633,
               "longitude" : -81.3149
            },
            "url" : "https://www.usa.edu",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-06 08:54:48",
            "date_created" : "2019-03-29 09:50:45",
            "id" : 4518,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4518"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad Continental, Lima",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.continental.edu.pe"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4517,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-28 15:00:22",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4517"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Continental Institutional Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "name" : "Repositorio Institucional - Continental",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish, German, Italian, French, Japanese, Portugese and English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.continental.edu.pe",
            "oai_url" : "http://repositorio.continental.edu.pe/oai/request?verb=Identify",
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://repository.eac.int/",
            "content_subjects" : [
               "23",
               "24",
               "25",
               "26"
            ],
            "oai_url" : "http://repository.eac.int/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "The EAC Information Repository is a one-stop-shop platform of digital information and knowledge generated by EAC Organs and Institutions in execution of their various mandates since 1993.  It contains mainly institution-specific documents including: treaties, protocols, development strategies, studies, speeches, parliamentary debates, court proceedings, photos, videos and documentaries of key events and milestones of the EAC integration process.   The interface is in English.",
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "East African Community Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "governmental"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4516",
            "publicly_visible" : "yes",
            "id" : 4516,
            "date_created" : "2019-03-28 11:05:08",
            "date_modified" : "2019-12-04 12:27:36"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "East African Community",
                  "acronym" : "EAC"
               }
            ],
            "url" : "http://eac.int",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tz",
                  "phrase" : "Tanzania, United Republic of"
               }
            ],
            "country" : "tz"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio Digital Universidad del Quindío"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish and English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "url" : "http://bdigital.uniquindio.edu.co/",
            "oai_url" : "https://bdigital.uniquindio.edu.co/oai/request?verb=Identify",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad del Quindío",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Quindio University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "url" : "https://www.uniquindio.edu.co/"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-03-28 10:05:05",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4515,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4515"
         }
      },
      {
         "system_metadata" : {
            "id" : 4514,
            "date_created" : "2019-03-27 14:39:05",
            "date_modified" : "2019-10-17 14:35:16",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4514",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 13.3697,
               "latitude" : 52.5069
            },
            "url" : "https://www.iai.spk-berlin.de/en/home.html",
            "country" : "de",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Ibero-Amerikanisches Institut",
                  "language" : "de",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "German",
                        "value" : "de",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Institutional Repository of the Ibero-American Institute, Berlin",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://publications.iai.spk-berlin.de/content/main/index.xml?lang=en",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://publications.iai.spk-berlin.de/servlets/OAIDataProvider",
            "content_languages" : [
               "en",
               "de"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "mycore",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "mycore",
                     "phrase" : "MyCoRe"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in German, Spanish, Portugese and English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "ug",
                  "language" : "en",
                  "phrase" : "Uganda"
               }
            ],
            "url" : "https://mubs.ac.ug",
            "location" : {
               "longitude" : 32.6171,
               "latitude" : 0.328011
            },
            "country" : "ug",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Makerere University Business School",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4513,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-27 14:20:27",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4513"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Makerere University Business School Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://mubsir.mubs.ac.ug",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Busitema University"
               }
            ],
            "country" : "ug",
            "location" : {
               "longitude" : 34.0198,
               "latitude" : 0.545317
            },
            "url" : "http://www.busitema.ac.ug/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ug",
                  "phrase" : "Uganda"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-27 14:12:49",
            "id" : 4512,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4512",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "url" : "http://ir.busitema.ac.ug/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Busitema University Open Access Digital Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Kampala International University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "ug",
            "country_phrases" : [
               {
                  "phrase" : "Uganda",
                  "value" : "ug",
                  "language" : "en"
               }
            ],
            "url" : "http://www.kiu.ac.ug",
            "location" : {
               "longitude" : 32.6051,
               "latitude" : 0.294631
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4511",
            "publicly_visible" : "yes",
            "date_created" : "2019-03-27 14:02:58",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4511
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.ir.kiu.ac.ug",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Kampala International University Institutional Repository",
                  "acronym" : "KIUIR",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Instituto de Pesquisas Energeticas e Nucleares",
                  "acronym" : "IPEN"
               }
            ],
            "url" : "http://www.ipen.br",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "value" : "br",
                  "language" : "en"
               }
            ],
            "country" : "br"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4510",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-03-27 13:46:40",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4510,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "pt",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositorio IPEN"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "9"
            ],
            "url" : "http://repositorio.ipen.br",
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "value" : "9",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Portugese."
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "SEGEMAR",
                  "name" : "Servicio Geológico Minero Argentino"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Argentine Geological Mining Service",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "ar",
            "url" : "http://www.segemar.gov.ar/",
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "value" : "ar",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4509",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-03-27 10:57:40",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4509,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Institucional SEGEMAR",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "governmental",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "6",
                  "language" : "en",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "language" : "en",
                  "value" : "7",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "language" : "en",
                  "value" : "13",
                  "phrase" : "Civil Engineering"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "description" : "This is the Institutional Repository of the Argentine Geological and Mining Survey. Most of its contents can be broadly linked to these areas, though it is possible to find technical reports on related sciences, such as Paleontology. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "6",
               "7",
               "13",
               "16"
            ],
            "url" : "http://repositorio.segemar.gob.ar",
            "oai_url" : "http://repositorio.segemar.gob.ar/oai/"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Polish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Polish Theological Society Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "pl",
                        "language" : "en",
                        "phrase" : "Polish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "pl",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repozytorium Instytucjonalne Polskiego Towarzystwa Teologicznego"
               }
            ],
            "url" : "https://repozytorium.ptt.net.pl/xmlui/",
            "content_subjects" : [
               "22"
            ],
            "content_languages" : [
               "pl"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Polish.",
            "content_subjects_phrases" : [
               {
                  "value" : "22",
                  "language" : "en",
                  "phrase" : "Philosophy and Religion"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-03-27 10:52:26",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4508,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4508"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Polish Theological Society, Krakow",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 19.9374,
               "latitude" : 50.0573
            },
            "url" : "https://ptt.net.pl",
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "country" : "pl"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "http://www.ufrj.br",
            "country" : "br",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "value" : "pt",
                        "language" : "en",
                        "phrase" : "Portuguese"
                     }
                  ],
                  "name" : "Universidade Federal do Rio de Janeiro",
                  "acronym" : "UFRJ",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Federal University of Rio de Janerio",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4507",
            "publicly_visible" : "yes",
            "id" : 4507,
            "date_created" : "2019-03-27 10:06:53",
            "date_modified" : "2019-10-17 14:35:16"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Pantheon"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Portugese, Spanish and English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "pt",
               "es"
            ],
            "url" : "https://pantheon.ufrj.br/",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Uganda Martyrs University Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "url" : "http://ir.umu.ac.ug/",
            "oai_url" : "http://ir.umu.ac.ug/oai/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-27 09:55:26",
            "id" : 4506,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4506",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "ug",
            "country_phrases" : [
               {
                  "phrase" : "Uganda",
                  "language" : "en",
                  "value" : "ug"
               }
            ],
            "url" : "http://umu.ac.ug/",
            "location" : {
               "longitude" : 32.0139,
               "latitude" : 0.0029
            },
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Uganda Martyrs University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Rakuno Gakuen University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "location" : {
               "latitude" : 43.0733,
               "longitude" : 141.51
            },
            "url" : "http://www.rakuno.ac.jp/"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4505",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-26 16:33:46",
            "id" : 4505,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "acronym" : "CLOVER",
                  "name" : "Collected Literature in Organized and Valuable Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://rakuno.repo.nii.ac.jp/oai",
            "url" : "https://rakuno.repo.nii.ac.jp"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "fa",
                  "language" : "en",
                  "phrase" : "Persian (Farsi)"
               }
            ],
            "name" : [
               {
                  "name" : "Repository of Research and Investigative Information",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "fa"
            ],
            "content_subjects" : [
               "10"
            ],
            "url" : "http://eprints.hums.ac.ir/",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4504",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-26 16:02:24",
            "id" : 4504,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "latitude" : 27.1817,
               "longitude" : 56.2996
            },
            "url" : "http://www.hums.ac.ir",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ir",
                  "phrase" : "Iran, Islamic Republic of"
               }
            ],
            "country" : "ir",
            "name" : [
               {
                  "name" : "Hormozgan University of Medical Sciences",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Argentina"
               }
            ],
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Facultad de Lenguas",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es"
               },
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Faculty of Langauges",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.uncoma.edu.ar/",
            "location" : {
               "longitude" : -67.575,
               "latitude" : -39.0306
            },
            "country" : "ar",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad Nacional del Comahue",
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "National Univeristy of Comahue"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4503",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4503,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-26 15:52:39",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Lenguas - Biblioteca Digital"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bibliotecadelenguas.uncoma.edu.ar/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Spanish.",
            "software" : {
               "name" : "omeka",
               "name_phrases" : [
                  {
                     "value" : "omeka",
                     "language" : "en",
                     "phrase" : "Omeka"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Repository of Shahrekord University of Medical Sciences",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://eprints.skums.ac.ir/cgi/oai2",
            "url" : "http://eprints.skums.ac.ir",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English."
         },
         "organisation" : {
            "country" : "ir",
            "location" : {
               "latitude" : 32.3569,
               "longitude" : 50.9125
            },
            "url" : "http://www.skums.ac.ir/",
            "country_phrases" : [
               {
                  "phrase" : "Iran, Islamic Republic of",
                  "language" : "en",
                  "value" : "ir"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Shahrekord University of Medical Sciences",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4502",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4502,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-26 14:27:42",
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4501",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-03-26 14:17:27",
            "date_modified" : "2019-10-17 14:35:16",
            "id" : 4501,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "latitude" : 66.4859,
               "longitude" : 25.7154
            },
            "url" : "https://www.ulapland.fi/",
            "country_phrases" : [
               {
                  "phrase" : "Finland",
                  "language" : "en",
                  "value" : "fi"
               }
            ],
            "country" : "fi",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Lapland, Rovaniemi",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in Finnish and English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "pure",
                     "phrase" : "PURE"
                  }
               ],
               "name" : "pure"
            },
            "url" : "https://lacris.ulapland.fi/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "fi"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Lapland Current Research System"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Finnish",
                  "value" : "fi",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4500",
            "publicly_visible" : "yes",
            "id" : 4500,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-26 14:07:30"
         },
         "organisation" : {
            "country" : "ng",
            "location" : {
               "latitude" : 8.1252,
               "longitude" : 5.0942
            },
            "url" : "http://lmu.edu.ng",
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "language" : "en",
                  "value" : "ng"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Landmark University"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Landmark University Repository"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://eprints.lmu.edu.ng/",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 4499,
            "date_modified" : "2019-10-17 14:35:16",
            "date_created" : "2019-03-26 13:45:17",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4499",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Lebanon",
                  "value" : "lb",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 33.9018,
               "longitude" : 35.4808
            },
            "url" : "https://www.aub.edu.lb/",
            "country" : "lb",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "American University of Beirut",
                  "acronym" : "AUB",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "American University of Beirut (AUB) Scholarworks",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://scholarworks.aub.edu.lb/",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "ScholarWorks"
            },
            "description" : "This repository hosts the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         }
      }
   ]
}

