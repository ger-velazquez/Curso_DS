{
   "items" : [
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio de la Universidad Peruana del Centro"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://repositorio.upecen.edu.pe/oai/request",
            "url" : "http://repositorio.upecen.edu.pe/",
            "content_subjects" : [
               "10",
               "2",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.4",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Peruana del Centro. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-25 09:07:09",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4884,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4884"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad Peruana del Centro"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "https://www.upecen.edu.pe"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "tr"
            ],
            "oai_url" : "http://acikerisim.selcuk.edu.tr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://acikerisim.selcuk.edu.tr",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Selçuk Üniversitesi. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "DSpace@Selçuk",
                  "name" : "Selcuk University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "value" : "tr",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "tr",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "DSpace@Selçuk",
                  "name" : "Selçuk Üniversitesi Acik Erisim Sistemi"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4883,
            "date_created" : "2019-09-25 08:43:02",
            "date_modified" : "2020-01-06 09:34:19",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4883",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Selçuk University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Selçuk Üniversitesi",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr"
               }
            ],
            "location" : {
               "latitude" : 38.0264,
               "longitude" : 32.5097
            },
            "unit" : [
               {
                  "name" : "Selçuk Üniversitesi Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "http://www.kutuphane.selcuk.edu.tr",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "country" : "tr"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "https://rep.ksma.ks.ua/oai/request",
            "url" : "https://rep.ksma.ks.ua",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Kherson State Maritime Academy. The interface is available in English, Ukranian and Russian.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "name" : "Electronic Institutional Repository Kherson State Maritime Academy",
                  "acronym" : "eKSMAIR",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-24 14:49:41",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4882,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4882"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Kherson State Maritime Academy",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://kma.ks.ua",
            "location" : {
               "latitude" : 46.6359,
               "longitude" : 32.6174
            },
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "UP Baguio Open Digital Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of the Philippines Baguio Library. The interface is available in English, and the research outputs are available in English and Filipino.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.upb.edu.ph/jspui/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-24 08:28:03",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4880,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4880"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "University of the Philippines",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of the Philippines Baguio Library"
               }
            ],
            "location" : {
               "latitude" : 16.4164,
               "longitude" : 120.593
            },
            "country_phrases" : [
               {
                  "phrase" : "Philippines",
                  "language" : "en",
                  "value" : "ph"
               }
            ],
            "country" : "ph"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universitas Katolik Darma Cendika. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositori.ukdc.ac.id/cgi/oai2",
            "url" : "http://repositori.ukdc.ac.id",
            "content_languages" : [
               "id"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "Repository UKDC",
                  "name" : "Repository Universitas Katolik Darma Cendika"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4878,
            "date_created" : "2019-09-23 10:09:09",
            "date_modified" : "2019-10-17 14:35:21",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4878",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "id",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "location" : {
               "latitude" : 7.29137,
               "longitude" : 112.781
            },
            "url" : "http://www.ukdc.ac.id",
            "name" : [
               {
                  "name" : "Universitas Katolik Darma Cendika",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "id",
                        "phrase" : "Indonesian"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Belgrade's Faculty of Pharmacy. The interface is available in English and Serbian.",
            "software" : {
               "version" : "5.10",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "sr"
            ],
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://farfar.pharmacy.bg.ac.rs/oai/request",
            "url" : "http://farfar.pharmacy.bg.ac.rs",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "FarFar - Pharmacy Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Serbian",
                  "value" : "sr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "rs",
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Faculty of Pharmacy"
               }
            ],
            "location" : {
               "longitude" : 20.4933,
               "latitude" : 44.748
            },
            "url" : "http://bg.ac.rs/en/index.php",
            "country_phrases" : [
               {
                  "value" : "rs",
                  "language" : "en",
                  "phrase" : "Serbia"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Belgrade"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4877",
            "publicly_visible" : "yes",
            "id" : 4877,
            "date_created" : "2019-09-23 09:53:49",
            "date_modified" : "2019-10-17 14:35:21"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Haramaya University Institutional Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Haramaya University. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://institutional_repository.haramaya.edu.et/oai/request",
            "url" : "http://institutional_repository.haramaya.edu.et",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4876",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-20 08:55:42",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4876,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "http://www.haramaya.edu.et",
            "country_phrases" : [
               {
                  "phrase" : "Ethiopia",
                  "value" : "et",
                  "language" : "en"
               }
            ],
            "country" : "et",
            "name" : [
               {
                  "name" : "Haramaya University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-20 08:00:41",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4875,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4875",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "latitude" : -12.0166,
               "longitude" : -76.8902
            },
            "url" : "https://www.universidadsise.edu.pe",
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad SISE"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional Universidad SISE"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.universidadsise.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.universidadsise.edu.pe",
            "software" : {
               "name" : "dspace",
               "version" : "6.2",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad SISE. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "de",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 49.2593,
               "longitude" : 7.05158
            },
            "url" : "https://cispa.saarland",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Helmholtz Center for Information Security",
                  "acronym" : "CISPA"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4874",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-20 07:13:00",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4874,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the CISPA Helmholtz Center for Information Security. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "https://publications.cispa.saarland",
            "oai_url" : "https://publications.cispa.saarland/cgi/oai2",
            "content_subjects" : [
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "CISPA Helmholtz Center for Information Security Publication Database"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Lincoln University"
               }
            ],
            "country" : "nz",
            "country_phrases" : [
               {
                  "phrase" : "New Zealand",
                  "value" : "nz",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 172.467,
               "latitude" : -43.6445
            },
            "url" : "http://www.lincoln.ac.nz"
         },
         "system_metadata" : {
            "date_created" : "2019-09-19 15:12:09",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4872,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4872",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "url" : "https://data.lincoln.ac.nz",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "oai_url" : "https://api.figshare.com/v2/oai?verb=ListRecords&metadataPrefix=oai_dc&set=portal_510",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of Lincoln University.  The interface is available in English.",
            "software" : {
               "name" : "other",
               "name_other" : "Figshare",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Data@Lincoln"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://repositorio.unne.edu.ar/oai/request",
            "url" : "http://repositorio.unne.edu.ar",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "pt",
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.7 SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional del Nordeste. Users may set up RSS feeds to be alerted to new content. The interface is available in English, Spanish and Portuguese.",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Universidad Nacional del Nordeste",
                  "acronym" : "RIUNNE",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4871,
            "date_created" : "2019-09-19 14:59:54",
            "date_modified" : "2019-12-04 12:27:37",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4871"
         },
         "organisation" : {
            "country" : "ar",
            "url" : "http://www.unne.edu.ar",
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "name" : [
               {
                  "acronym" : "UNNE",
                  "name" : "Universidad Nacional del Nordeste",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "sr"
            ],
            "url" : "http://rik.mrizp.rs",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://rik.mrizp.rs/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.10",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Maize Research Institute, \"Zemun Polje\". The interface is available in English and Serbian.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Serbian",
                  "language" : "en",
                  "value" : "sr"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Repository of the Maize Research Institute, \"Zemun Polje\"",
                  "acronym" : "RIK"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "sr",
                        "phrase" : "Serbian"
                     }
                  ],
                  "language" : "sr",
                  "acronym" : "RIK",
                  "name" : "Repozitorijum Instituta za kukuruz \"Zemun Polje\""
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country" : "rs",
            "url" : "http://mrizp.rs/",
            "location" : {
               "latitude" : 44.8698,
               "longitude" : 20.3289
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "rs",
                  "phrase" : "Serbia"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "MRIZP",
                  "name" : "Maize Research Institute Zemun Polje"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "sr",
                        "phrase" : "Serbian"
                     }
                  ],
                  "language" : "sr",
                  "name" : "Instituta za kukuruz \"Zemun Polje\""
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-19 14:47:23",
            "id" : 4870,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4870",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4869",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 4869,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-19 14:38:04",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UNU",
                  "name" : "Universidad Nacional de Ucayali"
               },
               {
                  "name" : "National University of Ucayali",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "url" : "http://unu.edu.pe",
            "location" : {
               "longitude" : -74.5798,
               "latitude" : -8.39489
            },
            "country" : "pe"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "es",
                  "acronym" : "Repositorio Institucional UNU",
                  "name" : "Repositorio Institucional - Universidad Nacional de Ucayali",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Ucayali. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "oai_url" : "http://repositorio.unu.edu.pe/oai/request",
            "url" : "http://repositorio.unu.edu.pe",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Cajamarca. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "oai_url" : "http://repositorio.unc.edu.pe/oai/request",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "url" : "http://repositorio.unc.edu.pe",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional de la Universidad Nacional de Cajamarca"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Institutional Repository of the National University of Cajamarca"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4868,
            "date_created" : "2019-09-19 13:32:08",
            "date_modified" : "2019-10-17 14:35:21",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4868",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Nacional de Cajamarca"
               }
            ],
            "url" : "http://www.unc.edu.pe",
            "location" : {
               "longitude" : -78.5003,
               "latitude" : -7.16378
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4867",
            "publicly_visible" : "yes",
            "id" : 4867,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-19 12:47:12"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Central Library of Slovak Academy of Sciences",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "sk",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "sk",
                  "phrase" : "Slovakia"
               }
            ],
            "url" : "http://www.uk.sav.sk/"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repository of Slovak Academy of Sciences"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "sk",
                  "language" : "en",
                  "phrase" : "Slovak"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Slovak Academy of Sciences. The interface is available in English and Slovak.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Advanced Rapid Library",
               "name" : "other"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://www.library.sk/arl-sav/",
            "content_languages" : [
               "en",
               "sk"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en",
               "tr"
            ],
            "url" : "http://acikerisim.aksaray.edu.tr",
            "oai_url" : "http://acikerisim.aksaray.edu.tr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Aksaray University Institutional Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "url" : [
                  "http://acikerisim.aksaray.edu.tr/dokumanlar/oa_yonerge.pdf"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  }
               ],
               "rules" : [
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students"
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://acikerisim.aksaray.edu.tr/dokumanlar/oa_yonerge.pdf"
               ]
            },
            "data_policy" : {
               "url" : [
                  "http://acikerisim.aksaray.edu.tr/dokumanlar/oa_yonerge.pdf"
               ]
            },
            "content_policy" : {
               "languages" : [
                  "tr"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "url" : [
                  "http://acikerisim.aksaray.edu.tr/dokumanlar/oa_yonerge.pdf"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "phrase" : "Turkish",
                     "language" : "en",
                     "value" : "tr"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "url" : "https://www.aksaray.edu.tr",
            "location" : {
               "latitude" : 38.33,
               "longitude" : 33.9831
            },
            "country" : "tr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Aksaray University"
               },
               {
                  "name" : "Aksaray Üniversitesi",
                  "language" : "tr",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "tr",
                        "phrase" : "Turkish"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4866",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-19 12:08:16",
            "id" : 4866,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://acikerisim.artuklu.edu.tr/oai/request",
            "url" : "http://acikerisim.artuklu.edu.tr",
            "content_languages" : [
               "en",
               "tr"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Mardin Artuklu University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "tr",
                  "language" : "en",
                  "phrase" : "Turkish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "name" : "Mardin Artuklu University Institutional Repository",
                  "acronym" : "DSpace@Artuklu",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "tr",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "Turkish",
                        "language" : "en",
                        "value" : "tr"
                     }
                  ],
                  "name" : "Mardin Artuklu Üniversitesi Akademik Arşiv Sistemi",
                  "acronym" : "DSpace@Artuklu",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4865",
            "publicly_visible" : "yes",
            "id" : 4865,
            "date_modified" : "2019-11-04 11:13:15",
            "date_created" : "2019-09-19 08:50:56"
         },
         "organisation" : {
            "country" : "tr",
            "country_phrases" : [
               {
                  "phrase" : "Turkey",
                  "language" : "en",
                  "value" : "tr"
               }
            ],
            "location" : {
               "longitude" : 40.7067,
               "latitude" : 37.3353
            },
            "url" : "http://www.artuklu.edu.tr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Mardin Artuklu University"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "tr",
                        "language" : "en",
                        "phrase" : "Turkish"
                     }
                  ],
                  "language" : "tr",
                  "name" : "Mardin Artuklu Üniversitesi"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "location" : {
               "longitude" : -71.5396,
               "latitude" : -16.3865
            },
            "url" : "https://sfx.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "acronym" : "SFX",
                  "name" : "Escuela de Postgrado San Francisco Xavier",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4863",
            "publicly_visible" : "yes",
            "id" : 4863,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-18 12:52:49"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio de la Escuela de Postgrado San Francisco Xavier - SFX"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.sfx.edu.pe",
            "oai_url" : "http://repositorio.sfx.edu.pe/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Escuela de Postgrado San Francisco Xavier SFX. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Repositorio Digital de la Universidad José Carlos Mariátegui",
                  "acronym" : "Repositorio Institucional - UJCM"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad José Carlos Mariátegui (UJCM). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.ujcm.edu.pe/oai/request",
            "url" : "http://repositorio.ujcm.edu.pe",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ]
         },
         "organisation" : {
            "url" : "https://www.ujcm.edu.pe",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UJCM",
                  "name" : "Universidad José Carlos Mariátegui"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4862",
            "publicly_visible" : "yes",
            "id" : 4862,
            "date_created" : "2019-09-18 11:29:05",
            "date_modified" : "2019-10-17 14:35:21"
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional San Luis Gonzaga. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.unica.edu.pe/oai/request",
            "url" : "http://repositorio.unica.edu.pe",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Digital - Universidad Nacional San Luis Gonzaga",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad Nacional San Luis Gonzaga"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "latitude" : -14.0829,
               "longitude" : -75.7343
            },
            "url" : "https://unica.edu.pe/",
            "country" : "pe"
         },
         "system_metadata" : {
            "id" : 4861,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-18 11:18:10",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4861",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad Privada de Huancayo Franklin Roosevelt"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "longitude" : -75.2106,
               "latitude" : -12.0681
            },
            "url" : "http://uroosevelt.edu.pe",
            "country" : "pe"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4859",
            "publicly_visible" : "yes",
            "id" : 4859,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-18 10:40:34"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://repositorio.uroosevelt.edu.pe/oai/request",
            "content_subjects" : [
               "10"
            ],
            "url" : "http://repositorio.uroosevelt.edu.pe",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.4",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research outputs (theses) of the Universidad Privada de Huancayo Franklin Roosevelt. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio de la Universidad Privada de Huancayo Franklin Roosevelt",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Repository Unitri"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universitas Tribhuwana Tunggadewi (UNITRI). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.unitri.ac.id/",
            "oai_url" : "http://repository.unitri.ac.id/cgi/oai2",
            "content_languages" : [
               "en",
               "id"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-18 10:29:01",
            "id" : 4858,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4858"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universitas Tribhuwana Tunggadewi",
                  "acronym" : "UNITRI",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ]
               }
            ],
            "country" : "id",
            "location" : {
               "latitude" : -7.93276,
               "longitude" : 112.6
            },
            "url" : "https://unitri.ac.id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "value" : "id",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Institute of Geophysics, Polish Academy of Sciences",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "pl",
                  "language_phrases" : [
                     {
                        "phrase" : "Polish",
                        "value" : "pl",
                        "language" : "en"
                     }
                  ],
                  "name" : "Instytut Geofizyki Polskiej Akademii Nauk",
                  "acronym" : "IGF PAN"
               }
            ],
            "country" : "pl",
            "url" : "https://www.igf.edu.pl/home.php",
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "language" : "en",
                  "value" : "pl"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4856",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-18 09:44:45",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4856
         },
         "repository_metadata" : {
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "https://dspace.igf.edu.pl/xmlui/handle/123456789/1",
            "content_languages" : [
               "en",
               "pl"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Institute of Geophysics (Instytut Geofizyki PAN). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Polish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Polish",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "name" : "Repository of publications of Institute of Geophysics, Polish Academy of Sciences",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Scipedia"
               }
            ],
            "type" : "aggregating",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "In-house platform",
               "name" : "other"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "description" : "This site provides access to research outputs from a variety of journals, congresses and collections across various institutions.  The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://www.scipedia.com",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "es"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4855",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-17 14:59:58",
            "id" : 4855
         },
         "organisation" : {
            "location" : {
               "longitude" : 2.1526,
               "latitude" : 41.3956
            },
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "name" : "Scipedia S.L."
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "url" : [
                  "https://www.scipedia.com/help/openaccess"
               ]
            },
            "submission_policy" : {
               "url" : [
                  "https://www.scipedia.com/help/openaccess"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Catalan",
                  "language" : "en",
                  "value" : "ca"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "UIC Open Acces Archive"
               }
            ],
            "content_languages" : [
               "ca",
               "en",
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositori.uic.es/oai/request",
            "url" : "http://repositori.uic.es/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universitat Internacional de Catalunya. Users may set up RSS feeds to be alerted to new content. The interface is available in English, Spanish and Catalan.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.4 SNAPSHOT",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "url" : "https://www.uic.es/es",
            "country" : "es",
            "name" : [
               {
                  "name" : "Universitat Internacional de Catalunya",
                  "language" : "ca",
                  "language_phrases" : [
                     {
                        "phrase" : "Catalan",
                        "language" : "en",
                        "value" : "ca"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4854",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-17 14:41:32",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4854
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "fi",
                  "language" : "en",
                  "phrase" : "Finnish"
               }
            ],
            "name" : [
               {
                  "name" : "Trepo - Institutional Repository of Tampere University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en",
               "fi"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://trepo.tuni.fi/oai/request",
            "url" : "https://trepo.tuni.fi/",
            "software" : {
               "name" : "dspace",
               "version" : "5.6",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Tampere University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Finnish."
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Tampere University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "https://www.tuni.fi/",
            "country_phrases" : [
               {
                  "phrase" : "Finland",
                  "language" : "en",
                  "value" : "fi"
               }
            ],
            "country" : "fi"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4853",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 4853,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-17 14:17:06",
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Bates College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "https://www.bates.edu/",
            "country" : "us"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-17 13:46:06",
            "id" : 4852,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4852",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "url" : [
                  "http://libguides.bates.edu/ld.php?content_id=36670889"
               ],
               "withdrawal" : {
                  "standard_reasons_phrases" : [
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     }
                  ],
                  "standard_reasons" : [
                     "legal_requirement_proven"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "value" : "removal_at_request",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "special_reasons" : [
                     "Bates College may remove content without notice"
                  ]
               }
            },
            "data_policy" : {
               "url" : [
                  "http://libguides.bates.edu/ld.php?content_id=36670889"
               ],
               "access_phrases" : [
                  {
                     "value" : "some_or_all_restricted",
                     "language" : "en",
                     "phrase" : "Access to some or all full items is restricted"
                  }
               ],
               "access" : "some_or_all_restricted"
            },
            "submission_policy" : {
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "url" : [
                  "http://libguides.bates.edu/ld.php?content_id=36670889"
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://libguides.bates.edu/ld.php?content_id=36670889"
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://libguides.bates.edu/ld.php?content_id=36670889"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Scholarly Communication and Research at Bates",
                  "acronym" : "SCARAB",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://scarab.bates.edu/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://libguides.bates.edu/ld.php?content_id=36670889",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Digital Commons",
                     "value" : "digital_commons",
                     "language" : "en"
                  }
               ],
               "name" : "digital_commons"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the students, staff and faculty members at Bates College.  The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4851,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-17 13:31:32",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4851"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidade Federal de Campina Grande",
                  "acronym" : "UFCG"
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "location" : {
               "longitude" : -35.9079,
               "latitude" : -7.2143
            },
            "url" : "http://www.ufcg.edu.br/index1.php"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "url" : "http://dspace.sti.ufcg.edu.br:8080/jspui/",
            "oai_url" : "http://dspace.sti.ufcg.edu.br:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "4.2"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the theses and dissertations from the Universidade Federal de Campina Grande.The interface is available in Portuguese, English, Spanish and French.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "name" : "Biblioteca Digital de Teses e Dissertações da Universidade Federal de Campina Grande",
                  "acronym" : "UFCG",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio Institucional Universidad El Bosque"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad El Bosque. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repositorio.unbosque.edu.co",
            "content_languages" : [
               "en",
               "es"
            ]
         },
         "organisation" : {
            "country" : "co",
            "url" : "https://www.unbosque.edu.co",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "co",
                  "phrase" : "Colombia"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad El Bosque",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-17 13:21:35",
            "date_modified" : "2019-12-04 12:27:37",
            "id" : 4850,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4850"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.neumann.edu.pe",
            "oai_url" : "http://repositorio.neumann.edu.pe/oai/request",
            "content_subjects" : [
               "24"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "6.0",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the Escuela de Postgrado Neumann Business School. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Neumann",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Escuela de Postgardo Neumann Business School"
               }
            ],
            "country" : "pe",
            "location" : {
               "longitude" : -70.2536,
               "latitude" : -18.0147
            },
            "url" : "https://www.epneumann.edu.pe/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-17 08:03:29",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4849,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4849",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "url" : "ttp://www.bausate.edu.pe/",
            "country" : "pe",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UJBM",
                  "name" : "Universidad Jaime Bausate y Meza"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-17 07:31:11",
            "id" : 4848,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4848"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "Universidad Jaime Bausate y Meza",
                  "name" : "Repositorio Institucional - UJBM",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.bausate.edu.pe/oai/request",
            "content_subjects" : [
               "17",
               "23"
            ],
            "url" : "http://repositorio.bausate.edu.pe/",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Jaime Bausate y Meza (UJBM). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de San Agustín de Arequipa (UNSA). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "oai_url" : "http://repositorio.unsa.edu.pe/oai/request",
            "url" : "http://repositorio.unsa.edu.pe",
            "content_subjects" : [
               "17",
               "10",
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la UNSA",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ]
         },
         "organisation" : {
            "country" : "pe",
            "location" : {
               "latitude" : -16.4077,
               "longitude" : -71.5184
            },
            "url" : "http://www.unsa.edu.pe/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "acronym" : "UNSA",
                  "name" : "Universidad Nacional de San Agustín de Arequipa",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-17 07:10:36",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4847,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4847",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the African Economic Research Consortium (AERC). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "fr"
            ],
            "content_subjects" : [
               "2",
               "23"
            ],
            "url" : "http://publications.aercafricalibrary.org/",
            "oai_url" : "http://publications.aercafricalibrary.org/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "AERC Repository"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "AERC",
                  "name" : "African Economic Research Consortium"
               }
            ],
            "country" : "ke",
            "url" : "https://aercafrica.org",
            "country_phrases" : [
               {
                  "value" : "ke",
                  "language" : "en",
                  "phrase" : "Kenya"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4846",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4846,
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-16 14:56:43",
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "country" : "si",
            "country_phrases" : [
               {
                  "phrase" : "Slovenia",
                  "value" : "si",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 14.8797,
               "latitude" : 46.0658
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Slovenian colleges and standalone higher education institutions"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4845,
            "date_created" : "2019-09-16 14:24:18",
            "date_modified" : "2019-10-17 14:35:21",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4845",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "quality_control" : "checked_by_subject_specialists",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is checked by internal subject specialists. ",
                     "value" : "checked_by_subject_specialists",
                     "language" : "en"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "value" : "author_eligibility",
                     "language" : "en"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  },
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ],
               "url" : [
                  "http://revis.openscience.si/info/index.php/eng/10-vsebine-en/34-policies"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "value" : "academic_staff",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting"
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "value" : "link_required",
                     "language" : "en"
                  },
                  {
                     "value" : "original_copyright_statement_required",
                     "language" : "en",
                     "phrase" : "the original copyright statement is given"
                  },
                  {
                     "phrase" : "the original rights permission statement is given",
                     "value" : "original_rights_statement_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://revis.openscience.si/info/index.php/eng/10-vsebine-en/34-policies"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions",
                     "language" : "en",
                     "value" : "individually_tagged"
                  }
               ],
               "reuse" : "individually_tagged",
               "access" : "some_or_all_restricted",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed transiently for full-text indexing",
                     "value" : "allowed_for_indexing",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting" : [
                  "allowed_for_indexing"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "access" : "some_or_all_restricted",
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all of the metadata is controlled",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "url" : [
                  "http://revis.openscience.si/info/index.php/eng/10-vsebine-en/34-policies"
               ]
            },
            "content_policy" : {
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "url" : [
                  "http://revis.openscience.si/info/index.php/eng/10-vsebine-en/34-policies"
               ],
               "metadata_phrases" : [
                  {
                     "value" : "version_type_and_date",
                     "language" : "en",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "value" : "hr",
                     "language" : "en",
                     "phrase" : "Croatian"
                  },
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  },
                  {
                     "phrase" : "German",
                     "value" : "de",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "hu",
                     "phrase" : "Hungarian"
                  },
                  {
                     "language" : "en",
                     "value" : "sl",
                     "phrase" : "Slovene"
                  }
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "value" : "submitted_versions",
                     "language" : "en"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "hr",
                  "en",
                  "de",
                  "hu",
                  "sl"
               ]
            }
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "notes" : "REVIS offers deposit and preservation of different electronic documents. Compatibility with OpenAIRE guidelines enables sharing content with other repositories and compliance with the provisions of the European Commission on open access to peer-reviewed scientific publications and corresponding research data from publicly funded projects under the FP7 and Horizon 2020 Framework Programes, as well as the requirements of Slovenian national strategy, institutional policies and financers.\r\n\r\nDuring the deposit into the Repository each document can be submitted for the detection of the similarity of its content (plagiarism) to all contents on the national open science portal.\r\n\r\nMetadata about masters and doctoral works will also be included into the DART-Europe portal of electronic research theses, held in European repositories.\r\n\r\nA  college or standalone higher education institution can become a member of REVIS on the basis of mutual agreement i.e. contract.",
            "description" : "Repository of colleges and standalone higher education institutions (REVIS) is a single point of entry for the access to electronic forms of scientific and professional papers, reports, research data and other material, generated by the researchers or students of member organizations.",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "DKUM"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "sl"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://revis.openscience.si/info/index.php/eng/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "aggregating",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Repository of colleges and higher education institutions",
                  "acronym" : "ReVIS"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Slovene",
                  "language" : "en",
                  "value" : "sl"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4844",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-16 13:57:50",
            "date_modified" : "2019-10-17 14:35:21",
            "id" : 4844
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad Privada Juan Pablo II"
               }
            ],
            "country" : "pe",
            "url" : "https://unijuanpablo.edu.pe/",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Privada Juan Pablo II. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "url" : "http://repositorio.unijuanpablo.edu.pe",
            "oai_url" : "http://repositorio.unijuanpablo.edu.pe/oai/request",
            "name" : [
               {
                  "name" : "Repositorio Digital Institucional de la Universidad Privada Juan Pablo II",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio Digital Universidad Andina del Cusco"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://repositorio.uandina.edu.pe/oai/request",
            "url" : "http://repositorio.uandina.edu.pe",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Andina del Cusco.  The interface is available in Spanish."
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "url" : "http://www.uandina.edu.pe",
            "country" : "pe",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Andina del Cusco"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4842",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 4842,
            "date_created" : "2019-09-16 13:38:10",
            "date_modified" : "2019-10-17 14:35:21",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "Repositorio UNAJMA",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional José María Arguedas (UNAJMA). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://repositorio.unajma.edu.pe",
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://repositorio.unajma.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4841",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-16 12:52:27",
            "id" : 4841
         },
         "organisation" : {
            "country" : "pe",
            "url" : "http://www.unajma.edu.pe",
            "location" : {
               "latitude" : -13.6556,
               "longitude" : -73.3872
            },
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UNAJMA",
                  "name" : "Universidad Nacional José María Arguedas"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional UPeU"
               }
            ],
            "url" : "https://repositorio.upeu.edu.pe",
            "oai_url" : "https://repositorio.upeu.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Peruana Unión (UPeU). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "6.4 SNAPSHOT",
               "name" : "dspace"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Peruana Unión",
                  "acronym" : "UPeU"
               }
            ],
            "country" : "pe",
            "location" : {
               "latitude" : -11.9831,
               "longitude" : -76.8397
            },
            "url" : "https://www.upeu.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:21",
            "date_created" : "2019-09-16 12:20:50",
            "id" : 4840,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4840"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the Universidad Nacional de la Amazonia Peruana (UNAP). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://repositorio.unapiquitos.edu.pe/",
            "oai_url" : "http://repositorio.unapiquitos.edu.pe/oai/request",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Digital UNAP",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-16 12:05:09",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4839,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4839",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UNAP",
                  "name" : "Universidad Nacional de la Amazonia Peruana"
               }
            ],
            "url" : "https://www.unapiquitos.edu.pe/",
            "location" : {
               "longitude" : -73.2538,
               "latitude" : -3.74912
            },
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "latitude" : 12.0931,
               "longitude" : -77.054
            },
            "url" : "http://www.adp.edu.pe",
            "country" : "pe",
            "name" : [
               {
                  "name" : "Academia Diplomática del Perú",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-16 10:33:39",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4838,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4838",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional de la Academia Diplomática del Perú"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Academia Diplomática del Per. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.adp.edu.pe",
            "oai_url" : "http://repositorio.adp.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UNFV",
                  "name" : "Universidad Nacional Federico Villarreal",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "location" : {
               "latitude" : -13.4517,
               "longitude" : -68.637
            },
            "url" : "http://www.unfv.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "country" : "pe"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4837,
            "date_created" : "2019-09-16 10:14:58",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4837"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional UNFV",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.unfv.edu.pe",
            "oai_url" : "http://repositorio.unfv.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional Federico Villarreal (UNFV). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish and English."
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : -12.1049,
               "longitude" : -76.9611
            },
            "url" : "https://www.ue.edu.pe/",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad ESAN"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4835",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 4835,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-16 10:07:12",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://repositorio.esan.edu.pe/oai/request",
            "url" : "http://repositorio.esan.edu.pe",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.6",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad ESAN. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Universidad ESAN",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "version" : "5.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Tumbes. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.untumbes.edu.pe/oai/request",
            "url" : "http://repositorio.untumbes.edu.pe/",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad Nacional de Tumbes",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-16 09:58:47",
            "id" : 4834,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4834",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Nacional de Tumbes",
                  "acronym" : "UNTumbes",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "longitude" : -80.4406,
               "latitude" : -3.5854
            },
            "url" : "http://www.untumbes.edu.pe",
            "country" : "pe"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.uladech.edu.pe/oai/request",
            "url" : "http://repositorio.uladech.edu.pe",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "software" : {
               "version" : "6.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad Católica Los Ángeles de Chimbote. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la Universidad Católica Los Ángeles de Chimbote",
                  "acronym" : "ULADEC CATÓLICA",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "id" : 4832,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-16 09:46:20",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4832",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "longitude" : -78.5893,
               "latitude" : -9.0774
            },
            "url" : "https://www.uladech.edu.pe",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Católica Los Ángeles de Chimbote",
                  "acronym" : "ULADECH CATÓLICA"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional INIA"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "governmental",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "url" : "http://repositorio.inia.gob.pe",
            "content_subjects" : [
               "3"
            ],
            "oai_url" : "http://repositorio.inia.gob.pe/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Instituto Nacional de Innovación Agraria (INIA). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4830",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4830,
            "date_created" : "2019-09-12 13:05:34",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "pe",
            "location" : {
               "latitude" : -12.0751,
               "longitude" : -76.9452
            },
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "name" : [
               {
                  "acronym" : "INIA",
                  "name" : "Instituto Nacional de Innovación Agraria",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Señor de Sipán (USS). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "oai_url" : "http://repositorio.uss.edu.pe/oai/request",
            "url" : "http://repositorio.uss.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Repositorio institucional  - Universidad Señor de Sipán",
                  "acronym" : "Repositorio institucional USS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4829",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-12 12:38:55",
            "date_modified" : "2019-12-04 12:25:31",
            "id" : 4829
         },
         "organisation" : {
            "url" : "https://www.uss.edu.pe",
            "location" : {
               "latitude" : -6.7917,
               "longitude" : -79.8805
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Señor de Sipán"
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "url" : [
                  "http://www.uss.edu.pe/uss/transparencia/investigacion/directiva/Directiva%20Repositorio%20Institucional%20V1%202019.pdf"
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://www.uss.edu.pe/uss/transparencia/investigacion/directiva/Directiva%20Repositorio%20Institucional%20V1%202019.pdf"
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               }
            },
            "metadata_policy" : {
               "url" : [
                  "http://www.uss.edu.pe/uss/transparencia/investigacion/directiva/Directiva%20Repositorio%20Institucional%20V1%202019.pdf"
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "languages_phrases" : [
                  {
                     "value" : "es",
                     "language" : "en",
                     "phrase" : "Spanish"
                  }
               ],
               "types_included" : {
                  "special_types_allowed" : [
                     "http://www.uss.edu.pe/uss/transparencia/investigacion/directiva/Directiva%20Repositorio%20Institucional%20V1%202019.pdf"
                  ],
                  "standard_types_allowed" : [
                     "journal_articles",
                     "conference_and_workshop_papers",
                     "theses_and_dissertations",
                     "books_chapters_and_sections",
                     "other_special_item_types"
                  ],
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "phrase" : "Journal Articles",
                        "value" : "journal_articles",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Conference and Workshop Papers",
                        "language" : "en",
                        "value" : "conference_and_workshop_papers"
                     },
                     {
                        "phrase" : "Theses and Dissertations",
                        "language" : "en",
                        "value" : "theses_and_dissertations"
                     },
                     {
                        "phrase" : "Books, Chapters and Sections",
                        "language" : "en",
                        "value" : "books_chapters_and_sections"
                     },
                     {
                        "value" : "other_special_item_types",
                        "language" : "en",
                        "phrase" : "Other Special Item Types"
                     }
                  ]
               },
               "languages" : [
                  "es"
               ],
               "url" : [
                  "http://www.uss.edu.pe/uss/transparencia/investigacion/directiva/Directiva%20Repositorio%20Institucional%20V1%202019.pdf"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Institute of Agricultural Economics",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Serbia",
                  "value" : "rs",
                  "language" : "en"
               }
            ],
            "url" : "http://www.iep.bg.ac.rs/",
            "location" : {
               "latitude" : 47.37,
               "longitude" : 8.531
            },
            "country" : "rs"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4828",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 12:14:49",
            "id" : 4828,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Repository of Institute of Agricultural Economics"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Serbian",
                  "value" : "sr",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Institute of Agricultural Economics. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.16"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "sr"
            ],
            "url" : "http://repository.iep.bg.ac.rs/",
            "oai_url" : "http://repository.iep.bg.ac.rs/cgi/oai2",
            "content_subjects" : [
               "3",
               "24"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Universidad Tecnológica de los Andes (UTEA). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.utea.edu.pe/",
            "oai_url" : "http://repositorio.utea.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Repositorio Digital Institucional de la Universidad Tecnológica de los Andes",
                  "acronym" : "(UTEA)"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4827",
            "publicly_visible" : "yes",
            "id" : 4827,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 12:06:15"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad Tecnológica de los Andes"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "latitude" : -13.6324,
               "longitude" : -72.8872
            },
            "url" : "https://www.utea.edu.pe/",
            "country" : "pe"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4826",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 11:57:01",
            "id" : 4826,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "url" : "http://unach.edu.pe/",
            "location" : {
               "longitude" : -78.393,
               "latitude" : -6.33738
            },
            "name" : [
               {
                  "name" : "Universidad Nacional Autónoma de Chota",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad Nacional Autónoma de Chota",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               },
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional Autónoma de Chota. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://repositorio.unach.edu.pe/oai/request",
            "url" : "http://repositorio.unach.edu.pe",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "content_languages" : [
               "es"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Antonio Ruiz de Montoya",
                  "acronym" : "UARM",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Antonio Ruiz de Montoya",
                  "acronym" : "UARM"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "latitude" : -12.0702,
               "longitude" : -77.0588
            },
            "url" : "https://www.uarm.edu.pe/"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4824",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4824,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 10:36:07",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to a selection of theses from the  Universidad Antonio Ruiz de Montoya (UARM). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "value" : "25",
                  "language" : "en",
                  "phrase" : "Education"
               },
               {
                  "phrase" : "Computers and IT",
                  "language" : "en",
                  "value" : "14"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "8",
               "25",
               "14"
            ],
            "url" : "http://repositorio.uarm.edu.pe",
            "oai_url" : "http://repositorio.uarm.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional UARM"
               },
               {
                  "acronym" : "UARM",
                  "name" : "Institutional Repository - University of Antonio Ruiz de Montoya",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Software",
                  "value" : "software",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "software",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Repositorio institucional - USDG",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "oai_url" : "http://repositorio.usdg.edu.pe/oai/request",
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "http://repositorio.usdg.edu.pe/",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Santo Domingo de Guzmán. The interface is available in English..",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Santo Domingo de Guzmán",
                  "acronym" : "USDG",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : -11.9422,
               "longitude" : -77.0997
            },
            "url" : "https://www.usdg.edu.pe/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 10:24:08",
            "id" : 4823,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4823",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio Institucional UTEC"
               },
               {
                  "acronym" : "UTEC",
                  "name" : "Institutional Repository - Universidad de Ingeniería y Tecnología",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "description" : "This site provides access to the research outputs of the Universidad de Ingeniería y Tecnología (UTEC). The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://repositorio.utec.edu.pe/oai/request",
            "url" : "https://repositorio.utec.edu.pe",
            "content_subjects" : [
               "2",
               "11"
            ],
            "content_languages" : [
               "es"
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "latitude" : -12.1334,
               "longitude" : -77.0222
            },
            "url" : "https://www.utec.edu.pe/",
            "country" : "pe",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UTEC",
                  "name" : "Universidad de Ingeniería y Tecnología"
               },
               {
                  "name" : "University of Engineering and Technology"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4822,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 09:54:41",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4822",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4821",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 09:45:24",
            "id" : 4821
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Instituto de Investigaciones de la Amazonía Peruana"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "url" : "http://www.iiap.org.pe",
            "location" : {
               "longitude" : -73.2745,
               "latitude" : -3.76755
            }
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional del IIAP",
                  "acronym" : "Instituto de Investigaciones de la Amazonía Peruana",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.iiap.org.pe",
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://repositorio.iiap.org.pe/oai/request",
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.0"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the Instituto de Investigaciones de la Amazonía Peruana (IIAP). Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UNJ",
                  "name" : "Repositorio - Universidad Nacional de Jaén"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.6",
               "name" : "dspace"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Jaén (UNJ). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://repositorio.unj.edu.pe/oai/request",
            "url" : "http://repositorio.unj.edu.pe/",
            "content_languages" : [
               "es"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4820",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-12 09:31:30",
            "id" : 4820
         },
         "organisation" : {
            "country" : "pe",
            "url" : "https://unj.edu.pe/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Universidad Nacional de Jaén"
               }
            ]
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  }
               ],
               "url" : [
                  "http://iriss.idn.org.rs/politics.html"
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Employees",
                     "language" : "en",
                     "value" : "employees"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_policy",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "depositors" : [
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ]
            },
            "data_policy" : {
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes" : [
                  "educational_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Not Allowed",
                     "language" : "en",
                     "value" : "not_allowed"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "individually_tagged",
               "reuse_phrases" : [
                  {
                     "value" : "individually_tagged",
                     "language" : "en",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "url" : [
                  "http://iriss.idn.org.rs/politics.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "language" : "en",
                     "value" : "some_items_have_different_conditions"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "language" : "en",
                     "value" : "given_to_third_parties",
                     "phrase" : "given to third parties"
                  }
               ],
               "harvesting" : [
                  "not_allowed"
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "url" : [
                  "http://iriss.idn.org.rs/politics.html"
               ],
               "closure_policy" : "undefined",
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               },
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "language" : "en",
                        "value" : "publisher_rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "language" : "en",
                        "value" : "national_security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://iriss.idn.org.rs/politics.html"
               ]
            },
            "content_policy" : {
               "languages" : [
                  "en"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "subjects" : [
                  "23"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "value" : "working_drafts",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ],
               "url" : [
                  "http://iriss.idn.org.rs/politics.html"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "value" : "version_type_and_date",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "peer_review_status",
                     "phrase" : "peer-review status"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Social Sciences General",
                     "value" : "23",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4819,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-11 14:56:04",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4819"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "rs",
                  "phrase" : "Serbia"
               }
            ],
            "url" : "https://www.idn.org.rs/",
            "location" : {
               "latitude" : 47.37,
               "longitude" : 8.531
            },
            "country" : "rs",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institute of Social Sciences"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Institutional Repository of Institute of Social Sciences",
                  "acronym" : "IRISS",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Serbian",
                  "language" : "en",
                  "value" : "sr"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Institute of Social Sciences. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "sr"
            ],
            "oai_url" : "http://iriss.idn.org.rs/cgi/oai2",
            "url" : "http://iriss.idn.org.rs",
            "content_subjects" : [
               "23"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "acronym" : "SENAMHI",
                  "name" : "Repositorio Institucional - Servicio Nacional de Meteorología e Hidrología del Perú",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "oai_url" : "http://repositorio.senamhi.gob.pe/oai/request",
            "url" : "http://repositorio.senamhi.gob.pe",
            "content_subjects" : [
               "7"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Servicio Nacional de Meteorología e Hidrología del Perú (SENAMHI). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            }
         },
         "organisation" : {
            "url" : "https://www.senamhi.gob.pe",
            "location" : {
               "longitude" : -77.0467,
               "latitude" : -12.0776
            },
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "name" : "Servicio Nacional de Meteorología e Hidrología del Perú",
                  "acronym" : "SENAMHI",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4818,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-11 14:39:37",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4818"
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "url" : "https://www.uigv.edu.pe",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad Inca Garcilaso de la Vega"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4817",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 4817,
            "date_created" : "2019-09-11 14:12:26",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Repositorio Universidad Inca Garcilaso de la Vega",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "fa",
                  "phrase" : "Persian (Farsi)"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Inca Garcilaso de la Vega. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.1"
            },
            "oai_url" : "http://repositorio.uigv.edu.pe/oai/request",
            "url" : "http://repositorio.uigv.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "fa"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "https://www.umb.edu.pe/",
            "location" : {
               "latitude" : -6.7674,
               "longitude" : -79.8326
            },
            "name" : [
               {
                  "acronym" : "UMB",
                  "name" : "Universidad Privada Juan Mejía Baca",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4816",
            "publicly_visible" : "yes",
            "id" : 4816,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-11 14:03:57"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Institucional UMB",
                  "acronym" : "Universidad Privada Juan Mejía Baca",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               },
               {
                  "name" : "Institutional Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.umb.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.umb.edu.pe/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Privada Juan Mejía Baca. The interface is available in Spanish.",
            "software" : {
               "version" : "5.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "system_metadata" : {
            "id" : 4815,
            "date_created" : "2019-09-11 13:30:20",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4815",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "url" : "http://unsaac.edu.pe",
            "location" : {
               "latitude" : -13.5221,
               "longitude" : -71.9583
            },
            "country" : "pe",
            "name" : [
               {
                  "acronym" : "UNSAAC",
                  "name" : "Universidad Naional de San Antonio Abad del Cusco",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.unsaac.edu.pe/oai/request",
            "content_subjects" : [
               "2",
               "23",
               "11"
            ],
            "url" : "http://repositorio.unsaac.edu.pe",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Naional de San Antonio Abad del Cusco (UNSAAC). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional UNSAAC",
                  "language" : "qu",
                  "language_phrases" : [
                     {
                        "value" : "qu",
                        "language" : "en",
                        "phrase" : "Quechua"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.unp.edu.pe",
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "oai_url" : "http://repositorio.unp.edu.pe/oai/request",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Piura. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Repositorio Institucional Digital de la Universidad Nacional de Piura"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4814",
            "publicly_visible" : "yes",
            "id" : 4814,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-11 13:24:16"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Nacional de Piura"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "latitude" : -5.19449,
               "longitude" : -80.6328
            },
            "url" : "http://www.unp.edu.pe"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4813",
            "publicly_visible" : "yes",
            "id" : 4813,
            "date_created" : "2019-09-11 13:18:52",
            "date_modified" : "2019-10-17 14:35:20"
         },
         "organisation" : {
            "location" : {
               "latitude" : -5.2727,
               "longitude" : -75.7034
            },
            "url" : "http://upouni.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Peruana del Oriente"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio de la Universidad Peruana del Oriente",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Peruana del Oriente. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "10",
               "2",
               "23",
               "11"
            ],
            "oai_url" : "http://repositorio.upouni.edu.pe/oai/request",
            "url" : "http://repositorio.upouni.edu.pe",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-11 12:44:53",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4812,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4812"
         },
         "organisation" : {
            "location" : {
               "longitude" : -77.0692,
               "latitude" : -12.0835
            },
            "url" : "http://www.ftpcl.edu.pe/",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "acronym" : "FTPCL",
                  "name" : "Facultad de Teología Pontificia y Civil de Lima",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "acronym" : "Repositorio Institucional FTPCL",
                  "name" : "Repositorio Institucional de la Facultad de Teología Pontificia y Civil de Lima",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.ftpcl.edu.pe/",
            "content_subjects" : [
               "22"
            ],
            "oai_url" : "http://repositorio.ftpcl.edu.pe/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Facultad de Teología Pontificia y Civil de Lima. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Privada San Carlos"
               }
            ],
            "country" : "pe",
            "location" : {
               "longitude" : -70.0294,
               "latitude" : -15.8394
            },
            "url" : "http://www.upsc.edu.pe/",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4811,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-11 12:39:09",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4811",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Repositorio Académico para el Acceso Libre de Información en Ciencia, Tecnología e Innovación"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Privada San Carlos. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.upsc.edu.pe/oai/request",
            "url" : "http://repositorio.upsc.edu.pe",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "digital_commons",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "digital_commons",
                     "phrase" : "Digital Commons"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "description" : "This site provides access to the research outputs of Rowan University. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://rdw.rowan.edu/do/oai/request",
            "url" : "https://rdw.rowan.edu/",
            "content_subjects" : [
               "17",
               "10"
            ],
            "name" : [
               {
                  "name" : "Rowan Digital Works",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Rowan University"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "url" : "https://www.rowan.edu/",
            "location" : {
               "longitude" : -75.1207,
               "latitude" : 39.7071
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4810",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-11 12:25:56",
            "id" : 4810
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Repositorio Institucional de la Universidad Católica de Trujillo Benedicto XVI"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.uct.edu.pe/",
            "oai_url" : "http://repositorio.uct.edu.pe/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad Católica de Trujillo Benedicto XVI. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4806",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 4806,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-10 12:55:08",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Católica de Trujillo Benedicto XVI",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "country" : "pe",
            "url" : "http://www.uct.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "url" : "http://ulp.edu.pe/",
            "location" : {
               "latitude" : -12.8605,
               "longitude" : -72.6921
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad Privada Lider Peruana SAC"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4804",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-10 10:34:12",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4804
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Universidad Privada Lider Peruana . Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "http://repositorio.ulp.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.ulp.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Universidad Privada Lider Peruana"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Autónoma del Estado de Hidalgo (UAE). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://repository.uaeh.edu.mx/oai/request",
            "url" : "https://repository.uaeh.edu.mx/bitstream/",
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional Abierto - UAEH"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Autónoma del Estado de Hidalgo"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Mexico",
                  "language" : "en",
                  "value" : "mx"
               }
            ],
            "url" : "https://www.uaeh.edu.mx",
            "country" : "mx"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4803",
            "publicly_visible" : "yes",
            "id" : 4803,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-10 10:01:34"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Institucional del OEFA"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "7"
            ],
            "oai_url" : "http://repositorio.oefa.gob.pe/oai/request",
            "url" : "https://repositorio.oefa.gob.pe/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Organismo de Evaluación y Fiscalización Ambiental. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4802",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:37",
            "date_created" : "2019-09-10 09:30:03",
            "id" : 4802
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Organismo de Evaluación y Fiscalización Ambiental"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "url" : "https://www.gob.pe/minam/oefa",
            "location" : {
               "longitude" : -77.0581,
               "latitude" : -12.0896
            }
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://dspace.unitru.edu.pe",
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://dspace.unitru.edu.pe/oai/request",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "2",
                  "phrase" : "Science General"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional de Trujillo. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional UNITRU"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Nacional de Trujillo"
               },
               {
                  "name" : "National University of Trujillo",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "location" : {
               "latitude" : -79.03,
               "longitude" : -8.11599
            },
            "url" : "http://unitru.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-10 09:21:31",
            "id" : 4801,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4801",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "no"
            ],
            "content_subjects" : [
               "3",
               "7"
            ],
            "url" : "https://ruralis.brage.unit.no",
            "oai_url" : "https://ruralis.brage.unit.no/ruralis-oai/request",
            "software" : {
               "version" : "5.5.1 SNAPSHOT",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Agriculture, Food and Veterinary",
                  "language" : "en",
                  "value" : "3"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "description" : "This site provides access to the research outputs of Ruralis – Institutt for rural- og regionalforskning (Ruralis - Institute for Rural and Regional Research). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Norwegian.",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norwegian"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "no",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "language" : "no",
                  "name" : "Ruralis Brage"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "location" : {
               "latitude" : 63.4069,
               "longitude" : 10.4742
            },
            "url" : "https://ruralis.no",
            "country_phrases" : [
               {
                  "value" : "no",
                  "language" : "en",
                  "phrase" : "Norway"
               }
            ],
            "country" : "no",
            "name" : [
               {
                  "name" : "Ruralis – Institutt for rural- og regionalforskning",
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "phrase" : "Norwegian",
                        "value" : "no",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "Ruralis - Institute for Rural and Regional Research",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-10 08:44:16",
            "id" : 4798,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4798",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.5.1 SNAPSHOT",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Norges Bank (The Central Bank of Norway). Users may set up RSS feeds to be alerted to new content. The interface is available in English and Norwegian.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "https://norges-bank.brage.unit.no",
            "content_subjects" : [
               "24"
            ],
            "oai_url" : "https://norges-bank.brage.unit.no/norges-bank-oai/request",
            "content_languages" : [
               "en",
               "no"
            ],
            "name" : [
               {
                  "name" : "Norges Banks vitenarkiv",
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "no",
                        "phrase" : "Norwegian"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "The Central Bank of Norway's Open Archive"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norwegian"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 10.7424,
               "latitude" : 59.9088
            },
            "url" : "https://www.norges-bank.no",
            "country_phrases" : [
               {
                  "phrase" : "Norway",
                  "value" : "no",
                  "language" : "en"
               }
            ],
            "country" : "no",
            "name" : [
               {
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "no",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "name" : "Norges Bank"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "The Central Bank of Norway"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-10 08:30:34",
            "id" : 4797,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4797"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "url" : "https://upa.edu.pe",
            "location" : {
               "latitude" : -5.74707,
               "longitude" : -78.4495
            },
            "country" : "pe",
            "name" : [
               {
                  "acronym" : "UPA",
                  "name" : "Universidad Politécnica Amazónica"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4794,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-09 13:32:20",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4794",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad Politécnica Amazónica",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               },
               {
                  "name" : "Amazon Polytechnic University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "url" : "http://repositorio.upa.edu.pe",
            "oai_url" : "http://repositorio.upa.edu.pe/oai/request",
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Politécnica Amazónica (UPA). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish and English."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4792,
            "date_created" : "2019-09-09 13:16:10",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4792"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Servicio Nacional Forestal y Fauna Silvestre"
               }
            ],
            "country" : "pe",
            "url" : "https://www.serfor.gob.pe/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "7"
            ],
            "url" : "http://repositorio.serfor.gob.pe/",
            "oai_url" : "http://repositorio.serfor.gob.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Servicio Nacional Forestal y Fauna Silvestre (SERFOR). The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.6",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio Nacional del SERFOR"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4790",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4790,
            "date_created" : "2019-09-09 12:47:47",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "https://portal.unas.edu.pe",
            "location" : {
               "latitude" : -9.31472,
               "longitude" : -75.9975
            },
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Nacional Agraria de la Selva",
                  "acronym" : "UNAS",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://repositorio.unas.edu.pe/oai/request",
            "url" : "http://repositorio.unas.edu.pe",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional Agraria de la Selva. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Institucional Digital UNAS",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4789",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 4789,
            "date_created" : "2019-09-09 12:39:21",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "http://ulc.edu.pe/",
            "country" : "pe",
            "name" : [
               {
                  "acronym" : "ULC",
                  "name" : "Universidad Latinoamericana CIMA",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Latinoamericana CIMA (ULA). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.1"
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.ulc.edu.pe/oai/request",
            "url" : "http://repositorio.ulc.edu.pe/",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional ULC"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.unasam.edu.pe/oai/request",
            "url" : "http://repositorio.unasam.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Nacional Santiago Antunez de Mayolo. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional Digital"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-09 12:27:48",
            "id" : 4788,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4788"
         },
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "longitude" : -77.5287,
               "latitude" : -9.5203
            },
            "url" : "https://unasam.edu.pe",
            "name" : [
               {
                  "name" : "Universidad Nacional Santiago Antunez de Mayolo"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Notre Dame University-Louaize Institutional Repository"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ir.ndu.edu.lb/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Notre Dame University-Louaize. The institutional Repository contains a collection of research and publications written by academic authors, students, staff, alumni and research groups.  The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.2",
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-09 12:16:32",
            "id" : 4787,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4787"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Notre Dame University-Louaize"
               }
            ],
            "location" : {
               "longitude" : 35.6159,
               "latitude" : 33.9554
            },
            "url" : "http://www.ndu.edu.lb/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "lb",
                  "phrase" : "Lebanon"
               }
            ],
            "country" : "lb"
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "TUdatalib is TU Darmstadt‘s institutional repository for all research data generated or worked with at TU Darmstadt. The interface is available in English and German.",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "de"
            ],
            "url" : "https://tudatalib.ulb.tu-darmstadt.de",
            "oai_url" : "https://tudatalib.ulb.tu-darmstadt.de/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "TUdatalib"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "datasets",
                  "language" : "en",
                  "phrase" : "Datasets"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4786",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-09 10:39:58",
            "id" : 4786,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Technische Universität Darmstadt"
               }
            ],
            "url" : "https://www.tu-darmstadt.de",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "country" : "de"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4785,
            "date_created" : "2019-09-09 10:14:29",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4785"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "by",
                  "phrase" : "Belarus"
               }
            ],
            "url" : "http://www.bstu.by",
            "country" : "by",
            "name" : [
               {
                  "acronym" : "BrSTU",
                  "name" : "Brest State Technical University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of Brest State Technical University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Russian.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ru"
            ],
            "oai_url" : "https://rep.bstu.by/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://rep.bstu.by/",
            "name" : [
               {
                  "name" : "Repository of Brest State Technical University",
                  "acronym" : "BrSTU",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Russian",
                        "language" : "en",
                        "value" : "ru"
                     }
                  ],
                  "language" : "ru",
                  "name" : "Репозиторий Брестского государственного технического университета"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "url" : "https://herbario.zamorano.edu",
            "content_subjects" : [
               "3"
            ],
            "oai_url" : "https://herbario.zamorano.edu/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Herbario Paul Standley. The interface is available in Spanish, French and English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Herbario Paul Standley"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4784",
            "publicly_visible" : "yes",
            "id" : 4784,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-09 10:01:01"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "hn",
                  "language" : "en",
                  "phrase" : "Honduras"
               }
            ],
            "url" : "https://www.zamorano.edu",
            "unit" : [
               {
                  "name" : "Escuela Agrícola Panamericana"
               }
            ],
            "location" : {
               "latitude" : 14.0127,
               "longitude" : -87.0038
            },
            "country" : "hn",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Universidad Zamorano"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-06 14:41:31",
            "id" : 4783,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4783"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad de Ciencias y Humanidades"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "latitude" : 11.9582,
               "longitude" : 77.0656
            },
            "url" : "https://www.uch.edu.pe/"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional UCH"
               }
            ],
            "url" : "http://repositorio.uch.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.uch.edu.pe/oai/request",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad de Ciencias y Humanidades. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.3",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "UTP",
                  "name" : "Universidad Tecnológica del Perú"
               }
            ],
            "url" : "https://www.utp.edu.pe/",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4782",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-06 14:25:44",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4782
         },
         "repository_metadata" : {
            "url" : "http://repositorio.utp.edu.pe/",
            "oai_url" : "http://repositorio.utp.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Tecnológica del Perú (UTP). The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional de la UTP",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://bdtd.ucb.br:8443/jspui/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "4.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidade Católica de Brasília. The interface is available in English, Spanish and Portuguese.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "pt",
                        "phrase" : "Portuguese"
                     }
                  ],
                  "language" : "pt",
                  "name" : "Biblioteca Digital de Teses e Dissertações da Universidade Católica de Brasília"
               },
               {
                  "name" : "Digital Library of Theses and Dissertations of the Catholic University of Brasilia",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "organisation" : {
            "url" : "https://ucb.catolica.edu.br/",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "language" : "en",
                  "value" : "br"
               }
            ],
            "country" : "br",
            "name" : [
               {
                  "name" : "Universidade Católica de Brasília"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4781",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-06 14:12:16",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4781,
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4780",
            "publicly_visible" : "yes",
            "id" : 4780,
            "date_created" : "2019-09-06 13:03:04",
            "date_modified" : "2019-10-17 14:35:20"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Escuela Internacional de Posgrado"
               }
            ],
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "url" : "http://eiposgrado.edu.pe"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "EIPOSGRADO"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Escuela Internacional de Posgrado. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://repositorio.eiposgrado.edu.pe",
            "oai_url" : "http://repositorio.eiposgrado.edu.pe/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "value" : "fr",
                        "language" : "en"
                     }
                  ],
                  "name" : "Répertoire des travaux de l’École supérieure polytechnique"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the l’École supérieure polytechnique. Users may set up RSS feeds to be alerted to new content. The interface is available in French.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "url" : "http://recherche.esp.sn:8080/xmlui",
            "oai_url" : "http://recherche.esp.sn:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "fr"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : -17.4666,
               "latitude" : 14.6825
            },
            "url" : "http://www.esp.sn/",
            "country_phrases" : [
               {
                  "phrase" : "Senegal",
                  "value" : "sn",
                  "language" : "en"
               }
            ],
            "country" : "sn",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr",
                  "name" : "École supérieure polytechnique"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-06 12:36:50",
            "id" : 4779,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4779"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Hatay Mustafa Kemal University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Turkish.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "tr"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://openaccess.mku.edu.tr",
            "oai_url" : "http://openaccess.mku.edu.tr/oai/request",
            "name" : [
               {
                  "name" : "Hatay Mustafa Kemal University Institutional Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkish"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4778,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-06 12:24:24",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4778"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Hatay Mustafa Kemal University"
               }
            ],
            "country" : "tr",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tr",
                  "phrase" : "Turkey"
               }
            ],
            "location" : {
               "longitude" : 36.1986,
               "latitude" : 36.3336
            },
            "url" : "https://www.mku.edu.tr"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Repositorio USEL"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Seminario Evangélico de Lima (USEL). The interface is available in English and Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "url" : "http://repositorio.usel.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.usel.edu.pe/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4777",
            "publicly_visible" : "yes",
            "id" : 4777,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-06 10:50:13"
         },
         "organisation" : {
            "url" : "https://usel.edu.pe/",
            "location" : {
               "latitude" : 47.37,
               "longitude" : 8.531
            },
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Seminario Evangélico de Lima",
                  "acronym" : "USEL"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Católica del Oriente.  The interface is available in Spanish, English and French.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.uco.edu.co/",
            "oai_url" : "http://repositorio.uco.edu.co/oai/request",
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional Universidad Católica del Oriente"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.uco.edu.co",
            "location" : {
               "latitude" : 4.60185,
               "longitude" : -74.0727
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "co",
                  "phrase" : "Colombia"
               }
            ],
            "country" : "co",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad Católica del Oriente"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-06 10:28:57",
            "id" : 4776,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4776"
         }
      },
      {
         "system_metadata" : {
            "id" : 4774,
            "date_created" : "2019-09-05 11:54:06",
            "date_modified" : "2019-10-17 14:35:20",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4774",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.autonoma.pe/",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Autónoma del Perú",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad Autónoma del Perú. The publications available give an account of the academic, social and research activity of the University community made up of students, graduates, teachers and authorities.\r\n\r\nThe interface is available in English and Spanish.",
            "software" : {
               "version" : "5.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "es"
            ],
            "url" : "http://repositorio.autonoma.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.autonoma.edu.pe/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio institucional de la Universidad Autónoma del Perú"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Benemérita Universidad Autónoma de Puebla. The interface is available in Spanish and English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repositorioinstitucional.buap.mx",
            "oai_url" : "https://repositorioinstitucional.buap.mx/oai/request",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio de Acceso Abierto BUAP"
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "BUAP Open Access Repository"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4773",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-05 09:43:10",
            "id" : 4773
         },
         "organisation" : {
            "url" : "https://www.buap.mx",
            "country_phrases" : [
               {
                  "value" : "mx",
                  "language" : "en",
                  "phrase" : "Mexico"
               }
            ],
            "country" : "mx",
            "name" : [
               {
                  "name" : "Benemérita Universidad Autónoma de Puebla"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-05 09:22:37",
            "id" : 4772,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4772"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Islamic University in Uganda",
                  "acronym" : "IUIU"
               }
            ],
            "country" : "ug",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ug",
                  "phrase" : "Uganda"
               }
            ],
            "url" : "https://iuiu.ac.ug/"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "IUIU Institutional Repository"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Islamic University in Uganda (IUIU), including scholarly articles, books and book chapters, theses and dissertations, conference proceedings, and Jummah prayer sermons. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.4 SNAPSHOT",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://ir.iuiu.ac.ug/oai/request",
            "url" : "https://ir.iuiu.ac.ug",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "COLIBRI: Repositorio Institucional de la Universidad de la República",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "COLIBRI: Institutional Repository of the University of the Republic"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad de la República (University of the Republic). The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "4.1",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://www.colibri.udelar.edu.uy/jspui/",
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-05 09:11:24",
            "id" : 4771,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4771",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : -55.7658,
               "latitude" : -32.5228
            },
            "url" : "http://www.universidad.edu.uy/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "uy",
                  "phrase" : "Uruguay"
               }
            ],
            "country" : "uy",
            "name" : [
               {
                  "name" : "Universidad de la República (Uruguay)",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               },
               {
                  "name" : "University of the Republic (Uruguay)",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad Interamericana para el Desarrollo. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "url" : "http://repositorio.unid.edu.pe/",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://repositorio.unid.edu.pe/oai/request",
            "name" : [
               {
                  "name" : "Repositorio Universidad Interamericana para el Desarrollo",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ]
         },
         "system_metadata" : {
            "id" : 4769,
            "date_modified" : "2019-10-17 14:35:20",
            "date_created" : "2019-09-03 14:49:11",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4769",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -12.056,
               "longitude" : -77.0444
            },
            "url" : "http://unid.edu.pe/",
            "country" : "pe",
            "name" : [
               {
                  "name" : "Universidad Interamericana para el Desarrollo",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-03 13:21:14",
            "date_modified" : "2019-10-17 14:35:20",
            "id" : 4768,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4768"
         },
         "organisation" : {
            "country" : "py",
            "country_phrases" : [
               {
                  "phrase" : "Paraguay",
                  "value" : "py",
                  "language" : "en"
               }
            ],
            "url" : "http://www.une.edu.py/web/index.php",
            "unit" : [
               {
                  "name" : "Facultad Politécnica"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad Nacional del Este"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "name" : "Portal de Conocimiento",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://fp.une.edu.py:8080/jspui/",
            "oai_url" : "http://fp.une.edu.py:8080/oai/request",
            "content_subjects" : [
               "23",
               "11"
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "description" : "This site provides access to the research outputs of the Facultad Politécnica, Universidad Nacional del Este. The interface is available in English and Spanish.",
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the STIKES Bina Sehat PPNI. Users may set up RSS feeds to be alerted to new content. The interface is available in Indonesian and English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "id"
            ],
            "oai_url" : "http://repository.stikes-ppni.ac.id:8080/oai/request?verb=Identify",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.stikes-ppni.ac.id:8080/xmlui/",
            "name" : [
               {
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "id",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "name" : "Repositori Institusi STIKES Bina Sehat PPNI"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4766",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-03 09:53:00",
            "date_modified" : "2019-10-17 14:35:19",
            "id" : 4766,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "STIKES Bina Sehat PPNI"
               }
            ],
            "country" : "id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "url" : "http://stikes-ppni.ac.id/"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Bern University of Applied Sciences",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "ch",
            "location" : {
               "longitude" : 7.43521,
               "latitude" : 46.9514
            },
            "url" : "https://www.bfh.ch/en/",
            "country_phrases" : [
               {
                  "value" : "ch",
                  "language" : "en",
                  "phrase" : "Switzerland"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:19",
            "date_created" : "2019-09-03 09:15:46",
            "id" : 4765,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4765"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://arbor.bfh.ch/cgi/oai2",
            "url" : "https://arbor.bfh.ch/",
            "content_languages" : [
               "en",
               "de"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.16",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Bern University of Applied Sciences. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Applied Research Bern Open Repository",
                  "acronym" : "ARBOR"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4764",
            "publicly_visible" : "yes",
            "id" : 4764,
            "date_modified" : "2019-10-17 14:35:19",
            "date_created" : "2019-09-03 08:43:44"
         },
         "organisation" : {
            "country" : "pe",
            "location" : {
               "longitude" : -77.0313,
               "latitude" : -12.0759
            },
            "url" : "https://www.escuelafolklore.edu.pe/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "name" : "Escuela Nacional Superior de Folklore José María Arguedas"
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of the National School of Folklore \"José María Arguedas\""
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "17"
            ],
            "url" : "http://repositorio.escuelafolklore.edu.pe/",
            "oai_url" : "http://repositorio.escuelafolklore.edu.pe/oai/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.3",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               }
            ],
            "description" : "This is an institutional repository for research outputs of the Escuela Nacional Superior de Folklore \"José María Arguedas\" (Institutional Repository of the National School of Folklore \"José María Arguedas\"). The interface is in Spanish.",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio Institucional Académico ENSFJMA",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of the National School of Folklore \"José María Arguedas\""
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4763",
            "publicly_visible" : "yes",
            "id" : 4763,
            "date_modified" : "2019-10-17 14:35:19",
            "date_created" : "2019-09-03 08:06:40"
         },
         "organisation" : {
            "url" : "https://www.niva.no/",
            "location" : {
               "latitude" : 59.9425,
               "longitude" : 10.7164
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norway"
               }
            ],
            "country" : "no",
            "name" : [
               {
                  "name" : "Norsk institutt for vannforskning",
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "value" : "no",
                        "language" : "en",
                        "phrase" : "Norwegian"
                     }
                  ]
               },
               {
                  "name" : "Norwegian Institute for Water Research",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "NIVA Open Access Archive",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "value" : "no",
                  "language" : "en",
                  "phrase" : "Norwegian"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the Norsk institutt for vannforskning (Norwegian Institute for Water Research). Users may set up RSS feeds to be alerted to new content. The interface is available in Norwegian and English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.5.1 SNAPSHOT",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "7"
            ],
            "url" : "https://niva.brage.unit.no",
            "oai_url" : "https://niva.brage.unit.no/niva-oai/request",
            "content_languages" : [
               "en",
               "no"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "no",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "no",
                  "phrase" : "Norway"
               }
            ],
            "location" : {
               "longitude" : 10.4067,
               "latitude" : 63.4141
            },
            "url" : "https://nina.no/",
            "name" : [
               {
                  "name" : "Norsk institutt for naturforskning",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "no",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "language" : "no"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Norwegian Institute for Nature Research"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4762",
            "publicly_visible" : "yes",
            "id" : 4762,
            "date_created" : "2019-09-03 07:58:45",
            "date_modified" : "2019-10-17 14:35:19"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Norsk institutt for naturforskning (NINA) (Norwegian Institute for Nature Research). Users may set up RSS feeds to be alerted to new content. The interface is available in Norwegian and English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "https://brage.nina.no",
            "oai_url" : "https://brage.nina.no/nina-oai/request",
            "content_subjects" : [
               "7"
            ],
            "content_languages" : [
               "en",
               "no"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language" : "no",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "no",
                        "phrase" : "Norwegian"
                     }
                  ],
                  "name" : "NINA Brage"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Norwegian",
                  "value" : "no",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "md",
            "location" : {
               "latitude" : 47.0037,
               "longitude" : 28.9071
            },
            "url" : "https://utm.md",
            "country_phrases" : [
               {
                  "phrase" : "Moldova",
                  "language" : "en",
                  "value" : "md"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Technical University of Moldova"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 4761,
            "date_modified" : "2019-10-17 14:35:19",
            "date_created" : "2019-09-03 07:43:29",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/4761"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "ro",
                  "language" : "en",
                  "phrase" : "Romanian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "Institutional Repository of the Technical University of Moldova",
                  "acronym" : "IRTUM"
               }
            ],
            "url" : "http://repository.utm.md",
            "oai_url" : "http://http:/repository.utm.md/oai/request",
            "content_subjects" : [
               "2",
               "11"
            ],
            "content_languages" : [
               "en",
               "ro"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research output of the Technical University of Moldova. The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            }
         }
      }
   ]
}

