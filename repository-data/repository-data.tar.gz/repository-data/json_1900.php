{
   "items" : [
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of South Wales"
               }
            ],
            "url" : "http://www.southwales.ac.uk/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "country" : "gb"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3864",
            "publicly_visible" : "yes",
            "id" : 3864,
            "date_created" : "2017-03-06 12:06:54",
            "date_modified" : "2019-10-17 14:35:05"
         },
         "repository_metadata" : {
            "metadata_record_count" : 7403,
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of South Wales Research Explorer",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://pure.southwales.ac.uk/",
            "software" : {
               "name" : "pure",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "pure",
                     "phrase" : "PURE"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Welsh or English. Some content is not available as full-text.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Eastern University Institutional Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 337,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This repository provides access to the research output of the Eastern University. The interface is available in English. Users may set up Atom and RSS feeds to be alerted to new content.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "4.5",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://dspace.easternuni.edu.bd:8080/xmlui/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "bd",
            "country_phrases" : [
               {
                  "phrase" : "Bangladesh",
                  "language" : "en",
                  "value" : "bd"
               }
            ],
            "url" : "http://www.easternuni.edu.bd/",
            "location" : {
               "longitude" : 90.4071,
               "latitude" : 23.7099
            },
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Eastern University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2017-03-06 11:48:31",
            "date_modified" : "2019-10-17 14:35:05",
            "id" : 3863,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3863"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "MKU Rwanda University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "rw",
            "url" : "http://mkurwanda.ac.rw/",
            "country_phrases" : [
               {
                  "phrase" : "Rwanda",
                  "language" : "en",
                  "value" : "rw"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:05",
            "date_created" : "2017-03-02 10:27:23",
            "id" : 3862,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3862",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 4,
            "url" : "http://repository.mkurwanda.ac.rw/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.mkurwanda.ac.rw/oai/request",
            "software" : {
               "version" : "5.6",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "metadata_record_count" : 5141,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "name" : "MKU Rwanda Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad de Camagüey &quot;Ignacio Agramonte Loynaz&quot;",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "cu",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "cu",
                  "phrase" : "Cuba"
               }
            ],
            "url" : "http://www.reduc.edu.cu/"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3861",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:05",
            "date_created" : "2017-03-02 10:23:41",
            "id" : 3861,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1053,
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "ReDIUC"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://rediuc.reduc.edu.cu/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 721,
            "oai_url" : "http://repository.sspu.sumy.ua/oai/request",
            "url" : "http://repository.sspu.sumy.ua/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "5.6",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Ukrainian and English.",
            "metadata_record_count" : 6868,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Electronic Sumy State Pedagogical University named after A. S. Makarenko Institutional Repository",
                  "acronym" : "eSSPUIR",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "uk"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Ukrainian",
                  "language" : "en",
                  "value" : "uk"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ua",
                  "phrase" : "Ukraine"
               }
            ],
            "location" : {
               "longitude" : 34.7551,
               "latitude" : 50.89
            },
            "url" : "https://sspu.sumy.ua/",
            "country" : "ua",
            "name" : [
               {
                  "name" : "Sumy State Pedagogical University named after A. S. Makarenko",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3860",
            "publicly_visible" : "yes",
            "id" : 3860,
            "date_modified" : "2019-10-17 14:35:05",
            "date_created" : "2017-03-02 10:19:12"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 4162,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "MUT INSTITUTIONAL REPOSITORY",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.mut.ac.ke:8080/oai/request",
            "url" : "http://repository.mut.ac.ke:8080/xmlui/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 1,
            "description" : "This repository provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "4.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3859",
            "publicly_visible" : "yes",
            "id" : 3859,
            "date_created" : "2017-03-02 09:26:00",
            "date_modified" : "2019-10-17 14:35:05"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Muranga University of Technology",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://mut.ac.ke/",
            "country_phrases" : [
               {
                  "value" : "ke",
                  "language" : "en",
                  "phrase" : "Kenya"
               }
            ],
            "country" : "ke"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "nl",
                  "phrase" : "Dutch"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "nl",
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Hanze UAS repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 12270,
            "description" : "This site is a university repository providing access to the research publication output of the university. Metadata is publicly available. The availability of full text is established per publication. The default interface language is English, content is mainly English and Dutch.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "pure",
                     "language" : "en",
                     "phrase" : "PURE"
                  }
               ],
               "name" : "pure"
            },
            "oai_url" : "https://research.hanze.nl/ws/oai",
            "url" : "https://research.hanze.nl/",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 1612,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Netherlands",
                  "value" : "nl",
                  "language" : "en"
               }
            ],
            "url" : "https://www.hanze.nl/eng",
            "location" : {
               "latitude" : 53.24,
               "longitude" : 6.533
            },
            "country" : "nl",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Hanze University of Applied Sciences",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3858",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2017-03-02 09:03:18",
            "date_modified" : "2019-10-17 14:35:05",
            "id" : 3858,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "H.S. Skovoroda Kharkiv National Pedagogical University"
               }
            ],
            "country" : "ua",
            "url" : "http://hnpu.edu.ua/uk",
            "country_phrases" : [
               {
                  "phrase" : "Ukraine",
                  "value" : "ua",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3857",
            "publicly_visible" : "yes",
            "id" : 3857,
            "date_created" : "2017-03-01 12:59:45",
            "date_modified" : "2019-10-17 14:35:05"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.0-rc3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Ukrainian, Russian and English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://dspace.hnpu.edu.ua/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "uk",
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "EKhNPUIR",
                  "name" : "Electronic Kharkiv National Pedagogic University Institutional Repository"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "metadata_record_count" : 1350,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "uk",
                  "phrase" : "Ukrainian"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "de",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://bonndoc.ulb.uni-bonn.de/",
            "oai_url" : "https://bonndoc.ulb.uni-bonn.de/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "6",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in German and English.",
            "metadata_record_count" : 574,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "bonndoc – Der Publikationsserver der Universität Bonn",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Bonn University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Bonn University Library"
               }
            ],
            "url" : "https://www.uni-bonn.de/",
            "location" : {
               "longitude" : 7.0982,
               "latitude" : 50.7374
            },
            "country" : "de"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3856",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3856,
            "date_modified" : "2019-10-17 14:35:05",
            "date_created" : "2017-02-28 14:39:57",
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "id" : 3855,
            "date_created" : "2017-02-27 10:30:31",
            "date_modified" : "2019-10-17 14:35:05",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3855",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "South Dakota State University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "http://www.sdstate.edu/",
            "location" : {
               "longitude" : -96.7819,
               "latitude" : 44.3178
            },
            "country" : "us"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "Open PRAIRIE",
                  "name" : "Public Research Access Institutional Repository and Information Exchange"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 14221,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://openprairie.sdstate.edu/",
            "oai_url" : "http://openprairie.sdstate.edu/do/oai/",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 942,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Institucional Universidad Católica San Pablo",
                  "acronym" : "Qolqa",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "oai_url" : "http://repositorio.ucsp.edu.pe/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.ucsp.edu.pe/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 723,
            "description" : "This site provides access to the research output of the institution. The interface is available in English or Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5",
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "id" : 3854,
            "date_created" : "2017-02-27 10:25:30",
            "date_modified" : "2019-10-17 14:35:05",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3854",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "url" : "http://ucsp.edu.pe/",
            "name" : [
               {
                  "name" : "Universidad Católica San Pablo",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "notes" : "Special items include: paintings, works on paper, sculptures, ceramics, religious icons, books, catalogues, posters, photographs, research essays and letters",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Philosophy and Religion",
                  "language" : "en",
                  "value" : "22"
               },
               {
                  "value" : "18",
                  "language" : "en",
                  "phrase" : "Fine and Performing Arts"
               }
            ],
            "metadata_record_count" : 1434,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Tyler Collection of Romanian and Modern Art: University of Tasmania",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://tylercollection.omeka.net/oai-pmh-repository/request",
            "content_subjects" : [
               "22",
               "18"
            ],
            "url" : "http://tylercollection.omeka.net/",
            "software" : {
               "name" : "omeka",
               "name_phrases" : [
                  {
                     "phrase" : "Omeka",
                     "language" : "en",
                     "value" : "omeka"
                  }
               ]
            },
            "description" : "This site provides access to the Tyler Collection of Romanian and Modern Art. The interface is available in English."
         },
         "organisation" : {
            "url" : "http://www.utas.edu.au/",
            "location" : {
               "longitude" : 147.329,
               "latitude" : -42.8787
            },
            "country_phrases" : [
               {
                  "value" : "au",
                  "language" : "en",
                  "phrase" : "Australia"
               }
            ],
            "country" : "au",
            "name" : [
               {
                  "acronym" : "UTAS",
                  "name" : "University of Tasmania",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2017-02-27 10:16:09",
            "date_modified" : "2019-12-04 12:27:34",
            "id" : 3853,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3853",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "AAB College",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "xk",
            "country_phrases" : [
               {
                  "phrase" : "Kosovo",
                  "language" : "en",
                  "value" : "xk"
               }
            ],
            "url" : "http://aab-edu.net/",
            "location" : {
               "longitude" : 21.112,
               "latitude" : 42.6398
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:34",
            "date_created" : "2017-02-27 10:09:27",
            "id" : 3852,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3852"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "AAB College repository"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1079,
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "6",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This is the Institutional Repository of AAB College. Many items are meta-data and abstract only, but some full text items may be found in the College Events and Lectures community. The interface is in English and contains RSS feed to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://dspace.aab-edu.net/",
            "oai_url" : "https://dspace.aab-edu.net/oai/request",
            "content_subjects" : [
               "1"
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "url" : "http://orb.binghamton.edu/",
            "oai_url" : "http://orb.binghamton.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "The Open Repository @Binghamton (The ORB)"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 2478,
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3851,
            "date_created" : "2017-02-27 09:56:11",
            "date_modified" : "2019-10-17 14:35:05",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3851",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Binghamton University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "us",
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Binghamton University Libraries"
               }
            ],
            "url" : "http://www.binghamton.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "ca",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "location" : {
               "latitude" : 50.6944,
               "longitude" : -120.358
            },
            "url" : "http://www.tru.ca/",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Thompson Rivers University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 3850,
            "date_modified" : "2019-12-04 12:27:34",
            "date_created" : "2017-02-22 12:20:20",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3850",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "TRUSpace"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "metadata_record_count" : 1170,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "software" : {
               "name" : "islandora",
               "name_phrases" : [
                  {
                     "phrase" : "islandora",
                     "value" : "islandora",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This repository provides access to the research output of the institution. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://tru.arcabc.ca/"
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "location" : {
               "longitude" : -76.9913,
               "latitude" : -12.1109
            },
            "url" : "http://orval.edu.pe/",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Universidad Peruana de Arte ORVAL",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3849",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 3849,
            "date_created" : "2017-02-22 10:24:56",
            "date_modified" : "2019-10-17 14:35:05",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositorio Institucional-Universidad Peruana de Arte ORVAL",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 59,
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This is the institutional repository of the University Peruvian of Arte ORVAL. The interface is in Spanish and English",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://repositorio.orval.edu.pe/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.orval.edu.pe/oai"
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. It contains both metadata and links to full-text versions, if available. The interface is in English and RSS feeds are available.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "pure",
                     "language" : "en",
                     "phrase" : "PURE"
                  }
               ],
               "name" : "pure"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://cris.vub.be",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "learning_objects"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Vrije Universiteit Brussel Research Portal"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Vrije Universiteit Brussel",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.vub.ac.be/",
            "country_phrases" : [
               {
                  "phrase" : "Belgium",
                  "language" : "en",
                  "value" : "be"
               }
            ],
            "country" : "be"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3848",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 3848,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-22 10:18:40",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Buketov Karaganda State University Repository"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "kk",
                  "phrase" : "Kazakh"
               },
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 2975,
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "value" : "5",
                  "language" : "en",
                  "phrase" : "Chemistry and Chemical Technology"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Russian.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "kk",
               "ru"
            ],
            "url" : "http://rep.ksu.kz/",
            "content_subjects" : [
               "21",
               "1",
               "4",
               "5",
               "7",
               "8",
               "9",
               "24",
               "26"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3847",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-20 10:27:25",
            "id" : 3847
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "kz",
                  "phrase" : "Kazakhstan"
               }
            ],
            "url" : "http://ksu.kz/",
            "location" : {
               "longitude" : 73.1256,
               "latitude" : 49.7708
            },
            "country" : "kz",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Academician E.A. Buketov Karaganda State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3846,
            "date_modified" : "2019-12-04 12:27:34",
            "date_created" : "2017-02-16 15:19:51",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3846"
         },
         "organisation" : {
            "url" : "http://www.utoledo.edu/",
            "location" : {
               "longitude" : -83.6089,
               "latitude" : 41.6764
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Toledo",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to cultural heritage collections, institutional records, and the research output of the institution. The interface is in English.\r\nSpecial items include cultural heritage collections and institutional archives",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "islandora",
                     "phrase" : "islandora"
                  }
               ],
               "name" : "islandora"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://utdr.utoledo.edu/",
            "oai_url" : "https://utdr.utoledo.edu/oai2/?verb=Identify",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Toledo Digital Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 16895,
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "IO PWr",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 82,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "software" : {
               "version" : "3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The site is available in English. Users may set up Atom and RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "11",
               "14"
            ],
            "oai_url" : "http://io.pwr.edu.pl/eprints/cgi/oai2",
            "url" : "http://io.pwr.edu.pl/eprints/",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               },
               {
                  "value" : "14",
                  "language" : "en",
                  "phrase" : "Computers and IT"
               }
            ],
            "content_languages" : [
               "en"
            ]
         },
         "policies" : {
            "content_policy" : {
               "metadata_phrases" : [
                  {
                     "value" : "version_type_and_date",
                     "language" : "en",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "language" : "en",
                     "value" : "peer_review_status"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://io.pwr.edu.pl/eprints/policies.html"
               ],
               "subjects_phrases" : [
                  {
                     "language" : "en",
                     "value" : "14",
                     "phrase" : "Computers and IT"
                  }
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "languages" : [
                  "en",
                  "pl"
               ],
               "subjects" : [
                  "14"
               ],
               "versions" : [
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  },
                  {
                     "phrase" : "Polish",
                     "value" : "pl",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               }
            },
            "metadata_policy" : {
               "url" : [
                  "http://io.pwr.edu.pl/eprints/policies.html"
               ],
               "commercial_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "allowed",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required"
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "value" : "software_emulation",
                     "language" : "en",
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats"
                  }
               ],
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "value" : "tombstone",
                           "language" : "en",
                           "phrase" : "URLs will continue to point to 'tombstone' citations."
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "national_security",
                        "phrase" : "National Security"
                     },
                     {
                        "phrase" : "Falsified research",
                        "value" : "falsified_research",
                        "language" : "en"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "value" : "errata_may_be_included",
                        "language" : "en",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "language" : "en",
                     "value" : "original_bitstream_retained",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "url" : [
                  "http://io.pwr.edu.pl/eprints/policies.html"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://io.pwr.edu.pl/eprints/policies.html"
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ]
            },
            "submission_policy" : {
               "url" : [
                  "http://io.pwr.edu.pl/eprints/policies.html"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ]
            }
         },
         "organisation" : {
            "country" : "pl",
            "url" : "http://pwr.edu.pl/",
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Division of Software Engineering"
               }
            ],
            "location" : {
               "longitude" : 17,
               "latitude" : 51
            },
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "name" : [
               {
                  "name" : "Wroclaw University of Science and Technology",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3845",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2017-02-14 13:27:55",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3845,
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-10 11:51:33",
            "id" : 3844,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3844",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "value" : "by",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 23.8403,
               "latitude" : 53.6902
            },
            "url" : "http://www.grsmu.by/",
            "country" : "by",
            "name" : [
               {
                  "name" : "Grodno State Medical University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ru",
                  "language" : "en",
                  "phrase" : "Russian"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "patents"
            ],
            "content_languages" : [
               "ru",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "metadata_record_count" : 7095,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               }
            ],
            "name" : [
               {
                  "name" : "Repository of Grodno State Medical University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://elib.grsmu.by/",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "http://elib.grsmu.by/oai/request",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output. Users may set up RSS and Atom feeds to be alerted to new content. The interface is available in Russian."
         }
      },
      {
         "organisation" : {
            "country" : "pt",
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "url" : "http://www.ipvc.pt/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Instituto Politécnico de Viana do Castelo",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3843",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 3843,
            "date_created" : "2017-02-10 11:16:20",
            "date_modified" : "2019-10-17 14:35:04",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "IPVC Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1103,
            "description" : "This site provides access to the research output of the institution. The interface is available in Portuguese and English.",
            "software" : {
               "version" : "5.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "url" : "http://repositorio.ipvc.pt/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.ipvc.pt/oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 880
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "url" : "http://www.lnec.pt/",
            "location" : {
               "longitude" : -9.14116,
               "latitude" : 38.7587
            },
            "country" : "pt",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "LNEC",
                  "name" : "Laboratório Nacional de Engenharia Civil",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3842",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-10 11:12:33",
            "id" : 3842
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "pt"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "4.2"
            },
            "url" : "http://repositorio.lnec.pt:8080/",
            "oai_url" : "http://repositorio.lnec.pt:8080/oai/",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Científico do LNEC",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 5927
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2017-02-10 10:46:04",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3841,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3841"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidade Atlântica"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portugal"
               }
            ],
            "url" : "http://www.uatlantica.pt/",
            "country" : "pt"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "RUA",
                  "name" : "Repositório da Universidade Atlântica",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "metadata_record_count" : 800,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content. The interface is available in Portuguese and English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "pt",
               "en"
            ],
            "url" : "http://repositorio-cientifico.uatlantica.pt/",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3840",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 3840,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-08 11:41:01",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Fundación Universidad de América"
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "location" : {
               "longitude" : 74.0617,
               "latitude" : 4.6019
            },
            "url" : "http://www.uamerica.edu.co/"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://repository.uamerica.edu.co/oai/",
            "content_subjects" : [
               "24",
               "25",
               "11",
               "12"
            ],
            "url" : "http://repository.uamerica.edu.co/",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The Interface is available in Spanish or English.",
            "metadata_record_count" : 693,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio institucional Universidad de América",
                  "acronym" : "Lumieres"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "24",
                  "phrase" : "Business and Economics"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "12",
                  "phrase" : "Architecture"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "https://opus4.kobv.de/opus4-bamberg/home",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://opus4.kobv.de/opus4-bamberg/oai",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 2747,
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Some content is not available as full-text.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "OPUS",
                     "language" : "en",
                     "value" : "opus"
                  }
               ],
               "version" : "4",
               "name" : "opus"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 49828,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "OPUS - Publikationsserver der Universität Bamberg",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "de"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Otto-Friedrich-Universität Bamberg"
               }
            ],
            "location" : {
               "latitude" : 49.8939,
               "longitude" : 10.8861
            },
            "url" : "https://www.uni-bamberg.de/",
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "country" : "de"
         },
         "system_metadata" : {
            "date_created" : "2017-02-08 11:28:13",
            "date_modified" : "2019-12-04 12:27:34",
            "id" : 3839,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3839",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "http://uni-bge.hu/",
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "value" : "hu",
                  "language" : "en"
               }
            ],
            "country" : "hu",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Budapest Business School"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3838,
            "date_created" : "2017-02-08 11:17:52",
            "date_modified" : "2019-10-17 14:35:04",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3838",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 596,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Budapest Business School Repository (BORY)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "url" : "http://repozitorium.uni-bge.hu/",
            "oai_url" : "http://publikaciotar.repozitorium.bgf.hu/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "Hungarian",
                  "value" : "hu",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "hu",
               "en"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "metadata_record_count" : 3547,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "KUMeL Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "http://kumel.medlib.dsmc.or.kr/",
            "oai_url" : "http://kumel.medlib.dsmc.or.kr/oai/reqeust",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "This site provides access to the research output of the institution.",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ko",
                  "phrase" : "Korean"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ko",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "kr",
                  "language" : "en",
                  "phrase" : "Korea, Republic of"
               }
            ],
            "url" : "http://www.dsmc.or.kr/",
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Keimyung University Medical Library (계명대학교 의학도서관)"
               }
            ],
            "country" : "kr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Keimyung University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-07 11:53:51",
            "id" : 3837,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3837"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Korean",
                  "value" : "ko",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "ko",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "metadata_record_count" : 3774,
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "DGIST Library Institutional Repository",
                  "acronym" : "DGIST Repository"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://scholar.dgist.ac.kr/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://scholar.dgist.ac.kr/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "description" : "This side provides access to the research output of the institution. Many items are not available as full-text."
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3836",
            "publicly_visible" : "yes",
            "id" : 3836,
            "date_modified" : "2019-12-04 12:27:34",
            "date_created" : "2017-02-07 11:40:15"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "kr",
                  "language" : "en",
                  "phrase" : "Korea, Republic of"
               }
            ],
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "DGIST Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "url" : "http://www.dgist.ac.kr/site/dgist/menu/1.do",
            "country" : "kr",
            "name" : [
               {
                  "name" : "DGIST (대구경북과학기술원)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 60672,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "HANYANG Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "oai_url" : "http://repository.hanyang.ac.kr/oai/request",
            "url" : "http://repository.hanyang.ac.kr/",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 440,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Korean.",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ko",
                  "phrase" : "Korean"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ko",
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "date_created" : "2017-02-07 10:58:40",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3835,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3835",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "HANYANG University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "kr",
                  "phrase" : "Korea, Republic of"
               }
            ],
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "HANYANG University Library",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "https://www.hanyang.ac.kr/",
            "country" : "kr"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Pusan National University Hospital (부산대학교병원)",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://pnuh.or.kr/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "kr",
                  "phrase" : "Korea, Republic of"
               }
            ],
            "country" : "kr"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3834",
            "publicly_visible" : "yes",
            "id" : 3834,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-07 10:49:15"
         },
         "repository_metadata" : {
            "metadata_record_count" : 746,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "name" : "Pusan National University Hospital Repository",
                  "acronym" : "PNUH Repository"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 379,
            "url" : "http://repository.pnuh.or.kr/",
            "oai_url" : "http://repository.pnuh.or.kr/oai/request",
            "content_subjects" : [
               "10",
               "25"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Korean.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Korean",
                  "value" : "ko",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ko"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "value" : "25",
                  "language" : "en",
                  "phrase" : "Education"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3833",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-07 10:23:41",
            "id" : 3833
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Korea, Republic of",
                  "language" : "en",
                  "value" : "kr"
               }
            ],
            "url" : "http://www.kinu.or.kr/",
            "country" : "kr",
            "name" : [
               {
                  "name" : "Korea Institute for National Unification (통일연구원)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://repo.kinu.or.kr/oai",
            "url" : "http://repo.kinu.or.kr/",
            "content_subjects" : [
               "24",
               "26"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.3",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Korean.",
            "metadata_record_count" : 3328,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "KINU Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "ko"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ko",
                  "language" : "en",
                  "phrase" : "Korean"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Mineralis"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "metadata_record_count" : 2021,
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "version" : "6.0",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content. The interface is available in Portuguese.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               },
               {
                  "language" : "en",
                  "value" : "6",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "phrase" : "Physics and Astronomy",
                  "language" : "en",
                  "value" : "9"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "url" : "http://mineralis.cetem.gov.br/",
            "content_subjects" : [
               "5",
               "6",
               "9"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Centro de Tecnologia Mineral",
                  "acronym" : "CETEM",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -43.2207,
               "latitude" : -22.8605
            },
            "url" : "http://www.cetem.gov.br/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "country" : "br"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3832,
            "date_created" : "2017-02-07 09:57:52",
            "date_modified" : "2019-12-04 12:27:34",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3832"
         }
      },
      {
         "organisation" : {
            "country" : "pt",
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -118,
               "latitude" : 34
            },
            "url" : "http://www.ipg.pt/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Instituto Politécnico da Guarda",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3831",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-06 16:09:38",
            "id" : 3831
         },
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositório Institucional do Instituto Politécnico da Guarda",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 4520,
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Portuguese.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://bdigital.ipg.pt/dspace/",
            "oai_url" : "http://bdigital.ipg.pt/dspace-oai/request",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 124,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt",
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repositorio.cespu.pt/",
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_other" : "Open Repository",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other",
               "version" : "5.5"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Portuguese, Spanish, French, Italian and English. Users may set up RSS and Atom feeds to be alerted to new content.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "metadata_record_count" : 1342,
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositório científico da CESPU"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CESPU.Cooperativa de Ensino Superior, Politécnico e Universitário, CRL"
               }
            ],
            "country" : "pt",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "url" : "https://www.cespu.pt/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3830",
            "publicly_visible" : "yes",
            "date_created" : "2017-02-06 16:05:21",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3830
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "ISMAI",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "pt",
            "url" : "http://www.ismai.pt/",
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "value" : "pt",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3829",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2017-02-06 15:50:15",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3829,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content. The interface is available in Portuguese or English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.2",
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.ismai.pt/oaiextended/request",
            "url" : "http://repositorio.ismai.pt/",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "RISMAI",
                  "name" : "Repositório Científico do ISMAI",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 768
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "url" : "http://repositorio.ucam.edu/",
            "oai_url" : "http://repositorio.ucam.edu/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 428,
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish and English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.6",
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 1530,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "RIUCAM",
                  "name" : "Institutional Repository UCAM",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 3828,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-06 11:22:52",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3828",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universidad Católica San Antonio de Murcia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "url" : "http://www.ucam.edu/",
            "location" : {
               "latitude" : 37.9913,
               "longitude" : -1.1851
            },
            "country" : "es"
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "software" : {
               "version" : "3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 451,
            "url" : "http://eprints.abuad.edu.ng/",
            "oai_url" : "http://eprints.abuad.edu.ng/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Afe Babalola University Repository"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 471,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 3827,
            "date_created" : "2017-02-06 11:12:55",
            "date_modified" : "2019-10-17 14:35:04",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3827",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ng",
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "value" : "ng",
                  "language" : "en"
               }
            ],
            "url" : "http://abuad.edu.ng/",
            "location" : {
               "latitude" : 7.60621,
               "longitude" : 5.30503
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Afe Babalola University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "id"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Management and Planning",
                  "value" : "28",
                  "language" : "en"
               },
               {
                  "phrase" : "Psychology",
                  "language" : "en",
                  "value" : "29"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "full_text_record_count" : 143,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://repository.ubharajaya.ac.id/",
            "oai_url" : "http://repository.ubharajaya.ac.id/cgi/oai2",
            "content_subjects" : [
               "28",
               "29"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3",
               "name" : "eprints"
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content.",
            "metadata_record_count" : 1301,
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "Repositori Universitas Bhayangkara Jakarta Raya",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3826",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-03 13:40:23",
            "id" : 3826
         },
         "organisation" : {
            "country" : "id",
            "location" : {
               "longitude" : 107.002,
               "latitude" : -6.2324
            },
            "url" : "http://www.ubharajaya.ac.id/",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universitas Bhayangkara Jakarta Raya",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 0,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Digital Library of Slovenia",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.dlib.si/",
            "oai_url" : "http://nukoai.nuk.uni-lj.si:8089/repox",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Repox",
               "name" : "other"
            },
            "description" : "This site provides access to the collections and research of the institution. The interface is available in Slovenian and English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Slovene",
                  "value" : "sl",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "sl"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "National and University Library of Slovenia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 46.0569,
               "longitude" : 14.5058
            },
            "url" : "http://www.nuk.uni-lj.si/",
            "country_phrases" : [
               {
                  "phrase" : "Slovenia",
                  "value" : "si",
                  "language" : "en"
               }
            ],
            "country" : "si"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3825",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:34",
            "date_created" : "2017-02-02 14:21:03",
            "id" : 3825
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "datasets"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://researchdata.aston.ac.uk/",
            "oai_url" : "http://researchdata.aston.ac.uk/cgi/oai2",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3.3.16",
               "name" : "eprints"
            },
            "description" : "This site provides access to the research data output of the institution. The interface is available in English. Users may set up RSS and Atom feeds to be alerted to new content.",
            "metadata_record_count" : 219,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Aston Data Explorer"
               }
            ],
            "type" : "institutional"
         },
         "policies" : {
            "data_policy" : {
               "url" : [
                  "hhttp://libguides.aston.ac.uk/ResearchData"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "some_or_all_restricted",
                     "phrase" : "Access to some or all full items is restricted"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions",
                     "value" : "individually_tagged",
                     "language" : "en"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "individually_tagged",
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "url_retention_phrases" : [
                        {
                           "value" : "not_retained",
                           "language" : "en",
                           "phrase" : "Not at all"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "not_retained"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security"
                  ],
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "value" : "removal_at_request",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "deleted"
               },
               "closure_policy" : "undefined",
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "retention_period" : {
                  "period" : "undefined",
                  "period_phrases" : [
                     {
                        "phrase" : "No retention period defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ]
               }
            },
            "submission_policy" : {
               "url" : [
                  "http://libguides.aston.ac.uk/ResearchData"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "value" : "no_policy",
                     "language" : "en",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "depositors" : [
                  "community_members"
               ],
               "quality_control" : "not_checked",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is not checked.",
                     "value" : "not_checked",
                     "language" : "en"
                  }
               ],
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ]
            },
            "content_policy" : {
               "types_included" : {
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "language" : "en",
                        "value" : "bibliographic_references",
                        "phrase" : "Bibliographic References"
                     },
                     {
                        "phrase" : "Datasets",
                        "value" : "datasets",
                        "language" : "en"
                     }
                  ],
                  "standard_types_allowed" : [
                     "bibliographic_references",
                     "datasets"
                  ]
               },
               "repository_type" : "institutional_or_departmental",
               "url" : [
                  "http://libguides.aston.ac.uk/ResearchData"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3824",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3824,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-02-02 14:14:46",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Aston University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "latitude" : 52.4862,
               "longitude" : -1.8896
            },
            "url" : "http://www.aston.ac.uk/",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "value" : "gb",
                  "language" : "en"
               }
            ],
            "country" : "gb"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "eprints",
               "version" : "3",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://eprints.ummi.ac.id/",
            "oai_url" : "http://eprints.ummi.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Repository UMMI",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 190,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "id"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "value" : "id",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2017-02-01 15:19:18",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3823,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3823",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Muhammadiyah Sukabumi"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "location" : {
               "latitude" : -6.91889,
               "longitude" : 106.932
            },
            "url" : "http://ummi.ac.id/",
            "country" : "id"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://194.44.12.92:8080/jspui/?locale=en",
            "content_languages" : [
               "uk",
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "1.8.2"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "metadata_record_count" : 2573,
            "content_languages_phrases" : [
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of the State Higher Educational Institution National Academy of Statistics, Accounting and Auditing"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ]
         },
         "organisation" : {
            "url" : "http://nasoa.edu.ua/en/",
            "location" : {
               "longitude" : 30.5238,
               "latitude" : 50.4547
            },
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "National Academy of Statistics, Accounting and Auditing",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3822",
            "publicly_visible" : "yes",
            "id" : 3822,
            "date_created" : "2017-02-01 13:40:55",
            "date_modified" : "2019-10-17 14:35:04"
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the institution.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "4.1"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "si",
               "en"
            ],
            "url" : "http://repository.kln.ac.lk/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Digital Repository, University of Kelaniya",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "si",
                  "language" : "en",
                  "phrase" : "Sinhalese"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 16274
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3821,
            "date_created" : "2017-01-31 10:45:29",
            "date_modified" : "2019-10-17 14:35:04",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3821"
         },
         "organisation" : {
            "country" : "lk",
            "location" : {
               "latitude" : 6.3153,
               "longitude" : 82.2656
            },
            "url" : "http://www.kln.ac.lk/",
            "country_phrases" : [
               {
                  "value" : "lk",
                  "language" : "en",
                  "phrase" : "Sri Lanka"
               }
            ],
            "name" : [
               {
                  "name" : "University of Kelaniya",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-21 08:30:06",
            "date_created" : "2017-01-30 10:32:30",
            "id" : 3820,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3820"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "acronym" : "CUC",
                  "name" : "Universidad de la Costa",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "location" : {
               "longitude" : -74.7894,
               "latitude" : 10.9963
            },
            "url" : "https://www.cuc.edu.co"
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "es"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the Universidad de la Costa. The interface is available in English, Spanish and Portuguese.",
            "software" : {
               "name" : "dspace",
               "version" : "6.3",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "oai_url" : "http://repositorio.cuc.edu.co/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.cuc.edu.co",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio - Universidad de la Costa",
                  "acronym" : "REDICUC",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 1164
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "https://www.uns.edu.pe/",
            "location" : {
               "longitude" : -78.5138,
               "latitude" : -9.1217
            },
            "country" : "pe",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Universidad Nacional del Santa",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3819",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2017-01-30 10:28:26",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3819,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "metadata_record_count" : 1151,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositorio Institucional Digital de la Universidad Nacional del Santa",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://repositorio.uns.edu.pe/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.uns.edu.pe/",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the students of this institution. The interface is available in Spanish. Users may set up RSS and Atom feeds to be alerted to new content."
         }
      },
      {
         "organisation" : {
            "location" : {
               "longitude" : -2.23322,
               "latitude" : 53.4679
            },
            "url" : "http://www.manchester.ac.uk/",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "University of Manchester",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-01-26 10:19:46",
            "id" : 3818,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3818",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "The University of Manchester - Institutional Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 207800,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "PURE",
                     "language" : "en",
                     "value" : "pure"
                  }
               ],
               "name" : "pure"
            },
            "description" : "This site provides access to the research outputs of the institution. Some content is not available as full text. The interface is available in English.",
            "full_text_record_count" : 75,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://www.research.manchester.ac.uk/portal",
            "oai_url" : "https://pure.manchester.ac.uk/ws/oai",
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 543,
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "name" : "CCT CONICET-CENPAT Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://www.repositorio.cenpat-conicet.gob.ar/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "CCT CONICET-CENPAT",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "url" : "http://www.cenpat-conicet.gov.ar/",
            "location" : {
               "longitude" : -65.083,
               "latitude" : -42.7438
            },
            "country" : "ar"
         },
         "system_metadata" : {
            "id" : 3817,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-01-12 14:26:21",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3817",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "language" : "en",
                  "value" : "26",
                  "phrase" : "Law and Politics"
               },
               {
                  "language" : "en",
                  "value" : "29",
                  "phrase" : "Psychology"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 10,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "UDAFF Repositorio Institucional",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "7",
               "24",
               "25",
               "26",
               "29"
            ],
            "url" : "http://repositorio.udaff.edu.pe/",
            "oai_url" : "http://repositorio.udaff.edu.pe/oai",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6",
               "name" : "dspace"
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "http://www.udaff.edu.pe/",
            "location" : {
               "latitude" : -13.1473,
               "longitude" : -74.2288
            },
            "country" : "pe",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad de Ayacucho Federico Froebel",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2017-01-05 15:10:43",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3816,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3816",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 3815,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-01-05 15:04:17",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3815",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Belarusian Trade and Economics University of Consumer Cooperatives",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "by",
            "location" : {
               "latitude" : 52.4067,
               "longitude" : 30.9355
            },
            "url" : "http://i-bteu.by/",
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "value" : "by",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages" : [
               "ru"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "value" : "29",
                  "language" : "en",
                  "phrase" : "Psychology"
               },
               {
                  "value" : "16",
                  "language" : "en",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "metadata_record_count" : 3173,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Electronic library of Belarusian Trade and Economics University of Consumer Cooperatives",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "[\"language_codes_typename_\" not defined]",
                        "value" : "",
                        "language" : "en"
                     }
                  ],
                  "language" : "",
                  "preferred" : "",
                  "preferred_phrases" : [
                     {
                        "phrase" : "UNSPECIFIED",
                        "language" : "en",
                        "value" : ""
                     }
                  ],
                  "name" : "Электронная библиотека БТЭУ потребительской кооперации"
               }
            ],
            "url" : "http://lib.i-bteu.by/",
            "oai_url" : "http://lib.i-bteu.by/oai/request",
            "content_subjects" : [
               "10",
               "24",
               "26",
               "29",
               "16"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 1555,
            "description" : "This site provides access to the output and collections of the institution. The interface is available in Russian or English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "4.3-SNAPSHOT",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of Kazimierz Wielki University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Polish"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 4925,
            "description" : "This site provides access to the research output of the institution. The interface is available in Polish.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repozytorium.ukw.edu.pl/",
            "content_languages" : [
               "pl",
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "closure_policy" : "undefined",
               "url" : [
                  "http://repozytorium.ukw.edu.pl/page/polityka"
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  },
                  "method_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No deletion method for withdrawn items defined"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "undefined"
               }
            },
            "submission_policy" : {
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ],
               "url" : [
                  "http://repozytorium.ukw.edu.pl/page/polityka"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "policy_undefined",
                     "language" : "en",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "content_embargo" : "policy_undefined"
            },
            "content_policy" : {
               "url" : [
                  "http://repozytorium.ukw.edu.pl/page/polityka"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "submitted_versions",
                  "accepted_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               }
            }
         },
         "organisation" : {
            "country" : "pl",
            "url" : "http://repozytorium.ukw.edu.pl/",
            "location" : {
               "latitude" : 53.1336,
               "longitude" : 18.0176
            },
            "country_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Poland"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Kazimierz Wielki University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-01-05 14:48:54",
            "id" : 3814,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3814"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3813",
            "publicly_visible" : "yes",
            "id" : 3813,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-01-04 14:40:10"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Eszterhazy Karoly University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "hu",
            "url" : "https://uni-eszterhazy.hu/",
            "country_phrases" : [
               {
                  "phrase" : "Hungary",
                  "value" : "hu",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "http://disszertacio.uni-eszterhazy.hu/",
            "oai_url" : "http://disszertacio.uni-eszterhazy.hu/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research output of the PhD students of the institution. The interface is available in Hungarian.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3"
            },
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 26,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "EKE Repository of PhD Dissertations",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_languages" : [
               "hu"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "hu",
                  "phrase" : "Hungarian"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "EKE Repository of Publications",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 365,
            "description" : "This site provides access to the research output of the institution. Atom and RSS feeds to alert users of new additions. Some content is only available to registered users. The interface is available in Hungarian.",
            "software" : {
               "name" : "eprints",
               "version" : "3",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "oai_url" : "http://publikacio.uni-eszterhazy.hu/cgi/oai2",
            "url" : "http://publikacio.uni-eszterhazy.hu/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Hungarian",
                  "language" : "en",
                  "value" : "hu"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "hu",
               "en"
            ]
         },
         "system_metadata" : {
            "date_created" : "2017-01-04 14:29:50",
            "date_modified" : "2019-10-17 14:35:04",
            "id" : 3812,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3812",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Eszterhazy Karoly University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "hu",
            "url" : "https://uni-eszterhazy.hu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "hu",
                  "phrase" : "Hungary"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.uca.edu.sv/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositorio Institucional Universidad Centroamericana José Simeón Cañas",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 831
         },
         "system_metadata" : {
            "id" : 3811,
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2017-01-04 13:46:33",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3811",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "url" : "http://www.uca.edu.sv/",
            "country_phrases" : [
               {
                  "phrase" : "El Salvador",
                  "language" : "en",
                  "value" : "sv"
               }
            ],
            "country" : "sv",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Centroamericana José Simeón Cañas"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://vital.lib.tsu.ru/",
            "content_languages" : [
               "ru"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "vital",
                     "language" : "en",
                     "phrase" : "VITAL"
                  }
               ],
               "name" : "vital"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "Digital library (repository) of Tomsk State University offers its users an access to various full-text resources - results of scientific research and educational activities held at TSU. It also includes publications that have scientific value for the researchers in the fields of history, culture and education in Siberia, Tomsk, Tomsk State University and the literary heritage of Tomsk oblast of federal and regional levels.\nThe Site and its contents are presented in Russian and English languages.",
            "metadata_record_count" : 33609,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Digital library (repository) of Tomsk State University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2016-12-14 13:07:35",
            "id" : 3810,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3810"
         },
         "organisation" : {
            "country" : "ru",
            "url" : "http://www.tsu.ru/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian Federation"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Tomsk State University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "language" : "en",
                     "value" : "working_drafts"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "published_versions"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://eprints.umsida.ac.id/policies.html"
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://eprints.umsida.ac.id/policies.html"
               ],
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission"
            },
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "spam_exclusion",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items may not be deposited until any embargo period has expired",
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry"
                  }
               ],
               "url" : [
                  "http://eprints.umsida.ac.id/policies.html"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "employees"
               ],
               "moderation_purposes" : [
                  "spam_exclusion"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry"
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://eprints.umsida.ac.id/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted",
                     "updated_versions_allowed"
                  ],
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ]
               },
               "withdrawal" : {
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Falsified research",
                        "language" : "en",
                        "value" : "falsified_research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "value" : "removal_not_normal",
                        "language" : "en",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "removed_from_public_view"
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  }
               ],
               "url" : [
                  "http://eprints.umsida.ac.id/policies.html"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ]
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3809",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2016-12-07 14:45:11",
            "id" : 3809,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universitas Muhammadiyah Sidoarjo",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "url" : "http://umsida.ac.id/home",
            "location" : {
               "latitude" : -7.4668,
               "longitude" : 112.717
            },
            "country" : "id"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution.",
            "software" : {
               "version" : "3.3.15",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "url" : "http://eprints.umsida.ac.id/",
            "content_subjects" : [
               "23",
               "24",
               "25",
               "11",
               "26",
               "13"
            ],
            "oai_url" : "http://eprints.umsida.ac.id/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "eprints umsida",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               }
            ],
            "metadata_record_count" : 1332,
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               },
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "phrase" : "Civil Engineering",
                  "value" : "13",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "id",
               "en"
            ],
            "content_types" : [
               "conference_and_workshop_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in a mixture of English and Arabic.",
            "software" : {
               "name" : "dspace",
               "version" : "4.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ar"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.wnu.edu.sd:8080/xmlui/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Digtial Repository of White Nile University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Arabic"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "metadata_record_count" : 379
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2016-12-07 14:29:38",
            "id" : 3808,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3808",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "White Nile University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "sd",
                  "phrase" : "Sudan"
               }
            ],
            "location" : {
               "latitude" : 13.1481,
               "longitude" : 32.6724
            },
            "url" : "http://www.wnu.edu.sd/",
            "country" : "sd"
         }
      },
      {
         "policies" : {
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ],
               "url" : [
                  "http://repositorio.upnfm.edu.hn:8081/xmlui/politicas.html"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ],
               "reuse_conditions" : [
                  "mentioning_the_repository_is_appreciated"
               ]
            },
            "submission_policy" : {
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "value" : "registered_students",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repositorio.upnfm.edu.hn:8081/xmlui/politicas.html"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "value" : "item_relevance",
                     "language" : "en"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "value" : "full_texts_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://repositorio.upnfm.edu.hn:8081/xmlui/politicas.html"
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "language" : "en",
                     "value" : "requires_permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "value" : "repository_mention_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "metadata_phrases" : [
                  {
                     "value" : "publication_status",
                     "language" : "en",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://repositorio.upnfm.edu.hn:8081/xmlui/politicas.html"
               ],
               "metadata" : [
                  "publication_status"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "languages" : [
                  "es",
                  "en"
               ],
               "types_included" : {
                  "all" : "true"
               },
               "languages_phrases" : [
                  {
                     "value" : "es",
                     "language" : "en",
                     "phrase" : "Spanish"
                  },
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "versions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "working_drafts",
                     "phrase" : "working drafts"
                  },
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidad Pedagógica Nacional Francisco Morazán"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "hn",
                  "language" : "en",
                  "phrase" : "Honduras"
               }
            ],
            "location" : {
               "latitude" : 14.0726,
               "longitude" : -87.1655
            },
            "url" : "http://www.upnfm.edu.hn/",
            "country" : "hn"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3807",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:04",
            "date_created" : "2016-12-07 14:15:57",
            "id" : 3807,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "url" : "http://repositorio.upnfm.edu.hn:8081/xmlui/",
            "oai_url" : "http://repositorio.upnfm.edu.hn:8081/oai",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositorio Documental de la Universidad Pedagógica Nacional Francisco Morazán",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 308,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3806,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-12-07 14:10:29",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3806"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Ivano-Frankivsk National Technical University of Oil and Gas",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 48.9295,
               "longitude" : 24.6958
            },
            "url" : "http://www.nung.edu.ua/",
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "country" : "ua"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Institutional Repository of Ivano-Frankivsk National Technical University of Oil and Gas",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 5761,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "description" : "This site provides open access to scientific materials of University. The interface is available in Ukrainian, English and Russian. Users may set up RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://elar.nung.edu.ua/",
            "oai_url" : "http://elar.nung.edu.ua/oai/request",
            "content_subjects" : [
               "7",
               "8"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "uk",
                  "phrase" : "Ukrainian"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               }
            ],
            "content_languages" : [
               "uk"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3804",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 3804,
            "date_created" : "2016-11-23 08:50:41",
            "date_modified" : "2019-10-17 14:35:03",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "location" : {
               "latitude" : 35.7264,
               "longitude" : 140.221
            },
            "url" : "http://www.rekihaku.ac.jp/",
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "National Museum of Japanese History"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "20"
            ],
            "url" : "https://rekihaku.repo.nii.ac.jp/",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The site interface is available in Japanese. Title and abstract are available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "name" : "National Museum of Japanese History Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Educational Establishment Gomel State Medical University"
               }
            ],
            "url" : "http://gsmu.by/",
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "value" : "by",
                  "language" : "en"
               }
            ],
            "country" : "by"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3803",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-22 14:37:42",
            "id" : 3803,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "4.3",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Russian or English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "21",
                  "phrase" : "Language and Literature"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://elib.gsmu.by/",
            "content_subjects" : [
               "21",
               "10"
            ],
            "content_languages" : [
               "ru"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of the Gomel State Medical University"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers"
            ],
            "metadata_record_count" : 3595,
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "value" : "ru",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2016-11-18 15:18:25",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3802,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3802"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Yamagata University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.yamagata-u.ac.jp/jp/",
            "location" : {
               "longitude" : 140.349,
               "latitude" : 38.2467
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         },
         "repository_metadata" : {
            "metadata_record_count" : 4727,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "name" : "Yamagata University Academic Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 4262,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://yamagata.repo.nii.ac.jp/",
            "oai_url" : "http://yamagata.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "17",
               "3",
               "10",
               "25",
               "11"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Japanese or English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Education",
                  "value" : "25",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3801",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2016-11-18 15:11:14",
            "date_modified" : "2019-12-04 12:27:34",
            "id" : 3801,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "http://www.unr.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "University of Nevada, Reno",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "5.5",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "oai_url" : "https://scholarworks.unr.edu/oai/request",
            "url" : "https://scholarworks.unr.edu/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "University of Nevada, Reno ScholarWorks Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2954,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://sinta.ukdw.ac.id/sinta",
            "oai_url" : "http://sinta.ukdw.ac.id/sinta/repo/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "description" : "This is repository of thesis and dissertation of UKDW. The interface is available in Indonesian",
            "software" : {
               "name" : "other",
               "name_other" : "JSP-MySQL-Alfresco",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 9144,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Sistem Informasi Tugas Akhir",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "id"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3800",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-17 14:44:01",
            "id" : 3800,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "id",
            "location" : {
               "longitude" : 110.376,
               "latitude" : -7.78605
            },
            "url" : "http://www.ukdw.ac.id/",
            "country_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesia"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universitas Kristen Duta Wacana",
                  "acronym" : "UKDW",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Maasai Mara University Institutional Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 5249,
            "description" : "This site provides access to the research output of the institution. The interface sis available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "dspace",
               "version" : "4.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://41.89.101.166:8080/xmlui/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-17 14:27:11",
            "id" : 3799,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3799"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Maasai Mara University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "ke",
            "url" : "http://www.mmarau.ac.ke/",
            "location" : {
               "latitude" : -1.0875,
               "longitude" : 35.8771
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ke",
                  "phrase" : "Kenya"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 4548,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Scholar Commons - Santa Clara University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1067,
            "oai_url" : "http://scholarcommons.scu.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://scholarcommons.scu.edu/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Santa Clara University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://www.scu.edu/",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Santa Clara University Library"
               }
            ],
            "location" : {
               "longitude" : -121.938,
               "latitude" : 37.3485
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3798",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 3798,
            "date_created" : "2016-11-17 14:16:07",
            "date_modified" : "2019-10-17 14:35:03",
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.almau.edu.kz/xmlui/",
            "content_languages" : [
               "ru"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Kazakh, Russian and English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "metadata_record_count" : 1590,
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Repository of Almaty Management University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ]
         },
         "system_metadata" : {
            "date_created" : "2016-11-17 14:06:33",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3797,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3797",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "kz",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "kz",
                  "phrase" : "Kazakhstan"
               }
            ],
            "location" : {
               "latitude" : 43.222,
               "longitude" : 76.8512
            },
            "url" : "http://www.almau.edu.kz/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Almaty Management University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Pontificia Comillas"
               }
            ],
            "country" : "es",
            "url" : "http://www.comillas.edu/",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3796",
            "publicly_visible" : "yes",
            "id" : 3796,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-17 14:03:52"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repositorio.comillas.edu/xmlui/",
            "oai_url" : "https://repositorio.comillas.edu/oai/request?",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English and Spanish.",
            "metadata_record_count" : 100,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Comillas"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The Interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "3.1",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://41.89.164.122:8080/xmlui/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "University of Eldoret Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 116
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3795",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-17 13:50:01",
            "id" : 3795
         },
         "organisation" : {
            "country" : "ke",
            "url" : "http://www.uoeld.ac.ke/karibu/",
            "country_phrases" : [
               {
                  "phrase" : "Kenya",
                  "value" : "ke",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "University of Eldoret",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "gb",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "url" : "http://www.winchester.ac.uk/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "University of Winchester",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 3794,
            "date_created" : "2016-11-15 14:24:54",
            "date_modified" : "2019-12-04 12:27:34",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3794",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repository.winchester.ac.uk/help/#data"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access" : "free_open_access",
               "reuse" : "individually_tagged",
               "reuse_phrases" : [
                  {
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions",
                     "language" : "en",
                     "value" : "individually_tagged"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Winchester Research Portal",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 3500,
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "PURE",
                     "value" : "pure",
                     "language" : "en"
                  }
               ],
               "name" : "pure"
            },
            "url" : "https://winchester.elsevierpure.com/",
            "oai_url" : "https://cris.winchester.ac.uk/ws/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 667
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 614,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "name" : "Repositorio institucional UAM",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.autonoma.edu.co/oai/request",
            "url" : "http://repositorio.autonoma.edu.co/jspui/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "1.8.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-11 15:40:57",
            "id" : 3793,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3793"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad Autónoma de Manizales"
               }
            ],
            "country" : "co",
            "country_phrases" : [
               {
                  "value" : "co",
                  "language" : "en",
                  "phrase" : "Colombia"
               }
            ],
            "location" : {
               "latitude" : 5.0671,
               "longitude" : -75.5183
            },
            "url" : "http://www.autonoma.edu.co/"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "el"
            ],
            "url" : "http://okeanos-dspace.hcmr.gr/",
            "content_subjects" : [
               "4",
               "6",
               "7",
               "5"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "language" : "en",
                  "value" : "6",
                  "phrase" : "Earth and Planetary Sciences"
               },
               {
                  "phrase" : "Ecology and Environment",
                  "value" : "7",
                  "language" : "en"
               },
               {
                  "phrase" : "Chemistry and Chemical Technology",
                  "language" : "en",
                  "value" : "5"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English or Greek.",
            "software" : {
               "name" : "dspace",
               "version" : "1.8.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "el",
                  "language" : "en",
                  "phrase" : "Greek (modern)"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               }
            ],
            "metadata_record_count" : 3155,
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Okeanos",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "country" : "gr",
            "country_phrases" : [
               {
                  "value" : "gr",
                  "language" : "en",
                  "phrase" : "Greece"
               }
            ],
            "url" : "http://www.hcmr.gr/",
            "location" : {
               "longitude" : 23.9041,
               "latitude" : 37.7335
            },
            "name" : [
               {
                  "name" : "Hellenic Centre for Marine Research",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3792,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 16:33:40",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3792"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "location" : {
               "latitude" : -12.085,
               "longitude" : -76.9099
            },
            "url" : "http://ucal.edu.pe/",
            "country" : "pe",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad de Ciencias y Artes de América Latina",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3791",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 16:28:04",
            "id" : 3791,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "metadata_record_count" : 80,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Repositorio UCAL",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 59,
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.ucal.edu.pe/oai/request",
            "url" : "http://repositorio.ucal.edu.pe/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3790",
            "publicly_visible" : "yes",
            "id" : 3790,
            "date_created" : "2016-11-10 16:19:55",
            "date_modified" : "2019-10-17 14:35:03"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "location" : {
               "latitude" : 51.4902,
               "longitude" : -0.17424
            },
            "url" : "http://www.icr.ac.uk/",
            "country" : "gb",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institute of Cancer Research",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "notes" : "Older publications are available at http://publications.icr.ac.uk/",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_subjects" : [
               "10"
            ],
            "url" : "http://repository.icr.ac.uk/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "software" : {
               "name" : "dspace",
               "version" : "5.4",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "metadata_record_count" : 1852,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Publications Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 11110,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               }
            ],
            "name" : [
               {
                  "name" : "Works",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 508,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://works.swarthmore.edu/",
            "oai_url" : "http://works.swarthmore.edu/do/oai/",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English. Some content is not available as full-text.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3788",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3788,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 16:00:18",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "unit" : [
               {
                  "name" : "Swarthmore College Libraries",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -75.353,
               "latitude" : 39.9053
            },
            "url" : "http://www.swarthmore.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "name" : "Swarthmore College",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "bg",
            "url" : "http://uni-sz.bg/",
            "country_phrases" : [
               {
                  "phrase" : "Bulgaria",
                  "value" : "bg",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Trakia University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3786",
            "publicly_visible" : "yes",
            "date_created" : "2016-11-10 15:52:30",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3786
         },
         "repository_metadata" : {
            "metadata_record_count" : 48,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Bulgarian",
                  "value" : "bg",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "name" : "Trakia University - Digital Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.uni-sz.bg/",
            "content_languages" : [
               "en",
               "bg"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "3.2",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Bulgarian or English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "SAUL Archive",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 1120,
            "description" : "This site provides access to the student research output of the institution. The interface is available in English.",
            "software" : {
               "version" : "3.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "oai_url" : "http://archive.saulibrary.edu.bd:8080/oai/request",
            "url" : "http://archive.saulibrary.edu.bd/",
            "content_subjects" : [
               "3"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Sher-e-Bangla Agricultural University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "bd",
                  "language" : "en",
                  "phrase" : "Bangladesh"
               }
            ],
            "url" : "http://www.saulibrary.edu.bd/",
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Sher-e-Bangla Agricultural University Library"
               }
            ],
            "country" : "bd"
         },
         "system_metadata" : {
            "id" : 3785,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 15:49:31",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3785",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "url" : [
                  "http://eprints.ukmc.ac.id/policies.html"
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "url" : [
                  "http://eprints.ukmc.ac.id/policies.html"
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://eprints.ukmc.ac.id/policies.html"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "language" : "en",
                     "value" : "working_drafts"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "url" : [
                  "http://eprints.ukmc.ac.id/policies.html"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://eprints.ukmc.ac.id/policies.html"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ]
            }
         },
         "system_metadata" : {
            "id" : 3784,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 15:40:55",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3784",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Musi Charitas Catholic University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "url" : "http://ukmc.ac.id/",
            "country" : "id"
         },
         "repository_metadata" : {
            "full_text_record_count" : 1442,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://eprints.ukmc.ac.id/cgi/oai2",
            "url" : "http://eprints.ukmc.ac.id/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "metadata_record_count" : 2082,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Musi Charitas Catholic University Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "id",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Arkansas, Fayetteville"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 36.0846,
               "longitude" : -94.1968
            },
            "url" : "http://www.uark.edu/",
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3783",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 15:32:07",
            "id" : 3783,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "metadata_record_count" : 8073,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "ScholarWorks@UARK",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://scholarworks.uark.edu/do/oai/",
            "url" : "http://scholarworks.uark.edu/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects",
               "patents"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "year_established" : 2015,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://eprints-bangaloreuniversity.in/",
            "oai_url" : "http://eprints-bangaloreuniversity.in/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "metadata_record_count" : 6043,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "ePrints@Bangalore University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country" : "in",
            "url" : "http://bangaloreuniversity.ac.in/",
            "location" : {
               "longitude" : 77.5052,
               "latitude" : 12.9445
            },
            "country_phrases" : [
               {
                  "value" : "in",
                  "language" : "en",
                  "phrase" : "India"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Bangalore University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3782",
            "publicly_visible" : "yes",
            "id" : 3782,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 15:29:53"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "metadata_record_count" : 79,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Gifu Womens University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 66,
            "url" : "https://gijodai.repo.nii.ac.jp/",
            "oai_url" : "https://gijodai.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution. The site interface is available in Japanese, or English."
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Gifu Womens University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "location" : {
               "latitude" : 35.5009,
               "longitude" : 136.808
            },
            "url" : "http://www.gijodai.ac.jp/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3781",
            "publicly_visible" : "yes",
            "id" : 3781,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 15:15:57"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3780",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2016-11-10 15:12:41",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3780,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Kyoto Gakuen University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "url" : "http://www.kyotogakuen.ac.jp/",
            "location" : {
               "latitude" : 34.9938,
               "longitude" : 135.554
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "full_text_record_count" : 1300,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://kyotogakuen.repo.nii.ac.jp/",
            "oai_url" : "https://kyotogakuen.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese or English",
            "metadata_record_count" : 1331,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "KYOTO GAKUEN UNIVERSITY ACADEMIC REPOSITORY",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 1867,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Fuji Women’s University Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 1857,
            "oai_url" : "https://fujijoshi.repo.nii.ac.jp/oai",
            "url" : "https://fujijoshi.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese or English",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 141.354,
               "latitude" : 43.0822
            },
            "url" : "http://www.fujijoshi.ac.jp/",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Fuji Women’s University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2016-11-10 15:11:09",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3779,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3779"
         }
      },
      {
         "system_metadata" : {
            "id" : 3778,
            "date_created" : "2016-11-10 15:10:13",
            "date_modified" : "2019-10-17 14:35:03",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3778",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Naragakuen University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "url" : "http://www.naragakuen-u.jp/",
            "location" : {
               "longitude" : 135.675,
               "latitude" : 34.603
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 3146,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Naragakuen University Academic Repository"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 2138,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://naragakuen.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://naragakuen.repo.nii.ac.jp/oai",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese or English",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "jp",
            "url" : "http://www.musashino-u.ac.jp/",
            "location" : {
               "latitude" : 35.7179,
               "longitude" : 139.548
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "name" : [
               {
                  "name" : "Musashino University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 3777,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 15:08:49",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3777",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 997,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Musashino University Academic Institutional Repository"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 937,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://mu.repo.nii.ac.jp/oai",
            "url" : "https://mu.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese or English."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3776,
            "date_created" : "2016-11-10 14:41:40",
            "date_modified" : "2019-12-04 12:27:34",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3776"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Ripon College",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -88.8359,
               "latitude" : 43.8422
            },
            "url" : "http://www.ripon.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "content_types" : [
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Rpion College Senior Showcase"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "description" : "This site provides access to multidisciplinary digitized projects presented at annual Senior Showcase.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "omeka",
                     "language" : "en",
                     "phrase" : "Omeka"
                  }
               ],
               "name" : "omeka"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://rcseniorshowcase.omeka.net/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "metadata_record_count" : 66,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Ryotokuji University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://ryotokuji-u.repo.nii.ac.jp/",
            "oai_url" : "https://ryotokuji-u.repo.nii.ac.jp/oia",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese or English."
         },
         "system_metadata" : {
            "id" : 3775,
            "date_created" : "2016-11-10 14:28:05",
            "date_modified" : "2019-10-17 14:35:03",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3775",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "url" : "http://www.ryotokuji-u.ac.jp/",
            "location" : {
               "longitude" : 139.926,
               "latitude" : 35.6387
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Ryotokuji University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Kanagawa Dental University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 35.2857,
               "longitude" : 139.67
            },
            "url" : "http://www.kdu.ac.jp/",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3774",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2016-11-10 14:26:53",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3774,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "metadata_record_count" : 1119,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "name" : "Kanagawa Dental University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 655,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "https://kdu.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://kdu.repo.nii.ac.jp/oai",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The site interface is available in Japanese.",
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "description" : "This site is an institutional repository providing access to the publication output of Saitama Medical University. The site interface is available in Japanese or English, although some parts of the site remain available in Japanese only.",
            "full_text_record_count" : 423,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://saitama-med.repo.nii.ac.jp/oai",
            "url" : "https://saitama-med.repo.nii.ac.jp/",
            "content_subjects" : [
               "10"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Saitama Medical University Repository"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 575,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3773",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 3773,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 14:25:43",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "埼玉医科大学",
                  "name" : "Saitama Medical University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "url" : "http://www.saitama-med.ac.jp/",
            "location" : {
               "latitude" : 35.9391,
               "longitude" : 139.306
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "full_text_record_count" : 2516,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://chikyu.repo.nii.ac.jp/oai",
            "url" : "https://chikyu.repo.nii.ac.jp/",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Japanese or English.",
            "metadata_record_count" : 3335,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Research Institute for Humanity and Nature Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Research Institute for Humanity and Nature",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "location" : {
               "longitude" : 135.455,
               "latitude" : 35.0422
            },
            "url" : "http://www.chikyu.ac.jp/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3772",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 14:24:21",
            "id" : 3772
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 10494,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "National Institute for Fusion Science (NIFS-Repository)",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 9133,
            "url" : "http://nifs-repository.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://nifs-repository.repo.nii.ac.jp/oai",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in a mixture of Japanese and English."
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "NIFS",
                  "name" : "National Institute for Fusion Science",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "jp",
            "url" : "http://www.nifs.ac.jp/",
            "location" : {
               "longitude" : 137.169,
               "latitude" : 35.326
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3771",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 14:20:31",
            "id" : 3771
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3770,
            "date_created" : "2016-11-10 14:17:03",
            "date_modified" : "2019-10-17 14:35:03",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3770"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "亞洲大學",
                  "name" : "Asia University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "tw",
            "location" : {
               "latitude" : 24.0241,
               "longitude" : 120.689
            },
            "url" : "http://www.asia.edu.tw/",
            "country_phrases" : [
               {
                  "phrase" : "Taiwan (Province of China)",
                  "value" : "tw",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "description" : "This site provides access to the research output of the institution. The interface is available in Japanese.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "url" : "https://asia-u.repo.nii.ac.jp/",
            "oai_url" : "http://asia-u.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 1898,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Asia University Academic Repositories",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 17477
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "TEIKYO University of Science",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.ntu.ac.jp/",
            "location" : {
               "latitude" : 35.7535,
               "longitude" : 139.789
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3769",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 14:14:48",
            "id" : 3769,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The site interface is available in Japanese or English.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "oai_url" : "https://tust.repo.nii.ac.jp/oai",
            "url" : "https://tust.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 168,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "TEIKYO University of Science Academic Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "metadata_record_count" : 650,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "oai_url" : "http://shk.repo.nii.ac.jp/oai",
            "url" : "https://shk.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 55,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution.The site interface is available in Japanese.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 58,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Higashi Nippon International University / Iwaki Junior College Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Iwaki Junior College"
               }
            ],
            "url" : "http://www.shk-ac.jp/",
            "location" : {
               "latitude" : 37.0568,
               "longitude" : 140.908
            },
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Higashi Nippon International University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3768",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 14:07:30",
            "id" : 3768
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3767,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 13:55:46",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3767"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Suzuka University of medical science",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.suzuka-u.ac.jp/index.shtml",
            "location" : {
               "longitude" : 136.598,
               "latitude" : 34.8593
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Suzuka University of medical science institutional repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 47,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in a mixture of Japanese and English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 32,
            "content_subjects" : [
               "1"
            ],
            "url" : "https://sums.repo.nii.ac.jp/",
            "oai_url" : "https://sums.repo.nii.ac.jp/oai",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ]
         }
      },
      {
         "organisation" : {
            "location" : {
               "longitude" : 135.48,
               "latitude" : 35.1913
            },
            "url" : "http://www.meiji-u.ac.jp/",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Meiji University of Integrative Medicine",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3766",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 3766,
            "date_modified" : "2019-10-17 14:35:03",
            "date_created" : "2016-11-10 13:51:01",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Meiji University of Integrative Medicine Academic Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 5,
            "description" : "This site provides access to the student research output of the institution. The interface is available in Japanese.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "url" : "https://meiji-u.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://meiji-u.repo.nii.ac.jp/oai",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 1,
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 3765,
            "date_created" : "2016-11-07 15:48:52",
            "date_modified" : "2019-12-04 12:27:34",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3765",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "http://www.csusb.edu/",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "John M. Pfau Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "name" : [
               {
                  "name" : "California State University San Bernardino",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 11389,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CSUSB ScholarWorks",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://scholarworks.lib.csusb.edu/do/oai/",
            "url" : "http://scholarworks.lib.csusb.edu/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "Institutional repository showcasing the scholarly output of students and faculty. Some items may be embargoed or restricted to on-campus access. The interface is available in English.",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            }
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 3764,
            "date_created" : "2016-11-07 15:40:33",
            "date_modified" : "2019-10-17 14:35:03",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3764"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "St. Cloud State University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.stcloudstate.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "metadata_record_count" : 1699,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository at St. Cloud State"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "url" : "http://repository.stcloudstate.edu/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "notes" : "This repository also contains the journals, Analysis of Gambling Behavior, Survive & Thrive: a Journal of the Medical Humanities; and Linguistic Portfolios: Student Scholarship in Applied Linguistics and seven quarterly economic and business condition reports focused on Minnesota.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://fada.birzeit.edu/",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Birzeit University Open Access Repository",
                  "acronym" : "FADA"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 4291,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "notes" : "Special items may include archaeological pieces and artistic collections",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2016-11-07 10:56:38",
            "date_modified" : "2019-12-04 12:27:34",
            "id" : 3763,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3763"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Birzeit University"
               }
            ],
            "country" : "ps",
            "url" : "http://www.birzeit.edu/",
            "country_phrases" : [
               {
                  "phrase" : "Palestine, State of",
                  "language" : "en",
                  "value" : "ps"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : -9.92756,
               "longitude" : -76.2378
            },
            "url" : "http://www.udh.edu.pe/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad de Huánuco"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2016-11-07 10:32:40",
            "date_modified" : "2019-10-17 14:35:03",
            "id" : 3762,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/3762",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 1890,
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Institucional de la Universidad de Huánuco",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 374,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.udh.edu.pe/",
            "oai_url" : "http://repositorio.udh.edu.pe/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.5"
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in Spanish. Not all items are available as full-text.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ]
         }
      }
   ]
}

