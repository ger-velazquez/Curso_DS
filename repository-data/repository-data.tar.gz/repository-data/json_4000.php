{
   "items" : [
      {
         "policies" : {
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1644",
            "publicly_visible" : "yes",
            "id" : 1644,
            "date_created" : "2009-10-22 11:11:00",
            "date_modified" : "2019-11-20 12:08:35"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -5.9823,
               "latitude" : 37.3881
            },
            "url" : "http://www.juntadeandalucia.es/organismos/educacionculturaydeporte.html",
            "country" : "es",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "JUNTA DE ANDALUCÍA, Consejería de Educación, Cultura y Deporte.",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Biblioteca Virtual de Andalucía"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "governmental",
            "metadata_record_count" : 10737,
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Digibib",
                     "value" : "digibib",
                     "language" : "en"
                  }
               ],
               "name" : "digibib"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "value" : "governmental",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "17",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               },
               {
                  "language" : "en",
                  "value" : "22",
                  "phrase" : "Philosophy and Religion"
               },
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "phrase" : "Science General",
                  "language" : "en",
                  "value" : "2"
               },
               {
                  "phrase" : "Mathematics and Statistics",
                  "language" : "en",
                  "value" : "8"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to digitised items of the institutions collection, relating to Andalusian heritage. The interface is in Spanish.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "17",
               "18",
               "22",
               "1",
               "2",
               "8",
               "23"
            ],
            "url" : "http://www.bibliotecavirtualdeandalucia.es/opencms"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1643",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 1643,
            "date_modified" : "2019-12-04 12:27:25",
            "date_created" : "2009-10-22 10:10:51",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "fr",
            "location" : {
               "latitude" : 48.8501,
               "longitude" : 2.3063
            },
            "url" : "http://www.unesco.org/new/en/",
            "country_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "France"
               }
            ],
            "name" : [
               {
                  "name" : "United Nations Educational, Scientific and Cultural Organization",
                  "acronym" : "UNESCO",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ar",
                  "language" : "en",
                  "phrase" : "Arabic"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 187,
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Majaliss",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "ar"
            ],
            "content_subjects" : [
               "1",
               "17",
               "21",
               "22"
            ],
            "url" : "http://rabat.unesco.org/majaliss/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Language and Literature",
                  "value" : "21",
                  "language" : "en"
               },
               {
                  "phrase" : "Philosophy and Religion",
                  "value" : "22",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "description" : "This site provides access to historic texts and audio items of North Africa (Maghreb Countries). The interface is in Arabic. Most files are in Zip format.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site is an institutional repository providing access to digitised historical source material from the ULB Darmstadt (Universitäts- und Landesbibliothek), some dating back to the 1500's. Materials include original magazines, incunabula, reports, illustrations, plans, photos, dictionaries and encyclopaedias. Also material that is interesting for the history of the region, e.g. the early yellow pages of the city of Darmstadt, Hessia.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "de"
            ],
            "url" : "http://www.ulb.tu-darmstadt.de/spezialabteilungen/digitale_sammlungen_2/digitale_sammlungen.de.jsp",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "tudigit",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "metadata_record_count" : 625,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1642",
            "publicly_visible" : "yes",
            "date_created" : "2009-10-22 10:10:37",
            "date_modified" : "2019-12-04 12:27:25",
            "id" : 1642
         },
         "organisation" : {
            "country" : "de",
            "url" : "http://www.ulb.tu-darmstadt.de/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "ULB Darmstadt",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 52.2682,
               "longitude" : 7.0313
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Technische Universität Darmstadt",
                  "acronym" : "TUD"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is in Spanish.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://acceda.ulpgc.es/",
            "oai_url" : "http://acceda.ulpgc.es/oai/request",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "acronym" : "ACCEDA",
                  "name" : "Documentacion cientifica de la ULPGC en abierto",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 700,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "es",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1641",
            "publicly_visible" : "yes",
            "id" : 1641,
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-22 10:10:33"
         },
         "organisation" : {
            "country" : "es",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ],
            "url" : "http://www.ulpgc.es/",
            "location" : {
               "longitude" : -15.43,
               "latitude" : 28.1248
            },
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "ULPGC",
                  "name" : "Universidad de Las Palmas de Gran Canaria",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            }
         }
      },
      {
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://elib.dlr.de/cgi/oai2",
            "url" : "http://elib.dlr.de/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the output of the institution. Some items are not available as full-text. The interface is in English and German.",
            "software" : {
               "version" : "3.0.5",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "patents",
                  "language" : "en",
                  "phrase" : "Patents"
               }
            ],
            "metadata_record_count" : 101210,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "DLR publication server",
                  "acronym" : "elib",
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en",
               "de"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1640",
            "publicly_visible" : "yes",
            "id" : 1640,
            "date_created" : "2009-10-22 10:10:28",
            "date_modified" : "2019-10-17 14:34:25"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Deutschen Zentrum für Luft- und Raumfahrt",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "longitude" : 7.112,
               "latitude" : 50.851
            },
            "url" : "http://www.dlr.de/",
            "country" : "de"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-22 09:09:59",
            "id" : 1638,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1638"
         },
         "organisation" : {
            "location" : {
               "longitude" : -3.7003,
               "latitude" : 40.4167
            },
            "url" : "http://www.bne.es/es/Inicio/index.html",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteca Nacional de España",
                  "acronym" : "BNE",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "repository_status" : "fully_functional",
            "notes" : "Other items: Musical Scores and Drawings",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Biblioteca Digital Hispánica",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 164490,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DigiTool",
                     "value" : "digitool",
                     "language" : "en"
                  }
               ],
               "name" : "digitool"
            },
            "description" : "This site provides access to digitised versions of the institutions collections. Some may be fee-based for the full texts. The interface is available in Spanish, English, French, Euskera and Galician.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.bne.es/es/Catalogos/BibliotecaDigitalHispanica/Inicio/index.html"
         }
      },
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "description" : "This site provides access to the output of the institution. Many items are only available to registered users. The interface is in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://vtext.valdosta.edu:8080/xmlui/",
            "oai_url" : "http://vtext.valdosta.edu/oai/request",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Vtext Digital Repository",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 2382
         },
         "system_metadata" : {
            "date_created" : "2009-10-22 09:09:51",
            "date_modified" : "2019-12-04 12:27:25",
            "id" : 1637,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1637",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.valdosta.edu/",
            "location" : {
               "latitude" : 30.8661,
               "longitude" : -83.2874
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Valdosta State University"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 5099,
            "content_types_phrases" : [
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "name" : [
               {
                  "name" : "EdShare",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "disciplinary",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 647,
            "oai_url" : "http://www.edshare.soton.ac.uk/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.edshare.soton.ac.uk/",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.14",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "description" : "This site provides access to learning materials. Some content is restricted to registered user. The interface is in English.",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "learning_objects"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  },
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "value" : "undefined",
                        "language" : "en",
                        "phrase" : "No deletion method for withdrawn items defined"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "undefined",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ]
               },
               "closure_policy" : "undefined",
               "url" : [
                  "http://www.edshare.soton.ac.uk/edshare_takedown.pdf"
               ],
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "retention_period" : {
                  "period" : "undefined",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "undefined",
                        "phrase" : "No retention period defined"
                     }
                  ]
               }
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Southampton"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "location" : {
               "latitude" : 50.9342,
               "longitude" : -1.3957
            },
            "url" : "https://www.southampton.ac.uk/",
            "country" : "gb"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1636,
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-22 09:09:45",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1636"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://eprints.undip.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.undip.ac.id/",
            "software" : {
               "name" : "eprints",
               "version" : "3.1.1",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "UNDIP INSTITUTIONAL REPOSITORY (UNDIP-IR) is a digital collection of the University's intellectual or research output. UNDIP-IR centralizes, collects, preserves, and complies to open access concept of accessing collection of scholarly materials that showcases the research output of Diponegoro University communities. This site provides access to the research output of the institution. Users may set up Atom and RSS feeds to be alerted to new content. The interface is available in Indonesian and English.",
            "metadata_record_count" : 55307,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "UNDIP -IR",
                  "name" : "Diponegoro University Institutional Repository"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "id",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "notes" : "Other items include experiments and monographs",
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Diponegoro University",
                  "acronym" : "UNDIP",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "country" : "id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "url" : "http://www.undip.ac.id/",
            "location" : {
               "latitude" : -6.9815,
               "longitude" : 110.453
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2009-10-20 10:10:36",
            "date_modified" : "2019-12-04 12:27:25",
            "id" : 1635,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1635"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.2.4"
            },
            "description" : "This site provides access to the research output of the institution. Users may set up Atom and RSS feeds to be alerted to new content. The interface is in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 15695,
            "url" : "https://spectrum.library.concordia.ca/",
            "oai_url" : "https://spectrum.library.concordia.ca/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "Spectrum",
                  "name" : "Concordia University Research Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 16472,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "withdrawal" : {
                  "method_phrases" : [
                     {
                        "phrase" : "No deletion method for withdrawn items defined",
                        "value" : "undefined",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "method" : "undefined",
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               },
               "url" : [
                  "http://spectrum.library.concordia.ca/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy" : "undefined",
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "No retention period defined",
                        "value" : "undefined",
                        "language" : "en"
                     }
                  ],
                  "period" : "undefined"
               }
            },
            "data_policy" : {
               "url" : [
                  "http://spectrum.library.concordia.ca/policies.html"
               ]
            },
            "submission_policy" : {
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "policy_undefined",
                     "language" : "en",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "url" : [
                  "http://spectrum.library.concordia.ca/policies.html"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "policy_undefined",
               "depositors" : [
                  "community_members",
                  "academic_staff"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is not checked.",
                     "value" : "not_checked",
                     "language" : "en"
                  }
               ],
               "quality_control" : "not_checked",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://spectrum.library.concordia.ca/policies.html"
               ]
            },
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "url" : [
                  "http://spectrum.library.concordia.ca/policies.html",
                  "http://spectrum.library.concordia.ca/information.html"
               ]
            }
         },
         "system_metadata" : {
            "id" : 1634,
            "date_created" : "2009-10-20 10:10:09",
            "date_modified" : "2019-10-17 14:34:25",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1634",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Concordia University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "ca",
            "location" : {
               "latitude" : 45.4967,
               "longitude" : -73.5787
            },
            "url" : "http://www.concordia.ca/",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Hawai'i at Manoa"
               }
            ],
            "url" : "http://www.uhm.hawaii.edu/",
            "location" : {
               "latitude" : 21.3249,
               "longitude" : -157.809
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1633",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2009-10-15 10:10:09",
            "date_modified" : "2019-10-17 14:34:25",
            "id" : 1633,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "notes" : "Special items include Annual reports and Broadsides",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "eVols at University of Hawaii at Manoa",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 55056,
            "description" : "This site provides access to digitised material within the University of Hawaii at Manoa Library. The interface is in English.",
            "software" : {
               "version" : "1.8",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "oai_url" : "http://evols.library.manoa.hawaii.edu/dspace-oai/request",
            "url" : "http://evols.library.manoa.hawaii.edu/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "theses_and_dissertations",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Sycamore Scholars",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 4868,
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is in English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 156,
            "oai_url" : "http://scholars.indstate.edu/oai/request",
            "url" : "http://scholars.indstate.edu/",
            "content_subjects" : [
               "1"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1632",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 1632,
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-15 09:09:59",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "ISU",
                  "name" : "Indiana State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "longitude" : -87.4096,
               "latitude" : 39.4719
            },
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Cunningham Memorial Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "url" : "http://www.indstate.edu/home.php"
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 456,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "ArtXiker - @HAL",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "disciplinary",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 387,
            "oai_url" : "https://api.archives-ouvertes.fr/oai/artxiker",
            "url" : "http://artxiker.ccsd.cnrs.fr/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "hal",
                     "language" : "en",
                     "phrase" : "HAL"
                  }
               ],
               "name" : "hal"
            },
            "description" : "This site is a digital library which receives and diffuses the scholarly production of international research in the field of the Basque language and typologically-related languages. The interface is available in French, English and Euskaraz. Users may set up an RSS feed to be alerted to new content.",
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "fr"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "url" : [
                  "http://artxiker.ccsd.cnrs.fr/"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "language" : "en",
                           "value" : "yes"
                        }
                     ]
                  }
               }
            },
            "submission_policy" : {
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "policy_undefined",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "url" : [
                  "http://artxiker.ccsd.cnrs.fr/"
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "policy_undefined",
               "depositors" : [
                  "community_members"
               ],
               "moderation_purposes" : [
                  "item_relevance"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "quality_control_phrases" : [
                  {
                     "value" : "not_checked",
                     "language" : "en",
                     "phrase" : " is not checked."
                  }
               ],
               "quality_control" : "not_checked",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "value" : "item_relevance",
                     "language" : "en",
                     "phrase" : "relevance to the scope of the repository"
                  }
               ]
            },
            "content_policy" : {
               "url" : [
                  "http://artxiker.ccsd.cnrs.fr/"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "multi_institution_subject",
                     "language" : "en",
                     "phrase" : "Multi-institution subject-based repository"
                  }
               ],
               "versions" : [
                  "working_drafts",
                  "submitted_versions"
               ],
               "repository_type" : "multi_institution_subject",
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "value" : "working_drafts",
                     "language" : "en"
                  },
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "France"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "CCSd",
                  "name" : "Centre pour la Communication scientifique directe"
               }
            ],
            "location" : {
               "latitude" : 43.5032,
               "longitude" : -1.4725
            },
            "url" : "http://www.iker.cnrs.fr/",
            "country" : "fr",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "IKER",
                  "name" : "Langue et les Textes basques IKER",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "id" : 1631,
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-13 09:09:50",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1631",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "policies" : {
            "submission_policy" : {
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "depositors" : [
                  "academic_staff"
               ],
               "url" : [
                  "http://www.esepf.pt/a_univ/pol_rep.pdf"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "value" : "no_policy",
                     "language" : "en"
                  }
               ],
               "moderation" : "no_policy",
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "language" : "en",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ]
            },
            "content_policy" : {
               "subjects" : [
                  "1"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "Multidisciplinary",
                     "value" : "1",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://www.esepf.pt/a_univ/pol_rep.pdf"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type" : "institutional_or_departmental"
            }
         },
         "organisation" : {
            "location" : {
               "latitude" : 41.1604,
               "longitude" : -8.6024
            },
            "url" : "http://www.esepf.pt/index.php",
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "country" : "pt",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Escola Superior de Educação de Paula Frassinetti",
                  "acronym" : "ESEPF",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-12 15:15:38",
            "id" : 1630,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1630",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 1242,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositório Institucional da ESEPF"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repositorio.esepf.pt/",
            "oai_url" : "http://repositorio.esepf.pt/oai/request",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. The interface is available in English and Portuguese. Users may set up RSS feeds to be alerted to new content.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "tw",
            "location" : {
               "longitude" : 121.451,
               "latitude" : 25.1747
            },
            "url" : "http://www.tku.edu.tw/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "tw",
                  "phrase" : "Taiwan (Province of China)"
               }
            ],
            "name" : [
               {
                  "name" : "Tamkang University",
                  "acronym" : "淡江大學",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1629,
            "date_created" : "2009-10-12 15:15:32",
            "date_modified" : "2019-10-17 14:34:25",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1629"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. Interface available in Chinese and Chinese (simplified) and English. Some items are not available as full-text.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 4563,
            "url" : "http://tkuir.lib.tku.edu.tw:8080/dspace/",
            "oai_url" : "http://tkuir.lib.tku.edu.tw:8080/dspace-oai/request",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Tamkang University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 88543,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidade de Trás-os-Montes e Alto Douro",
                  "acronym" : "UTAD",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "pt",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "url" : "http://www.utad.pt/",
            "location" : {
               "latitude" : 41.2876,
               "longitude" : -7.7404
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1628",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:25",
            "date_created" : "2009-10-12 15:15:25",
            "id" : 1628
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in English and Portuguese. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repositorio.utad.pt/",
            "oai_url" : "http://repositorio.utad.pt/oaiextended/request",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repositório da UTAD",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 6934,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt"
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1627",
            "publicly_visible" : "yes",
            "id" : 1627,
            "date_created" : "2009-10-12 15:15:19",
            "date_modified" : "2019-12-04 12:27:25"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Wales Trinity Saint David",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "gb",
            "url" : "http://www.uwtsd.ac.uk/",
            "location" : {
               "longitude" : -3.8727,
               "latitude" : 51.6144
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is in English.",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.14",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.uwtsd.ac.uk/cgi/oai2",
            "url" : "http://repository.uwtsd.ac.uk/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 476,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Wales Trinity Saint David"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 674
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "University of Botswana Research, Innovation and Scholarship Archive",
                  "acronym" : "UBRISA",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1108,
            "description" : "This site provides access to the research output of the institution. The interface is in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "1.6.1",
               "name" : "dspace"
            },
            "url" : "http://www.ubrisa.ub.bw/",
            "oai_url" : "http://www.ubrisa.ub.bw/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Botswana",
                  "value" : "bw",
                  "language" : "en"
               }
            ],
            "url" : "http://www.ub.bw/",
            "location" : {
               "latitude" : -24.6581,
               "longitude" : 25.9329
            },
            "country" : "bw",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Botswana"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1626",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-10-06 15:15:50",
            "id" : 1626
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               }
            ],
            "metadata_record_count" : 48150,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "ScholarSpace at University of Hawai'i at Manoa",
                  "acronym" : "ScholarSpace",
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "oai_url" : "http://scholarspace.manoa.hawaii.edu/dspace-oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://scholarspace.manoa.hawaii.edu/",
            "full_text_record_count" : 12008,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is in English.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "5.4",
               "name" : "dspace"
            }
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.uhm.hawaii.edu/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Hawaii at Manoa Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -157.809,
               "latitude" : 21.3249
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Hawai'i at Manoa",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "id" : 1625,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-30 09:09:24",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1625",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "url" : "http://scholarworks.gvsu.edu/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://scholarworks.gvsu.edu/do/oai/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 4539,
            "description" : "This site provides access to the output of the institution. The interface is in English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "metadata_record_count" : 17283,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Scholarworks@GVSU"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Grand Valley State University"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -85.9509,
               "latitude" : 42.9675
            },
            "url" : "http://www.gvsu.edu/",
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2009-09-29 11:11:02",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1624,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1624"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:25",
            "date_created" : "2009-09-29 10:10:54",
            "id" : 1623,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1623"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Biblioteca Valenciana",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 39.4988,
               "longitude" : -0.3678
            },
            "url" : "http://bivaldi.gva.es/es/cms/elemento.cmd?id=estaticos/paginas/inicio.html",
            "country" : "es"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "undefined",
               "harvesting" : [
                  "allowed"
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "notes" : "Special items include maps, ephemera, engravings and postcards.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Biblioteca Valenciana Digital",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 15473,
            "description" : "This site provides access to digitised copies of the collections of the institution. The interface is in Spanish, Portuguese and English.",
            "software" : {
               "name" : "digibib",
               "name_phrases" : [
                  {
                     "phrase" : "Digibib",
                     "language" : "en",
                     "value" : "digibib"
                  }
               ]
            },
            "oai_url" : "http://bivaldi.gva.es/i18n/oai/oai_bivaldi.gva.es.cmd",
            "url" : "http://bivaldi.gva.es/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 7289
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1622",
            "publicly_visible" : "yes",
            "date_created" : "2009-09-29 10:10:48",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1622
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Instituto de España",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Real Academia de Jurisprudencia y Legislación",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -3.6956,
               "latitude" : 40.4175
            },
            "url" : "http://www.insde.es/"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "notes" : "Other items include legislative documentation.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "value" : "28",
                  "language" : "en",
                  "phrase" : "Management and Planning"
               }
            ],
            "metadata_record_count" : 1514,
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Biblioteca Virtual de la Real Academia de Jurisprudencia y Legislación",
                  "acronym" : "IURIS Digital"
               }
            ],
            "type" : "disciplinary",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://bvrajyl.rajyl.es/i18n/oai/oai_bvrajyl.rajyl.es.cmd",
            "content_subjects" : [
               "20",
               "26",
               "28"
            ],
            "url" : "http://bvrajyl.insde.es/i18n/estaticos/contenido.cmd?pagina=estaticos/presentacion",
            "software" : {
               "name" : "digibib",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "digibib",
                     "phrase" : "Digibib"
                  }
               ]
            },
            "description" : "Users may set up RSS feeds to be alerted to new content. The interface is in Spanish. The collection specialises in law and related sciences, and its content reflects the history of law in Spain and the evolution of teaching it, and the history of institutions and the administration of justice."
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1621",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 1621,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-29 10:10:40",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidade da Madeira",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "pt",
            "country_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portugal"
               }
            ],
            "location" : {
               "latitude" : 32.6505,
               "longitude" : -16.9096
            },
            "url" : "http://www.uma.pt/"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "technically_malfunctioning",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "metadata_record_count" : 2475,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositório Digital da Universidade da Madeira",
                  "acronym" : "DigitUMa Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 1309,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "technically_malfunctioning",
                  "phrase" : "Technically Malfunctioning"
               }
            ],
            "oai_url" : "http://digituma.uma.pt/oaiextended/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitool.uma.pt/",
            "software" : {
               "name" : "digitool",
               "name_phrases" : [
                  {
                     "phrase" : "DigiTool",
                     "value" : "digitool",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the student output of the institution. The interface is in Portuguese."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1620,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-09-29 10:10:27",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1620"
         },
         "organisation" : {
            "country" : "pt",
            "url" : "http://www.ul.pt/",
            "location" : {
               "longitude" : -9.1436,
               "latitude" : 38.7133
            },
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidade de Lisboa",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the output of the institution. The interface is in Portuguese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "digitool",
               "name_phrases" : [
                  {
                     "phrase" : "DigiTool",
                     "language" : "en",
                     "value" : "digitool"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt",
               "en"
            ],
            "url" : "http://digitool01.sibul.ul.pt/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio da Universidade de Lisboa",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 4269
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "pt",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://dspace.uevora.pt/rdpc-oaiextended/request",
            "url" : "http://dspace.uevora.pt/rdpc/",
            "full_text_record_count" : 7190,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is in Portuguese.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "metadata_record_count" : 23853,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Repositório Científico da Universidade de Évora",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "url" : "http://www.uevora.pt/",
            "location" : {
               "latitude" : 38.573,
               "longitude" : -7.9054
            },
            "country" : "pt",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidade de Évora"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1619",
            "publicly_visible" : "yes",
            "id" : 1619,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-29 10:10:22"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Universidade do Porto",
                  "acronym" : "UP",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "pt",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "FEUP",
                  "name" : "Faculdade de Engenharia",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.up.pt/",
            "location" : {
               "latitude" : 41.1527,
               "longitude" : -8.6158
            },
            "country_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portugal"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1618,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-29 10:10:16",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1618"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "SDI",
                  "name" : "Serviços de Documentação e Informação",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "metadata_record_count" : 4284,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name" : "digitool",
               "name_phrases" : [
                  {
                     "phrase" : "DigiTool",
                     "language" : "en",
                     "value" : "digitool"
                  }
               ]
            },
            "repository_status" : "replaced_by_new_url",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is in Portuguese.",
            "repository_status_phrases" : [
               {
                  "value" : "replaced_by_new_url",
                  "language" : "en",
                  "phrase" : "Replaced by New URL"
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eos.fe.up.pt/"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 48904,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Central University Library Institutional Repository (NCULR) - 中央大學機構典藏"
               }
            ],
            "url" : "http://ir.lib.ncu.edu.tw/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ir.lib.ncu.edu.tw:8081/ir-oai/request",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the student output of the institution. Interface available in Chinese and Chinese (simplified) and English. A few items are not available as full-text. The majority of items are hosted by another site within the institutions library.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            }
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-29 10:10:05",
            "id" : 1617,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1617",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "tw",
            "country_phrases" : [
               {
                  "value" : "tw",
                  "language" : "en",
                  "phrase" : "Taiwan (Province of China)"
               }
            ],
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Central University Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 25,
               "longitude" : 121
            },
            "url" : "http://www.ncu.edu.tw/",
            "name" : [
               {
                  "acronym" : "國立中央大學",
                  "name" : "National Central University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1",
               "2"
            ],
            "oai_url" : "http://ir.cnu.edu.tw/ir-oai/request",
            "url" : "http://ir.cnu.edu.tw/",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese, Chinese Simplified and English. Some items are not available as full-text.",
            "metadata_record_count" : 17544,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "patents",
                  "phrase" : "Patents"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "嘉南藥理大學機構典藏",
                  "name" : "Chia Nan University of Pharmacy & Science Institutional Repository"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               },
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "patents",
               "other_special_item_types"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1616",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-29 09:09:57",
            "id" : 1616
         },
         "organisation" : {
            "country" : "tw",
            "url" : "http://www.cnu.edu.tw/",
            "location" : {
               "longitude" : 120.223,
               "latitude" : 22.9239
            },
            "country_phrases" : [
               {
                  "phrase" : "Taiwan (Province of China)",
                  "language" : "en",
                  "value" : "tw"
               }
            ],
            "name" : [
               {
                  "acronym" : "嘉南藥理大學",
                  "name" : "Chia Nan University of Pharmacy &amp; Science",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  }
               ],
               "url" : [
                  "http://ir.chna.edu.tw/about/index.jsp"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "language" : "en",
                     "value" : "reproduced"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "description" : "This site provides access to publications relating to sustainable mountain development. Users may set up a RSS feed to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://www.infoandina.org/search",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Recursos",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "disciplinary",
            "metadata_record_count" : 3602,
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1615,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-09-28 14:14:46",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1615"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Info Andina",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -76.9588,
               "latitude" : -12.0671
            },
            "url" : "http://www.infoandina.org/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pe",
                  "phrase" : "Peru"
               }
            ],
            "country" : "pe"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Psiquiatria.tv",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spain"
               }
            ],
            "location" : {
               "longitude" : 2.5401,
               "latitude" : 39.5259
            },
            "url" : "http://www.psiquiatria.tv/",
            "country" : "es"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1614",
            "publicly_visible" : "yes",
            "id" : 1614,
            "date_created" : "2009-09-28 14:14:36",
            "date_modified" : "2019-10-17 14:34:24"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "metadata_record_count" : 5797,
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "name" : "Bibliopsiquis",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://www.bibliopsiquis.com/",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to publications on psychiatry published in Spanish. Users may set up RSS feeds to be alerted to new content.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "disciplinary",
                  "phrase" : "Disciplinary"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-28 14:14:24",
            "id" : 1613,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1613"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Miejska Bibloteka Publiczna - Radomiu",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "pl",
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "url" : "http://www.mbpradom.pl/",
            "location" : {
               "longitude" : 21.1541,
               "latitude" : 51.3987
            }
         },
         "repository_metadata" : {
            "description" : "This site provides access to the collections of the institutions. The interface is available in Polish and English. users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dlibra",
                     "language" : "en",
                     "phrase" : "dLibra"
                  }
               ],
               "version" : "5.5.0",
               "name" : "dlibra"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bc.mbpradom.pl/dlibra",
            "oai_url" : "http://bc.mbpradom.pl/dlibra/oai-pmh-repository.xml",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "governmental",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "Radomska Bibliotecka Cyfrowa",
                  "name" : "Radom Digital Library",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 24169,
            "notes" : "Special items include catalogues",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "governmental",
                  "phrase" : "Governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pl",
               "en",
               "de"
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "language" : "en",
                  "value" : "pl"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "German",
                  "value" : "de",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Polish",
                  "value" : "pl",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "pl"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Digital Library of Book Studies"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 4016,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "software" : {
               "version" : "4",
               "name" : "dlibra",
               "name_phrases" : [
                  {
                     "phrase" : "dLibra",
                     "language" : "en",
                     "value" : "dlibra"
                  }
               ]
            },
            "description" : "This site provides access to the collections of the institution. The interface is available in Polish or English. Users may set up RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bbc.uw.edu.pl/dlibra",
            "oai_url" : "http://bbc.uw.edu.pl/dlibra/oai-pmh-repository.xml"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1612",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 1612,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-28 14:14:17",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "pl",
            "url" : "http://www.uw.edu.pl/",
            "unit" : [
               {
                  "name" : "Instytut Informacji Naukowej i Studiów Bibliologicznych",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 52.2404,
               "longitude" : 21.0192
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pl",
                  "phrase" : "Poland"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "University of Warsaw",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-28 14:14:12",
            "id" : 1611,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1611"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pl",
                  "phrase" : "Poland"
               }
            ],
            "location" : {
               "latitude" : 52.2274,
               "longitude" : 21.0232
            },
            "url" : "http://www.ore.edu.pl/",
            "country" : "pl",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "CED",
                  "name" : "Centre for Education Development (Ośrodek Rozwoju Edukacji)",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "25",
                  "language" : "en",
                  "phrase" : "Education"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "replaced_by_new_url",
            "content_languages" : [
               "pl"
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pl",
                  "language" : "en",
                  "phrase" : "Polish"
               }
            ],
            "description" : "The interface is available in Polish and English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "version" : "3.0",
               "name" : "dlibra",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dlibra",
                     "phrase" : "dLibra"
                  }
               ]
            },
            "content_subjects" : [
               "25"
            ],
            "oai_url" : "http://bc.codn.edu.pl/dlibra/oai-pmh-repository.xml",
            "url" : "http://bc.codn.edu.pl/",
            "repository_status_phrases" : [
               {
                  "value" : "replaced_by_new_url",
                  "language" : "en",
                  "phrase" : "Replaced by New URL"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Biblioteka Cyfrowa Centralnego Ośrodka Doskonalenia Nauczycieli",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 71
         }
      },
      {
         "system_metadata" : {
            "id" : 1610,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-09-28 13:13:27",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1610",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universitat Pompeu Fabra",
                  "acronym" : "UPF",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "es",
            "url" : "http://www.upf.edu/",
            "location" : {
               "longitude" : 2.1795,
               "latitude" : 41.3791
            },
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 12057,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "UPF Digital Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://repositori.upf.edu/",
            "oai_url" : "http://oai-repositori.upf.edu/request",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This is the institutional repository of the Pompeu Fabra University which provides access to the scientific output produced by their researchers. The interface is in Spanish, Catalan and English. Some items are hosted on external sites but the full text of others is available from the repository. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.5",
               "name" : "dspace"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ca",
                  "phrase" : "Catalan"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages" : [
               "ca",
               "en",
               "es"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://cybertesis.uach.cl/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the student output of the institution. The interface is in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "cybertesis",
                     "phrase" : "Cybertesis"
                  }
               ],
               "name" : "cybertesis"
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 1693,
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Tesis Electronica UACh",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Universidad Austral de Chile"
               }
            ],
            "country" : "cl",
            "location" : {
               "longitude" : -70.7128,
               "latitude" : -33.9823
            },
            "url" : "http://www.uach.cl/",
            "country_phrases" : [
               {
                  "value" : "cl",
                  "language" : "en",
                  "phrase" : "Chile"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1609",
            "publicly_visible" : "yes",
            "date_created" : "2009-09-28 13:13:20",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1609
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 11543,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repositorio Institucional de la Universidad Veracruzana"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://cdigital.uv.mx/oai/request",
            "url" : "http://cdigital.uv.mx/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "1.7.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is in Spanish. Some items may only be accessible to local users. Users may set up RSS feeds to be alerted to new content.",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "notes" : "Special items include: Agreements and contracts from the Universidad Veracruzana with other institutions",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "mx",
            "location" : {
               "longitude" : -96.1333,
               "latitude" : 19.1727
            },
            "url" : "http://www.uv.mx/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Bibliotecas de la Universidad Veracruzana",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "mx",
                  "phrase" : "Mexico"
               }
            ],
            "name" : [
               {
                  "name" : "Universidad Veracruzana",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2009-09-28 13:13:14",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1608,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1608"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Universidad Centroamericana UCA",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "ni",
            "url" : "http://www.uca.edu.ni/",
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Biblioteca José Coronel Urtecho",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -86.2734,
               "latitude" : 12.1475
            },
            "country_phrases" : [
               {
                  "phrase" : "Nicaragua",
                  "value" : "ni",
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2009-09-28 11:11:54",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1607,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1607",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the student output of the institution. The interface is in Spanish.",
            "repository_status" : "withdrawn_from_use",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "url" : "http://bjcu.uca.edu.ni:5050/dspace/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Withdrawn from use",
                  "language" : "en",
                  "value" : "withdrawn_from_use"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio Academico de la Biblioteca \"JCU\"",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "metadata_record_count" : 2517
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Biblioteca Digital del Sistema de Bibliotecas de la Universidad de Antioquia",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 300,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "4.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://bibliotecadigital.udea.edu.co/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://bibliotecadigital.udea.edu.co/oai/request",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "es"
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-09-28 11:11:48",
            "id" : 1606,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1606",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "co",
            "url" : "http://www.udea.edu.co/",
            "location" : {
               "longitude" : -75.576,
               "latitude" : 6.2513
            },
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "value" : "co",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "acronym" : "UdeA",
                  "name" : "Universidad de Antioquia",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 153,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteka Cyfrowa KLF UW (Digital Library of the Formal Linguistics Department at the University of Warsaw)",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 140,
            "url" : "http://bc.klf.uw.edu.pl/",
            "content_subjects" : [
               "21"
            ],
            "oai_url" : "http://bc.klf.uw.edu.pl/cgi/oai2",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "name" : "eprints",
               "version" : "3.1.2.1"
            },
            "description" : "This site provides access to the output of the institution. Users may set up Atom and RSS feeds to be alerted to new content. The interface is available in Polish and English. Some items are not available in full text. Many of the others allow users to request a copy.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pl",
                  "phrase" : "Polish"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "pl",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               }
            ]
         },
         "system_metadata" : {
            "id" : 1605,
            "date_created" : "2009-09-24 16:16:50",
            "date_modified" : "2019-10-17 14:34:24",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1605",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 52.2404,
               "longitude" : 21.0192
            },
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Katedry Lingwistyki Formalnej",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.uw.edu.pl/",
            "country_phrases" : [
               {
                  "phrase" : "Poland",
                  "language" : "en",
                  "value" : "pl"
               }
            ],
            "country" : "pl",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Warsaw"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "types_included" : {
                  "all" : "true"
               }
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "requires_permission",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "submission_policy" : {
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "yes",
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "moderation_purposes" : [
                  "valid_formatting"
               ]
            },
            "data_policy" : {
               "harvesting" : [
                  "allowed"
               ],
               "reuse" : "individually_tagged",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "individually_tagged",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     }
                  ],
                  "standard_reasons" : [
                     "legal_requirement_proven"
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method" : "removed_from_public_view"
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "language" : "en",
                        "value" : "changes_not_permitted"
                     },
                     {
                        "language" : "en",
                        "value" : "errata_may_be_included",
                        "phrase" : "Errata and corrigenda lists may be included with the original if required"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "oai_url" : "http://air.repo.nii.ac.jp/oai",
            "url" : "https://air.repo.nii.ac.jp/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 39,
            "description" : "This site provides access to the output of the institution. The interface is available in Japanese and English.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 3698,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "AIR",
                  "name" : "Akita University Institutional Repository System (秋田大学学術情報リポジトリ)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "ja",
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 140.134,
               "latitude" : 39.7265
            },
            "url" : "http://www.akita-u.ac.jp/honbu/",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Akita University",
                  "acronym" : "秋田大学",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-24 13:13:15",
            "id" : 1602,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1602"
         }
      },
      {
         "organisation" : {
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "location" : {
               "latitude" : 42.874,
               "longitude" : -8.5571
            },
            "url" : "http://www.usc.es/",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Universidade de Santiago de Compostela",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-24 13:13:06",
            "id" : 1601,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1601"
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  }
               }
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted."
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "repository_type" : "institutional_or_departmental"
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es",
               "en"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Minerva. Repositorio Institucional da Universidade de Santiago de Compostela",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 15130,
            "description" : "This site provides access to the output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish, English and Galician.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "oai_url" : "https://minerva.usc.es/oai/request",
            "url" : "https://minerva.usc.es/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 1261
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Digital Commons @ Butler University",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 15953,
            "description" : "This site provides access to the output of the institution. The interface is in English. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            },
            "oai_url" : "http://digitalcommons.butler.edu/do/oai/",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcommons.butler.edu/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 8997,
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ]
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 39.8206,
               "longitude" : -86.1701
            },
            "url" : "http://butler.edu/",
            "name" : [
               {
                  "name" : "Butler University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "system_metadata" : {
            "id" : 1600,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-23 16:16:56",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1600",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 1599,
            "date_created" : "2009-09-23 16:16:53",
            "date_modified" : "2019-10-17 14:34:24",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1599",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ca",
            "location" : {
               "latitude" : 43.6581,
               "longitude" : -79.3804
            },
            "url" : "http://www.ryerson.ca/index.html",
            "country_phrases" : [
               {
                  "value" : "ca",
                  "language" : "en",
                  "phrase" : "Canada"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Ryerson University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "RULA Digital Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 2524,
            "description" : "This site provides access to the output of the institution. The interface is in English. Users may set up RSS feeds to be alerted to new content.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digital.library.ryerson.ca/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "DigitalCommons@C.O.D.",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 9468,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "This site provides access to the output of the institution. The interface is in English. Users may set up RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 836,
            "oai_url" : "http://dc.cod.edu/do/oai/",
            "url" : "http://dc.cod.edu/",
            "content_subjects" : [
               "1"
            ],
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2009-09-23 16:16:50",
            "date_modified" : "2019-12-04 12:27:24",
            "id" : 1598,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1598"
         },
         "organisation" : {
            "country" : "us",
            "url" : "http://www.cod.edu/index.aspx",
            "location" : {
               "longitude" : -88.0608,
               "latitude" : 41.8736
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "name" : "College of DuPage",
                  "acronym" : "COD",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1597",
            "publicly_visible" : "yes",
            "id" : 1597,
            "date_created" : "2009-09-23 16:16:47",
            "date_modified" : "2019-10-17 14:34:24"
         },
         "organisation" : {
            "unit" : [
               {
                  "name" : "John F Reed Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.fortlewis.edu/",
            "location" : {
               "longitude" : -107.811,
               "latitude" : 37.4124
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "name" : "Fort Lewis College",
                  "acronym" : "FLC",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcommons.fortlewis.edu/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Replaced by New URL",
                  "value" : "replaced_by_new_url",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is in English. Users may set up RSS feeds to be alerted to new content.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "replaced_by_new_url",
            "software" : {
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "metadata_record_count" : 85,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "DigitalCommons@Fort Lewis College",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 1596,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-21 14:14:38",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1596",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "es",
            "url" : "http://www.ubu.es/",
            "location" : {
               "latitude" : 42.3241,
               "longitude" : -3.713
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad de Burgos",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the student output of the institution. The site interface is in Spanish.",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://dspace.ubu.es:8080/trabajosacademicos/",
            "oai_url" : "http://dspace.ubu.es:8080/trabajosacademicos-oai/request",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Universidad de Burgos - Repositorio Institucional. Trabajos Académicos",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 131,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "https://ruc.udc.es/dspace",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://ruc.udc.es/oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "description" : "This site provides access to the research outputs of the Universidade da Coruña. Users may set up RSS feeds to be alerted to new content. The interface is available in English, Galician and Spanish.",
            "metadata_record_count" : 15814,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "RUC",
                  "name" : "RUC: Repositorio da Universidade da Coruña"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en",
               "gl",
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "gl",
                  "phrase" : "Galician"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1595",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-12 09:18:44",
            "date_created" : "2009-09-15 14:14:52",
            "id" : 1595
         },
         "organisation" : {
            "country" : "es",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ],
            "location" : {
               "longitude" : -8.4159,
               "latitude" : 43.3506
            },
            "url" : "https://www.udc.gal",
            "name" : [
               {
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "name" : "Universidade da Coruña",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "policies" : {
            "content_policy" : {
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "url" : [
                  "http://elib.bsu.by/handle/123456789/103102"
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "version_type_and_date",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "phrase" : "peer-review status",
                     "language" : "en",
                     "value" : "peer_review_status"
                  },
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "languages_phrases" : [
                  {
                     "value" : "ru",
                     "language" : "en",
                     "phrase" : "Russian"
                  },
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "be",
                     "phrase" : "Belarusian"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "versions" : [
                  "submitted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "value" : "submitted_versions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "ru",
                  "en",
                  "be"
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://elib.bsu.by/handle/123456789/103102"
               ],
               "commercial_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "value" : "repository_mention_required",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "value" : "repository_mention_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "allowed",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "yes",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ],
               "url" : [
                  "http://elib.bsu.by/handle/123456789/103102"
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control" : "checked_by_subject_specialists",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "checked_by_subject_specialists",
                     "phrase" : " is checked by internal subject specialists. "
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "value" : "spam_exclusion",
                     "language" : "en"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work",
                     "phrase" : "Authors may only submit their own work for archiving."
                  },
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "moderation" : "yes"
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "value" : "some_items_have_different_conditions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  }
               ],
               "harvesting" : [
                  "not_allowed"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes",
                  "commercial_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "not_allowed",
                     "language" : "en",
                     "phrase" : "Not Allowed"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "phrase" : "the original copyright statement is given",
                     "value" : "original_copyright_statement_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "the original rights permission statement is given",
                     "value" : "original_rights_statement_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://elib.bsu.by/handle/123456789/103102"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  },
                  {
                     "phrase" : "commercial purposes",
                     "language" : "en",
                     "value" : "commercial_purposes"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "value" : "migrate_file_formats",
                     "language" : "en"
                  }
               ],
               "withdrawal" : {
                  "withdrawn_items" : {
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Not at all",
                           "language" : "en",
                           "value" : "not_retained"
                        }
                     ],
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "not_retained",
                     "searchable" : "no"
                  },
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "value" : "legal_requirement_proven",
                        "language" : "en"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ],
                  "method" : "deleted",
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request"
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "value" : "updated_versions_allowed",
                        "language" : "en",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "value" : "persistent_urls_link_to_latest",
                        "language" : "en",
                        "phrase" : "The items persistent URL will always link to the latest version"
                     }
                  ],
                  "earlier_versions" : [
                     "persistent_urls_link_to_latest"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "regular_backups",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "url" : [
                  "http://elib.bsu.by/handle/123456789/103102"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "BSU",
                  "name" : "Belarusian State University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "by",
            "country_phrases" : [
               {
                  "phrase" : "Belarus",
                  "language" : "en",
                  "value" : "by"
               }
            ],
            "url" : "http://www.bsu.by/",
            "location" : {
               "latitude" : 53.8976,
               "longitude" : 27.5546
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1594",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "id" : 1594,
            "date_created" : "2009-09-15 10:10:40",
            "date_modified" : "2019-10-17 14:34:24",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "metadata_record_count" : 108215,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "Электронная библиотека БГУ",
                  "name" : "BSU Digital Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 12239,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://oai.elib.bsu.by/request",
            "url" : "http://elib.bsu.by/",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.0",
               "name" : "dspace"
            },
            "description" : "This site provides access to the output and collections of the institution. The interface is available in Russian and English. Users may set up RSS feeds to be alerted to new content.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "ru",
               "en"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "https://helda.helsinki.fi/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://helda.helsinki.fi/xoai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 25797,
            "description" : "This site provides access to the output of the institution. The Bank of Finland's institutional repository can be accessed as a sub-repository on this site. The interface is in Finnish, Swedish and English. Many items are not available as full text, but may provide links to access content elsewhere.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               }
            ],
            "metadata_record_count" : 68273,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "acronym" : "HELDA",
                  "name" : "Helsingin yliopiston digitaalinen arkisto",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en",
               "fi",
               "sv"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "notes" : "Also contains the sub-repositories of D-HANKEN, Elintarviketurvallisuusvirasto - Evira, Ilmatieteen laitos, Kansaneläkelaitos (Kela), Suomen Metsätieteellinen Seura (SMS) - The Finnish Society of Forest Science, Teatterikorkeakoulu / Teaterhögskolan / Theatre Academy Helsinki.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "fi",
                  "phrase" : "Finnish"
               },
               {
                  "phrase" : "Swedish",
                  "language" : "en",
                  "value" : "sv"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects"
            ]
         },
         "organisation" : {
            "url" : "http://www.helsinki.fi/university/",
            "location" : {
               "latitude" : 60.1702,
               "longitude" : 24.949
            },
            "country_phrases" : [
               {
                  "phrase" : "Finland",
                  "value" : "fi",
                  "language" : "en"
               }
            ],
            "country" : "fi",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "Helsingin Yliopisto / Helsingfors Universitet",
                  "name" : "University of Helsinki"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1593",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2009-09-09 14:14:46",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1593,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 2.351,
               "latitude" : 48.8567
            },
            "url" : "http://www.dauphine.fr/",
            "country" : "fr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Université Paris-Dauphine",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-04 14:14:00",
            "id" : 1591,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1591"
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 15771,
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Base de publications de l'université Paris-Dauphine",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://basepub.dauphine.fr/",
            "oai_url" : "http://basepub.dauphine.fr/oai/request",
            "content_subjects" : [
               "8",
               "24",
               "26",
               "28"
            ],
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This repository gives access to all the scientific publications and documents produced by the institution. The interface is in French.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages" : [
               "fr"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Business and Economics",
                  "value" : "24",
                  "language" : "en"
               },
               {
                  "phrase" : "Law and Politics",
                  "value" : "26",
                  "language" : "en"
               },
               {
                  "phrase" : "Management and Planning",
                  "language" : "en",
                  "value" : "28"
               }
            ],
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 42167,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Cronfa at Swansea University",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 8192,
            "oai_url" : "https://cronfa.swan.ac.uk/OAI/",
            "url" : "https://cronfa.swan.ac.uk/",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "3.1.1",
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "language" : "en",
                     "value" : "other"
                  }
               ],
               "name_other" : "VuFind"
            },
            "description" : "Users may set up RSS feeds to be alerted to new content. Many items do not have full-text available. The interface can be set to Welsh or English.",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "cy",
                  "phrase" : "Welsh"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en",
               "cy"
            ],
            "repository_status" : "fully_functional",
            "notes" : "Links to publishers websites are provided for the full text of most articles",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "phrase" : "Earlier versions may be withdrawn from public view"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "value" : "updated_versions_allowed",
                        "language" : "en"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn"
                  ]
               },
               "retention_period" : {
                  "period" : "for_years",
                  "years" : 10,
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "for_years",
                        "phrase" : "Items will be retained for a specified number of years"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed",
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats"
                  }
               ],
               "withdrawal" : {
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research",
                     "other"
                  ],
                  "policy" : "removal_at_request_discouraged",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request_discouraged",
                        "phrase" : "Items may be removed at the request of the author/copyright holder but this is strongly discouraged"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "value" : "publisher_rules",
                        "language" : "en",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     },
                     {
                        "value" : "other",
                        "language" : "en",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "method_phrases" : [
                     {
                        "value" : "removed_from_public_view",
                        "language" : "en",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "special_reasons" : [
                     "Concerns over the quality of the submission and the potential to impact  negatively on the reputation of the University ."
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "unusual_files_not_guaranteed"
               ],
               "closure_policy" : "transfer_to_appropriate_archive"
            },
            "data_policy" : {
               "reuse_permitted_actions" : [
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required"
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "displayed or performed",
                     "language" : "en",
                     "value" : "displayed_or_performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed_for_indexing"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions",
                     "language" : "en",
                     "value" : "some_items_have_different_conditions"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "value" : "personal_research_or_study",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed_for_indexing",
                     "language" : "en",
                     "phrase" : "Allowed transiently for full-text indexing"
                  }
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "value" : "no",
                     "language" : "en",
                     "phrase" : "Submitted items are not vetted by the administrator."
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  }
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation" : "no"
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en",
                  "cy"
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  },
                  {
                     "phrase" : "Welsh",
                     "value" : "cy",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "value" : "version_type_and_date",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "version_type_and_date"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "language" : "en",
                     "value" : "oai_id_or_link_required"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse" : "allowed"
            }
         },
         "system_metadata" : {
            "id" : 1590,
            "date_modified" : "2019-12-04 12:25:28",
            "date_created" : "2009-09-03 14:14:14",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1590",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Swansea University"
               }
            ],
            "country" : "gb",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "value" : "gb",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 51.608,
               "longitude" : -4.0628
            },
            "url" : "http://www.swan.ac.uk/"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "ALT",
                  "name" : "Association for Learning Technology"
               }
            ],
            "url" : "http://www.alt.ac.uk/",
            "location" : {
               "longitude" : -1.2115,
               "latitude" : 51.7932
            },
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "country" : "gb"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1588",
            "publicly_visible" : "yes",
            "date_created" : "2009-09-03 13:13:57",
            "date_modified" : "2019-12-04 12:27:24",
            "id" : 1588
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "ALT Open Access Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 894,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "3.3.16",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 698,
            "oai_url" : "http://repository.alt.ac.uk/cgi/oai2/",
            "url" : "http://repository.alt.ac.uk/",
            "content_subjects" : [
               "25"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "datasets",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "CemOA"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 2180,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name_other" : "Cadic Integrale",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "This site provides access to the research output of the institution. The majority of items are only available as bibliographic records, however a few clearly marked full-text items are available. The interface is available in a mixture of French and English.",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "2",
               "11"
            ],
            "oai_url" : "http://cemadoc.irstea.fr/oai/serveur/oai2.php",
            "url" : "http://cemoa.irstea.fr/",
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Science General",
                  "value" : "2",
                  "language" : "en"
               },
               {
                  "phrase" : "Technology General",
                  "value" : "11",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages" : [
               "fr"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-03 13:13:36",
            "id" : 1587,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1587"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Institut national de recherche en sciences et technologies pour l'environnement et l'agriculture",
                  "acronym" : "Irstea",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "France"
               }
            ],
            "url" : "http://www.irstea.fr/",
            "location" : {
               "latitude" : 48.7585,
               "longitude" : 2.328
            },
            "country" : "fr"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the research output of the institution, in relation to its faculty open access policies. Users may set up RSS feeds to be alerted to new content. The interface is in English. Provides links to other repositories at Harvard.",
            "full_text_record_count" : 25824,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "http://dash.harvard.edu/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dash.harvard.edu/",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym",
                  "acronym" : "DASH",
                  "name" : "Digital Access to Scholarship at Harvard",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 47842,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Harvard University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.harvard.edu/",
            "location" : {
               "latitude" : 42.377,
               "longitude" : -71.1167
            },
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-02 10:10:56",
            "id" : 1586,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1586"
         },
         "policies" : {
            "submission_policy" : {
               "rules" : [
                  "bibliographic_metadata_required"
               ],
               "copyright" : [
                  "responsibility_of_depositor"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students"
               ],
               "content_embargo" : "policy_undefined",
               "moderation_phrases" : [
                  {
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted.",
                     "language" : "en",
                     "value" : "no_policy"
                  }
               ],
               "url" : [
                  "http://osc.hul.harvard.edu/DASH/dash-procedure-faq.php"
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "policy_undefined",
                     "language" : "en",
                     "phrase" : "No embargo policy defined"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "value" : "community_members",
                     "language" : "en",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  }
               ],
               "rules_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  }
               ],
               "moderation" : "no_policy",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  }
               ],
               "quality_control" : "not_checked",
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "not_checked",
                     "phrase" : " is not checked."
                  }
               ]
            },
            "data_policy" : {
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "https://osc.hul.harvard.edu/dash/termsofuse"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "original_copyright_statement_required",
                     "phrase" : "the original copyright statement is given"
                  },
                  {
                     "language" : "en",
                     "value" : "original_rights_statement_required",
                     "phrase" : "the original rights permission statement is given"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "personal research or study",
                     "language" : "en",
                     "value" : "personal_research_or_study"
                  },
                  {
                     "language" : "en",
                     "value" : "educational_purposes",
                     "phrase" : "educational purposes"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_requirements" : [
                  "original_copyright_statement_required",
                  "original_rights_statement_required"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  },
                  {
                     "phrase" : "given to third parties",
                     "language" : "en",
                     "value" : "given_to_third_parties"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "searchable_phrases" : [
                        {
                           "phrase" : "Yes",
                           "value" : "yes",
                           "language" : "en"
                        }
                     ]
                  }
               }
            },
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "versions_phrases" : [
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "url" : [
                  "http://osc.hul.harvard.edu/DASH/dash-copyright-faq.php"
               ]
            },
            "metadata_policy" : {
               "commercial_reuse_conditions_phrases" : [
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "url" : [
                  "http://openmetadata.lib.harvard.edu/content/digital-access-scholarship-harvard-dash-dataset"
               ],
               "access" : "free_open_access",
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "repository_mention_required",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "commercial_reuse" : "allowed",
               "non_profit_reuse" : "allowed",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "commercial_reuse_conditions" : [
                  "repository_mention_required"
               ]
            }
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1585",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 1585,
            "date_created" : "2009-09-01 10:10:17",
            "date_modified" : "2019-12-04 12:27:24",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "unit" : [
               {
                  "name" : "George A Smathers Libraries",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -82.3546,
               "latitude" : 29.6422
            },
            "url" : "http://www.ufl.edu/",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Florida",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "notes" : "Special items include: interview transcripts and posters.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 212695,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "UFDC",
                  "name" : "University of Florida Digital Collections"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://ufdc.ufl.edu/",
            "oai_url" : "http://ufdc.ufl.edu/sobekcm_oai.aspx",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "SobekCM"
            },
            "description" : "This site provides access to unique and rare digitised materials held at the University of Florida and partner institutions. Users may set up RSS feeds to be alerted to new content. Some content is only available to view online. The interface is in English."
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://bdigital.uncu.edu.ar/OAI/index.php",
            "url" : "http://bdigital.uncu.edu.ar/",
            "content_subjects" : [
               "1",
               "2",
               "10"
            ],
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "BDUNCO"
            },
            "description" : "This site provides access to the scientific output of the institution. The interface is in Spanish.",
            "metadata_record_count" : 8586,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Repositorio OAI Biblioteca Digital Universidad Nacional de Cuyo",
                  "acronym" : "Biblioteca Digital UNCuyo",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               },
               {
                  "value" : "2",
                  "language" : "en",
                  "phrase" : "Science General"
               },
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : -32.8815,
               "longitude" : -68.8772
            },
            "url" : "http://www.uncu.edu.ar/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "Sistema integrado de Documentación",
                  "acronym" : "SID",
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Argentina"
               }
            ],
            "country" : "ar",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Nacional de Cuyo",
                  "acronym" : "UNCuyo",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1584",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 1584,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-09-01 10:10:09",
            "publicly_visible" : "yes"
         },
         "policies" : {
            "submission_policy" : {
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "moderation" : "no",
               "rules_phrases" : [
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "language" : "en",
                     "value" : "community_members"
                  },
                  {
                     "language" : "en",
                     "value" : "academic_staff",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "value" : "registered_students",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_deposit_until_embargo_expiry",
                     "phrase" : "Items may not be deposited until any embargo period has expired"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no",
                     "phrase" : "Submitted items are not vetted by the administrator."
                  }
               ],
               "content_embargo" : "no_deposit_until_embargo_expiry",
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students"
               ]
            },
            "data_policy" : {
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "the_repository_is_not_the_publisher"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "link_required",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "phrase" : "the original copyright statement is given",
                     "language" : "en",
                     "value" : "original_copyright_statement_required"
                  },
                  {
                     "language" : "en",
                     "value" : "original_rights_statement_required",
                     "phrase" : "the original rights permission statement is given"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "language" : "en",
                     "value" : "content_not_changed"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties",
                  "stored_in_a_database"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  },
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  },
                  {
                     "phrase" : "stored in a database",
                     "value" : "stored_in_a_database",
                     "language" : "en"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "language" : "en",
                           "value" : "indefinite"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "language" : "en",
                           "value" : "no"
                        }
                     ]
                  },
                  "standard_reasons_phrases" : [
                     {
                        "language" : "en",
                        "value" : "publisher_rules",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism",
                        "phrase" : "Proven copyright violation or plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven"
                  ],
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "value" : "removed_from_public_view",
                        "language" : "en"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may be removed at the request of the author/copyright holder",
                        "language" : "en",
                        "value" : "removal_at_request"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Record preservation metadata",
                     "value" : "record_preservation_metadata",
                     "language" : "en"
                  },
                  {
                     "value" : "offsite_backups",
                     "language" : "en",
                     "phrase" : "Backup items in external archives"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "language" : "en",
                     "value" : "software_emulation"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats",
                     "language" : "en",
                     "value" : "original_bitstream_retained"
                  }
               ],
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "changes_not_permitted",
                        "phrase" : "Changes to deposited items are not permitted"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted"
                  ]
               },
               "third_party_collaborations" : [
                  "record_preservation_metadata",
                  "offsite_backups"
               ],
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "closure_policy" : "undefined",
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "requires_permission",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission"
            },
            "content_policy" : {
               "languages" : [
                  "es",
                  "en",
                  "fr"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "language" : "en",
                     "value" : "institutional_or_departmental"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "language" : "en",
                     "value" : "published_versions"
                  }
               ],
               "languages_phrases" : [
                  {
                     "phrase" : "Spanish",
                     "language" : "en",
                     "value" : "es"
                  },
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  },
                  {
                     "phrase" : "French",
                     "value" : "fr",
                     "language" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "metadata_phrases" : [
                  {
                     "phrase" : "publication status",
                     "value" : "publication_status",
                     "language" : "en"
                  }
               ],
               "metadata" : [
                  "publication_status"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "full_text_record_count" : 1193,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "https://digitalarchive.wm.edu/",
            "oai_url" : "https://digitalarchive.wm.edu/oai/request",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "dspace",
               "version" : "1.8.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the research and administrative output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is in English.",
            "metadata_record_count" : 11891,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "DSpace at The College of William and Mary",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ]
         },
         "policies" : {
            "content_policy" : {
               "url" : [
                  "http://digitalarchive.wmwikis.net/"
               ]
            },
            "metadata_policy" : {
               "url" : [
                  "http://digitalarchive.wmwikis.net/"
               ]
            },
            "submission_policy" : {
               "url" : [
                  "http://digitalarchive.wmwikis.net/"
               ]
            },
            "preservation_policy" : {
               "url" : [
                  "http://digitalarchive.wmwikis.net/"
               ]
            },
            "data_policy" : {
               "url" : [
                  "http://digitalarchive.wmwikis.net/"
               ]
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1583",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-09-01 10:10:00",
            "id" : 1583
         },
         "organisation" : {
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Earl Gregg Swem Library",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "latitude" : 37.2707,
               "longitude" : -76.7078
            },
            "url" : "http://www.wm.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "College of William and Mary"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 1582,
            "date_created" : "2009-08-28 16:16:50",
            "date_modified" : "2019-11-08 11:44:30",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1582",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "fr",
                  "phrase" : "France"
               }
            ],
            "location" : {
               "latitude" : 48.8566,
               "longitude" : 2.35097
            },
            "url" : "http://www.inra.fr",
            "country" : "fr",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "National Institute of Agricultural Research"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr",
                  "preferred" : "acronym",
                  "acronym" : "INRA",
                  "name" : "Institut National de la Recherche Agronomique",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_other" : "ProdInra",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name" : "other"
            },
            "description" : "ProdInra is the INRA open archive and the whole repository for INRA research productions. The portal is available in French, English and Spanish. The subjects are agricultural-related.  Users may set up RSS feeds to be alerted to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "https://prodinra.inra.fr",
            "content_subjects" : [
               "1",
               "3"
            ],
            "oai_url" : "http://oai.prodinra.inra.fr/ft",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "ProdINRA - The INRA Open Archive",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 44550,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "bibliographic_references",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "3",
                  "phrase" : "Agriculture, Food and Veterinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "fr"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Università di Bergamo",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "it",
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "url" : "http://www.unibg.it/",
            "location" : {
               "latitude" : 45.6863,
               "longitude" : 9.6617
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1581",
            "publicly_visible" : "yes",
            "date_created" : "2009-08-27 11:11:48",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1581
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "patents"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Italian",
                  "language" : "en",
                  "value" : "it"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "it",
               "en"
            ],
            "name" : [
               {
                  "acronym" : "Aisberg",
                  "name" : "Archivio Istituzionale Università di Bergamo",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 20586,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "value" : "bibliographic_references",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Patents",
                  "language" : "en",
                  "value" : "patents"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "description" : "This site provides access to the doctoral theses output of the institution. Some items are not available as full-text. Users may set up RSS feeds to be alerted to new content. The interface is available in Italian and English.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "full_text_record_count" : 0,
            "oai_url" : "http://aisberg.unibg.it/dspace-oai/request",
            "url" : "http://aisberg.unibg.it/",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Lowcountry Digital Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "type" : "aggregating",
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://lowcountrydigital.library.cofc.edu/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "contentdm",
                     "phrase" : "CONTENTdm"
                  }
               ],
               "name" : "contentdm"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "description" : "A digital repository of unique materials housed in various archives located in the South Carolina Lowcountry. Some items are available as full-text. The interface is in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "College of Charleston",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.cofc.edu/",
            "location" : {
               "latitude" : 32.7865,
               "longitude" : -79.9308
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "id" : 1579,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-08-19 11:11:51",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1579",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1578",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-08-19 11:11:44",
            "id" : 1578
         },
         "organisation" : {
            "country" : "gb",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Archaeology Data Service",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : -1.0861,
               "latitude" : 53.962
            },
            "url" : "https://www.york.ac.uk/",
            "name" : [
               {
                  "name" : "University of York",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "policies" : {
            "data_policy" : {
               "url" : [
                  "http://archaeologydataservice.ac.uk/about/ourWork.xhtml"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "reuse_conditions" : [
                  "the_repository_is_not_the_publisher"
               ],
               "reuse_permitted_purposes" : [
                  "educational_purposes"
               ],
               "reuse_permitted_actions" : [
                  "reproduced"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "reproduced",
                     "value" : "reproduced",
                     "language" : "en"
                  }
               ],
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher",
                     "phrase" : "This repository is not the publisher; it is merely the online archive"
                  }
               ]
            },
            "preservation_policy" : {
               "third_party_collaborations" : [
                  "migrate_file_formats"
               ],
               "url" : [
                  "http://archaeologydataservice.ac.uk/advice/PolicyDocuments.xhtml#PresPol"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  }
               ],
               "retention_period" : {
                  "period" : "undefined",
                  "period_phrases" : [
                     {
                        "phrase" : "No retention period defined",
                        "language" : "en",
                        "value" : "undefined"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  },
                  {
                     "phrase" : "Items will be migrated to new file formats where necessary",
                     "language" : "en",
                     "value" : "migrate_file_formats"
                  }
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Convert or migrate file formats"
                  }
               ]
            },
            "submission_policy" : {
               "url" : [
                  "http://archaeologydataservice.ac.uk/advice/collectionsPolicy.xhtml"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            },
            "content_policy" : {
               "url" : [
                  "http://archaeologydataservice.ac.uk/advice/collectionsPolicy.xhtml"
               ],
               "subjects_phrases" : [
                  {
                     "phrase" : "History and Archaeology",
                     "language" : "en",
                     "value" : "20"
                  }
               ],
               "versions" : [
                  "published_versions"
               ],
               "repository_type" : "multi_institution_subject",
               "versions_phrases" : [
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "repository_type_phrases" : [
                  {
                     "phrase" : "Multi-institution subject-based repository",
                     "value" : "multi_institution_subject",
                     "language" : "en"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "subjects" : [
                  "20"
               ]
            }
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "datasets",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "notes" : "Special items include: maps",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "20",
                  "phrase" : "History and Archaeology"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "language" : "en",
                  "value" : "disciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "type" : "disciplinary",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Archaeology Data Service",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 1340,
            "description" : "This site contains a mixture of metadata and project archives on archaeological sites and finds. Mandated depository for archaeological work funded by the AHRC in the UK. The interface is in English.",
            "software" : {
               "name_phrases" : []
            },
            "oai_url" : "http://archaeologydataservice.ac.uk/advice/OAIPMH",
            "url" : "http://archaeologydataservice.ac.uk/",
            "content_subjects" : [
               "20"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 0
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1577",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 1577,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-19 11:11:27",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "cn",
            "unit" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "National Science Library",
                  "acronym" : "NSL"
               }
            ],
            "location" : {
               "longitude" : 116.335,
               "latitude" : 39.9112
            },
            "url" : "http://www.cas.ac.cn/",
            "country_phrases" : [
               {
                  "value" : "cn",
                  "language" : "en",
                  "phrase" : "China"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Chinese Academy of Sciences (中国科学院)",
                  "acronym" : "CAS",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "zh"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://ir.las.ac.cn/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "NSL-IR",
                  "name" : "Knowledge Repository of National Science Library, CAS",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "metadata_record_count" : 8179,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Centro Latino-Americano e do Caribe de Informação em Ciências da Saúde",
                  "acronym" : "BIREME",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "br",
            "url" : "http://www.bireme.br/",
            "location" : {
               "latitude" : -23.5489,
               "longitude" : -46.6388
            },
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "language" : "en",
                  "value" : "br"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1576",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-19 11:11:17",
            "id" : 1576
         },
         "repository_metadata" : {
            "content_subjects" : [
               "10"
            ],
            "url" : "http://www.scielosp.org/",
            "content_languages" : [
               "en",
               "pt",
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "value" : "disciplinary",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "description" : "This site collects together a large collection of selected publications from Public Health journals. The site interface is in English, Spanish and Portuguese.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "scielo",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "scielo",
                     "phrase" : "SciELO"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "metadata_record_count" : 1863,
            "type" : "disciplinary",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "SciELO Public Health"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "http://www.scielo.org.za/",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site collects together a large collection of selected publications from South African journals. The interface is available in English, Spanish and Portuguese.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "scielo",
               "name_phrases" : [
                  {
                     "phrase" : "SciELO",
                     "value" : "scielo",
                     "language" : "en"
                  }
               ]
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "metadata_record_count" : 1584,
            "type" : "aggregating",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Scientific Electronic Library Online - South Africa",
                  "acronym" : "SciELO - South Africa",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1575",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-19 11:11:12",
            "id" : 1575,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Academy of Science of South Africa",
                  "acronym" : "ASSAf",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "za",
            "country_phrases" : [
               {
                  "value" : "za",
                  "language" : "en",
                  "phrase" : "South Africa"
               }
            ],
            "location" : {
               "latitude" : -25.7415,
               "longitude" : 28.3111
            },
            "url" : "http://www.assaf.org.za/"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Taipei Medical University",
                  "acronym" : "臺北醫學大學",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "tw",
            "country_phrases" : [
               {
                  "value" : "tw",
                  "language" : "en",
                  "phrase" : "Taiwan (Province of China)"
               }
            ],
            "location" : {
               "latitude" : 25.025,
               "longitude" : 121.561
            },
            "url" : "http://www.tmu.edu.tw/"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-18 09:09:42",
            "id" : 1573,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1573"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "bibliographic_references"
            ],
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "name" : "Taipei Medical University Repository",
                  "acronym" : "TMUR"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               }
            ],
            "metadata_record_count" : 58015,
            "description" : "This site provides access to the research output of the institution. A small number of items are available in Full-Text, however these are clearly marked. The majority of the content is bibliographic. The interface is available in Chinese and Chinese (simplified) and English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://libir.tmu.edu.tw/",
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "ca",
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "url" : "http://www.polymtl.ca/",
            "location" : {
               "longitude" : -73.6139,
               "latitude" : 45.5011
            },
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "École Polytechnique de Montréal",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1572",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-18 09:09:35",
            "id" : 1572,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "content_languages" : [
               "fr"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "year_established" : 2009,
            "content_types" : [
               "theses_and_dissertations"
            ],
            "oai_url" : "http://publications.polymtl.ca/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://publications.polymtl.ca/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the student output of the institution, since June 2009. Users may set up Atom and RSS feeds to be alerted to new content. The interface is in French.",
            "software" : {
               "version" : "3.3.13",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 2535,
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "PolyPublie",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Biblioteca Digital de Monografias",
                  "acronym" : "BDM",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 19984,
            "description" : "This site provides access to the monographic collections of the institute. Users may set up RSS feeds to be alerted to new content. The interface is available in Portuguese.",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "url" : "http://bdm.unb.br/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://bdm.unb.br/oai/request",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "policies" : {
            "preservation_policy" : {
               "withdrawal" : {
                  "withdrawn_items" : {
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ],
                     "searchable" : "yes"
                  }
               }
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ]
            },
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "acronym" : "UnB",
                  "name" : "Universidade de Brasília",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "phrase" : "Brazil",
                  "value" : "br",
                  "language" : "en"
               }
            ],
            "url" : "http://www.unb.br/",
            "unit" : [
               {
                  "name" : "Biblioteca Central",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : -47.9292,
               "latitude" : -15.7801
            }
         },
         "system_metadata" : {
            "date_created" : "2009-08-17 16:16:07",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1571,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1571",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 1570,
            "date_created" : "2009-08-17 10:10:25",
            "date_modified" : "2019-10-17 14:34:24",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1570",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : 90.4072,
               "latitude" : 23.7802
            },
            "url" : "http://www.bracu.ac.bd//",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "bd",
                  "phrase" : "Bangladesh"
               }
            ],
            "country" : "bd",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "BRAC University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://dspace.bracu.ac.bd/policy.jsp"
               ]
            },
            "metadata_policy" : {
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "value" : "free_open_access",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://dspace.bracu.ac.bd/policy.jsp"
               ]
            },
            "submission_policy" : {
               "moderation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_policy",
                     "phrase" : " No moderation policy defined. Assume nothing has been vetted."
                  }
               ],
               "depositors_phrases" : [
                  {
                     "language" : "en",
                     "value" : "community_members",
                     "phrase" : "Accredited Community Members"
                  },
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "language" : "en",
                     "value" : "registered_students",
                     "phrase" : "Registered Students"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "No embargo policy defined",
                     "value" : "policy_undefined",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://dspace.bracu.ac.bd/policy.jsp"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students"
               ],
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required"
               ],
               "content_embargo" : "policy_undefined",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "rules_phrases" : [
                  {
                     "value" : "bibliographic_metadata_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "phrase" : "Eligible depositors must deposit full texts of all their publications",
                     "value" : "full_texts_required",
                     "language" : "en"
                  }
               ],
               "moderation" : "no_policy"
            },
            "data_policy" : {
               "reuse_phrases" : [
                  {
                     "phrase" : "No full-item re-use policy defined. Assume no rights at all have been granted.",
                     "value" : "undefined",
                     "language" : "en"
                  }
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access full items free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "reuse" : "undefined",
               "access" : "free_open_access",
               "url" : [
                  "http://dspace.bracu.ac.bd/policy.jsp"
               ],
               "harvesting" : [
                  "allowed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ]
            },
            "preservation_policy" : {
               "closure_policy_phrases" : [
                  {
                     "phrase" : "No closure policy defined",
                     "language" : "en",
                     "value" : "undefined"
                  }
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "unusual_files_not_guaranteed"
               ],
               "closure_policy" : "undefined",
               "url" : [
                  "http://dspace.bracu.ac.bd/policy.jsp"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "value" : "unusual_files_not_guaranteed",
                     "language" : "en",
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats"
                  }
               ],
               "withdrawal" : {
                  "method" : "removed_from_public_view",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ],
                  "withdrawn_items" : {
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "searchable" : "no"
                  }
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "version_control" : {
                  "policy" : [
                     "changes_not_permitted"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     }
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "value" : "indefinitely",
                        "language" : "en",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "metadata_record_count" : 8947,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "name" : "BRAC University Institutional Repository",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 3854,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://dspace.bracu.ac.bd/oai/request",
            "content_subjects" : [
               "1",
               "17",
               "21",
               "8",
               "23",
               "24",
               "10",
               "25",
               "11",
               "12",
               "14"
            ],
            "url" : "http://dspace.bracu.ac.bd/",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.4"
            },
            "description" : "This site provides access to the output of the institution. The interface is in English. The Digital Institutional Repository program is funded by the International Network for the Availability of Scientific Publications (INASP). Users may set up Atom and RSS feeds to be alerted to new content.",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               },
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Language and Literature",
                  "language" : "en",
                  "value" : "21"
               },
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "25",
                  "phrase" : "Education"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               },
               {
                  "phrase" : "Architecture",
                  "language" : "en",
                  "value" : "12"
               },
               {
                  "phrase" : "Computers and IT",
                  "language" : "en",
                  "value" : "14"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "metadata_record_count" : 6995,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Biblioteca Virtual de la Cooperación Internacional"
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.bvcooperacion.pe/biblioteca",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "1.6.2",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "description" : "This site provides access to documents relating to international cooperation in Peru. The interface is available in Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-14 14:14:21",
            "id" : 1569,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1569"
         },
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "location" : {
               "latitude" : -12.0872,
               "longitude" : -77.0048
            },
            "url" : "http://www.bvcooperacion.pe/",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Biblioteca Virtual de la Cooperación Internacional",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "bibliographic_references",
               "conference_and_workshop_papers",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Jos Institutional Repository"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 1837,
            "content_types_phrases" : [
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "software" : {
               "version" : "3.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "description" : "This site provides access to the teaching and research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is in English. Most of the items are available as full text.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://irepos.unijos.edu.ng/jspui",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://irepos.unijos.edu.ng/oai/request"
         },
         "organisation" : {
            "url" : "http://www.unijos.edu.ng/",
            "location" : {
               "longitude" : 8.8894,
               "latitude" : 9.9503
            },
            "country_phrases" : [
               {
                  "phrase" : "Nigeria",
                  "value" : "ng",
                  "language" : "en"
               }
            ],
            "country" : "ng",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "University of Jos"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1568",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2009-08-13 16:16:43",
            "date_modified" : "2019-12-04 12:27:24",
            "id" : 1568,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Universiti Putra Malaysia Institutional Repository",
                  "acronym" : "PSAS IR",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 60868,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.1.2.1",
               "name" : "eprints"
            },
            "description" : "This site provides access to the research and teaching output of the institution. Users may set up Atom or RSS feeds to be alerted to new content. The interface is available in English. As the policy of the University does not permit users to view the full text of theses, access is only given to the content pages and abstracts of the theses.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "full_text_record_count" : 42919,
            "oai_url" : "http://psasir.upm.edu.my/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://psasir.upm.edu.my/"
         },
         "policies" : {
            "content_policy" : {
               "subjects_phrases" : [
                  {
                     "phrase" : "Multidisciplinary",
                     "value" : "1",
                     "language" : "en"
                  }
               ],
               "metadata_phrases" : [
                  {
                     "language" : "en",
                     "value" : "version_type_and_date",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "language" : "en",
                     "value" : "peer_review_status",
                     "phrase" : "peer-review status"
                  },
                  {
                     "value" : "publication_status",
                     "language" : "en",
                     "phrase" : "publication status"
                  }
               ],
               "url" : [
                  "http://psasir.upm.edu.my/policies.html"
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "subjects" : [
                  "1"
               ],
               "repository_type_phrases" : [
                  {
                     "language" : "en",
                     "value" : "institutional_or_departmental",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "ms",
                  "en"
               ],
               "languages_phrases" : [
                  {
                     "language" : "en",
                     "value" : "ms",
                     "phrase" : "Malay"
                  },
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "all" : "false",
                  "standard_types_excluded" : [
                     "journal_articles"
                  ],
                  "standard_types_excluded_phrases" : [
                     {
                        "phrase" : "Journal Articles",
                        "language" : "en",
                        "value" : "journal_articles"
                     }
                  ]
               },
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions"
               ],
               "versions_phrases" : [
                  {
                     "value" : "working_drafts",
                     "language" : "en",
                     "phrase" : "working drafts"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "oai_id_or_link_required",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse" : "allowed",
               "url" : [
                  "http://psasir.upm.edu.my/policies.html"
               ],
               "access" : "free_open_access",
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ]
            },
            "data_policy" : {
               "reuse_conditions_phrases" : [
                  {
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "language" : "en",
                     "value" : "some_items_have_different_conditions",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  },
                  {
                     "phrase" : "Mention of the repository is appreciated but not mandatory",
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "phrase" : "displayed or performed",
                     "value" : "displayed_or_performed",
                     "language" : "en"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_copyright_statement_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "displayed_or_performed"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "language" : "en",
                     "value" : "not_for_profit_purposes",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "phrase" : "the original copyright statement is given",
                     "value" : "original_copyright_statement_required",
                     "language" : "en"
                  },
                  {
                     "value" : "content_not_changed",
                     "language" : "en",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://psasir.upm.edu.my/policies.html"
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "general_policy",
                     "phrase" : "General full-item re-use policy defined"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "some_or_all_restricted"
            },
            "preservation_policy" : {
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "language" : "en",
                     "value" : "regular_backups"
                  }
               ],
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest",
                     "link_between_versions"
                  ],
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn"
                     },
                     {
                        "value" : "persistent_urls_link_to_latest",
                        "language" : "en",
                        "phrase" : "The items persistent URL will always link to the latest version"
                     },
                     {
                        "language" : "en",
                        "value" : "link_between_versions",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "language" : "en",
                        "value" : "indefinitely"
                     }
                  ]
               },
               "withdrawal" : {
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "value" : "publisher_rules",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "value" : "falsified_research",
                        "language" : "en",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "no",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "indefinite",
                           "phrase" : "Indefinitely"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "language" : "en",
                           "value" : "tombstone"
                        }
                     ]
                  },
                  "policy" : "removal_at_request",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_at_request",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removed_from_public_view",
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "functional_preservation_phrases" : [
                  {
                     "value" : "readability_and_accessibility",
                     "language" : "en",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "language" : "en",
                     "value" : "transfer_to_appropriate_archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://psasir.upm.edu.my/policies.html"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility"
               ]
            }
         },
         "system_metadata" : {
            "date_created" : "2009-08-12 16:16:24",
            "date_modified" : "2019-12-04 12:27:24",
            "id" : 1567,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1567",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "my",
                  "language" : "en",
                  "phrase" : "Malaysia"
               }
            ],
            "location" : {
               "latitude" : 2.9917,
               "longitude" : 101.717
            },
            "url" : "http://www.upm.edu.my/",
            "country" : "my",
            "name" : [
               {
                  "name" : "Universiti Putra Malaysia",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1566",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2009-08-11 10:10:00",
            "date_modified" : "2019-10-17 14:34:24",
            "id" : 1566,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "European University Viadrina Frankfurt Oder University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "url" : "http://www.euv-frankfurt-o.de/",
            "location" : {
               "latitude" : 52.3471,
               "longitude" : 14.5505
            },
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "European University Viadrina Frankfurt Oder University Library",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "country" : "de"
         },
         "repository_metadata" : {
            "metadata_record_count" : 84,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Elektronische Dokumente der EUV - OPUS",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://opus.kobv.de/euv/oai2/oai2.php",
            "content_subjects" : [
               "1",
               "17",
               "24"
            ],
            "url" : "http://www.ub.euv-frankfurt-o.de/de/benutzung/bestand/edocs/index.html",
            "software" : {
               "name" : "opus",
               "name_phrases" : [
                  {
                     "phrase" : "OPUS",
                     "language" : "en",
                     "value" : "opus"
                  }
               ]
            },
            "description" : "University repository providing access to the publication output of the institution. The interface is in German.",
            "content_languages_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "German"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_languages" : [
               "de"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               },
               {
                  "value" : "17",
                  "language" : "en",
                  "phrase" : "Arts and Humanities General"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "url" : "http://vixra.org/",
            "content_subjects" : [
               "1",
               "4",
               "8",
               "9",
               "14"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Disciplinary",
                  "value" : "disciplinary",
                  "language" : "en"
               }
            ],
            "description" : "This site is an e-print archive set up as an alternative to the popular arXiv.org service.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               },
               {
                  "value" : "4",
                  "language" : "en",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "value" : "9",
                  "language" : "en",
                  "phrase" : "Physics and Astronomy"
               },
               {
                  "phrase" : "Computers and IT",
                  "value" : "14",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 24640,
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "viXra",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "journal_articles"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1565",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-11 09:09:52",
            "id" : 1565,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "gb",
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "http://vixra.org/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "viXra",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 1564,
            "date_created" : "2009-08-11 09:09:41",
            "date_modified" : "2019-10-17 14:34:24",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1564",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Portugal",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "url" : "http://www.ipleiria.pt/",
            "location" : {
               "longitude" : -8.8217,
               "latitude" : 39.735
            },
            "country" : "pt",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Instituto Politécnico de Leiria",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is available in English and Portuguese. Users may set up RSS feeds to be alerted to new content.",
            "software" : {
               "name" : "dspace",
               "version" : "1.6.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "https://iconline.ipleiria.pt/",
            "oai_url" : "https://iconline.ipleiria.pt/oai/request",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 1897,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "IC-online",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3688,
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "pt"
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1563,
            "date_modified" : "2019-10-17 14:34:24",
            "date_created" : "2009-08-10 13:13:42",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1563"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Science and Technology Development Agency (NSTDA)",
                  "acronym" : "สำนักงานพัฒนาวิทยาศาสตร์และเทคโนโลยีแห่งชาติ",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "th",
            "location" : {
               "latitude" : 15.87,
               "longitude" : 100.993
            },
            "url" : "http://www.nstda.or.th/index.php",
            "country_phrases" : [
               {
                  "value" : "th",
                  "language" : "en",
                  "phrase" : "Thailand"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "th",
               "en"
            ],
            "notes" : "Other items include Policy Documents",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Thai",
                  "language" : "en",
                  "value" : "th"
               },
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "url" : "http://stks.or.th/nstdair/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "Some items are only available to registered users. The interface is in Thai.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 2556,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "NSTDA Knowledge Repository"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "RiuNet",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 77333,
            "description" : "This site is an institutional repository which provides access to the digital output of the members of the University. The interface is in Spanish. Users may set up an RSS feed to be alerted to new content.",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.8"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "http://riunet.upv.es/",
            "oai_url" : "http://riunet.upv.es/oai/request",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "notes" : "Special items: maps",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ]
         },
         "organisation" : {
            "country" : "es",
            "url" : "http://www.upv.es/",
            "location" : {
               "longitude" : -0.3447,
               "latitude" : 39.4817
            },
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universitat Politècnica de València"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1560",
            "publicly_visible" : "yes",
            "id" : 1560,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-07-30 10:10:54"
         },
         "policies" : {
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "phrase" : "Anyone may access the metadata free of charge",
                     "language" : "en",
                     "value" : "free_open_access"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "value" : "requires_permission",
                     "language" : "en",
                     "phrase" : "Requires Formal Permission"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "https://riunet.upv.es/help/politicacol"
               ],
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  },
                  {
                     "value" : "repository_mention_required",
                     "language" : "en",
                     "phrase" : "The Repository must be mentioned."
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ]
            },
            "content_policy" : {
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "es",
                  "en"
               ],
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "versions_phrases" : [
                  {
                     "value" : "working_drafts",
                     "language" : "en",
                     "phrase" : "working drafts"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "language" : "en",
                     "value" : "submitted_versions"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "language" : "en",
                     "value" : "accepted_versions"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "languages_phrases" : [
                  {
                     "value" : "es",
                     "language" : "en",
                     "phrase" : "Spanish"
                  },
                  {
                     "value" : "en",
                     "language" : "en",
                     "phrase" : "English"
                  }
               ],
               "types_included" : {
                  "all" : "true"
               },
               "url" : [
                  "https://riunet.upv.es/help/politicacol"
               ],
               "metadata_phrases" : [
                  {
                     "value" : "version_type_and_date",
                     "language" : "en",
                     "phrase" : "version_type_and_date"
                  },
                  {
                     "value" : "peer_review_status",
                     "language" : "en",
                     "phrase" : "peer-review status"
                  },
                  {
                     "value" : "publication_status",
                     "language" : "en",
                     "phrase" : "publication status"
                  }
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ]
            },
            "submission_policy" : {
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "bibliographic_metadata_required",
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications."
                  },
                  {
                     "language" : "en",
                     "value" : "full_texts_required",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "language" : "en",
                     "value" : "item_relevance",
                     "phrase" : "relevance to the scope of the repository"
                  },
                  {
                     "phrase" : "valid layout and format",
                     "language" : "en",
                     "value" : "valid_formatting"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "checked_by_subject_specialists",
                     "phrase" : " is checked by internal subject specialists. "
                  }
               ],
               "quality_control" : "checked_by_subject_specialists",
               "copyright_phrases" : [
                  {
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors.",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en"
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "rules" : [
                  "authors_restricted_to_own_work",
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "language" : "en",
                     "value" : "employees",
                     "phrase" : "Employees"
                  }
               ],
               "url" : [
                  "https://riunet.upv.es/help/politicacol"
               ],
               "moderation_phrases" : [
                  {
                     "value" : "yes",
                     "language" : "en",
                     "phrase" : " The administrator vets items for recorded purposes only."
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "unusual_files_not_guaranteed"
               ],
               "url" : [
                  "https://riunet.upv.es/help/politicacol"
               ],
               "closure_policy" : "undefined",
               "closure_policy_phrases" : [
                  {
                     "language" : "en",
                     "value" : "undefined",
                     "phrase" : "No closure policy defined"
                  }
               ],
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  }
               ],
               "version_control" : {
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "language" : "en",
                        "value" : "earlier_versions_may_be_withdrawn"
                     },
                     {
                        "phrase" : "The items persistent URL will always link to the latest version",
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest"
                     },
                     {
                        "language" : "en",
                        "value" : "link_between_versions",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "language" : "en",
                        "value" : "errata_may_be_included"
                     },
                     {
                        "language" : "en",
                        "value" : "updated_versions_allowed",
                        "phrase" : "If necessary, an updated version may be deposited"
                     }
                  ],
                  "policy" : [
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ],
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest",
                     "link_between_versions"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "special_reasons" : [
                     "Does not correspond to nature of repository, contains errors or viruses or incorrect file format"
                  ],
                  "method" : "removed_from_public_view",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "publisher_rules",
                        "language" : "en",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "phrase" : "Legal requirements and proven violations",
                        "language" : "en",
                        "value" : "legal_requirement_proven"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     },
                     {
                        "value" : "other",
                        "language" : "en",
                        "phrase" : "Other (specify)"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "phrase" : "No",
                           "language" : "en",
                           "value" : "no"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ]
                  },
                  "policy_phrases" : [
                     {
                        "value" : "removal_at_request",
                        "language" : "en",
                        "phrase" : "Items may be removed at the request of the author/copyright holder"
                     }
                  ],
                  "policy" : "removal_at_request",
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research",
                     "other"
                  ]
               },
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "phrase" : "It may not be possible to guarantee the readability of some unusual file formats",
                     "language" : "en",
                     "value" : "unusual_files_not_guaranteed"
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "individually_tagged",
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "individually_tagged",
                     "phrase" : "All full items are individually tagged with differring rights permissions and conditions"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "url" : [
                  "https://riunet.upv.es/help/politicacol"
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research output of the institution. The interface is in German.",
            "software" : {
               "name_phrases" : []
            },
            "content_subjects" : [
               "10"
            ],
            "url" : "http://edoc.rki.de/",
            "oai_url" : "http://edoc.rki.de/OAI",
            "full_text_record_count" : 25,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Publikationsserver des Robert Koch-Instituts",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "metadata_record_count" : 6222,
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "de"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1559",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2009-07-23 11:11:02",
            "date_modified" : "2019-10-17 14:34:23",
            "id" : 1559,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "de",
            "location" : {
               "latitude" : 52.5234,
               "longitude" : 13.4114
            },
            "url" : "http://www.rki.de/",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "name" : [
               {
                  "name" : "Robert Koch-Institut",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Boise State University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "latitude" : 43.6039,
               "longitude" : -116.202
            },
            "url" : "http://www.boisestate.edu/"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1558",
            "publicly_visible" : "yes",
            "id" : 1558,
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-07-21 09:09:46"
         },
         "repository_metadata" : {
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "value" : "other",
                     "language" : "en",
                     "phrase" : "Other"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. Some items are not available as full -text or are restricted to registered users. The interface is in English.",
            "full_text_record_count" : 5142,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://scholarworks.boisestate.edu/",
            "oai_url" : "http://scholarworks.boisestate.edu/do/oai/",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Boise State University - ScholarWorks",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 18456,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "metadata_record_count" : 9442,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "name" : "Flacso Andes DSpace",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "23"
            ],
            "oai_url" : "http://www.flacsoandes.org/oai/request",
            "url" : "http://www.flacsoandes.org/dspace/",
            "software" : {
               "name" : "dspace",
               "version" : "1.7.1",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the output of the institution. The interface is in Spanish."
         },
         "organisation" : {
            "country" : "ec",
            "location" : {
               "latitude" : -0.2527,
               "longitude" : -78.4918
            },
            "url" : "http://www.flacsoandes.edu.ec/",
            "country_phrases" : [
               {
                  "phrase" : "Ecuador",
                  "language" : "en",
                  "value" : "ec"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Facultad Latinoamericana de Ciencias Sociales",
                  "acronym" : "FLACSO ANDES",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1557",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-07-20 10:10:01",
            "id" : 1557
         }
      },
      {
         "system_metadata" : {
            "id" : 1556,
            "date_created" : "2009-07-20 09:09:55",
            "date_modified" : "2019-10-17 14:34:23",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1556",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "tw",
            "country_phrases" : [
               {
                  "phrase" : "Taiwan (Province of China)",
                  "value" : "tw",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "National Central University Library"
               }
            ],
            "location" : {
               "longitude" : 121,
               "latitude" : 25
            },
            "url" : "http://www.ncu.edu.tw/",
            "name" : [
               {
                  "acronym" : "國立中央大學",
                  "name" : "National Central University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "ETD-db",
               "name" : "other"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the institutions thesis output. The interface is available in Chinese and English. Some items are under embargo.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://thesis.lib.ncu.edu.tw/ETD-db/ETD-search-c/search",
            "name" : [
               {
                  "name" : "National Central University Library Electronic Thesis & Dissertation System",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "metadata_record_count" : 27865,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "location" : {
               "latitude" : 39.0904,
               "longitude" : -94.5837
            },
            "url" : "http://www.kumc.edu/",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Kansas Medical Center",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2009-07-16 10:10:28",
            "date_modified" : "2019-12-04 12:27:24",
            "id" : 1555,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1555",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "metadata_record_count" : 1120,
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "Archie",
                  "name" : "Digital Collections@KUMC",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "10",
               "28"
            ],
            "url" : "http://archie.kumc.edu/",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "1.8",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the output of the institution, including internal management reports. The interface is in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Management and Planning",
                  "language" : "en",
                  "value" : "28"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 3798,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "name" : "UNTHSC Scholarly Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "url" : "http://digitalcommons.hsc.unt.edu/",
            "content_subjects" : [
               "10"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the theses output of the institution. Users may set up RSS feeds and email alerts to be notified of new content. The interface is in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "language" : "en",
                  "value" : "10"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "Digital Commons",
               "name" : "other"
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "UNTHSC",
                  "name" : "University of North Texas Health Science Center"
               }
            ],
            "country" : "us",
            "url" : "http://www.hsc.unt.edu/",
            "location" : {
               "latitude" : 32.7376,
               "longitude" : -97.3841
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2009-07-16 10:10:24",
            "date_modified" : "2019-10-17 14:34:23",
            "id" : 1554,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1554",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 1553,
            "date_created" : "2009-07-16 10:10:19",
            "date_modified" : "2019-12-04 12:27:24",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1553",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "ec",
            "country_phrases" : [
               {
                  "phrase" : "Ecuador",
                  "value" : "ec",
                  "language" : "en"
               }
            ],
            "url" : "http://www.epn.edu.ec/",
            "location" : {
               "longitude" : -78.4892,
               "latitude" : -0.2075
            },
            "unit" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Biblioteca General de la EPN"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Escuela Politecnica Nacional",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "software" : {
               "version" : "1.7.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the thesis output of the institution. The interface is in Spanish, English and German and includes RSS feeds to alert users to new content.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://bibdigital.epn.edu.ec/",
            "oai_url" : "http://bibdigital.epn.edu.ec/oai/request",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "Respositorio Digital EPN",
                  "name" : "Repositorio Institucional de la Escuela Politecnica Nacional",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 17736,
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Aston University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "country" : "gb",
            "location" : {
               "longitude" : -1.8896,
               "latitude" : 52.4862
            },
            "url" : "http://www.aston.ac.uk/",
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ]
         },
         "system_metadata" : {
            "id" : 1552,
            "date_created" : "2009-07-16 10:10:04",
            "date_modified" : "2019-10-17 14:34:23",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1552",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "policies" : {
            "content_policy" : {
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "types_included" : {
                  "all" : "false",
                  "standard_types_excluded" : [
                     "learning_objects"
                  ],
                  "standard_types_excluded_phrases" : [
                     {
                        "phrase" : "Learning Objects",
                        "language" : "en",
                        "value" : "learning_objects"
                     }
                  ]
               },
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "value" : "working_drafts",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "submitted_versions",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "language" : "en",
                     "value" : "accepted_versions",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "phrase" : "published versions (publisher-created files)",
                     "value" : "published_versions",
                     "language" : "en"
                  }
               ],
               "subjects" : [
                  "1",
                  "5",
                  "8",
                  "24",
                  "26",
                  "27",
                  "28",
                  "14",
                  "29",
                  "15",
                  "16"
               ],
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "metadata" : [
                  "version_type_and_date",
                  "peer_review_status",
                  "publication_status"
               ],
               "subjects_phrases" : [
                  {
                     "language" : "en",
                     "value" : "1",
                     "phrase" : "Multidisciplinary"
                  },
                  {
                     "language" : "en",
                     "value" : "5",
                     "phrase" : "Chemistry and Chemical Technology"
                  },
                  {
                     "phrase" : "Mathematics and Statistics",
                     "language" : "en",
                     "value" : "8"
                  },
                  {
                     "value" : "24",
                     "language" : "en",
                     "phrase" : "Business and Economics"
                  },
                  {
                     "phrase" : "Law and Politics",
                     "language" : "en",
                     "value" : "26"
                  },
                  {
                     "language" : "en",
                     "value" : "27",
                     "phrase" : "Library and Information Science"
                  },
                  {
                     "value" : "28",
                     "language" : "en",
                     "phrase" : "Management and Planning"
                  },
                  {
                     "value" : "14",
                     "language" : "en",
                     "phrase" : "Computers and IT"
                  },
                  {
                     "phrase" : "Psychology",
                     "value" : "29",
                     "language" : "en"
                  },
                  {
                     "phrase" : "Electrical and Electronic Engineering",
                     "language" : "en",
                     "value" : "15"
                  },
                  {
                     "phrase" : "Mechanical Engineering and Materials",
                     "language" : "en",
                     "value" : "16"
                  }
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "version_type_and_date",
                     "value" : "version_type_and_date",
                     "language" : "en"
                  },
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "phrase" : "publication status",
                     "language" : "en",
                     "value" : "publication_status"
                  }
               ],
               "url" : [
                  "http://eprints.aston.ac.uk/policies.html"
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://eprints.aston.ac.uk/policies.html"
               ],
               "non_profit_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  },
                  {
                     "phrase" : "The Repository must be mentioned.",
                     "language" : "en",
                     "value" : "repository_mention_required"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required",
                  "repository_mention_required"
               ]
            },
            "preservation_policy" : {
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "url" : [
                  "http://eprints.aston.ac.uk/policies.html"
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "third_party_collaborations" : [
                  "offsite_backups"
               ],
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "phrase" : "Items will be retained indefinitely",
                        "value" : "indefinitely",
                        "language" : "en"
                     }
                  ]
               },
               "version_control" : {
                  "earlier_versions" : [
                     "earlier_versions_may_be_withdrawn",
                     "persistent_urls_link_to_latest",
                     "link_between_versions"
                  ],
                  "policy_phrases" : [
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "updated_versions_allowed"
                  ],
                  "earlier_versions_phrases" : [
                     {
                        "phrase" : "Earlier versions may be withdrawn from public view",
                        "value" : "earlier_versions_may_be_withdrawn",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "persistent_urls_link_to_latest",
                        "phrase" : "The items persistent URL will always link to the latest version"
                     },
                     {
                        "value" : "link_between_versions",
                        "language" : "en",
                        "phrase" : "There will be links between earlier and later versions, with the most recent version clearly identified"
                     }
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "phrase" : "The repository regularly backs up its file according to current best practices",
                     "value" : "regular_backups",
                     "language" : "en"
                  }
               ],
               "functional_preservation_phrases" : [
                  {
                     "language" : "en",
                     "value" : "readability_and_accessibility",
                     "phrase" : "The repository will try to ensure continued readability and accessibility"
                  },
                  {
                     "language" : "en",
                     "value" : "migrate_file_formats",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  }
               ],
               "third_party_collaborations_phrases" : [
                  {
                     "phrase" : "Backup items in external archives",
                     "language" : "en",
                     "value" : "offsite_backups"
                  }
               ],
               "file_preservation" : [
                  "regular_backups"
               ],
               "withdrawal" : {
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research",
                     "other"
                  ],
                  "policy" : "removal_not_normal",
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "value" : "publisher_rules",
                        "language" : "en",
                        "phrase" : "Journal Publishers' rules"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "language" : "en",
                        "value" : "legal_requirement_proven",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     },
                     {
                        "phrase" : "Other (specify)",
                        "value" : "other",
                        "language" : "en"
                     }
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "url_retention_phrases" : [
                        {
                           "language" : "en",
                           "value" : "trainsient",
                           "phrase" : "Transiently"
                        }
                     ],
                     "url_retention" : "trainsient",
                     "searchable_phrases" : [
                        {
                           "language" : "en",
                           "value" : "yes",
                           "phrase" : "Yes"
                        }
                     ]
                  },
                  "special_reasons" : [
                     "complaints from readers"
                  ],
                  "method" : "deleted",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are deleted entirely from the database",
                        "value" : "deleted",
                        "language" : "en"
                     }
                  ]
               }
            },
            "data_policy" : {
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties",
                  "stored_in_a_database"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "access_phrases" : [
                  {
                     "phrase" : "Access to some or all full items is restricted",
                     "language" : "en",
                     "value" : "some_or_all_restricted"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  },
                  {
                     "value" : "stored_in_a_database",
                     "language" : "en",
                     "phrase" : "stored in a database"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "value" : "no_commercial_selling_without_permission",
                     "language" : "en"
                  },
                  {
                     "value" : "some_items_have_different_conditions",
                     "language" : "en",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  },
                  {
                     "value" : "mentioning_the_repository_is_appreciated",
                     "language" : "en",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ],
               "access" : "some_or_all_restricted",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "language" : "en",
                     "value" : "general_policy"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "language" : "en",
                     "value" : "full_citation_required"
                  },
                  {
                     "phrase" : "a url for the original metadata page is given",
                     "language" : "en",
                     "value" : "link_required"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "language" : "en",
                     "value" : "content_not_changed"
                  }
               ],
               "url" : [
                  "http://eprints.aston.ac.uk/policies.html"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "value" : "personal_research_or_study",
                     "language" : "en",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "value" : "educational_purposes",
                     "language" : "en"
                  },
                  {
                     "value" : "not_for_profit_purposes",
                     "language" : "en",
                     "phrase" : "not-for-profit purposes"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ]
            },
            "submission_policy" : {
               "moderation" : "yes",
               "rules_phrases" : [
                  {
                     "phrase" : "Eligible depositors must deposit bibliographic metadata for all their publications.",
                     "value" : "bibliographic_metadata_required",
                     "language" : "en"
                  },
                  {
                     "value" : "full_texts_required",
                     "language" : "en",
                     "phrase" : "Eligible depositors must deposit full texts of all their publications"
                  },
                  {
                     "language" : "en",
                     "value" : "restrict_full_text_for_embargo_permitted",
                     "phrase" : "Depositors may delay making full texts publicly visible to comply with publishers' embargos"
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "phrase" : "the eligibility of authors/depositors",
                     "language" : "en",
                     "value" : "author_eligibility"
                  },
                  {
                     "value" : "valid_formatting",
                     "language" : "en",
                     "phrase" : "valid layout and format"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "value" : "responsibility_of_depositor",
                     "language" : "en"
                  }
               ],
               "copyright_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "rules" : [
                  "bibliographic_metadata_required",
                  "full_texts_required",
                  "restrict_full_text_for_embargo_permitted"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "valid_formatting"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "depositors" : [
                  "community_members",
                  "academic_staff",
                  "registered_students"
               ],
               "url" : [
                  "http://eprints.aston.ac.uk/policies.html"
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  },
                  {
                     "value" : "academic_staff",
                     "language" : "en",
                     "phrase" : "Academic Staff"
                  },
                  {
                     "phrase" : "Registered Students",
                     "value" : "registered_students",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "language" : "en",
                     "value" : "yes"
                  }
               ]
            }
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "en"
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "metadata_record_count" : 33136,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Aston Publications Explorer"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://publications.aston.ac.uk/",
            "oai_url" : "http://publications.aston.ac.uk/cgi/oai2",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access the research output of the institution. Some items are not available as full-text. Users may set up RSS feeds to be alerted to new content. The interface is in English.",
            "software" : {
               "name" : "eprints",
               "version" : "3.3.16",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Leeds Beckett University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "value" : "gb",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 53.8266,
               "longitude" : -1.5919
            },
            "url" : "http://www.leedsbeckett.ac.uk/",
            "country" : "gb"
         },
         "system_metadata" : {
            "id" : 1551,
            "date_created" : "2009-07-16 09:09:56",
            "date_modified" : "2019-10-17 14:34:23",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1551",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "policies" : {
            "submission_policy" : {
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately.",
                     "language" : "en",
                     "value" : "removal_of_items_on_proof_of_violation"
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "language" : "en",
                     "value" : "responsibility_of_depositor",
                     "phrase" : " is the sole responsibility of the depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "rules_phrases" : [
                  {
                     "value" : "authors_restricted_to_own_work",
                     "language" : "en",
                     "phrase" : "Authors may only submit their own work for archiving."
                  }
               ],
               "moderation_purposes_phrases" : [
                  {
                     "value" : "author_eligibility",
                     "language" : "en",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "phrase" : "the exclusion of spam",
                     "language" : "en",
                     "value" : "spam_exclusion"
                  }
               ],
               "moderation" : "yes",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Accredited Community Members",
                     "value" : "community_members",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired",
                     "language" : "en",
                     "value" : "restricted_until_embargo_expiry"
                  }
               ],
               "url" : [
                  "http://repository.leedsmet.ac.uk/main/policies.php"
               ],
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "community_members"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "restricted_until_embargo_expiry"
            },
            "data_policy" : {
               "access" : "some_or_all_restricted",
               "reuse" : "general_policy",
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "url" : [
                  "http://repository.leedsmet.ac.uk/main/policies.php"
               ],
               "reuse_requirements_phrases" : [
                  {
                     "language" : "en",
                     "value" : "full_citation_required",
                     "phrase" : "the authors, title and full bibliographic details are given"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "phrase" : "the content is not changed in any way",
                     "value" : "content_not_changed",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "value" : "educational_purposes",
                     "language" : "en",
                     "phrase" : "educational purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "value" : "not_for_profit_purposes",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "the_repository_is_not_the_publisher",
                  "mentioning_the_repository_is_appreciated"
               ],
               "harvesting_phrases" : [
                  {
                     "value" : "allowed",
                     "language" : "en",
                     "phrase" : "Allowed"
                  }
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "content_not_changed"
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "some_or_all_restricted",
                     "phrase" : "Access to some or all full items is restricted"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "value" : "reproduced",
                     "language" : "en",
                     "phrase" : "reproduced"
                  },
                  {
                     "value" : "displayed_or_performed",
                     "language" : "en",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "value" : "given_to_third_parties",
                     "language" : "en",
                     "phrase" : "given to third parties"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "reuse_conditions_phrases" : [
                  {
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders",
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "value" : "the_repository_is_not_the_publisher",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "mentioning_the_repository_is_appreciated",
                     "phrase" : "Mention of the repository is appreciated but not mandatory"
                  }
               ]
            },
            "preservation_policy" : {
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "value" : "readability_and_accessibility",
                     "language" : "en"
                  },
                  {
                     "value" : "migrate_file_formats",
                     "language" : "en",
                     "phrase" : "Items will be migrated to new file formats where necessary"
                  },
                  {
                     "phrase" : "Where possible, software emulation will be provided to access un-migrated formats",
                     "value" : "software_emulation",
                     "language" : "en"
                  }
               ],
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "withdrawal" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Items may not normally be removed from the repository",
                        "value" : "removal_not_normal",
                        "language" : "en"
                     }
                  ],
                  "method" : "removed_from_public_view",
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "phrase" : "Withdrawn items are not deleted per se, but are removed from public view",
                        "language" : "en",
                        "value" : "removed_from_public_view"
                     }
                  ],
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "language" : "en",
                        "value" : "copyright_violation_or_plagiarism"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "phrase" : "National Security",
                        "value" : "national_security",
                        "language" : "en"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "searchable" : "yes",
                     "item_page" : [
                        "tombstone"
                     ],
                     "url_retention" : "indefinite",
                     "searchable_phrases" : [
                        {
                           "value" : "yes",
                           "language" : "en",
                           "phrase" : "Yes"
                        }
                     ],
                     "url_retention_phrases" : [
                        {
                           "phrase" : "Indefinitely",
                           "value" : "indefinite",
                           "language" : "en"
                        }
                     ],
                     "item_page_phrases" : [
                        {
                           "phrase" : "URLs will continue to point to 'tombstone' citations.",
                           "value" : "tombstone",
                           "language" : "en"
                        }
                     ]
                  }
               },
               "retention_period" : {
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ],
                  "period" : "indefinitely"
               },
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "phrase" : "Changes to deposited items are not permitted",
                        "value" : "changes_not_permitted",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "value" : "errata_may_be_included",
                        "language" : "en"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "value" : "original_bitstream_retained",
                     "language" : "en",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "url" : [
                  "http://repository.leedsmet.ac.uk/main/policies.php"
               ],
               "functional_preservation" : [
                  "readability_and_accessibility",
                  "migrate_file_formats",
                  "software_emulation"
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "closure_policy_phrases" : [
                  {
                     "phrase" : "The database will be transferred to another appropriate archive",
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en"
                  }
               ]
            },
            "content_policy" : {
               "types_included" : {
                  "all" : "false",
                  "standard_types_allowed_phrases" : [
                     {
                        "language" : "en",
                        "value" : "journal_articles",
                        "phrase" : "Journal Articles"
                     }
                  ],
                  "standard_types_allowed" : [
                     "journal_articles"
                  ]
               },
               "languages_phrases" : [
                  {
                     "phrase" : "English",
                     "language" : "en",
                     "value" : "en"
                  }
               ],
               "versions_phrases" : [
                  {
                     "value" : "submitted_versions",
                     "language" : "en",
                     "phrase" : "submitted versions (as sent to journals for peer-review)"
                  },
                  {
                     "value" : "accepted_versions",
                     "language" : "en",
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)"
                  },
                  {
                     "language" : "en",
                     "value" : "published_versions",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "versions" : [
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "repository_type" : "institutional_or_departmental",
               "repository_type_phrases" : [
                  {
                     "value" : "institutional_or_departmental",
                     "language" : "en",
                     "phrase" : "Institutional or departmental repository"
                  }
               ],
               "languages" : [
                  "en"
               ],
               "metadata" : [
                  "peer_review_status",
                  "publication_status"
               ],
               "url" : [
                  "http://repository.leedsmet.ac.uk/main/policies.php"
               ],
               "metadata_phrases" : [
                  {
                     "phrase" : "peer-review status",
                     "value" : "peer_review_status",
                     "language" : "en"
                  },
                  {
                     "language" : "en",
                     "value" : "publication_status",
                     "phrase" : "publication status"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "value" : "free_open_access",
                     "language" : "en",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "commercial_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_phrases" : [
                  {
                     "language" : "en",
                     "value" : "allowed",
                     "phrase" : "Allowed"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "access" : "free_open_access",
               "url" : [
                  "http://repository.leedsmet.ac.uk/main/policies.php"
               ],
               "commercial_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "allowed",
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given.",
                     "value" : "oai_id_or_link_required",
                     "language" : "en"
                  }
               ],
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ]
            }
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "http://eprints.leedsbeckett.ac.uk/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://eprints.leedsbeckett.ac.uk/",
            "software" : {
               "version" : "3.3.16",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site provides access to the research and teaching output of the institution. Many items provide links to the work held elsewhere.",
            "metadata_record_count" : 4363,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Leeds Beckett University Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ],
            "oai_url" : "http://rephip.unr.edu.ar/oai/request",
            "url" : "http://rephip.unr.edu.ar/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research and teaching output of the institution. The interface is in Spanish.",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "1.6.2"
            },
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 5050,
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "Repositorio Hipermedial de la Universidad Nacional de Rosario",
                  "acronym" : "RepHipUNR"
               }
            ]
         },
         "organisation" : {
            "country" : "ar",
            "url" : "http://www.unr.edu.ar/",
            "location" : {
               "longitude" : -60.6667,
               "latitude" : -32.95
            },
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "value" : "ar",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Nacional de Rosario"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-07-13 10:10:40",
            "id" : 1550,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1550",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "http://www.luiss.it/",
            "location" : {
               "longitude" : 12.4823,
               "latitude" : 41.8955
            },
            "country_phrases" : [
               {
                  "phrase" : "Italy",
                  "language" : "en",
                  "value" : "it"
               }
            ],
            "country" : "it",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "LUISS - Libera Università Internazionale degli Studi Sociali Guido Carli",
                  "acronym" : "LUISS",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-07-10 12:12:05",
            "id" : 1549,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1549",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Italian",
                  "value" : "it",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "it",
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "LUISSearch"
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 881,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "version" : "3.1.3",
               "name" : "eprints"
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS and Atom feeds to be alerted to new content. The interface is in English and Italian.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://eprints.luiss.it/cgi/oai2",
            "url" : "http://eprints.luiss.it/",
            "content_subjects" : [
               "1"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Scholarship@Western",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "metadata_record_count" : 26686,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "software" : {
               "name" : "other",
               "name_other" : "Digital Commons",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up an RSS feed to be alerted to new content. Some items are not available as full text. The interface is in English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 25,
            "url" : "http://ir.lib.uwo.ca/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ir.lib.uwo.ca/do/oai/"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "University of Western Ontario",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "ca",
            "unit" : [
               {
                  "name" : "Western Libraries",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "http://www.uwo.ca/",
            "location" : {
               "longitude" : -81.2771,
               "latitude" : 43.0082
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ca",
                  "phrase" : "Canada"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1548",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-07-08 09:09:21",
            "id" : 1548,
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-07-02 15:15:54",
            "id" : 1547,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1547"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Балтийский федеральный университет имени Иммануила Канта (Immanuel Kant Baltic Federal University)",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "url" : "http://www.kantiana.ru/",
            "country_phrases" : [
               {
                  "phrase" : "Russian Federation",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "country" : "ru"
         },
         "repository_metadata" : {
            "metadata_record_count" : 468,
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Архив электронных публикаций"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Withdrawn from use",
                  "value" : "withdrawn_from_use",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ru"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://elib.albertina.ru/",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "withdrawn_from_use",
            "description" : "This site provides access to the output of the institution. The interface is in Russian.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "ua",
                  "language" : "en",
                  "phrase" : "Ukraine"
               }
            ],
            "location" : {
               "latitude" : 50.0046,
               "longitude" : 36.2275
            },
            "url" : "http://www.univer.kharkov.ua/",
            "country" : "ua",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "acronym" : "V.N. Karazin",
                  "name" : "Kharkiv National University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1546,
            "date_modified" : "2019-12-03 11:32:32",
            "date_created" : "2009-07-01 11:11:20",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1546"
         },
         "repository_metadata" : {
            "full_text_record_count" : 6691,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://dspace.univer.kharkov.ua/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dspace.univer.kharkov.ua/",
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in Ukrainian, Russian and English.",
            "metadata_record_count" : 13862,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Електронного архіву Харківського національного університету імені В.Н.Каразіна (Electronic Archive V.N. Karazin Kharkiv National University)",
                  "acronym" : "eKhNUIR",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_languages" : [
               "en",
               "ru",
               "uk"
            ],
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "phrase" : "Russian",
                  "language" : "en",
                  "value" : "ru"
               },
               {
                  "value" : "uk",
                  "language" : "en",
                  "phrase" : "Ukrainian"
               }
            ],
            "content_types" : [
               "journal_articles"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1545",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 1545,
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-07-01 11:11:13",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Katholische Universität Eichstätt-Ingolstadt (KU)",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "de",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "latitude" : 48.891,
               "longitude" : 11.1852
            },
            "url" : "http://www.ku-eichstaett.de/"
         },
         "policies" : {
            "content_policy" : {
               "types_included" : {
                  "all" : "true"
               },
               "versions_phrases" : [
                  {
                     "phrase" : "working drafts",
                     "value" : "working_drafts",
                     "language" : "en"
                  },
                  {
                     "phrase" : "submitted versions (as sent to journals for peer-review)",
                     "value" : "submitted_versions",
                     "language" : "en"
                  },
                  {
                     "phrase" : "accepted versions (author's final peer-reviewed drafts)",
                     "value" : "accepted_versions",
                     "language" : "en"
                  },
                  {
                     "value" : "published_versions",
                     "language" : "en",
                     "phrase" : "published versions (publisher-created files)"
                  }
               ],
               "repository_type" : "institutional_or_departmental",
               "versions" : [
                  "working_drafts",
                  "submitted_versions",
                  "accepted_versions",
                  "published_versions"
               ],
               "url" : [
                  "http://edoc.ku-eichstaett.de/help"
               ],
               "repository_type_phrases" : [
                  {
                     "phrase" : "Institutional or departmental repository",
                     "value" : "institutional_or_departmental",
                     "language" : "en"
                  }
               ]
            },
            "metadata_policy" : {
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access the metadata free of charge"
                  }
               ],
               "access" : "free_open_access",
               "non_profit_reuse_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "value" : "allowed",
                     "language" : "en"
                  }
               ],
               "commercial_reuse_phrases" : [
                  {
                     "phrase" : "Requires Formal Permission",
                     "language" : "en",
                     "value" : "requires_permission"
                  }
               ],
               "url" : [
                  "http://edoc.ku-eichstaett.de/help"
               ],
               "non_profit_reuse" : "allowed",
               "commercial_reuse" : "requires_permission",
               "non_profit_reuse_conditions" : [
                  "oai_id_or_link_required"
               ],
               "non_profit_reuse_conditions_phrases" : [
                  {
                     "value" : "oai_id_or_link_required",
                     "language" : "en",
                     "phrase" : "The OAI Identifier and/or a link to the original metadata must be given."
                  }
               ]
            },
            "data_policy" : {
               "harvesting_phrases" : [
                  {
                     "phrase" : "Allowed",
                     "language" : "en",
                     "value" : "allowed"
                  }
               ],
               "reuse_conditions" : [
                  "no_commercial_selling_without_permission",
                  "some_items_have_different_conditions",
                  "the_repository_is_not_the_publisher"
               ],
               "reuse_permitted_purposes" : [
                  "personal_research_or_study",
                  "educational_purposes",
                  "not_for_profit_purposes"
               ],
               "reuse_permitted_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "personal_research_or_study",
                     "phrase" : "personal research or study"
                  },
                  {
                     "phrase" : "educational purposes",
                     "language" : "en",
                     "value" : "educational_purposes"
                  },
                  {
                     "phrase" : "not-for-profit purposes",
                     "language" : "en",
                     "value" : "not_for_profit_purposes"
                  }
               ],
               "reuse_requirements_phrases" : [
                  {
                     "phrase" : "the authors, title and full bibliographic details are given",
                     "value" : "full_citation_required",
                     "language" : "en"
                  },
                  {
                     "value" : "link_required",
                     "language" : "en",
                     "phrase" : "a url for the original metadata page is given"
                  },
                  {
                     "value" : "original_rights_statement_required",
                     "language" : "en",
                     "phrase" : "the original rights permission statement is given"
                  },
                  {
                     "language" : "en",
                     "value" : "content_not_changed",
                     "phrase" : "the content is not changed in any way"
                  }
               ],
               "url" : [
                  "http://edoc.ku-eichstaett.de/help"
               ],
               "reuse_phrases" : [
                  {
                     "phrase" : "General full-item re-use policy defined",
                     "value" : "general_policy",
                     "language" : "en"
                  }
               ],
               "reuse" : "general_policy",
               "access" : "free_open_access",
               "reuse_conditions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "no_commercial_selling_without_permission",
                     "phrase" : "Full items must not be sold commercially without formal permission of the copyright holders"
                  },
                  {
                     "value" : "some_items_have_different_conditions",
                     "language" : "en",
                     "phrase" : "Some full items are individually tagged with different rights permissions and conditions"
                  },
                  {
                     "phrase" : "This repository is not the publisher; it is merely the online archive",
                     "language" : "en",
                     "value" : "the_repository_is_not_the_publisher"
                  }
               ],
               "harvesting" : [
                  "allowed"
               ],
               "access_phrases" : [
                  {
                     "language" : "en",
                     "value" : "free_open_access",
                     "phrase" : "Anyone may access full items free of charge"
                  }
               ],
               "reuse_permitted_actions_phrases" : [
                  {
                     "language" : "en",
                     "value" : "reproduced",
                     "phrase" : "reproduced"
                  },
                  {
                     "language" : "en",
                     "value" : "displayed_or_performed",
                     "phrase" : "displayed or performed"
                  },
                  {
                     "phrase" : "given to third parties",
                     "value" : "given_to_third_parties",
                     "language" : "en"
                  }
               ],
               "reuse_permitted_actions" : [
                  "reproduced",
                  "displayed_or_performed",
                  "given_to_third_parties"
               ],
               "reuse_requirements" : [
                  "full_citation_required",
                  "link_required",
                  "original_rights_statement_required",
                  "content_not_changed"
               ]
            },
            "preservation_policy" : {
               "file_preservation_phrases" : [
                  {
                     "value" : "regular_backups",
                     "language" : "en",
                     "phrase" : "The repository regularly backs up its file according to current best practices"
                  },
                  {
                     "value" : "original_bitstream_retained",
                     "language" : "en",
                     "phrase" : "The original bit stream is retained for all items, in addition to any upgraded formats"
                  }
               ],
               "version_control" : {
                  "policy_phrases" : [
                     {
                        "value" : "changes_not_permitted",
                        "language" : "en",
                        "phrase" : "Changes to deposited items are not permitted"
                     },
                     {
                        "phrase" : "Errata and corrigenda lists may be included with the original if required",
                        "value" : "errata_may_be_included",
                        "language" : "en"
                     },
                     {
                        "phrase" : "If necessary, an updated version may be deposited",
                        "language" : "en",
                        "value" : "updated_versions_allowed"
                     }
                  ],
                  "policy" : [
                     "changes_not_permitted",
                     "errata_may_be_included",
                     "updated_versions_allowed"
                  ]
               },
               "retention_period" : {
                  "period" : "indefinitely",
                  "period_phrases" : [
                     {
                        "language" : "en",
                        "value" : "indefinitely",
                        "phrase" : "Items will be retained indefinitely"
                     }
                  ]
               },
               "withdrawal" : {
                  "standard_reasons_phrases" : [
                     {
                        "phrase" : "Journal Publishers' rules",
                        "value" : "publisher_rules",
                        "language" : "en"
                     },
                     {
                        "phrase" : "Proven copyright violation or plagiarism",
                        "value" : "copyright_violation_or_plagiarism",
                        "language" : "en"
                     },
                     {
                        "value" : "legal_requirement_proven",
                        "language" : "en",
                        "phrase" : "Legal requirements and proven violations"
                     },
                     {
                        "value" : "national_security",
                        "language" : "en",
                        "phrase" : "National Security"
                     },
                     {
                        "language" : "en",
                        "value" : "falsified_research",
                        "phrase" : "Falsified research"
                     }
                  ],
                  "standard_reasons" : [
                     "publisher_rules",
                     "copyright_violation_or_plagiarism",
                     "legal_requirement_proven",
                     "national_security",
                     "falsified_research"
                  ],
                  "withdrawn_items" : {
                     "searchable" : "no",
                     "searchable_phrases" : [
                        {
                           "value" : "no",
                           "language" : "en",
                           "phrase" : "No"
                        }
                     ],
                     "url_retention" : "indefinite",
                     "url_retention_phrases" : [
                        {
                           "value" : "indefinite",
                           "language" : "en",
                           "phrase" : "Indefinitely"
                        }
                     ]
                  },
                  "policy_phrases" : [
                     {
                        "language" : "en",
                        "value" : "removal_not_normal",
                        "phrase" : "Items may not normally be removed from the repository"
                     }
                  ],
                  "method" : "deleted",
                  "policy" : "removal_not_normal",
                  "method_phrases" : [
                     {
                        "value" : "deleted",
                        "language" : "en",
                        "phrase" : "Withdrawn items are deleted entirely from the database"
                     }
                  ]
               },
               "file_preservation" : [
                  "regular_backups",
                  "original_bitstream_retained"
               ],
               "functional_preservation_phrases" : [
                  {
                     "phrase" : "The repository will try to ensure continued readability and accessibility",
                     "language" : "en",
                     "value" : "readability_and_accessibility"
                  }
               ],
               "closure_policy_phrases" : [
                  {
                     "value" : "transfer_to_appropriate_archive",
                     "language" : "en",
                     "phrase" : "The database will be transferred to another appropriate archive"
                  }
               ],
               "closure_policy" : "transfer_to_appropriate_archive",
               "functional_preservation" : [
                  "readability_and_accessibility"
               ]
            },
            "submission_policy" : {
               "moderation_purposes_phrases" : [
                  {
                     "language" : "en",
                     "value" : "author_eligibility",
                     "phrase" : "the eligibility of authors/depositors"
                  },
                  {
                     "phrase" : "relevance to the scope of the repository",
                     "language" : "en",
                     "value" : "item_relevance"
                  },
                  {
                     "language" : "en",
                     "value" : "valid_formatting",
                     "phrase" : "valid layout and format"
                  },
                  {
                     "value" : "spam_exclusion",
                     "language" : "en",
                     "phrase" : "the exclusion of spam"
                  }
               ],
               "rules_phrases" : [
                  {
                     "phrase" : "Authors may only submit their own work for archiving.",
                     "language" : "en",
                     "value" : "authors_restricted_to_own_work"
                  }
               ],
               "moderation" : "yes",
               "copyright_phrases" : [
                  {
                     "value" : "responsibility_of_depositor",
                     "language" : "en",
                     "phrase" : "Any copyright violations are entirely the responsibility of the authors/depositors."
                  },
                  {
                     "value" : "removal_of_items_on_proof_of_violation",
                     "language" : "en",
                     "phrase" : "If the repository receives proof of copyright violation, the relevant item will be removed immediately."
                  }
               ],
               "quality_control_phrases" : [
                  {
                     "phrase" : " is the sole responsibility of the depositor",
                     "language" : "en",
                     "value" : "responsibility_of_depositor"
                  }
               ],
               "quality_control" : "responsibility_of_depositor",
               "moderation_purposes" : [
                  "author_eligibility",
                  "item_relevance",
                  "valid_formatting",
                  "spam_exclusion"
               ],
               "depositors" : [
                  "academic_staff",
                  "registered_students",
                  "employees"
               ],
               "copyright" : [
                  "responsibility_of_depositor",
                  "removal_of_items_on_proof_of_violation"
               ],
               "rules" : [
                  "authors_restricted_to_own_work"
               ],
               "content_embargo" : "restricted_until_embargo_expiry",
               "moderation_phrases" : [
                  {
                     "phrase" : " The administrator vets items for recorded purposes only.",
                     "value" : "yes",
                     "language" : "en"
                  }
               ],
               "depositors_phrases" : [
                  {
                     "phrase" : "Academic Staff",
                     "language" : "en",
                     "value" : "academic_staff"
                  },
                  {
                     "value" : "registered_students",
                     "language" : "en",
                     "phrase" : "Registered Students"
                  },
                  {
                     "phrase" : "Employees",
                     "value" : "employees",
                     "language" : "en"
                  }
               ],
               "content_embargo_phrases" : [
                  {
                     "value" : "restricted_until_embargo_expiry",
                     "language" : "en",
                     "phrase" : "Items can be deposited at any time, but will not be made publicly visible until any embargo period has expired"
                  }
               ],
               "url" : [
                  "http://edoc.ku-eichstaett.de/help"
               ]
            }
         },
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "de"
            ],
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "books_chapters_and_sections"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "German",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "description" : "University repository providing access to the publication output of the institution. Not all items listed are available as full text, and many are bibliographic entries only. Users may set up Atom and RSS feeds to be alerted to new content. The interface is in German.",
            "software" : {
               "version" : "3.1.3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "url" : "http://edoc.ku-eichstaett.de/",
            "oai_url" : "http://edoc.ku-eichstaett.de/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "full_text_record_count" : 514,
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "KU.doc",
                  "name" : "Publikationsserver der Katholischen Universität Eichstätt-Ingolstadt",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 19097
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "United Nations Educational, Scientific and Cultural Organisation",
                  "acronym" : "UNESCO",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "longitude" : 2.3064,
               "latitude" : 48.8502
            },
            "url" : "http://www.unesco.org/new/en/",
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "country" : "fr"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1544",
            "publicly_visible" : "yes",
            "id" : 1544,
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-06-29 11:11:47"
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.wdl.org/en/",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to primary material from around the globe. Some items are not available to download. The interface is available in Arabic, Chinese, English, French, Portuguese, Russian, and Spanish. Various partner institutions have been involved.",
            "software" : {
               "name_phrases" : []
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 10778,
            "type" : "governmental",
            "name" : [
               {
                  "acronym" : "WDL",
                  "name" : "World Digital Library",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_languages" : [
               "en",
               "ar",
               "zh",
               "fr"
            ],
            "notes" : "Special Items include Manuscripts, Sound Recordings and Maps",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "language" : "en",
                  "value" : "ar",
                  "phrase" : "Arabic"
               },
               {
                  "phrase" : "Chinese",
                  "language" : "en",
                  "value" : "zh"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Russian Federation",
                  "language" : "en",
                  "value" : "ru"
               }
            ],
            "location" : {
               "longitude" : 53.2113,
               "latitude" : 56.8538
            },
            "url" : "http://udsu.ru",
            "country" : "ru",
            "name" : [
               {
                  "name" : "Udmurt State University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "language" : "ru",
                  "language_phrases" : [
                     {
                        "value" : "ru",
                        "language" : "en",
                        "phrase" : "Russian"
                     }
                  ],
                  "name" : "Удмуртский государственный университет"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1543",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:24",
            "date_created" : "2009-06-26 15:15:33",
            "id" : 1543
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "http://elibrary.udsu.ru",
            "content_languages" : [
               "ru"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the output of the institution. Some items are only available to registered users. Users may set up RSS feeds to be alerted to new content. The interface is in Russian.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "1.8.2"
            },
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ru",
                  "phrase" : "Russian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 16147,
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Udmurt State University eLibrary",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               },
               {
                  "acronym" : "УдНОЭБ",
                  "name" : "Удмуртская научно-образовательная электронная библиотека",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Russian",
                        "language" : "en",
                        "value" : "ru"
                     }
                  ],
                  "language" : "ru",
                  "preferred" : "name"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1542",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-06-26 10:10:25",
            "id" : 1542,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "url" : "http://www.ed.gov/",
            "unit" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "IES",
                  "name" : "Institute of Education Sciences",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "latitude" : 38.8864,
               "longitude" : -77.0188
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "U.S. Department of Education",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "bibliographic_references",
                  "language" : "en",
                  "phrase" : "Bibliographic References"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 1210279,
            "content_types" : [
               "journal_articles",
               "bibliographic_references",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "type" : "governmental",
            "name" : [
               {
                  "acronym" : "ERIC",
                  "name" : "Education Resources Information Center",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1",
               "25"
            ],
            "url" : "http://www.eric.ed.gov/",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Governmental",
                  "language" : "en",
                  "value" : "governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               }
            ],
            "description" : "This site provides access to research output researchers funded by the institution. Many items are not available as full-text, particularly within the last 12 months. The sites interface is in English.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1540",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2009-06-25 09:09:59",
            "date_modified" : "2019-12-04 12:27:24",
            "id" : 1540,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Cyprus University of Technology (Τεχνολογικό Πανεπιστήμιο Κύπρου)",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "country" : "cy",
            "country_phrases" : [
               {
                  "value" : "cy",
                  "language" : "en",
                  "phrase" : "Cyprus"
               }
            ],
            "location" : {
               "longitude" : 33.0333,
               "latitude" : 34.6667
            },
            "url" : "http://www.cut.ac.cy/"
         },
         "repository_metadata" : {
            "content_languages" : [
               "el",
               "en"
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "el",
                  "language" : "en",
                  "phrase" : "Greek (modern)"
               },
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "bibliographic_references",
               "other_special_item_types"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://ktisis.cut.ac.cy/oai/request",
            "url" : "http://ktisis.cut.ac.cy/",
            "full_text_record_count" : 3,
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research output of the institution. Users may set up RSS feeds to be alerted to new content. The interface is in Greek and English. Many items are not available as full text. Ktisis was named after the symbol of the Cyprus University of Technology depicting Ktisis, the spirit of creation. The symbol originates from a mosaic notation at the Efstolios house that lies in ancient Curium and originates at the start of the 5th d.c. century.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "version" : "5.6.2",
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Bibliographic References",
                  "language" : "en",
                  "value" : "bibliographic_references"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "metadata_record_count" : 100,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Ktisis",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 1539,
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-06-25 09:09:52",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1539"
         },
         "organisation" : {
            "country" : "in",
            "url" : "http://ggsipu.nic.in/",
            "location" : {
               "longitude" : 77.2329,
               "latitude" : 28.6643
            },
            "country_phrases" : [
               {
                  "phrase" : "India",
                  "value" : "in",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Guru Gobind Singh Indraprastha University",
                  "acronym" : "गुरु गोबिन्द सिंह इंद्रप्रस्थ विश्वविद्यालय"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This is an institutional repository providing access to the research and theses output of the institution. The interface is in English.",
            "software" : {
               "name" : "dspace",
               "version" : "1.7.2",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://14.139.60.216:8080/xmlui/",
            "oai_url" : "http://14.139.60.216:8080/oai/request",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "full_text_record_count" : 0,
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "DSpace @ GGSIPU"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "metadata_record_count" : 135,
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2009-06-22 14:14:58",
            "date_modified" : "2019-10-17 14:34:23",
            "id" : 1538,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1538"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Georg-Simon-Ohm-Hochschule Nürnberg",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 49.4531,
               "longitude" : 11.0924
            },
            "url" : "http://www.ohm-hochschule.de/",
            "country_phrases" : [
               {
                  "phrase" : "Germany",
                  "language" : "en",
                  "value" : "de"
               }
            ],
            "country" : "de"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "de",
                  "phrase" : "German"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "content_languages" : [
               "de"
            ],
            "repository_status" : "trial",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 70,
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "OhmDok",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "full_text_record_count" : 0,
            "repository_status_phrases" : [
               {
                  "phrase" : "Trial",
                  "value" : "trial",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.opus-bayern.de/ohm-hochschule/",
            "oai_url" : "http://www.opus-bayern.de/ohm-hochschule/oai2/oai2.php",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "opus",
                     "phrase" : "OPUS"
                  }
               ],
               "version" : "3.2",
               "name" : "opus"
            },
            "description" : "This site provides access to the scientific publications of the institution. The interface is available in German."
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "國立清華大學",
                  "name" : "National Tsing Hua University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Taiwan (Province of China)",
                  "value" : "tw",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 120.965,
               "latitude" : 24.8039
            },
            "url" : "http://www.nthu.edu.tw/",
            "country" : "tw"
         },
         "system_metadata" : {
            "date_created" : "2009-06-22 11:11:23",
            "date_modified" : "2019-10-17 14:34:23",
            "id" : 1537,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1537",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 56719,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Tsing Hua University Institutional Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "http://nthur.lib.nthu.edu.tw/",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://nthur.lib.nthu.edu.tw/dspace-oai/request",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the scholarly output of the institution. Users may set up an RSS feed to be alerted to new content. Some items are not available as full text. The front page interface is available in Chinese, and the main pages are available in English, Chinese and Chinese (simplified)"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1536",
            "publicly_visible" : "yes",
            "id" : 1536,
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-06-22 11:11:15"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "National Chengchi University",
                  "acronym" : "國立政治大學",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "tw",
            "url" : "http://www.nccu.edu.tw/",
            "location" : {
               "longitude" : 121.56,
               "latitude" : 25.0911
            },
            "country_phrases" : [
               {
                  "value" : "tw",
                  "language" : "en",
                  "phrase" : "Taiwan (Province of China)"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "zh",
                  "phrase" : "Chinese"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "datasets"
            ],
            "content_languages" : [
               "zh",
               "en"
            ],
            "repository_status" : "replaced_by_new_url",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "metadata_record_count" : 24783,
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "value" : "conference_and_workshop_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "NCCU Institutional Repository"
               }
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Replaced by New URL",
                  "value" : "replaced_by_new_url",
                  "language" : "en"
               }
            ],
            "url" : "http://nccuir.lib.nccu.edu.tw/",
            "oai_url" : "http://nccuir.lib.nccu.edu.tw/dspace-oai/request",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace"
            },
            "description" : "This site provides access to the output of the institution. The interface is available in Chinese, Chinese (simplified) and English. Many items are not available as full-text."
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University College Cork",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Ireland",
                  "value" : "ie",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 51.89,
               "longitude" : -8.49
            },
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "UCC Library Service"
               }
            ],
            "url" : "http://www.ucc.ie/en/",
            "country" : "ie"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/1535",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-17 14:34:23",
            "date_created" : "2009-06-22 11:11:02",
            "id" : 1535
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "oai_url" : "http://cora.ucc.ie/oai/request",
            "url" : "http://cora.ucc.ie/",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "CORA Cork Open Research Archive is the institutional repository of University College Cork, Ireland. CORA provides access to the institution's scholarly research including peer-reviewed journal articles and electronic theses from across the four colleges and research institutes and centres.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "4.2",
               "name" : "dspace"
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "metadata_record_count" : 5713,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "acronym",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Cork Open Research Archive",
                  "acronym" : "CORA",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ]
         }
      }
   ]
}

