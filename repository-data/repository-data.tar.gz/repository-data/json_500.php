{
   "items" : [
      {
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "value" : "17",
                  "language" : "en"
               },
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the special collections, faculty notes and student publications from Des Moines Area Community College. Users may set up RSS feeds to be alerted to new content. Both the interface and content are in English only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "url" : "https://openspace.dmacc.edu",
            "oai_url" : "https://openspace.dmacc.edu/do/oai/",
            "content_subjects" : [
               "17",
               "10"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "DMACC",
                  "name" : "Open SPACE @ DMACC (Des Moines Area Community College)",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "acronym" : "DMACC",
                  "name" : "Des Moines area community college",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "acronym"
               }
            ],
            "country" : "us",
            "location" : {
               "longitude" : -93.6275,
               "latitude" : 41.5978
            },
            "url" : "https://www.dmacc.edu/Pages/welcome.aspx",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7438",
            "publicly_visible" : "yes",
            "id" : 7438,
            "date_created" : "2019-09-28 03:05:31",
            "date_modified" : "2019-12-04 12:27:39"
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-28 03:05:13",
            "date_modified" : "2019-11-19 15:21:04",
            "id" : 7432,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7432",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UConn",
                  "name" : "University of Connecticut",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 41.8071,
               "longitude" : -72.2525
            },
            "url" : "https://uconn.edu",
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "UConn Library"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "OpenCommons@UConn",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Connecticut. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://opencommons.uconn.edu/do/oai",
            "url" : "https://opencommons.uconn.edu",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site provides access to the research outputs of the Winona State University and southeast Minnesota. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://openriver.winona.edu",
            "oai_url" : "https://openriver.winona.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "OpenRiver",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "unit" : [
               {
                  "name" : "Darrell W. Krueger Library"
               }
            ],
            "location" : {
               "latitude" : 44.0475,
               "longitude" : -91.6433
            },
            "url" : "https://www.winona.edu",
            "country" : "us",
            "name" : [
               {
                  "name" : "Winona State University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "system_metadata" : {
            "id" : 7430,
            "date_created" : "2019-09-28 03:04:59",
            "date_modified" : "2019-11-06 11:15:34",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7430",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 03:04:57",
            "date_modified" : "2019-11-06 16:03:06",
            "id" : 7429,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7429"
         },
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 40.7009,
               "longitude" : -99.1014
            },
            "url" : "https://www.unk.edu/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "name" : "University of Nebraska Kearney"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "url" : "https://openspaces.unk.edu",
            "oai_url" : "https://openspaces.unk.edu/do/oai",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research output of the University of Nebraska at Kearney as well as some related source material and campus publications. Users may set up RSS feeds to alert them to new content. \r\nThe site is only available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "name" : "OpenSPACES@UNK (University of Nebraska at Kearney)",
                  "acronym" : "UNK",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 03:04:44",
            "date_modified" : "2019-10-30 09:48:27",
            "id" : 7425,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7425"
         },
         "organisation" : {
            "location" : {
               "latitude" : 34.88,
               "longitude" : 135.42
            },
            "url" : "https://www.osaka-aoyama.ac.jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Osaka Aoyama University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "大阪青山大学",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "ja"
            ],
            "oai_url" : "https://osaka-aoyama.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "10"
            ],
            "url" : "https://osaka-aoyama.repo.nii.ac.jp",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of Osaka Aoyama University in Japan   The interface is available in Japanese and English.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Osaka Aoyama University Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "大阪青山大学学術情報リポジトリ"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7424",
            "publicly_visible" : "yes",
            "id" : 7424,
            "date_modified" : "2019-11-18 09:00:18",
            "date_created" : "2019-09-28 03:04:42"
         },
         "organisation" : {
            "url" : "https://www.chiyoda.ac.jp/",
            "location" : {
               "longitude" : 135.549,
               "latitude" : 34.4454
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka Chiyoda Junior College"
               },
               {
                  "name" : "大阪千代田短期大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka Chiyoda Junior College Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "name" : "大阪千代田短期大学リポジトリ"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://chiyoda.repo.nii.ac.jp/oai",
            "url" : "https://chiyoda.repo.nii.ac.jp",
            "content_subjects" : [
               "23"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_subjects_phrases" : [
               {
                  "value" : "23",
                  "language" : "en",
                  "phrase" : "Social Sciences General"
               }
            ],
            "description" : "This site allows access to the research output of Osaka Chiyoda Junior College. The interface is available in English or Japanese but all text are Japanese only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Osaka Christian College Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "大阪キリスト教短期大学リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of Osaka Christian College. The interface is available in English or Japanese. All text is in Japanese only.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://occ.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://occ.repo.nii.ac.jp",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7423",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-21 15:40:50",
            "date_created" : "2019-09-28 03:04:38",
            "id" : 7423
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "location" : {
               "latitude" : 34.6366,
               "longitude" : 135.508
            },
            "url" : "http://www.occ.ac.jp/",
            "country" : "jp",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Osaka Christian College"
               },
               {
                  "name" : "大阪キリスト教短期大学",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "url" : "https://osaka-dent.repo.nii.ac.jp",
            "oai_url" : "https://osaka-dent.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "4"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               }
            ],
            "description" : "This site provides access to the research outputs of Osaka Dental University.  The interface is available in Japanese and English.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka Dental University Academic Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "preferred" : "name",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "大阪歯科大学学術リポジトリ"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Osaka Dental University",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "location" : {
               "latitude" : 34.8586,
               "longitude" : 135.676
            },
            "url" : "https://www.osaka-dent.ac.jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7422",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 03:04:36",
            "date_modified" : "2019-12-09 11:08:06",
            "id" : 7422
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Osaka Electro-Communication University Repository",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "大阪電気通信大学学術リポジトリ"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Osaka University.   The interface is available in Japanese and English.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "url" : "https://oecu.repo.nii.ac.jp",
            "oai_url" : "https://oecu.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "url" : "https://oecu.repo.nii.ac.jp",
            "location" : {
               "latitude" : 34.822,
               "longitude" : 135.522
            },
            "unit" : [
               {
                  "name" : "Electro Communication",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka University",
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "大阪電気通信大学",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7421,
            "date_created" : "2019-09-28 03:04:34",
            "date_modified" : "2019-12-04 08:37:44",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7421"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7420",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "date_created" : "2019-09-28 03:04:31",
            "date_modified" : "2019-11-27 08:41:17",
            "id" : 7420,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka Gakuin University"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja",
                  "name" : "大阪学院大学"
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "location" : {
               "latitude" : 34.7732,
               "longitude" : 135.542
            },
            "url" : "https://www.osaka-gu.ac.jp/"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka Gakuin University Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "name" : "大阪学院大学学術機関リポジトリ"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "oai_url" : "https://ogu.repo.nii.ac.jp/oai",
            "url" : "https://ogu.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of Osaka Gakuin University. The interface is available in English or Japanese but all content is Japanese only.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "name" : "Osaka Institute of Technology",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "http://www.oit.ac.jp",
            "location" : {
               "longitude" : 135.542,
               "latitude" : 34.7306
            },
            "country" : "jp"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7419,
            "date_created" : "2019-09-28 03:04:29",
            "date_modified" : "2019-11-13 11:57:12",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7419"
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Manabu Surgery. The interface is available in English and Japanese.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "oai_url" : "https://oit.repo.nii.ac.jp/oai",
            "url" : "https://oit.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Manabu surgery institutional repository"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "学術機関リポジトリ"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of Osaka International University. The interface is available in Japanese or English, all content is Japanese.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "oai_url" : "https://oiu.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://oiu.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka International University & Osaka International College Repository"
               },
               {
                  "name" : "大阪国際大学 大阪国際大学短期大学部リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "url" : "https://www.oiu.ac.jp/",
            "location" : {
               "longitude" : 135.604,
               "latitude" : 34.7474
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka International University"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "name" : "大阪国際大学"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7418",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 03:04:26",
            "date_modified" : "2019-12-02 10:46:02",
            "id" : 7418
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "oai_url" : "https://osaka-ohtani.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://osaka-ohtani.repo.nii.ac.jp",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Osaka Ohtani University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka Ohtani University Library Intelligence Valuable Entrance Institutional Repositories"
               },
               {
                  "name" : "飯田女子短期大学リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "https://www.osaka-ohtani.ac.jp",
            "location" : {
               "latitude" : 34.4825,
               "longitude" : 135.581
            },
            "country" : "jp",
            "name" : [
               {
                  "name" : "Osaka Ohtani University"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7417",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-11-19 14:34:53",
            "date_created" : "2019-09-28 03:04:23",
            "id" : 7417,
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka Sangyo University"
               },
               {
                  "name" : "大阪産業大学",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "country" : "jp",
            "url" : "https://www.osaka-sandai.ac.jp",
            "location" : {
               "longitude" : 135.641,
               "latitude" : 34.7079
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ]
         },
         "system_metadata" : {
            "id" : 7416,
            "date_created" : "2019-09-28 03:04:21",
            "date_modified" : "2019-11-26 12:20:08",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7416",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka Sangyo University Repository"
               },
               {
                  "name" : "大阪産業大学リポジトリ",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               }
            ],
            "description" : "This site provides access to the research outputs of the Osaka Sangyo University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://osu.repo.nii.ac.jp/oai",
            "url" : "https://osu.repo.nii.ac.jp",
            "content_subjects" : [
               "8"
            ],
            "content_languages" : [
               "ja"
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://osaka-shoin.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "23"
            ],
            "url" : "https://osaka-shoin.repo.nii.ac.jp",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Osaka Shoin Women's University. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka Shoin Women's University Repository"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "大阪樟蔭女子大学リポジトリ"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Osaka Shoin Women Repository"
               }
            ],
            "url" : "https://www.osaka-shoin.ac.jp",
            "location" : {
               "latitude" : 34.6631,
               "longitude" : 135.577
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7415",
            "publicly_visible" : "yes",
            "id" : 7415,
            "date_modified" : "2019-11-06 10:54:26",
            "date_created" : "2019-09-28 03:04:19"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka University of Commerce Repository"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "大阪商業大学学術情報リポジトリ"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://ouc.repo.nii.ac.jp",
            "content_subjects" : [
               "24"
            ],
            "oai_url" : "https://ouc.repo.nii.ac.jp/oai",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Osaka University of Commerce. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "24",
                  "language" : "en",
                  "phrase" : "Business and Economics"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7413,
            "date_modified" : "2019-12-03 10:25:48",
            "date_created" : "2019-09-28 03:04:13",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7413"
         },
         "organisation" : {
            "country" : "jp",
            "location" : {
               "latitude" : 34.6754,
               "longitude" : 135.573
            },
            "url" : "https://ouc.daishodai.ac.jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka University of Commerce",
                  "acronym" : "OUC",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7412",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 03:04:11",
            "date_modified" : "2019-11-11 14:02:20",
            "id" : 7412,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "longitude" : 135.539,
               "latitude" : 34.6105
            },
            "url" : "http://www.jonan.ac.jp/?_ga=2.141034484.714096384.1573480542-917268100.1573480542",
            "country" : "jp",
            "name" : [
               {
                  "name" : "Osaka University of Comprehensive Children Education and Osaka Jonan Women’s Junior College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "大阪総合保育大学 ' 大阪城南女子短期大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "ja"
            ],
            "oai_url" : "https://jonan.repo.nii.ac.jp/oai",
            "url" : "https://jonan.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Learning Objects",
                  "value" : "learning_objects",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "learning_objects"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka University of Comprehensive Children Education and Osaka Jonan Women’s Junior College Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "/ 大阪総合保育大学 大阪城南女子短期大学リポジトリ"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 03:04:08",
            "date_modified" : "2019-10-31 09:05:17",
            "id" : 7411,
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7411"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "url" : "https://www.oups.ac.jp",
            "location" : {
               "longitude" : 135.574,
               "latitude" : 34.8636
            },
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Osaka Pharmaceutical University Library"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka University of Pharmaceutical Sciences"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "value" : "disciplinary",
                  "language" : "en",
                  "phrase" : "Disciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Osaka University of Pharmaceutical Sciences . The interface is available in English and Japanese.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "url" : "https://oups.repo.nii.ac.jp",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "https://oups.repo.nii.ac.jp/oai",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "disciplinary",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka University of Pharmaceutical Sciences Knowledge Archive"
               },
               {
                  "language" : "jv",
                  "language_phrases" : [
                     {
                        "value" : "jv",
                        "language" : "en",
                        "phrase" : "Javanese"
                     }
                  ],
                  "name" : "大阪薬科大学学術情報リポジトリ"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Osaka University of Tourism Academic Repository"
               },
               {
                  "name" : "大阪観光大学学術リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "23",
                  "phrase" : "Social Sciences General"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Osaka University of Tourism in Japan. The interface is available in Japanese and English.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "23"
            ],
            "oai_url" : "https://tourism.repo.nii.ac.jp/oai",
            "url" : "https://tourism.repo.nii.ac.jp",
            "content_languages" : [
               "en",
               "ja"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7410",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "id" : 7410,
            "date_modified" : "2019-10-30 09:32:24",
            "date_created" : "2019-09-28 03:04:06",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "name" : "Osaka University of Tourism",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "ja",
                  "name" : "大阪観光大学",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 34.393,
               "longitude" : 135.339
            },
            "url" : "https://www.tourism.ac.jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7407",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 7407,
            "date_modified" : "2019-12-09 10:50:45",
            "date_created" : "2019-09-28 03:03:36",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "University of Otago",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "nz",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "nz",
                  "phrase" : "New Zealand"
               }
            ],
            "url" : "https://www.otago.ac.nz",
            "location" : {
               "latitude" : -45.8655,
               "longitude" : 170.514
            }
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Otago University Research Archive",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "https://ourarchive.otago.ac.nz",
            "oai_url" : "https://ourarchive.otago.ac.nz/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Otago.  The interface is available in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.1",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "Otani University Academic Repository",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "大谷大学学術情報リポジトリ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://otani.repo.nii.ac.jp/oai",
            "url" : "https://otani.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 35.0429,
               "longitude" : 135.758
            },
            "url" : "http://www.otani.ac.jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Otani University"
               },
               {
                  "name" : "大谷大学"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7406",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 03:03:33",
            "date_modified" : "2019-12-04 08:35:47",
            "id" : 7406
         }
      },
      {
         "organisation" : {
            "country" : "us",
            "location" : {
               "latitude" : 40.1994,
               "longitude" : -77.1973
            },
            "url" : "https://dickinsonlaw.psu.edu",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "name" : "PennState Dickinson Law",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7372",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-19 14:16:40",
            "date_created" : "2019-09-28 03:00:08",
            "id" : 7372
         },
         "repository_metadata" : {
            "name" : [
               {
                  "acronym" : "Dickinson Law IDEAS",
                  "name" : "Dickinson Law Inspire Digital Engagement, Archives and Scholarship",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ],
               "name" : "bepress"
            },
            "description" : "This site provides access to the research outputs of the Penn State Dickinson Law. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://ideas.dickinsonlaw.psu.edu/do/oai",
            "content_subjects" : [
               "26"
            ],
            "url" : "https://ideas.dickinsonlaw.psu.edu",
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "repository_metadata" : {
            "url" : "https://elibrary.law.psu.edu",
            "content_subjects" : [
               "26"
            ],
            "oai_url" : "https://elibrary.law.psu.edu/do/oai",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Penn State Law. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "PennState Law eLibrary"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Penn State Law"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -79.8739,
               "latitude" : 40.8601
            },
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "H.Laddie Montague, Jr. Law Library"
               }
            ],
            "url" : "https://law.psu.edu",
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-26 11:58:02",
            "date_created" : "2019-09-28 03:00:07",
            "id" : 7371,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7371"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "DigitalCommons@PCOM",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "https://digitalcommons.pcom.edu/do/oai",
            "url" : "https://digitalcommons.pcom.edu",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the PCOM (Philadelphia College of Osteopathic Medicine). Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://www.pcom.edu",
            "location" : {
               "latitude" : 40.005,
               "longitude" : -75.217
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "name" : [
               {
                  "name" : "Philadelphia College of Osteopathic Medicine",
                  "acronym" : "PCOM",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7351",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-17 15:14:04",
            "date_created" : "2019-09-28 02:59:14",
            "id" : 7351
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Plymouth Marjon University Repository (CREST)"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://marjon.collections.crest.ac.uk",
            "oai_url" : "https://marjon.collections.crest.ac.uk/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of Plymouth Marjon university. The interface and articles are in English only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "version" : "3.3.16",
               "name" : "eprints"
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:58:42",
            "date_modified" : "2019-11-11 13:41:31",
            "id" : 7337,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7337",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "plymouth marjon university",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country_phrases" : [
               {
                  "value" : "gb",
                  "language" : "en",
                  "phrase" : "United Kingdom"
               }
            ],
            "location" : {
               "longitude" : -4.1104,
               "latitude" : 50.4196
            },
            "url" : "https://www.marjon.ac.uk/",
            "country" : "gb"
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "description" : "The Polar Data Catalogue is a repository of diverse open access data sets as well as metadata generated by Arctic and Antarctic researchers. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Earth and Planetary Sciences",
                  "value" : "6",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://www.polardata.ca",
            "oai_url" : "http://www.polardata.ca/oai/provider",
            "content_subjects" : [
               "6"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Polar Data Catalogue"
               }
            ],
            "content_types" : [
               "datasets"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-10-30 09:14:29",
            "date_created" : "2019-09-28 02:58:27",
            "id" : 7335,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7335",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "language" : "en",
                  "value" : "ca"
               }
            ],
            "url" : "https://www.ccin.ca",
            "location" : {
               "longitude" : -80.54,
               "latitude" : 43.46
            },
            "country" : "ca",
            "name" : [
               {
                  "preferred" : "acronym",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "language" : "en",
                        "value" : "acronym"
                     }
                  ],
                  "name" : "Canadian Cryospheric Information Network",
                  "acronym" : "CCIN"
               },
               {
                  "name" : "University of Waterloo - Canada",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "id"
            ],
            "url" : "http://repository.nscpolteksby.ac.id",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.nscpolteksby.ac.id/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Polytechnic NSC Surabaya. The interface is available in Indonesian.",
            "software" : {
               "version" : "3.3.15",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "value" : "id",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Politeknik NSC Repository"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-13 11:37:37",
            "date_created" : "2019-09-28 02:57:52",
            "id" : 7329,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7329",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "ax",
            "url" : "https://en.nscpolteksby.ac.id",
            "location" : {
               "longitude" : 112.74,
               "latitude" : -7.2682
            },
            "country_phrases" : [
               {
                  "value" : "ax",
                  "language" : "en",
                  "phrase" : "Aland Islands"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Polytechnic NSC Surabaya"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "id",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "language" : "id",
                  "name" : "Politeknik NSC Surabaya"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site allows access to the research output of the Pontifical Catholic University of Chile: UC Repository. The interface is available in Spanish only but some of the articles are in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "8",
                  "language" : "en",
                  "phrase" : "Mathematics and Statistics"
               },
               {
                  "language" : "en",
                  "value" : "9",
                  "phrase" : "Physics and Astronomy"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "version" : "6.2",
               "name" : "dspace"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en",
               "es"
            ],
            "url" : "http://repositorio.uc.cl",
            "oai_url" : "http://repositorio.uc.cl/oai/openaire",
            "content_subjects" : [
               "8",
               "9"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Pontifical Catholic University of Chile: UC Repository"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "name" : "Pontificia Universidad Católica de Chile: Repositorio UC"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-11 13:16:26",
            "date_created" : "2019-09-28 02:57:18",
            "id" : 7322,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7322",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.uc.cl/",
            "location" : {
               "longitude" : -70.64,
               "latitude" : -33.442
            },
            "country_phrases" : [
               {
                  "phrase" : "Chile",
                  "language" : "en",
                  "value" : "cl"
               }
            ],
            "country" : "cl",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Pontifical Catholic University of Chile"
               },
               {
                  "name" : "Pontificia Universidad Católica de Chile"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site is a repository maintained by the Population Council based in New York, USA and provides open access to the research output of that organisation to facilitate evidence-based approaches to solving population development challenges. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://knowledgecommons.popcouncil.org",
            "content_subjects" : [
               "23"
            ],
            "oai_url" : "https://knowledgecommons.popcouncil.org/do/oai/",
            "name" : [
               {
                  "name" : "Population Council Knowledge Commons",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "The Population Council",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               }
            ],
            "location" : {
               "longitude" : -73.968,
               "latitude" : 40.752
            },
            "url" : "https://www.popcouncil.org",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:57:12",
            "date_modified" : "2019-12-04 12:27:39",
            "id" : 7320,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7320",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7235",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-06 10:44:40",
            "date_created" : "2019-09-28 02:51:48",
            "id" : 7235
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Portland Public Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "url" : "https://www.portlandlibrary.com",
            "location" : {
               "longitude" : -70.2591,
               "latitude" : 43.6577
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Portland Public Library: Digital Commons",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Digital Commons",
                     "language" : "en",
                     "value" : "digital_commons"
                  }
               ],
               "name" : "digital_commons"
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Portland Public Library. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "https://digitalcommons.portlandlibrary.com",
            "oai_url" : "https://digitalcommons.portlandlibrary.com/do/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7224",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 02:51:16",
            "date_modified" : "2019-12-05 14:02:37",
            "id" : 7224,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "url" : "https://www.proquest.com",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "ProQuest"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [],
               "version" : "ProQuest"
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Aggregating",
                  "value" : "aggregating",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to full text of open access dissertations and theses. The interface is available in English, Portuguese, German, French. Tueky, Italian, Turkish, Spanish, Chinese, Japanese.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://pqdtoai.proquest.com/OAIHandler",
            "url" : "https://pqdtopen.proquest.com",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "PQDT Open",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "type" : "aggregating",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Catholic University of Cordoba",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universidad Católica de Córdoba",
                  "acronym" : "UCC",
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "country" : "es",
            "url" : "https://www.uccor.edu.ar",
            "location" : {
               "latitude" : -31.4191,
               "longitude" : -64.1869
            },
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-09 10:26:18",
            "date_created" : "2019-09-28 02:50:31",
            "id" : 7212,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7212",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://pa.bibdigital.uccor.edu.ar/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://pa.bibdigital.uccor.edu.ar",
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.16"
            },
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Catholic University of Córdoba. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Academic Production",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Producción Académica",
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.nlm.nih.gov",
            "location" : {
               "longitude" : -77.0988,
               "latitude" : 38.9959
            },
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "NLM",
                  "name" : "NIH U.S. National Library of Medicine"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7209",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 7209,
            "date_created" : "2019-09-28 02:50:15",
            "date_modified" : "2019-11-13 10:28:19",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Profiles in Science",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Health and Medicine",
                  "value" : "10",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of various scientists. The interface is available in English.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            },
            "url" : "http://profiles.nlm.nih.gov",
            "content_subjects" : [
               "10"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "longitude" : -76.6168,
               "latitude" : 39.321
            },
            "url" : "https://muse.jhu.edu/",
            "country" : "us",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "MUSE"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7208",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:50:12",
            "date_modified" : "2019-12-02 10:27:54",
            "id" : 7208
         },
         "repository_metadata" : {
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "aggregating",
                  "phrase" : "Aggregating"
               }
            ],
            "description" : "This site allows access to several journal publications and book collections brought together under project MUSE.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "http://muse.jhu.edu",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://muse.jhu.edu/oai",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Project MUSE"
               }
            ],
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "type" : "aggregating",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Providence St. Joseph Health"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.psjhealth.org",
            "country" : "us"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7205,
            "date_modified" : "2019-12-04 12:27:39",
            "date_created" : "2019-09-28 02:50:02",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7205"
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Providence St. Joseph Health Digital Commons",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "description" : "This site provides access to the research outputs of Providence St. Joseph Health. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "10",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "https://digitalcommons.psjhealth.org",
            "content_subjects" : [
               "10"
            ],
            "oai_url" : "https://digitalcommons.psjhealth.org/do/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "acronym" : "QUT",
                  "name" : "Queensland University of Technology: QUT Digital Collections",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://digitalcollections.qut.edu.au/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcollections.qut.edu.au",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the digital works collected by the Queensland University of Technology. It includes graduate art work collections and selected student publications as well as a more detailed collection of academic work on the sugar industry. \r\nInterface and articles are available in English only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3.3.15",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:46:57",
            "date_modified" : "2019-11-18 08:49:59",
            "id" : 7169,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7169",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.qut.edu.au/",
            "location" : {
               "latitude" : -27.4775,
               "longitude" : 153.028
            },
            "country_phrases" : [
               {
                  "value" : "au",
                  "language" : "en",
                  "phrase" : "Australia"
               }
            ],
            "country" : "au",
            "name" : [
               {
                  "acronym" : "QUT",
                  "name" : "Queensland University of Technology"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Queen’s University Belfast: Special Collections & Archives"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site allows access to the special collections housed at Queen’s University Belfast. The interface is in several languages and the texts are in a mixture of modern or ancient languages.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "value" : "contentdm",
                     "language" : "en"
                  }
               ],
               "name" : "contentdm"
            },
            "url" : "https://cdm15979.contentdm.oclc.org",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://cdm15979.contentdm.oclc.org/oai/oai.php",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7168",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-21 15:16:24",
            "date_created" : "2019-09-28 02:46:50",
            "id" : 7168
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Queen's University Belfast",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "location" : {
               "longitude" : -5.934,
               "latitude" : 54.5842
            },
            "url" : "https://www.qub.ac.uk/",
            "country" : "gb"
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "https://racimo.usal.edu.ar",
            "oai_url" : "https://racimo.usal.edu.ar/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "version" : "3.3.15",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Universidad del Salvador. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "name" : "RACIMO - Repositorio Institucional",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional"
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7164",
            "publicly_visible" : "yes",
            "id" : 7164,
            "date_created" : "2019-09-28 02:46:25",
            "date_modified" : "2019-11-13 10:14:13"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "acronym" : "USAL",
                  "name" : "Universidad del Salvador"
               }
            ],
            "country" : "ar",
            "location" : {
               "latitude" : -34.5996,
               "longitude" : -58.3929
            },
            "url" : "http://movil.usal.edu.ar",
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "br",
            "location" : {
               "longitude" : -51.1523,
               "latitude" : -29.7945
            },
            "url" : "http://www.unisinos.br/",
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ],
            "name" : [
               {
                  "name" : "University of the Rio dos Sinos Valley",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Universidade do Vale do Rio dos Sinos",
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "pt",
                        "phrase" : "Portuguese"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:46:22",
            "date_modified" : "2019-12-02 10:14:50",
            "id" : 7163,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7163"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "language" : "en",
                  "value" : "pt"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "name" : [
               {
                  "name" : "RBDU RepositÃ³rio Digital da Biblioteca da Unisinos",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://www.repositorio.jesuita.org.br",
            "oai_url" : "http://www.repositorio.jesuita.org.br/oai/request",
            "software" : {
               "name" : "dspace",
               "version" : "4.1",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site allows access to the student research output of the University of the Rio dos Sinos Valley. The interface is available in English, Portuguese or Spanish, all content is Portuguese only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "aggregating",
            "name" : [
               {
                  "acronym" : "RCAAP",
                  "name" : "Repositórios Científicos de Acesso Aberto de Portugal",
                  "language_phrases" : [
                     {
                        "value" : "pt",
                        "language" : "en",
                        "phrase" : "Portuguese"
                     }
                  ],
                  "language" : "pt"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "aggregating",
                  "language" : "en",
                  "phrase" : "Aggregating"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs from Portuguese Institutional  Repositories. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Portuguese.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "pt"
            ],
            "oai_url" : "https://www.rcaap.pt/oai/openaire",
            "url" : "https://www.rcaap.pt",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:46:11",
            "date_modified" : "2019-11-06 10:21:07",
            "id" : 7160,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7160"
         },
         "organisation" : {
            "country" : "pt",
            "url" : "https://www.rcaap.pt",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ],
                  "language" : "pt",
                  "name" : "Repositórios Científicos de Acesso Aberto de Portugal"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "name" : "Federal University of Rio Grande",
                  "acronym" : "RI FURG",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "language" : "pt",
                  "name" : "Universidade Federal do Rio Grande"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "pt"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://200.19.254.174/oai/request",
            "url" : "http://200.19.254.174",
            "software" : {
               "version" : "3.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site allows access to the research output of the Federal University of Rio Grande. The interface and most texts are available in Portuguese only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "https://www.furg.br/en/",
            "location" : {
               "latitude" : -32.0688,
               "longitude" : -52.1616
            },
            "country" : "br",
            "name" : [
               {
                  "name" : "Federal University of Rio Grande"
               },
               {
                  "name" : "Universidade Federal do Rio Grande"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:45:43",
            "date_modified" : "2019-11-15 13:49:00",
            "id" : 7154,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7154",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 135.779,
               "latitude" : 35.0262
            },
            "url" : "http://www.kurims.kyoto-u.ac.jp",
            "country" : "jp",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Kyoto University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "京都大学"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7151,
            "date_modified" : "2019-12-04 08:34:12",
            "date_created" : "2019-09-28 02:45:32",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7151"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://ismrepo.ism.ac.jp",
            "content_subjects" : [
               "8"
            ],
            "oai_url" : "https://ismrepo.ism.ac.jp/oai",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of Kyoto University.  The interface is available in Japanese and English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "8",
                  "phrase" : "Mathematics and Statistics"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Software",
                  "value" : "software",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "RISM",
                  "name" : "RISM (Repository of the Institute of Statistical Mathematics)"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "ja",
                  "name" : "統計数理研究所 学術研究リポジトリ",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "software"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "id" : 7149,
            "date_created" : "2019-09-28 02:45:06",
            "date_modified" : "2019-12-04 12:27:39",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7149",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : -22.9041,
               "longitude" : -43.1166
            },
            "url" : "http://www.uff.br",
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ],
            "country" : "br",
            "name" : [
               {
                  "acronym" : "UFF",
                  "name" : "Universidade Federal Fluminense",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ],
                  "language" : "pt"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections",
               "learning_objects",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "acronym" : "RIUFF",
                  "name" : "Repositório Institucional da Universidade Federal Fluminense",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ],
                  "language" : "pt"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidade Federal Fluminense. The interface is available in English, Spanish and Portuguese.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "5.7",
               "name" : "dspace"
            },
            "oai_url" : "https://app.uff.br/oai/request",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://app.uff.br",
            "content_languages" : [
               "pt"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "an",
                  "language" : "en",
                  "phrase" : "Aragonese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_types" : [
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Raden Intan Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "an"
            ],
            "oai_url" : "http://repository.radenintan.ac.id/cgi/oai2",
            "url" : "http://repository.radenintan.ac.id",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the UIN Raden Intan. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Indonesian.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3.3.15",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universitas Islam Negeri Raden Intan Lampung",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "country" : "id",
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "url" : "https://www.radenintan.ac.id",
            "location" : {
               "longitude" : 105.304,
               "latitude" : -5.3809
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7146",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:44:50",
            "date_modified" : "2019-11-26 11:35:09",
            "id" : 7146
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Rare & Special e-Zone",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site allows access to the special collections of the Hong Kong university of Science and Technology. The interface is in English and the text are in a mixture of modern to ancient languages.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "version" : "5.2.2",
               "name" : "other",
               "name_phrases" : [
                  {
                     "phrase" : "Other",
                     "value" : "other",
                     "language" : "en"
                  }
               ],
               "name_other" : "WordPress"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "http://lbezone.ust.hk",
            "oai_url" : "http://lbezone.ust.hk/rse/OAI/Server",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Hong Kong university of Science and Technology",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : 114.265,
               "latitude" : 22.3355
            },
            "url" : "https://www.ust.hk/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "hk",
                  "phrase" : "Hong Kong"
               }
            ],
            "country" : "hk"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7138",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 02:44:19",
            "date_modified" : "2019-11-21 15:00:39",
            "id" : 7138,
            "publicly_visible" : "yes"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Reitaku University Academic Repository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "麗澤大学学術リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja",
                  "preferred" : "name"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://reitaku.repo.nii.ac.jp",
            "oai_url" : "https://reitaku.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Reitaku University. The interface is available in English and Japanese.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7122,
            "date_modified" : "2019-12-09 09:37:41",
            "date_created" : "2019-09-28 02:43:31",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7122"
         },
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Reitaku University",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "location" : {
               "latitude" : 35.833,
               "longitude" : 139.955
            },
            "url" : "https://www.reitaku-u.ac.jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp"
         }
      },
      {
         "system_metadata" : {
            "id" : 7115,
            "date_modified" : "2019-11-06 10:11:03",
            "date_created" : "2019-09-28 02:43:00",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7115",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Muria Kudus University"
               },
               {
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "id",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "name" : "Universitas Muria Kudus"
               }
            ],
            "country" : "id",
            "url" : "https://umk.ac.id",
            "location" : {
               "longitude" : 110.864,
               "latitude" : -6.7837
            },
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "id"
            ],
            "url" : "http://eprints.umk.ac.id",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://eprints.umk.ac.id/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Muria Kudus University. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Indonesian.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.15"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Repositori Universitas Muria Kudus"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "acronym" : "CUDI",
                  "name" : "University Corporation for Internet Development",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "acronym" : "CUDI",
                  "name" : "Corporación Universitaria para el Desarrollo de Internet",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "es"
               }
            ],
            "url" : "http://virtual.cudi.edu.mx",
            "country_phrases" : [
               {
                  "phrase" : "Mexico",
                  "language" : "en",
                  "value" : "mx"
               }
            ],
            "country" : "mx"
         },
         "system_metadata" : {
            "id" : 7110,
            "date_created" : "2019-09-28 02:42:42",
            "date_modified" : "2019-12-04 12:27:39",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7110",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               },
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "CUDI Respository",
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "CUDI Repositorio",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "es"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.cudi.edu.mx/oai/openaire",
            "url" : "http://repositorio.cudi.edu.mx",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "4.2"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site is a repository operated by The University Corporation for Internet Development (CUDI) which is  a non-profit organisation that manages the National Research and Education Network in Mexico. This repository contains videos that reflect the activities of its communities and technical groups and includes video conferences, virtual events &\r\nCUDI meetings.The interface is available in English, Spanish, German and French."
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Repositorio Digital Institutional Universidad Nacional del Comahue (RDI UNCo)"
               }
            ],
            "content_languages" : [
               "es"
            ],
            "url" : "http://rdi.uncoma.edu.ar",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://rdi.uncoma.edu.ar/oai/openaire",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site allows access to the research output of the National University of Comahue. The interface is available in English or Spanish but content is in Spanish only.",
            "software" : {
               "version" : "6.3",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "National University of Comahue"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Argentina",
                  "language" : "en",
                  "value" : "ar"
               }
            ],
            "location" : {
               "longitude" : -68.0575,
               "latitude" : -38.9405
            },
            "url" : "https://www.uncoma.edu.ar/",
            "country" : "ar"
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:42:16",
            "date_modified" : "2019-11-21 14:44:45",
            "id" : 7108,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7108"
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Humboldt Institutional Repository",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Repositorio Institucional Humboldt",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ],
            "content_languages" : [
               "es"
            ],
            "content_subjects" : [
               "4",
               "6",
               "7"
            ],
            "oai_url" : "http://repository.humboldt.org.co/oai/openaire",
            "url" : "http://repository.humboldt.org.co",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "4",
                  "phrase" : "Biology and Biochemistry"
               },
               {
                  "phrase" : "Earth and Planetary Sciences",
                  "language" : "en",
                  "value" : "6"
               },
               {
                  "value" : "7",
                  "language" : "en",
                  "phrase" : "Ecology and Environment"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Alexander von Humboldt Biological Resources Research Institute. The interface is available in English and Spanish.",
            "software" : {
               "name_phrases" : []
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "url" : "http://www.humboldt.org.co/es",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spain"
               }
            ],
            "country" : "es",
            "name" : [
               {
                  "name" : "Alexander von Humboldt Biological Resources Research Institute",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Instituto de Investigación de Recursos Biológicos Alexander von Humboldt"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7096",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:41:05",
            "date_modified" : "2019-12-17 15:09:28",
            "id" : 7096
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://repositorio.umch.edu.pe/oai/openaire",
            "url" : "http://repositorio.umch.edu.pe",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "5.7"
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the student works of the Marcelino Champagnat University. Both interface and text are in Spanish only.",
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "name" : "UMCH Institutional Repository (Marcelino Champagnat University)",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es",
                  "name" : "Repositorio Institucional UMCH (Universidad Marcelino Champagnat)"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7094,
            "date_modified" : "2019-11-15 13:38:34",
            "date_created" : "2019-09-28 02:40:51",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7094"
         },
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "url" : "https://umch.edu.pe/",
            "location" : {
               "longitude" : -77.0057,
               "latitude" : -12.1364
            },
            "name" : [
               {
                  "name" : "Marcelino Champagnat Private University",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Universidad Privada Marcelino Champagnat",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7086,
            "date_modified" : "2019-11-26 11:17:24",
            "date_created" : "2019-09-28 02:39:40",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7086"
         },
         "organisation" : {
            "country" : "ec",
            "url" : "https://www.puce.edu.ec",
            "location" : {
               "longitude" : -78.4913,
               "latitude" : -0.21
            },
            "country_phrases" : [
               {
                  "value" : "ec",
                  "language" : "en",
                  "phrase" : "Ecuador"
               }
            ],
            "name" : [
               {
                  "name" : "Pontificia Universidad Católica del Ecuador",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Pontificia Universidad Católica del Ecuador. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.\r\n\r\n( Sede Ambato)",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://repositorio.pucesa.edu.ec",
            "oai_url" : "http://repositorio.pucesa.edu.ec/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio PUCESA"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "co",
            "country_phrases" : [
               {
                  "phrase" : "Colombia",
                  "language" : "en",
                  "value" : "co"
               }
            ],
            "url" : "https://www.udes.edu.co",
            "location" : {
               "latitude" : 7.1056,
               "longitude" : -73.1301
            },
            "name" : [
               {
                  "acronym" : "UDES",
                  "name" : "Universidad de Santander",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "language" : "en",
                        "value" : "es"
                     }
                  ],
                  "language" : "es",
                  "preferred" : "acronym"
               }
            ]
         },
         "system_metadata" : {
            "id" : 7085,
            "date_modified" : "2019-11-06 09:57:10",
            "date_created" : "2019-09-28 02:39:39",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7085",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Universidad de Santander. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "software" : {
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "es"
            ],
            "oai_url" : "https://repositorio.udes.edu.co/oai/openaire",
            "url" : "https://repositorio.udes.edu.co",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repositorio Universidad de Santander",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "language" : "en",
                  "value" : "es"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "es",
            "country_phrases" : [
               {
                  "phrase" : "Spain",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "unit" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Institute of Social Research"
               },
               {
                  "name" : "Instituto de Investigaciones Sociales",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "location" : {
               "latitude" : 19.3288,
               "longitude" : -99.1872
            },
            "url" : "https://www.unam.mx",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "National Autonomous University of Mexico"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad Nacional Autónoma de México"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7081",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-17 15:07:25",
            "date_created" : "2019-09-28 02:39:08",
            "id" : 7081
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Digital University Repository Institute of Social Research"
               },
               {
                  "name" : "Repositorio Universitario Digital Instituto de Investigaciones Sociales",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "es",
                  "language" : "en",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "description" : "This site provides access to the research outputs of Institute of Social Research. The interface is available in English and Spanish.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "dspace",
                     "language" : "en",
                     "phrase" : "DSpace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.2"
            },
            "oai_url" : "http://ru.iis.sociales.unam.mx/oai/openaire",
            "url" : "http://ru.iis.sociales.unam.mx",
            "content_subjects" : [
               "23"
            ],
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "pe",
            "country_phrases" : [
               {
                  "value" : "pe",
                  "language" : "en",
                  "phrase" : "Peru"
               }
            ],
            "url" : "https://www.esup.edu.pe/index.html",
            "location" : {
               "longitude" : -77.165,
               "latitude" : -12.0706
            },
            "name" : [
               {
                  "name" : "Naval War Superior School",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "name" : "Escuela Superior de Guerra Naval",
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-21 14:32:15",
            "date_created" : "2019-09-28 02:38:54",
            "id" : 7078,
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7078"
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "version" : "4.2",
               "name" : "dspace"
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "26",
                  "language" : "en",
                  "phrase" : "Law and Politics"
               },
               {
                  "value" : "11",
                  "language" : "en",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site allows access to the research output of the Naval War Superior School. The interface is available in English or Spanish. All content is Spanish only.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "26",
               "11"
            ],
            "url" : "http://virtual.esup.edu.pe",
            "oai_url" : "http://virtual.esup.edu.pe/oai/openaire",
            "content_languages" : [
               "es"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Repositorio de la Escuela Superior de Guerra Naval (RIESUP)"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositorio de la Universidad Privada de Tacna",
                  "acronym" : "UPT",
                  "preferred" : "name",
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "phrase" : "Spanish",
                        "value" : "es",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Repository of the Private University of Tacna",
                  "acronym" : "UPT",
                  "preferred" : "name"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Repository of the Private University of Tacna (UPT). Users may set up RSS feeds to be alerted to new content. The interface is available in Spanish.",
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.4",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "url" : "http://repositorio.upt.edu.pe",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repositorio.upt.edu.pe/oai/openaire",
            "content_languages" : [
               "es"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:38:38",
            "date_modified" : "2019-11-13 09:40:58",
            "id" : 7074,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7074",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad Privada de Tacna"
               },
               {
                  "name" : "Private University of Tacna",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ],
            "url" : "http://www.upt.edu.pe",
            "location" : {
               "latitude" : -18.0058,
               "longitude" : -70.2254
            },
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "language" : "en",
                  "value" : "pe"
               }
            ],
            "country" : "pe"
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "es"
            ],
            "oai_url" : "http://repositorio.autonomadeica.edu.pe/oai/openaire",
            "url" : "http://repositorio.autonomadeica.edu.pe",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the University of Ica. The interface is available in English and Spanish.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "es",
                  "phrase" : "Spanish"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Institutional Repository University of Ica",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "es",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "es",
                        "phrase" : "Spanish"
                     }
                  ],
                  "name" : "Repositorio institucional Universidad Autónoma de Ica"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "longitude" : -76.1286,
               "latitude" : -13.4156
            },
            "url" : "https://autonomadeica.edu.pe",
            "country_phrases" : [
               {
                  "phrase" : "Peru",
                  "value" : "pe",
                  "language" : "en"
               }
            ],
            "country" : "pe",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "University of Ica"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "es",
                        "language" : "en",
                        "phrase" : "Spanish"
                     }
                  ],
                  "language" : "es",
                  "name" : "Universidad Autonoma de Ica"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-26 10:56:24",
            "date_created" : "2019-09-28 02:38:19",
            "id" : 7071,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7071",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "acronym" : "IAIN",
                  "name" : "Repository Institut Agama Islam Negeri Bukittinggi",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Acronym",
                        "value" : "acronym",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site offers access to the research output of the Institut Agama Islam Negeri of Bukittinggi. The interface is in part English but all data is in Indonesian.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ],
               "version" : "3.3.15",
               "name" : "eprints"
            },
            "oai_url" : "http://repo.iainbukittinggi.ac.id/cgi/oai2",
            "url" : "http://repo.iainbukittinggi.ac.id",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "id"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7069,
            "date_created" : "2019-09-28 02:38:03",
            "date_modified" : "2019-11-06 15:12:50",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7069"
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "IAIN",
                  "name" : "Institut Agama Islam Negeri of Bukittinggi"
               }
            ],
            "url" : "http://febi.iainbukittinggi.ac.id/",
            "location" : {
               "longitude" : 100.392,
               "latitude" : -0.2948
            },
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "country" : "id"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Kanjuruhan University Malang"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ],
                  "language" : "id",
                  "name" : "Universitas Kanjuruhan Malang"
               }
            ],
            "country" : "id",
            "country_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesia"
               }
            ],
            "url" : "https://unikama.ac.id"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:37:50",
            "date_modified" : "2019-12-17 15:11:31",
            "id" : 7066,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7066",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en",
               "id"
            ],
            "oai_url" : "http://repository.unikama.ac.id/cgi/oai2",
            "url" : "http://repository.unikama.ac.id",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Kanjuruhan University Malang. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name" : "eprints",
               "version" : "3.3.16",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "phrase" : "Indonesian",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "phrase" : "Patents",
                  "value" : "patents",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "patents",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Repository UNIKAMA",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7065",
            "publicly_visible" : "yes",
            "id" : 7065,
            "date_created" : "2019-09-28 02:37:48",
            "date_modified" : "2019-12-04 12:27:39"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Indonesia",
                  "language" : "en",
                  "value" : "id"
               }
            ],
            "location" : {
               "latitude" : 0.448,
               "longitude" : 101.454
            },
            "url" : "https://uir.ac.id",
            "country" : "id",
            "name" : [
               {
                  "name" : "Islamic University of Riau",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name"
               },
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Universitas Islam Riau",
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "language" : "en",
                        "value" : "id"
                     }
                  ],
                  "language" : "id",
                  "preferred" : "name"
               }
            ]
         },
         "repository_metadata" : {
            "software" : {
               "name" : "eprints",
               "version" : "3.3.16",
               "name_phrases" : [
                  {
                     "value" : "eprints",
                     "language" : "en",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the  Islamic University of Riau. Users may set up RSS feeds to be alerted to new content. The interface is available in Indonesian. Whilst most of the content requires a user login, some datasets and articles are open access.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en",
               "id"
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "http://repository.uir.ac.id/cgi/oai2",
            "url" : "http://repository.uir.ac.id",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "Repository of the Islamic University of Riau"
               },
               {
                  "name" : "Universitas Islam Riau",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ]
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7063,
            "date_created" : "2019-09-28 02:37:44",
            "date_modified" : "2019-11-21 14:00:34",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7063"
         },
         "organisation" : {
            "country" : "id",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "location" : {
               "longitude" : 113.897,
               "latitude" : -2.2173
            },
            "url" : "http://www.upr.ac.id/",
            "name" : [
               {
                  "name" : "University of Palangka Raya",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "value" : "id",
                        "language" : "en"
                     }
                  ],
                  "language" : "id",
                  "name" : "Universitas Palangka Raya"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "http://repository.upr.ac.id/cgi/oai2",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://repository.upr.ac.id",
            "content_languages" : [
               "id"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "3",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site allows access to the research output of Palangka Raya university. The interface is a mix of English and Indonesian but all content is Indonesian only.",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Repository Universitas Palangka Raya"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations"
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 7060,
            "date_created" : "2019-09-28 02:37:37",
            "date_modified" : "2019-11-26 15:16:45",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7060",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Japanese Red Cross Toyota College of Nursing",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "日本赤十字豊田看護大学"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "https://www.rctoyota.ac.jp/",
            "location" : {
               "latitude" : 35.1023,
               "longitude" : 137.119
            },
            "country" : "jp"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Repository of Japanese Red Cross Toyota College of Nursing (HUMANITY)"
               },
               {
                  "name" : "日本赤十字豊田看護大学学術情報リポジトリ",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://rctoyota.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "10"
            ],
            "url" : "https://rctoyota.repo.nii.ac.jp",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "description" : "This site allows access to the research output of the Toyota College of Nursing. The interface is available in Japanese or English but most content is Japanese only.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 7056,
            "date_modified" : "2019-11-26 10:48:02",
            "date_created" : "2019-09-28 02:37:30",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7056"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "FKIP Universitas Langlangbuana",
                  "language" : "id",
                  "language_phrases" : [
                     {
                        "value" : "id",
                        "language" : "en",
                        "phrase" : "Indonesian"
                     }
                  ]
               },
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "FKIP Langlangbuana University"
               }
            ],
            "country" : "id",
            "location" : {
               "longitude" : 107.615,
               "latitude" : -6.9312
            },
            "country_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesia"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Other Special Item Types",
                  "language" : "en",
                  "value" : "other_special_item_types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "id",
                  "language" : "en",
                  "phrase" : "Indonesian"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Indonesian",
                        "value" : "id",
                        "language" : "en"
                     }
                  ],
                  "language" : "id",
                  "name" : "Repositori Skripsi"
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "id"
            ],
            "url" : "http://repository.fkip.unla.ac.id",
            "oai_url" : "http://repository.fkip.unla.ac.id/oai-pmh-repository/request",
            "content_subjects" : [
               "25"
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Omeka",
                     "language" : "en",
                     "value" : "omeka"
                  }
               ],
               "name" : "omeka"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               }
            ],
            "description" : "This site provides access to the research outputs of the FKIP Langlangbuana University. The interface is available in English and Japanese."
         }
      },
      {
         "organisation" : {
            "country" : "de",
            "country_phrases" : [
               {
                  "value" : "de",
                  "language" : "en",
                  "phrase" : "Germany"
               }
            ],
            "location" : {
               "latitude" : 52.453,
               "longitude" : 13.2905
            },
            "url" : "https://www.fu-berlin.de",
            "name" : [
               {
                  "name" : "Freie Universitat Berlin"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-05 16:42:26",
            "date_created" : "2019-09-28 02:37:28",
            "id" : 7055,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7055",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repository: Freie Universität Berlin, Math Department"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site provides access to the research outputs of the  Freie Universität Berlin, Math Department . Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "8",
                  "language" : "en",
                  "phrase" : "Mathematics and Statistics"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.15"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://publications.imp.fu-berlin.de/cgi/oai2",
            "url" : "http://publications.imp.fu-berlin.de",
            "content_subjects" : [
               "8"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "6.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs from the Euripides University Center of Marilia.  The site is in Portuguese only.",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://aberto.univem.edu.br/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://aberto.univem.edu.br",
            "content_languages" : [
               "pt"
            ],
            "name" : [
               {
                  "name" : "Euripides University Center of Marilia",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ]
         },
         "organisation" : {
            "country" : "br",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "br",
                  "phrase" : "Brazil"
               }
            ],
            "location" : {
               "longitude" : -49.9674,
               "latitude" : -22.2318
            },
            "url" : "https://www.univem.edu.br/vestibular",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "The Euripides University Center of Marilia"
               }
            ]
         },
         "system_metadata" : {
            "id" : 7054,
            "date_created" : "2019-09-28 02:37:16",
            "date_modified" : "2019-11-06 14:52:05",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7054",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "acronym" : "UNIFEI",
                  "name" : "Federal University of Itajuba"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "value" : "pt",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "pt",
                  "acronym" : "UNIFEI",
                  "name" : "Universidade Federal de Itajubá",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "country" : "br",
            "country_phrases" : [
               {
                  "value" : "br",
                  "language" : "en",
                  "phrase" : "Brazil"
               }
            ],
            "url" : "https://unifei.edu.br",
            "location" : {
               "longitude" : -45.4494,
               "latitude" : -22.4127
            }
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7044",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 7044,
            "date_created" : "2019-09-28 02:36:34",
            "date_modified" : "2019-11-13 09:18:47",
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "16"
            ],
            "url" : "https://repositorio.unifei.edu.br",
            "oai_url" : "https://repositorio.unifei.edu.br/oai/request",
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "dspace",
               "version" : "5.3",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "16",
                  "phrase" : "Mechanical Engineering and Materials"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Federal University of Itajuba. Users may set up RSS feeds to be alerted to new content. The interface is available in English, Portuguese and Spanish.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Portuguese",
                  "value" : "pt",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "name" : "UNIFEI Institutional Repository",
                  "acronym" : "RIUNIFEI"
               },
               {
                  "language" : "pt",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "phrase" : "Portuguese",
                        "language" : "en",
                        "value" : "pt"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ],
                  "name" : "Repositório Institucional da UNIFEI",
                  "acronym" : "RIUNIFEI"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ]
         }
      },
      {
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://dados.rcaap.pt",
            "oai_url" : "http://dados.rcaap.pt/oai/openaire",
            "content_languages" : [
               "pt"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.2",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "dspace",
                     "phrase" : "DSpace"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the RCAAP. Users may set up RSS feeds to be alerted to new content. The interface is available in English and Portuguese.",
            "content_languages_phrases" : [
               {
                  "value" : "pt",
                  "language" : "en",
                  "phrase" : "Portuguese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               },
               {
                  "phrase" : "Datasets",
                  "value" : "datasets",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language" : "pt",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "pt",
                        "phrase" : "Portuguese"
                     }
                  ],
                  "name" : "Repositório Dados Científicos"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "datasets"
            ]
         },
         "organisation" : {
            "country" : "pt",
            "url" : "https://www.rcaap.pt",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "pt",
                  "phrase" : "Portugal"
               }
            ],
            "name" : [
               {
                  "acronym" : "RCAAP",
                  "name" : "Repositorios Cientificas de Accesso Aberto de Portugal",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ],
                  "preferred" : "acronym"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:36:25",
            "date_modified" : "2019-11-19 13:32:52",
            "id" : 7042,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7042",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "learning_objects",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "learning_objects"
            ],
            "name" : [
               {
                  "name" : "Research Commons Kutztown University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "oai_url" : "https://research.library.kutztown.edu/do/oai/",
            "url" : "https://research.library.kutztown.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "description" : "This site allows access to the research output of Kutztown University. Users may set up RSS feeds to be notified of new content. Interface and text are in English.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "value" : "bepress",
                     "language" : "en",
                     "phrase" : "Bepress"
                  }
               ]
            }
         },
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Kutztown University of Pennsylvania"
               }
            ],
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.kutztown.edu/",
            "location" : {
               "latitude" : 40.5099,
               "longitude" : -75.7831
            },
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7034",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 7034,
            "date_modified" : "2019-11-15 13:19:43",
            "date_created" : "2019-09-28 02:36:06",
            "publicly_visible" : "yes"
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7033",
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-21 13:44:09",
            "date_created" : "2019-09-28 02:36:03",
            "id" : 7033
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "url" : "http://www.leeds.ac.uk/",
            "location" : {
               "latitude" : 53.8063,
               "longitude" : -1.555
            },
            "country" : "gb",
            "name" : [
               {
                  "name" : "University of Leeds",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "datasets"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Research Data Leeds Repository (University of Leeds)"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site allows access to the research data from studies carried out at Leeds university. The interface and contents are in English only.",
            "software" : {
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://archive.researchdata.leeds.ac.uk/cgi/oai2",
            "url" : "http://archive.researchdata.leeds.ac.uk",
            "content_subjects" : [
               "1"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "ResearchOnline @JCU"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "oai_url" : "https://researchonline.jcu.edu.au/cgi/oai2",
            "url" : "https://researchonline.jcu.edu.au",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "3.3.15",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "eprints",
                     "phrase" : "EPrints"
                  }
               ]
            },
            "description" : "This site provides access to the research outputs of the James Cook University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.jcu.edu.au",
            "location" : {
               "longitude" : 146.758,
               "latitude" : -19.3277
            },
            "country_phrases" : [
               {
                  "phrase" : "Australia",
                  "value" : "au",
                  "language" : "en"
               }
            ],
            "country" : "au",
            "name" : [
               {
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "James Cook University",
                  "acronym" : "JCU",
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "value" : "name",
                        "language" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-19 12:34:37",
            "date_created" : "2019-09-28 02:35:46",
            "id" : 7027,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/7027",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "date_created" : "2019-09-28 02:27:40",
            "date_modified" : "2019-11-19 12:25:14",
            "id" : 6892,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6892",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Rhode Island School of Design"
               }
            ],
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "location" : {
               "latitude" : 41.8258,
               "longitude" : -71.4079
            },
            "url" : "https://www.risd.edu",
            "country" : "us"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "content_languages" : [
               "en"
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "metadata_record_count" : 18845,
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Digital Commons @ RISD"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://digitalcommons.risd.edu",
            "oai_url" : "http://digitalcommons.risd.edu/do/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Rhode Island School of Design. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            }
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Rissho University's Institutional Repository (Rissho-IR)"
               },
               {
                  "name" : "立正大学学術機関リポジトリ",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "oai_url" : "http://repository.ris.ac.jp/dspace-oai/request",
            "url" : "http://repository.ris.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "description" : "This site allows access to the research output of Rissho University. The interface is in a mix of Japanese and English but all text are in Japanese.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "value" : "dspace",
                     "language" : "en"
                  }
               ],
               "name" : "dspace"
            }
         },
         "system_metadata" : {
            "id" : 6884,
            "date_created" : "2019-09-28 02:27:04",
            "date_modified" : "2019-11-15 12:57:47",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6884",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "country" : "jp",
            "url" : "http://www.ris.ac.jp/en/",
            "location" : {
               "latitude" : 35.6205,
               "longitude" : 139.723
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Rissho University"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "name" : "立正大学"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Rollins College: Rollins Scholarship Online (RSO)"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "description" : "This site allows access to the research output and special collections of Rollins College. Users may set up RSS feeds to be alerted as to new submissions, interface and content are in English only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "content_subjects" : [
               "1"
            ],
            "url" : "https://scholarship.rollins.edu",
            "oai_url" : "https://scholarship.rollins.edu/do/oai/",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "organisation" : {
            "url" : "https://www.rollins.edu/",
            "location" : {
               "latitude" : 28.5922,
               "longitude" : -81.3483
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Rollins college"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6878",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "id" : 6878,
            "date_created" : "2019-09-28 02:26:30",
            "date_modified" : "2019-12-02 09:39:03",
            "publicly_visible" : "yes"
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Rollins College"
               }
            ],
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ],
            "url" : "https://www.rollins.edu",
            "unit" : [
               {
                  "name" : "Olin Library",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -81.3483,
               "latitude" : 28.5914
            },
            "country" : "us"
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6877",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_modified" : "2019-12-04 12:27:39",
            "date_created" : "2019-09-28 02:26:28",
            "id" : 6877,
            "publicly_visible" : "yes"
         },
         "repository_metadata" : {
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "contentdm",
                     "phrase" : "CONTENTdm"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the historical materials in the Olin Library. Users may set up RSS feeds to be alerted to new content. The interface is available in English, German, Spanish, Korean, Chinese, Dutch, French, Catalan, Japanese and Thai.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "oai_url" : "https://cdm16496.contentdm.oclc.org/oai/oai.php",
            "url" : "https://cdm16496.contentdm.oclc.org",
            "content_subjects" : [
               "1"
            ],
            "name" : [
               {
                  "name" : "Rollins Digital Collections",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ],
            "content_types" : [
               "other_special_item_types"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "phrase" : "Datasets",
                  "language" : "en",
                  "value" : "datasets"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "type" : "governmental",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "datasets",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "preferred" : "acronym",
                  "language" : "en",
                  "acronym" : "rosap",
                  "name" : "National Transportation Library Repository and Open Access Portal",
                  "preferred_phrases" : [
                     {
                        "value" : "acronym",
                        "language" : "en",
                        "phrase" : "Acronym"
                     }
                  ]
               }
            ],
            "url" : "https://rosap.ntl.bts.gov",
            "oai_url" : "https://rosap.ntl.bts.gov/fedora/oai",
            "content_subjects" : [
               "23",
               "11"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site provides access to the research outputs of the United States Department of Transportation. The interface is available in English.",
            "type_phrases" : [
               {
                  "value" : "governmental",
                  "language" : "en",
                  "phrase" : "Governmental"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               },
               {
                  "phrase" : "Technology General",
                  "language" : "en",
                  "value" : "11"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : []
            }
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6873",
            "publicly_visible" : "yes",
            "id" : 6873,
            "date_modified" : "2019-12-02 11:28:37",
            "date_created" : "2019-09-28 02:26:22"
         },
         "organisation" : {
            "url" : "https://www.transportation.gov",
            "unit" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "National Transportation Library"
               }
            ],
            "location" : {
               "latitude" : 38.8758,
               "longitude" : -77.0029
            },
            "name" : [
               {
                  "name" : "United States Department of Transportation",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_languages" : [
               "zh",
               "en",
               "fr",
               "oc",
               "es"
            ],
            "content_subjects" : [
               "18"
            ],
            "url" : "https://rosalis.bibliotheque.toulouse.fr",
            "oai_url" : "https://rosalis.bibliotheque.toulouse.fr/cgi-bin/hub-oaiserver",
            "repository_status_phrases" : [
               {
                  "phrase" : "Undetermined",
                  "value" : "undetermined",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Fine and Performing Arts",
                  "language" : "en",
                  "value" : "18"
               }
            ],
            "description" : "This site allows access to digitized heritage collections of illuminated manuscripts, printed books, journals, photographs, maps, scores and sound recordings held at the library. The site is predominantly French and attempting to translate does raise issues with the collection search function.",
            "software" : {
               "version" : "4.9.6",
               "name_other" : "WordPress",
               "name_phrases" : []
            },
            "repository_status" : "undetermined",
            "content_languages_phrases" : [
               {
                  "phrase" : "Chinese",
                  "value" : "zh",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               },
               {
                  "value" : "fr",
                  "language" : "en",
                  "phrase" : "French"
               },
               {
                  "value" : "oc",
                  "language" : "en",
                  "phrase" : "Occitan"
               },
               {
                  "phrase" : "Spanish",
                  "value" : "es",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Learning Objects",
                  "language" : "en",
                  "value" : "learning_objects"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "learning_objects",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Rosalis - Tolouse Digital Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "Rosalis - Bibliothèque numérique de Tolouse",
                  "language_phrases" : [
                     {
                        "value" : "fr",
                        "language" : "en",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6872",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-04 12:27:39",
            "date_created" : "2019-09-28 02:26:21",
            "id" : 6872
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "France",
                  "value" : "fr",
                  "language" : "en"
               }
            ],
            "country" : "fr",
            "name" : [
               {
                  "name" : "Municipal Library of Toulouse",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               },
               {
                  "language" : "fr",
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "language" : "en",
                        "value" : "fr"
                     }
                  ],
                  "name" : "la Bibliothèque municipale de Toulouse"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Rose-Hulman Institute of Technolgy"
               }
            ],
            "country" : "us",
            "location" : {
               "longitude" : -87.3241,
               "latitude" : 39.4825
            },
            "url" : "https://www.rose-hulman.edu",
            "country_phrases" : [
               {
                  "value" : "us",
                  "language" : "en",
                  "phrase" : "United States of America"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-18 12:27:12",
            "date_created" : "2019-09-28 02:26:20",
            "id" : 6871,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6871",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               },
               {
                  "phrase" : "Other Special Item Types",
                  "value" : "other_special_item_types",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "name" : [
               {
                  "name" : "Rose-Hulman Scholar",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://scholar.rose-hulman.edu",
            "content_subjects" : [
               "11"
            ],
            "oai_url" : "https://scholar.rose-hulman.edu/do/oai",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "11",
                  "phrase" : "Technology General"
               }
            ],
            "description" : "This site provides access to the research outputs of the Rose-Hulman Institute of Technology. Users may set up RSS feeds to be alerted to new content. The interface is available in English."
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6870",
            "publicly_visible" : "yes",
            "date_modified" : "2019-10-29 14:21:42",
            "date_created" : "2019-09-28 02:26:17",
            "id" : 6870
         },
         "organisation" : {
            "url" : "https://www.rau.ac.uk",
            "location" : {
               "latitude" : 51.71,
               "longitude" : -1.995
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "gb",
                  "phrase" : "United Kingdom"
               }
            ],
            "country" : "gb",
            "name" : [
               {
                  "preferred" : "name",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "preferred_phrases" : [
                     {
                        "phrase" : "Name",
                        "language" : "en",
                        "value" : "name"
                     }
                  ],
                  "name" : "Royal Agricultural University",
                  "acronym" : "RAU"
               }
            ]
         },
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "name",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "RAU",
                  "name" : "Royal Agricultural University Repository"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "phrase" : "Conference and Workshop Papers",
                  "language" : "en",
                  "value" : "conference_and_workshop_papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "3",
                  "language" : "en",
                  "phrase" : "Agriculture, Food and Veterinary"
               },
               {
                  "phrase" : "Business and Economics",
                  "language" : "en",
                  "value" : "24"
               },
               {
                  "value" : "28",
                  "language" : "en",
                  "phrase" : "Management and Planning"
               }
            ],
            "description" : "This site provides access to the research outputs of the Royal Agricultural University in Cirencester, UK, including peer reviewed research papers  written by staff and PhD students of the institution. Users may set up RSS feeds to be alerted to new content. The interface is available in English.\r\nThe site is also part of the aggregated GuildHE Research Repositories (formerly CREST).",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "software" : {
               "version" : "3.3.16",
               "name" : "eprints",
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "value" : "eprints",
                     "language" : "en"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "url" : "https://rau.repository.guildhe.ac.uk",
            "content_subjects" : [
               "3",
               "24",
               "28"
            ],
            "oai_url" : "http://rau.repository.guildhe.ac.uk/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "description" : "This site allows access to a limited number of current research papers from NHS staff. The interface and articles are only available in English.",
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ],
               "name" : "dspace",
               "version" : "6.3"
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "en"
            ],
            "url" : "https://rde.openrepository.com",
            "oai_url" : "https://rde.openrepository.com/rde/oai/openaire",
            "content_subjects" : [
               "10"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Royal Devon and Exeter Research Repository"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "value" : "en",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-11-15 12:47:03",
            "date_created" : "2019-09-28 02:26:16",
            "id" : 6869,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6869",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "United Kingdom",
                  "language" : "en",
                  "value" : "gb"
               }
            ],
            "location" : {
               "longitude" : -3.5101,
               "latitude" : 50.7165
            },
            "url" : "https://exeterhealthlibrary.net/",
            "country" : "gb",
            "name" : [
               {
                  "name" : "Exeter Health Library",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "https://www.rku.ac.jp/global/en/",
            "location" : {
               "longitude" : 140.19,
               "latitude" : 35.9157
            },
            "country" : "jp",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Ryutsu Keizai University",
                  "acronym" : "RKU"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "流通経済大学"
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:25:43",
            "date_modified" : "2019-11-11 11:41:27",
            "id" : 6857,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6857",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://rku.repo.nii.ac.jp/oai",
            "url" : "https://rku.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of Ryutsu Keizai University. The interface is available in Japanese or English however the majority of text are Japanese only.",
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ],
               "name" : "weko"
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "RKU",
                  "name" : "Ryutsu Keizai University (RKU) Repository"
               },
               {
                  "name" : "流通経済大学学術情報リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Canada",
                  "value" : "ca",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -71.0526,
               "latitude" : 48.419
            },
            "url" : "https://www.uqac.ca",
            "country" : "ca",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Université du Québec à Chicoutimi"
               },
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "fr",
                        "phrase" : "French"
                     }
                  ],
                  "language" : "fr",
                  "preferred" : "acronym",
                  "preferred_phrases" : [
                     {
                        "language" : "en",
                        "value" : "acronym",
                        "phrase" : "Acronym"
                     }
                  ],
                  "acronym" : "UQAC",
                  "name" : "Université du Québec à Chicoutimi"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6852",
            "publicly_visible" : "yes",
            "date_modified" : "2019-12-06 15:44:11",
            "date_created" : "2019-09-28 02:25:16",
            "id" : 6852
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "French",
                  "language" : "en",
                  "value" : "fr"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "value" : "books_chapters_and_sections",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "acronym" : "SDEIR",
                  "name" : "Service de documentation en etudes et interventions regionales",
                  "language_phrases" : [
                     {
                        "phrase" : "French",
                        "value" : "fr",
                        "language" : "en"
                     }
                  ],
                  "preferred" : "name",
                  "language" : "fr"
               }
            ],
            "content_languages" : [
               "fr"
            ],
            "url" : "https://e-sdeir.uqac.ca",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://e-sdeir.uqac.ca/cgi/oai2",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of University of Quebecat Chicoutimi. Users may set up RSS feeds to be alerted to new content. The interface is available in French and English.",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "EPrints",
                     "language" : "en",
                     "value" : "eprints"
                  }
               ],
               "name" : "eprints",
               "version" : "3.3.15"
            },
            "repository_status" : "fully_functional"
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "journal_articles",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "SEISA University Repository"
               },
               {
                  "name" : "星槎大学 リポジトリ",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://seisa.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://seisa.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the SEISA University. The interface is available in Japanese and English."
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:25:09",
            "date_modified" : "2019-11-12 16:13:05",
            "id" : 6849,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6849",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Hosei University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "url" : "https://www.hosei.ac.jp",
            "location" : {
               "longitude" : 139.741,
               "latitude" : 35.6955
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 6836,
            "date_created" : "2019-09-28 02:24:06",
            "date_modified" : "2019-12-04 08:32:43",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6836",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Universitas Muhammadiyah Metro",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "url" : "https://perpustakaan.ummetro.ac.id/",
            "location" : {
               "longitude" : 105.33,
               "latitude" : -5.1204
            },
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesia"
               }
            ],
            "country" : "id"
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "id",
                  "phrase" : "Indonesian"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "books_chapters_and_sections"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Senayan Library Management System Repository"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "http://lib.ummetro.ac.id",
            "oai_url" : "http://lib.ummetro.ac.id/oai.php",
            "content_languages" : [
               "id"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the student research papers and certain books from Senayan Library. The interface is available in a number of languages but content is Indonesian.",
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "other",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "other",
                     "phrase" : "Other"
                  }
               ],
               "name_other" : "SLiMS"
            }
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Soai University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "https://www.soai.ac.jp",
            "location" : {
               "latitude" : 34.6346,
               "longitude" : 135.428
            }
         },
         "system_metadata" : {
            "id" : 6832,
            "date_modified" : "2019-11-19 12:11:23",
            "date_created" : "2019-09-28 02:23:47",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6832",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "ja",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               }
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "SOAI Open Access Repository of Archives)",
                  "acronym" : "SOARA"
               },
               {
                  "name" : "相愛大学リポジトリ",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://soai.repo.nii.ac.jp",
            "oai_url" : "https://soai.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site provides access to the research outputs of the Soai University. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "url" : "http://www.sozo.ac.jp",
            "country" : "jp",
            "name" : [
               {
                  "name" : "Toyohashi Sozo University"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6830",
            "publicly_visible" : "yes",
            "date_created" : "2019-09-28 02:23:24",
            "date_modified" : "2019-11-05 16:21:44",
            "id" : 6830
         },
         "repository_metadata" : {
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "1"
            ],
            "url" : "https://sozo-air.repo.nii.ac.jp",
            "oai_url" : "https://sozo-air.repo.nii.ac.jp/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "language" : "en",
                  "value" : "fully_functional"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "language" : "en",
                  "value" : "1"
               }
            ],
            "description" : "This site provides access to the research outputs of the Toyohashi Sozo University. The interface is available in English and Japanese",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "phrase" : "Unpublished Reports and Working Papers",
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en"
               }
            ],
            "content_types" : [
               "journal_articles",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "SOZO Academic Information Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "name" : "豊橋創造大学学術情報リポジトリ",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "SUNY Geneseo KnightScholar (State University of New York)"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "unpub_reports_and_working_papers",
               "books_chapters_and_sections",
               "learning_objects"
            ],
            "content_types_phrases" : [
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "books_chapters_and_sections",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "learning_objects",
                  "language" : "en",
                  "phrase" : "Learning Objects"
               }
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site allows access to the research output and special collections of the State University of New York. Users may set up RSS feeds to be alerted to new submissions. Both interface and content are English only.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://knightscholar.geneseo.edu/do/oai/",
            "url" : "https://knightscholar.geneseo.edu",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6818",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_created" : "2019-09-28 02:21:57",
            "date_modified" : "2019-12-02 09:23:08",
            "id" : 6818,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "us",
                  "phrase" : "United States of America"
               }
            ],
            "location" : {
               "latitude" : 42.6479,
               "longitude" : -73.7495
            },
            "url" : "https://www.suny.edu/",
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "State University of New York"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6816",
            "publicly_visible" : "yes",
            "id" : 6816,
            "date_created" : "2019-09-28 02:21:49",
            "date_modified" : "2019-11-26 10:36:00"
         },
         "organisation" : {
            "url" : "https://www.swosu.edu",
            "location" : {
               "latitude" : 36.4735,
               "longitude" : -101.93
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "acronym" : "SWOSU",
                  "name" : "Southwestern Oklahoma State University"
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "value" : "bepress",
                     "language" : "en"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Southwestern Oklahoma State University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "url" : "https://dc.swosu.edu",
            "oai_url" : "https://dc.swosu.edu/do/oai",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "SWOSU Digital Commons"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "books_chapters_and_sections"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Books, Chapters and Sections",
                  "language" : "en",
                  "value" : "books_chapters_and_sections"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               }
            ]
         }
      },
      {
         "organisation" : {
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "url" : "http://www.saijo.ac.jp/",
            "location" : {
               "latitude" : 35.8952,
               "longitude" : 139.359
            },
            "name" : [
               {
                  "name" : "Saitama Women's Junior College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ],
                  "language" : "ja",
                  "name" : "埼玉女子短期大学"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6809",
            "publicly_visible" : "yes",
            "id" : 6809,
            "date_created" : "2019-09-28 02:21:34",
            "date_modified" : "2019-11-15 12:31:37"
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Saijo Academic Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "埼玉女子短期大学学術情報リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "content_subjects_phrases" : [
               {
                  "language" : "en",
                  "value" : "1",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site gives access to the research output of Saitama Women's Junior College. The interface is available in Japanese or English but all texts are in Japanese.",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "oai_url" : "https://saijo.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://saijo.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Saint Louis University"
               }
            ],
            "url" : "http://www.slu.edu/",
            "unit" : [
               {
                  "name" : "Saint Louis University library"
               }
            ],
            "location" : {
               "longitude" : -90.2341,
               "latitude" : 38.6343
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "country" : "us"
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:21:21",
            "date_modified" : "2019-11-21 11:50:31",
            "id" : 6808,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6808",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ]
         },
         "repository_metadata" : {
            "content_languages" : [
               "en"
            ],
            "oai_url" : "http://cdm.slu.edu/oai/oai.php",
            "url" : "http://cdm.slu.edu",
            "content_subjects" : [
               "19",
               "20"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "description" : "This site allows access to the special collections and historical text made available at the Saint Louis University Libraries. The interface and text are  in English only.",
            "content_subjects_phrases" : [
               {
                  "value" : "19",
                  "language" : "en",
                  "phrase" : "Geography and Regional Studies"
               },
               {
                  "phrase" : "History and Archaeology",
                  "language" : "en",
                  "value" : "20"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "software" : {
               "name" : "contentdm",
               "name_phrases" : [
                  {
                     "phrase" : "CONTENTdm",
                     "language" : "en",
                     "value" : "contentdm"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_types_phrases" : [
               {
                  "value" : "books_chapters_and_sections",
                  "language" : "en",
                  "phrase" : "Books, Chapters and Sections"
               },
               {
                  "value" : "other_special_item_types",
                  "language" : "en",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types" : [
               "books_chapters_and_sections",
               "other_special_item_types"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "name" : "Saint Louis University Libraries Digital Collections"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "bepress",
                     "phrase" : "Bepress"
                  }
               ],
               "name" : "bepress"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Law and Politics",
                  "language" : "en",
                  "value" : "26"
               }
            ],
            "description" : "This site provides access to the research outputs of Saint Louis University School of Law.  Users may set up RSS feeds to be alerted to new content.  The interface is available in English",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "en"
            ],
            "url" : "https://scholarship.law.slu.edu",
            "oai_url" : "https://scholarship.law.slu.edu/do/oai",
            "content_subjects" : [
               "26"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Scholarship Commons"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ]
         },
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6807",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "date_modified" : "2019-12-06 15:28:30",
            "date_created" : "2019-09-28 02:21:18",
            "id" : 6807,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "value" : "us",
                  "language" : "en"
               }
            ],
            "location" : {
               "longitude" : -90.237,
               "latitude" : 38.6376
            },
            "url" : "https://scholarship.law.slu.edu",
            "name" : [
               {
                  "name" : "Saint Louis University School of Law",
                  "preferred_phrases" : [
                     {
                        "value" : "name",
                        "language" : "en",
                        "phrase" : "Name"
                     }
                  ],
                  "language" : "en",
                  "preferred" : "name",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "id" : 6806,
            "date_modified" : "2019-12-03 16:06:51",
            "date_created" : "2019-09-28 02:21:16",
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6806",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "location" : {
               "latitude" : 44.6316,
               "longitude" : -63.5822
            },
            "url" : "https://smu.ca/",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "ca",
                  "phrase" : "Canada"
               }
            ],
            "country" : "ca",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Saint Mary's University"
               }
            ]
         },
         "repository_metadata" : {
            "description" : "This site allows access to the research output of Saint Mary's University, Halifax. Both interface and content are in English only.",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "version" : "5.5",
               "name" : "dspace",
               "name_phrases" : [
                  {
                     "phrase" : "DSpace",
                     "language" : "en",
                     "value" : "dspace"
                  }
               ]
            },
            "oai_url" : "http://library2.smu.ca/oai/openaire",
            "content_subjects" : [
               "1"
            ],
            "url" : "http://library2.smu.ca",
            "content_languages" : [
               "en"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "name" : "Saint Mary's University, Halifax: Institutional Repository",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "en",
                  "language" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "conference_and_workshop_papers",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "organisation" : {
            "name" : [
               {
                  "name" : "Saitama Gakuen University",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "name" : "埼玉学園大学",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja"
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "language" : "en",
                  "value" : "jp",
                  "phrase" : "Japan"
               }
            ],
            "url" : "http://www.saigaku.ac.jp/",
            "location" : {
               "longitude" : 139.714,
               "latitude" : 35.8573
            }
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 6805,
            "date_modified" : "2019-11-26 14:16:16",
            "date_created" : "2019-09-28 02:21:10",
            "publicly_visible_phrases" : [
               {
                  "value" : "yes",
                  "language" : "en",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6805"
         },
         "repository_metadata" : {
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "url" : "https://saigaku.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://saigaku.repo.nii.ac.jp/oai",
            "software" : {
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "description" : "This site gives access to the research output of Saitama Gakuen University & Kawaguchi Junior College. The interface is in English or Japanese but all content is Japanese only.",
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "value" : "unpub_reports_and_working_papers",
                  "language" : "en",
                  "phrase" : "Unpublished Reports and Working Papers"
               }
            ],
            "name" : [
               {
                  "name" : "Saitama Gakuen University & Kawaguchi Junior College: Academic Repository",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "埼玉学園大学・川口短期大学機関リポジトリ"
               }
            ],
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "unpub_reports_and_working_papers"
            ],
            "type" : "institutional"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6804",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 02:21:05",
            "date_modified" : "2019-11-12 15:48:31",
            "id" : 6804,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "location" : {
               "latitude" : 35.8698,
               "longitude" : 139.78
            },
            "url" : "http://www.saitamatoho.jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "name" : "Saitama Toho Junior College",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ],
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles"
            ],
            "name" : [
               {
                  "name" : "Saitama Toho Junior College Academic Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "name" : "埼玉東萌短期大学学術機関リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "description" : "This site provides access to the research outputs of the Saitama Toho Junior College. The interface is available in English and Japanese.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Arts and Humanities General",
                  "language" : "en",
                  "value" : "17"
               },
               {
                  "phrase" : "Social Sciences General",
                  "value" : "23",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "value" : "weko",
                     "language" : "en"
                  }
               ],
               "name" : "weko"
            },
            "url" : "https://saitamatoho.repo.nii.ac.jp",
            "content_subjects" : [
               "17",
               "23"
            ],
            "oai_url" : "https://saitamatoho.repo.nii.ac.jp/oai",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Saku University Institutional Repository"
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "佐久大学機関リポジトリ"
               }
            ],
            "content_types" : [
               "journal_articles",
               "conference_and_workshop_papers",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               },
               {
                  "value" : "conference_and_workshop_papers",
                  "language" : "en",
                  "phrase" : "Conference and Workshop Papers"
               },
               {
                  "value" : "theses_and_dissertations",
                  "language" : "en",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "description" : "This site allows access to the research output of Saku University. The interface is available in English or Japanese, all content is Japanese only.",
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "oai_url" : "https://saku.repo.nii.ac.jp/oai",
            "url" : "https://saku.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-02 09:06:50",
            "date_created" : "2019-09-28 02:21:01",
            "id" : 6803,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6803",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ]
         },
         "organisation" : {
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Saku university"
               },
               {
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ],
                  "language" : "ja",
                  "name" : "佐久大学"
               }
            ],
            "country" : "jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "url" : "https://www.saku.ac.jp/",
            "location" : {
               "latitude" : 36.2659,
               "longitude" : 138.463
            }
         }
      },
      {
         "repository_metadata" : {
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "language" : "en",
                  "value" : "journal_articles"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "name" : "Sakura no Seibo Junior College Institutional Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "ja",
                        "phrase" : "Japanese"
                     }
                  ],
                  "name" : "桜の聖母短期大学学術機関リポジトリ"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "23"
            ],
            "url" : "https://sakuranoseibo.repo.nii.ac.jp",
            "oai_url" : "https://sakuranoseibo.repo.nii.ac.jp/oai",
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "language" : "en",
                  "value" : "institutional"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Social Sciences General",
                  "language" : "en",
                  "value" : "23"
               }
            ],
            "description" : "This site provides access to the research outputs of the Sakura no Seibo Junior College. The interface is available in English and Japanese.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional"
         },
         "organisation" : {
            "location" : {
               "longitude" : 140.473,
               "latitude" : 37.763
            },
            "url" : "https://www.sakuranoseibo.jp",
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "name" : "Sakura no Seibo Junior College",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_created" : "2019-09-28 02:20:59",
            "date_modified" : "2019-11-19 11:54:05",
            "id" : 6802,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6802",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ]
         }
      },
      {
         "repository_metadata" : {
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations"
            ],
            "type" : "institutional",
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en",
                  "name" : "Sakushin University Academic Repository / 作新学院大学学術機関リポジトリ"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               }
            ],
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "description" : "This site provides access to the research outputs of the Sakushin University. The interface is available in English and Japanese.",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "language" : "en",
                     "value" : "weko",
                     "phrase" : "WEKO"
                  }
               ]
            },
            "repository_status" : "fully_functional",
            "content_languages" : [
               "ja"
            ],
            "url" : "https://sakushin-u.repo.nii.ac.jp",
            "oai_url" : "https://sakushin-u.repo.nii.ac.jp/oai",
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         },
         "system_metadata" : {
            "publicly_visible" : "yes",
            "id" : 6801,
            "date_modified" : "2019-11-26 10:27:11",
            "date_created" : "2019-09-28 02:20:56",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "language" : "en",
                  "value" : "yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6801"
         },
         "organisation" : {
            "country_phrases" : [
               {
                  "value" : "jp",
                  "language" : "en",
                  "phrase" : "Japan"
               }
            ],
            "location" : {
               "latitude" : 36.5427,
               "longitude" : 139.977
            },
            "url" : "https://www.sakushin-u.ac.jp",
            "country" : "jp",
            "name" : [
               {
                  "name" : "Sakushin University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "name" : "作新学院大学"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6800",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ],
            "date_created" : "2019-09-28 02:20:54",
            "date_modified" : "2019-11-05 16:06:48",
            "id" : 6800,
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "country" : "us",
            "url" : "https://www.salemstate.edu",
            "location" : {
               "latitude" : 42.5031,
               "longitude" : 70.8926
            },
            "country_phrases" : [
               {
                  "phrase" : "United States of America",
                  "language" : "en",
                  "value" : "us"
               }
            ],
            "name" : [
               {
                  "name" : "Salem State University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "bepress",
               "name_phrases" : [
                  {
                     "phrase" : "Bepress",
                     "language" : "en",
                     "value" : "bepress"
                  }
               ]
            },
            "type_phrases" : [
               {
                  "phrase" : "Institutional",
                  "value" : "institutional",
                  "language" : "en"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "value" : "1",
                  "language" : "en",
                  "phrase" : "Multidisciplinary"
               }
            ],
            "description" : "This site provides access to the research outputs of the Salem State University. Users may set up RSS feeds to be alerted to new content. The interface is available in English.",
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_subjects" : [
               "1"
            ],
            "oai_url" : "https://digitalcommons.salemstate.edu/do/oai",
            "url" : "https://digitalcommons.salemstate.edu",
            "content_languages" : [
               "en"
            ],
            "name" : [
               {
                  "name" : "Digital Commons at Salem State University",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ]
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "theses_and_dissertations",
               "unpub_reports_and_working_papers",
               "other_special_item_types"
            ],
            "content_languages_phrases" : [
               {
                  "language" : "en",
                  "value" : "en",
                  "phrase" : "English"
               }
            ],
            "content_types_phrases" : [
               {
                  "phrase" : "Theses and Dissertations",
                  "value" : "theses_and_dissertations",
                  "language" : "en"
               },
               {
                  "language" : "en",
                  "value" : "unpub_reports_and_working_papers",
                  "phrase" : "Unpublished Reports and Working Papers"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ]
         }
      },
      {
         "organisation" : {
            "url" : "http://sanotan.jp",
            "location" : {
               "longitude" : 139.605,
               "latitude" : 36.3022
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "language" : "en",
                  "value" : "jp"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "name" : "Sano Nihon University Junior College f"
               },
               {
                  "name" : "佐野日本大学短期大学",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ]
         },
         "system_metadata" : {
            "date_modified" : "2019-12-03 09:59:23",
            "date_created" : "2019-09-28 02:20:50",
            "id" : 6798,
            "publicly_visible" : "yes",
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6798",
            "publicly_visible_phrases" : [
               {
                  "phrase" : "Yes",
                  "value" : "yes",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "name" : [
               {
                  "name" : "Sano Nihon University College Academic Repository",
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "value" : "en",
                        "language" : "en"
                     }
                  ]
               },
               {
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "name" : "佐野短期大学学術リポジトリ"
               }
            ],
            "content_types" : [
               "journal_articles"
            ],
            "type" : "institutional",
            "content_types_phrases" : [
               {
                  "phrase" : "Journal Articles",
                  "value" : "journal_articles",
                  "language" : "en"
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "Japanese",
                  "value" : "ja",
                  "language" : "en"
               }
            ],
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "repository_status" : "fully_functional",
            "type_phrases" : [
               {
                  "language" : "en",
                  "value" : "institutional",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Sano Nihon University College. The interface is available in English and Japanese.",
            "content_subjects_phrases" : [
               {
                  "value" : "10",
                  "language" : "en",
                  "phrase" : "Health and Medicine"
               },
               {
                  "phrase" : "Education",
                  "language" : "en",
                  "value" : "25"
               }
            ],
            "repository_status_phrases" : [
               {
                  "language" : "en",
                  "value" : "fully_functional",
                  "phrase" : "Fully Functional"
               }
            ],
            "content_languages" : [
               "ja"
            ],
            "content_subjects" : [
               "10",
               "25"
            ],
            "oai_url" : "https://sanotan.repo.nii.ac.jp/oai",
            "url" : "https://sanotan.repo.nii.ac.jp"
         }
      },
      {
         "system_metadata" : {
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6796",
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "id" : 6796,
            "date_modified" : "2019-11-01 12:41:09",
            "date_created" : "2019-09-28 02:20:42",
            "publicly_visible" : "yes"
         },
         "organisation" : {
            "name" : [
               {
                  "name" : "Sapporo City University",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "language" : "en"
               },
               {
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "value" : "ja",
                        "language" : "en"
                     }
                  ],
                  "language" : "ja",
                  "name" : "札幌市立大学"
               }
            ],
            "country" : "jp",
            "location" : {
               "latitude" : 42.9448,
               "longitude" : 141.343
            },
            "url" : "https://www.scu.ac.jp",
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ]
         },
         "repository_metadata" : {
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "datasets"
            ],
            "name" : [
               {
                  "language_phrases" : [
                     {
                        "phrase" : "English",
                        "language" : "en",
                        "value" : "en"
                     }
                  ],
                  "language" : "en",
                  "name" : "Sapporo City University Academic Repository"
               },
               {
                  "name" : "札幌市立大学学術機関リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ],
            "content_languages_phrases" : [
               {
                  "phrase" : "English",
                  "language" : "en",
                  "value" : "en"
               },
               {
                  "phrase" : "Japanese",
                  "language" : "en",
                  "value" : "ja"
               }
            ],
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "phrase" : "Theses and Dissertations",
                  "language" : "en",
                  "value" : "theses_and_dissertations"
               },
               {
                  "language" : "en",
                  "value" : "datasets",
                  "phrase" : "Datasets"
               }
            ],
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site provides access to the research outputs of the Sapporo City University. The interface is available in English and Japanese.",
            "repository_status" : "fully_functional",
            "software" : {
               "name" : "weko",
               "name_phrases" : [
                  {
                     "phrase" : "WEKO",
                     "language" : "en",
                     "value" : "weko"
                  }
               ]
            },
            "oai_url" : "https://scu.repo.nii.ac.jp/oai",
            "url" : "https://scu.repo.nii.ac.jp",
            "content_subjects" : [
               "1"
            ],
            "content_languages" : [
               "en",
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "value" : "fully_functional",
                  "language" : "en",
                  "phrase" : "Fully Functional"
               }
            ]
         }
      },
      {
         "system_metadata" : {
            "publicly_visible" : "yes",
            "date_modified" : "2019-11-15 11:56:47",
            "date_created" : "2019-09-28 02:20:37",
            "id" : 6794,
            "publicly_visible_phrases" : [
               {
                  "language" : "en",
                  "value" : "yes",
                  "phrase" : "Yes"
               }
            ],
            "uri" : "http://v2.sherpa.ac.uk/id/repository/6794"
         },
         "organisation" : {
            "url" : "https://www.sapporo-u.ac.jp/",
            "location" : {
               "longitude" : 141.384,
               "latitude" : 43.0107
            },
            "country_phrases" : [
               {
                  "phrase" : "Japan",
                  "value" : "jp",
                  "language" : "en"
               }
            ],
            "country" : "jp",
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "value" : "en",
                        "language" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Sapporo University, Hokkaido"
               },
               {
                  "name" : "札幌大学、北海道",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "phrase" : "Japanese",
                        "language" : "en",
                        "value" : "ja"
                     }
                  ]
               }
            ]
         },
         "repository_metadata" : {
            "oai_url" : "https://sapporo-u.repo.nii.ac.jp/oai",
            "content_subjects" : [
               "1"
            ],
            "url" : "https://sapporo-u.repo.nii.ac.jp",
            "content_languages" : [
               "ja"
            ],
            "repository_status_phrases" : [
               {
                  "phrase" : "Fully Functional",
                  "value" : "fully_functional",
                  "language" : "en"
               }
            ],
            "type_phrases" : [
               {
                  "value" : "institutional",
                  "language" : "en",
                  "phrase" : "Institutional"
               }
            ],
            "description" : "This site allows access to the research output of Sapporo University, Hokkaido. The interface is available in English or Japanese but all text is Japanese only.",
            "content_subjects_phrases" : [
               {
                  "phrase" : "Multidisciplinary",
                  "value" : "1",
                  "language" : "en"
               }
            ],
            "repository_status" : "fully_functional",
            "software" : {
               "name_phrases" : [
                  {
                     "value" : "weko",
                     "language" : "en",
                     "phrase" : "WEKO"
                  }
               ],
               "name" : "weko"
            },
            "content_types_phrases" : [
               {
                  "value" : "journal_articles",
                  "language" : "en",
                  "phrase" : "Journal Articles"
               },
               {
                  "language" : "en",
                  "value" : "theses_and_dissertations",
                  "phrase" : "Theses and Dissertations"
               },
               {
                  "language" : "en",
                  "value" : "other_special_item_types",
                  "phrase" : "Other Special Item Types"
               }
            ],
            "content_languages_phrases" : [
               {
                  "value" : "ja",
                  "language" : "en",
                  "phrase" : "Japanese"
               }
            ],
            "type" : "institutional",
            "content_types" : [
               "journal_articles",
               "theses_and_dissertations",
               "other_special_item_types"
            ],
            "name" : [
               {
                  "language" : "en",
                  "language_phrases" : [
                     {
                        "language" : "en",
                        "value" : "en",
                        "phrase" : "English"
                     }
                  ],
                  "name" : "Sapporo University Academic Repository"
               },
               {
                  "name" : "札幌大学学術情報リポジトリ",
                  "language" : "ja",
                  "language_phrases" : [
                     {
                        "value" : "ja",
                        "language" : "en",
                        "phrase" : "Japanese"
                     }
                  ]
               }
            ]
         }
      }
   ]
}

